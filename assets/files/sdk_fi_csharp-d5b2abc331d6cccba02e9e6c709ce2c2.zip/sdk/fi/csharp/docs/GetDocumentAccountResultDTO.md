# It.TSEnterprise.Sdk.Model.GetDocumentAccountResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionResult** | **bool** |  | [optional] 
**IdaccountCg24** | **long** |  | [optional] 
**Suddconti** | **double** |  | [optional] 
**Idreverse** | **int** |  | [optional] 
**Conto** | **string** |  | [optional] 
**CodeFormatted** | **string** |  | [optional] 
**ContoDescr** | **string** |  | [optional] 
**VatTypeCode** | **double?** |  | [optional] 
**VatTypeDescr** | **string** |  | [optional] 
**ReversTypeCode** | **int?** |  | [optional] 
**ReversTypeDescr** | **string** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

