# It.TSEnterprise.Sdk.Model.FilesFepaPassCODTO
IE83_FILESFEPAPASS - FilesFepaPassCO<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Batchid** | **string** | IE83_BATCHID - Batchid | [optional] 
**CedprestCodFisc** | **string** | IE83_CEDPREST_CODFISC - CedprestCodFisc | [optional] 
**CedprestCognome** | **string** | IE83_CEDPREST_COGNOME - CedprestCognome | [optional] 
**CedprestDenom** | **string** | IE83_CEDPREST_DENOM - CedprestDenom | [optional] 
**CedprestId** | **string** | IE83_CEDPREST_ID - CedprestId | [optional] 
**CedprestNome** | **string** | IE83_CEDPREST_NOME - CedprestNome | [optional] 
**CedprestPaeseid** | **string** | IE83_CEDPREST_PAESEID - CedprestPaeseid | [optional] 
**CedprestTitolo** | **string** | IE83_CEDPREST_TITOLO - CedprestTitolo | [optional] 
**CesscomCodFisc** | **string** | IE83_CESSCOM_CODFISC - CesscomCodFisc | [optional] 
**CesscomCognome** | **string** | IE83_CESSCOM_COGNOME - CesscomCognome | [optional] 
**CesscomDenom** | **string** | IE83_CESSCOM_DENOM - CesscomDenom | [optional] 
**CesscomId** | **string** | IE83_CESSCOM_ID - CesscomId | [optional] 
**CesscomNome** | **string** | IE83_CESSCOM_NOME - CesscomNome | [optional] 
**CesscomPaeseid** | **string** | IE83_CESSCOM_PAESEID - CesscomPaeseid | [optional] 
**ChangeType** | **int** | IE83_CHANGETYPE - Tipo di modifica | 
**Codiceraggr** | **string** | IE83_CODICERAGGR - Codiceraggr | [optional] 
**Conallegato** | **int** | IE83_CONALLEGATO - Conallegato | 
**Dataconsegnasdi** | **DateTime?** | IE83_DATACONSEGNASDI - Dataconsegnasdi | [optional] 
**Datadoc** | **string** | IE83_DATADOC - Datadoc | [optional] 
**Datecreation** | **DateTime?** | IE83_DATECREATION - Datecreation | [optional] 
**DittaCg18** | **double?** | IE83_DITTA_CG18 - DittaCg18 | [optional] 
**Divisa** | **string** | IE83_DIVISA - Divisa | [optional] 
**EmitstrasmId** | **string** | IE83_EMITSTRASM_ID - EmitstrasmId | [optional] 
**EmitstrasmPaeseid** | **string** | IE83_EMITSTRASM_PAESEID - EmitstrasmPaeseid | [optional] 
**Errori** | **string** | IE83_ERRORI - Errori | [optional] 
**Esito** | **int** | IE83_ESITO - Esito | 
**EsitoGenerazione** | **int** | IE83_ESITO_GENERAZIONE - EsitoGenerazione | 
**EsitoImport** | **int?** | IE83_ESITO_IMPORT - EsitoImport&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Non processato&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Sono presenti avvisi&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Sono presenti errori&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Importato&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Filedocdata** | **DateTime?** | IE83_FILEDOCDATA - Filedocdata | [optional] 
**Filedocnum** | **string** | IE83_FILEDOCNUM - Filedocnum | [optional] 
**Filename** | **string** | IE83_FILENAME - Filename | [optional] 
**Filetype** | **string** | IE83_FILETYPE - Filetype | [optional] 
**Flowtype** | **string** | IE83_FLOWTYPE - Flowtype | [optional] 
**GuidDo11** | **Guid?** | IE83_GUID_DO11 - GuidDo11 | [optional] 
**Hashcode** | **string** | IE83_HASHCODE - Hashcode | [optional] 
**Hubid** | **string** | IE83_HUBID - Hubid | [optional] 
**Id** | **int?** | IE83_ID - Id (Required only in PUT/PATCH) | [optional] 
**Identificativosdi** | **string** | IE83_IDENTIFICATIVOSDI - Identificativo SDI | [optional] 
**Idlotto** | **int?** | IE83_IDLOTTO - Idlotto | [optional] 
**IdproformaCg41** | **long?** | IE83_IDPROFORMA_CG41 - Riferimento proforma | [optional] 
**Imptotdoc** | **double?** | IE83_IMPTOTDOC - Imptotdoc | [optional] 
**Modificato** | **int** | IE83_MODIFICATO - Modificato | 
**Objectcct** | **int?** | IE83_OBJECTCCT - Objectcct | [optional] 
**Objectid** | **int?** | IE83_OBJECTID - Objectid | [optional] 
**Posfat** | **int?** | IE83_POSFAT - Posfat | [optional] 
**ProgInvio** | **string** | IE83_PROGINVIO - ProgInvio | [optional] 
**Recipientid** | **string** | IE83_RECIPIENTID - Recipientid | [optional] 
**Senderid** | **string** | IE83_SENDERID - Senderid | [optional] 
**Statecheck** | **int** | IE83_STATECHECK - Statecheck | 
**Statusdate** | **DateTime?** | IE83_STATUSDATE - Statusdate | [optional] 
**Statusid** | **int?** | IE83_STATUSID - Statusid | [optional] 
**Statusname** | **string** | IE83_STATUSNAME - Statusname | [optional] 
**Tipodoc** | **string** | IE83_TIPODOC - Tipodoc | [optional] 
**Tipoentita** | **int** | IE83_TIPOENTITA - Tipoentita | 
**TracciatoIe82** | **int?** | IE83_TRACCIATO_IE82 - TracciatoIe82 | [optional] 
**Trasmitterid** | **string** | IE83_TRASMITTERID - Trasmitterid | [optional] 
**Userfilename** | **string** | IE83_USERFILENAME - Userfilename | [optional] 
**Versione** | **string** | IE83_VERSIONE - Versione | [optional] 
**Xml** | **string** | IE83_XML - Xml | [optional] 
**B2BHeaderCODTO** | [**B2BHeaderCODTO**](B2BHeaderCODTO.md) |  | [optional] 
**B2BResultsCODTO** | [**List&lt;B2BResultsCODTO&gt;**](B2BResultsCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

