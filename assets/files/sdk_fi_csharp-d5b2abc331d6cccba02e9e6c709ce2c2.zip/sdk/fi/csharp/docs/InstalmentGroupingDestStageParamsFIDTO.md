# It.TSEnterprise.Sdk.Model.InstalmentGroupingDestStageParamsFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InstalmentStageId** | **int?** |  | [optional] 
**Delete** | **bool** |  | [optional] 
**Number** | **int** |  | [optional] 
**Type** | **double** |  | [optional] 
**SubType** | **double?** |  | [optional] 
**ExpiryDate** | **DateTime** |  | [optional] 
**TaxableAmount** | **double** |  | [optional] 
**VatAmount** | **double** |  | [optional] 
**CustomerSupplierBankId** | **int?** |  | [optional] 
**CompanyBankId** | **int?** |  | [optional] 
**Sezpart** | **string** |  | [optional] 
**Numpart** | **double** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

