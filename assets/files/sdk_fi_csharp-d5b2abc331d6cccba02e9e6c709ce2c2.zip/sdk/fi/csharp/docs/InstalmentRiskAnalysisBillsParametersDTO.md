# It.TSEnterprise.Sdk.Model.InstalmentRiskAnalysisBillsParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RiskElabId** | **long** |  | [optional] 
**ElabDate** | **DateTime** |  | [optional] 
**IdcliforCg44** | **int** |  | [optional] 
**IndBillDateType** | **int** |  | [optional] 
**BillMonthsNumber** | **int?** |  | [optional] 
**StartBillDate** | **DateTime?** |  | [optional] 
**FlgConsolidBill** | **int** |  | [optional] 
**FlgToConsolidBill** | **int** |  | [optional] 
**FlgEstimatedBill** | **int** |  | [optional] 
**FlgBillNoAmount** | **int** |  | [optional] 
**IndBillForDelay** | **int** |  | [optional] 
**IndAllBillsCalcType** | **int** |  | [optional] 
**IndOpenedBillsCalcType** | **int** |  | [optional] 
**IndClosedBillsCalcType** | **int** |  | [optional] 
**MinAmountForUnsolved** | **double?** |  | [optional] 
**MinAmountForDelay** | **double?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

