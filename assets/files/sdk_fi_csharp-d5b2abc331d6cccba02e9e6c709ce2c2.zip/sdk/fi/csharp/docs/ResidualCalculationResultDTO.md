# It.TSEnterprise.Sdk.Model.ResidualCalculationResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ResidualAmount** | **double?** |  | [optional] 
**DebitCreditIndicator** | **int?** |  | [optional] 
**ResidualAmountCC** | **double?** |  | [optional] 
**DataCambio** | **DateTime?** |  | [optional] 
**Cambio** | **double?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

