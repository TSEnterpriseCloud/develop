# It.TSEnterprise.Sdk.Model.InstalmentCalculationResultFIDTO
Results of the deadline calculation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Result** | **bool** |  | [optional] 
**Elements** | [**List&lt;InstalmentCalculationResultElementDTO&gt;**](InstalmentCalculationResultElementDTO.md) |  | [optional] [readonly] 
**CodPagUtilizzato** | **string** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

