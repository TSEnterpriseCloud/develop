# It.TSEnterprise.Sdk.Model.PaymentTermCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodPag** | **string** |  | [optional] 
**DescPag** | **string** |  | [optional] 
**DesPagAnal** | **string** |  | [optional] 
**FlgDesc** | **double** |  | [optional] 
**FlgDisgg** | **double** |  | [optional] 
**FlgPrefatt** | **int** |  | [optional] 
**FlgPrefpass** | **int** |  | [optional] 
**FlgStornoiva** | **double** |  | [optional] 
**Guid** | **Guid** |  | [optional] 
**Id** | **long** |  | [optional] 
**IdEntityWithDescriptions** | **int?** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**Scart26** | **double?** |  | [optional] 
**Scpercart26** | **double?** |  | [optional] 
**Scpercas** | **double?** |  | [optional] 
**Scpermer1** | **double?** |  | [optional] 
**Scpermer2** | **double?** |  | [optional] 
**RemovedExtendedAttribute** | [**ExtendedAttributeValuesCO**](ExtendedAttributeValuesCO.md) |  | [optional] 
**ExtendedAttribute** | [**ExtendedAttributeValuesCO**](ExtendedAttributeValuesCO.md) |  | [optional] 
**LanguageDescriptionCO** | [**List&lt;LanguageDescriptionCO&gt;**](LanguageDescriptionCO.md) |  | [optional] 
**PaymentTermDetailCO** | [**List&lt;PaymentTermDetailCO&gt;**](PaymentTermDetailCO.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

