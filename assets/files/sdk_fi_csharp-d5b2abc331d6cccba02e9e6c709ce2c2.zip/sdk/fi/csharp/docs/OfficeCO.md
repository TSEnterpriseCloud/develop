# It.TSEnterprise.Sdk.Model.OfficeCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Cap** | **string** |  | [optional] 
**Citta** | **string** |  | [optional] 
**Codice** | **double** |  | [optional] 
**DittaCg18** | **double** |  | [optional] 
**IdmediaCg99** | **double?** |  | [optional] 
**IndDimcentrocomm** | **double** |  | [optional] 
**IndIrizzo** | **string** |  | [optional] 
**Numerorea** | **string** |  | [optional] 
**ProgRea** | **double?** |  | [optional] 
**Prov** | **string** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

