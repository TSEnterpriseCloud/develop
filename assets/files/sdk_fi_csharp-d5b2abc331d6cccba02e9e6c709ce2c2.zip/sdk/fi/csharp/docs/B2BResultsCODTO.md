# It.TSEnterprise.Sdk.Model.B2BResultsCODTO
IE89_B2BESITI - B2BResultsCO<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DescriptionId** | **int?** | IE89_DESCRIPTIONID - DescriptionId | [optional] 
**Gravita** | **int?** | IE89_GRAVITA - Gravita&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Non elaborato&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - OK&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Warning&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Errore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Id** | **int?** | IE89_ID - Id (Required only in PUT/PATCH) | [optional] 
**IdIe83** | **int** | IE89_ID_IE83 - IdIe83 | 
**NumLineaL** | **string** | IE89_NUMLINEA_L - Riga | [optional] 
**TestoMsg** | **string** | IE89_TESTOMSG - TestoMsg | [optional] 
**TipoEsito** | **int** | IE89_TIPO_ESITO - TipoEsito | 
**Tipologia** | **int?** | IE89_TIPOLOGIA - Tipologia | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

