# It.TSEnterprise.Sdk.Model.CompanyBankSupplierCreditCardAccountFIDTO
EF15_CARTECRECONTIFO - CompanyBankSupplierCreditCardAccountFI<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodCarta** | **string** | EF15_CODCARTA - Codice carta di credito | 
**ConchiucarcreCg24** | **string** | EF15_CONCHIUCARCRE_CG24 - Conto per chiusura carta di credito | [optional] 
**Descrcarta** | **string** | EF15_DESCRCARTA - Descrizione carta di credito | [optional] 
**DittaCg18** | **double** | EF15_DITTA_CG18 - Ditta | 
**FlgPref** | **double** | EF15_FLGPREF - Carta di credito preferenziale | 
**GruchiucarcreCg24** | **double?** | EF15_GRUCHIUCARCRE_CG24 - GruchiucarcreCg24 | [optional] 
**Id** | **long?** | EF15_ID - ID (Required only in PUT/PATCH) | [optional] 
**IdCg64** | **long** | EF15_ID_CG64 - IdCg64 | 
**IdchiucarcreCg24** | **long?** | EF15_IDCHIUCARCRE_CG24 - IdchiucarcreCg24 | [optional] 
**IdEf08** | **long?** | EF15_ID_EF08 - IdEf08 | [optional] 
**IndStipoeff** | **double** | EF15_INDSTIPOEFF - Sottotipo effetto | 
**IndTipoeff** | **double?** | EF15_INDTIPOEFF - Tipo effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Carta di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Bancomat&lt;/li&gt;&lt;/ul&gt; | [optional] 
**ProgREf08** | **double** | EF15_PROGR_EF08 - ProgREf08 | 
**Rowversion** | **byte[]** | EF15_ROWVERSION - Rowversion | [optional] 
**CoaAccountFI** | [**COAAccountDescrFIDTO**](COAAccountDescrFIDTO.md) |  | [optional] 
**SubTypeCO** | [**SubTypeCODTO**](SubTypeCODTO.md) |  | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

