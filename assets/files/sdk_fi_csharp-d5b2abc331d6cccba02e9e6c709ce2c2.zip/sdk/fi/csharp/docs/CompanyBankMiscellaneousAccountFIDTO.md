# It.TSEnterprise.Sdk.Model.CompanyBankMiscellaneousAccountFIDTO
EF13_BANCHECONVARI - CompanyBankMiscellaneousAccountFI<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BancaCg12** | **double?** | EF13_BANCA_CG12 - Abi | [optional] 
**ConchiueffCg24** | **string** | EF13_CONCHIUEFF_CG24 - Conto chiusura effetti | [optional] 
**ConritspebanCg24** | **string** | EF13_CONRITSPEBAN_CG24 - Conto spese rit. addeb. dalla banca | [optional] 
**ConritspecliCg24** | **string** | EF13_CONRITSPECLI_CG24 - Conto spese rit. addeb. al cliente | [optional] 
**DittaCg18** | **double** | EF13_DITTA_CG18 - Ditta | 
**GruchiueffCg24** | **double?** | EF13_GRUCHIUEFF_CG24 - GruchiueffCg24 | [optional] 
**GruritspebanCg24** | **double?** | EF13_GRURITSPEBAN_CG24 - GruritspebanCg24 | [optional] 
**GruritspecliCg24** | **double?** | EF13_GRURITSPECLI_CG24 - GruritspecliCg24 | [optional] 
**Id** | **long?** | EF13_ID - ID (Required only in PUT/PATCH) | [optional] 
**IdchiueffCg24** | **long?** | EF13_IDCHIUEFF_CG24 - IdchiueffCg24 | [optional] 
**IdEf08** | **long?** | EF13_ID_EF08 - IdEf08 | [optional] 
**IdritspebanCg24** | **long?** | EF13_IDRITSPEBAN_CG24 - IdritspebanCg24 | [optional] 
**IdritspecliCg24** | **long?** | EF13_IDRITSPECLI_CG24 - IdritspecliCg24 | [optional] 
**IndEffclifor** | **double?** | EF13_INDEFFCLIFOR - Cliente / Fornitore&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Clienti&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Fornitori&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTipoeff** | **double?** | EF13_INDTIPOEFF - Tipo effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Ri.Ba.&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Tratte, Tratte acc.&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Cessioni, Cambiali&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - RID&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - MAV&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Rowversion** | **byte[]** | EF13_ROWVERSION - Rowversion | [optional] 
**BankCO** | [**BankCODTO**](BankCODTO.md) |  | [optional] 
**BankReturnFee** | [**COAAccountDescrFIDTO**](COAAccountDescrFIDTO.md) |  | [optional] 
**BillClosing** | [**COAAccountDescrFIDTO**](COAAccountDescrFIDTO.md) |  | [optional] 
**CustomerReturnFee** | [**COAAccountDescrFIDTO**](COAAccountDescrFIDTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

