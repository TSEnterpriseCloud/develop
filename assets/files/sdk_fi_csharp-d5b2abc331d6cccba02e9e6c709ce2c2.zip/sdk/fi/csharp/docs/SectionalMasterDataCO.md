# It.TSEnterprise.Sdk.Model.SectionalMasterDataCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Caustcoll** | **string** |  | [optional] 
**Descsez** | **string** |  | [optional] 
**DittaCg18** | **double** |  | [optional] 
**FlgNoLiqIva** | **int** |  | [optional] 
**Idagentecoll** | **int?** |  | [optional] 
**IdEntityWithDescriptions** | **int?** |  | [optional] 
**Idprov** | **double** |  | [optional] 
**IndIntra1213** | **double** |  | [optional] 
**IndRegione** | **double** |  | [optional] 
**IndTipologia** | **double** |  | [optional] 
**PuntovenCg7a** | **double** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**Sezionale** | **string** |  | [optional] 
**DescrizioniLingua** | [**List&lt;LanguageDescriptionCO&gt;**](LanguageDescriptionCO.md) |  | [optional] 
**StoreCO** | [**StoreCO**](StoreCO.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

