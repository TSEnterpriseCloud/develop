# It.TSEnterprise.Sdk.Model.CurrencyCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Cambiofisso** | **double?** |  | [optional] 
**Codice** | **string** |  | [optional] 
**Dataattuem** | **DateTime?** |  | [optional] 
**Descr** | **string** |  | [optional] 
**FlgValuem** | **double?** |  | [optional] 
**IdmediaCg99** | **double?** |  | [optional] 
**IndCertoincerto** | **int** |  | [optional] 
**IndSepmigl** | **double?** |  | [optional] 
**IndValuem** | **double?** |  | [optional] 
**Numdec** | **double?** |  | [optional] 
**Sigla** | **string** |  | [optional] 
**ExchangeRateCO** | [**List&lt;ExchangeRateCO&gt;**](ExchangeRateCO.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

