# It.TSEnterprise.Sdk.Model.DocumentMasterCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Datacre** | **DateTime?** |  | [optional] 
**Datavar** | **DateTime?** |  | [optional] 
**Descnote1** | **string** |  | [optional] 
**DittaCg18** | **double** |  | [optional] 
**Editincoge** | **int** |  | [optional] 
**FlgDelnote1** | **double?** |  | [optional] 
**Gruppocre** | **string** |  | [optional] 
**Gruppovar** | **string** |  | [optional] 
**IndCoin** | **double** |  | [optional] 
**IndCoinanomalia** | **int?** |  | [optional] 
**IndCoincoge** | **double** |  | [optional] 
**IndNote1** | **double?** |  | [optional] 
**IndTipoop** | **double** |  | [optional] 
**Numreg** | **string** |  | [optional] 
**Utentecre** | **string** |  | [optional] 
**Utentevar** | **string** |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

