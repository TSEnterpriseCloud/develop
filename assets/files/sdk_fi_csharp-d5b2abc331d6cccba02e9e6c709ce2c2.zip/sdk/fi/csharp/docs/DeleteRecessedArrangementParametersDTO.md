# It.TSEnterprise.Sdk.Model.DeleteRecessedArrangementParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DispositionId** | **long** |  | [optional] 
**InstalmentId** | **long?** |  | [optional] 
**DeleteAction** | **EDeleteActions** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

