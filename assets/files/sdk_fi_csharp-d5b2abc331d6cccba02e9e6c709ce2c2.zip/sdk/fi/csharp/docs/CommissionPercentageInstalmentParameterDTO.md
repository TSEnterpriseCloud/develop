# It.TSEnterprise.Sdk.Model.CommissionPercentageInstalmentParameterDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**GlEntryId** | **long** |  | [optional] 
**ReferenceDate** | **DateTime** |  | [optional] 
**SettlementType** | **int** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

