# It.TSEnterprise.Sdk.Model.DecumulateCalculationParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Amount** | **double** |  | [optional] 
**Percentage** | **double** |  | [optional] 
**PercentageNd** | **double** |  | [optional] 
**VatCode** | **string** |  | [optional] 
**OperationType** | **int** |  | [optional] 
**RowIdStage** | **long** |  | [optional] 
**StageGuid** | **Guid** |  | [optional] 
**Currency** | **string** |  | [optional] 
**DataCambio** | **DateTime?** |  | [optional] 
**Cambio** | **double?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

