# It.TSEnterprise.Sdk.Model.Int64StringValueTuple

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Item1** | **long** |  | [optional] 
**Item2** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

