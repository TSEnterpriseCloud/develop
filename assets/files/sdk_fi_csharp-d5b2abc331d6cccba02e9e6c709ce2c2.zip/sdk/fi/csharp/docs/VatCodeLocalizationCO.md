# It.TSEnterprise.Sdk.Model.VatCodeLocalizationCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodiceCg28** | **string** |  | [optional] 
**Delivopercode** | **string** |  | [optional] 
**EsRecargoequi** | **double?** |  | [optional] 
**Identity** | **long** |  | [optional] 
**Iso3166A2** | **string** |  | [optional] 
**Parent** | [**VatCodeCO**](VatCodeCO.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

