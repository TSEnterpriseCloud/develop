# It.TSEnterprise.Sdk.Model.SourceSelectionStateDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdSource** | **long** |  | [optional] 
**SelectState** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

