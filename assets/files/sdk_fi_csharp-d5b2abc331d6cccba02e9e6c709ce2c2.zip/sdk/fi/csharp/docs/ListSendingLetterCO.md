# It.TSEnterprise.Sdk.Model.ListSendingLetterCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Dataimpegno** | **DateTime?** |  | [optional] 
**Dataprotocollo** | **DateTime?** |  | [optional] 
**DittaCg18** | **double** |  | [optional] 
**FlgCessanmarino** | **int** |  | [optional] 
**FlgCessintra** | **int** |  | [optional] 
**FlgDichivapres** | **int** |  | [optional] 
**FlgEsport** | **int** |  | [optional] 
**FlgOperassim** | **int** |  | [optional] 
**FlgOperstraord** | **int** |  | [optional] 
**Id** | **int** |  | [optional] 
**IntermediarioCg77** | **double** |  | [optional] 
**Note** | **string** |  | [optional] 
**Numprotocollo** | **double?** |  | [optional] 
**ProgR** | **double** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**Tipoplafond** | **double?** |  | [optional] 
**DigitalSendersCO** | [**DigitalSendersCO**](DigitalSendersCO.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

