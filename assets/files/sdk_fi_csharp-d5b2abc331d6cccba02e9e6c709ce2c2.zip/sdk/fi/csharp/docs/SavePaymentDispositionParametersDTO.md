# It.TSEnterprise.Sdk.Model.SavePaymentDispositionParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TransferType** | **ETransferType** |  | [optional] 
**TransferModeType** | **ETransferModeType** |  | [optional] 
**PresentationBankId** | **int** |  | [optional] 
**CreationDate** | **DateTime** |  | [optional] 
**RegistrationDate** | **DateTime** |  | [optional] 
**ExecutionDate** | **DateTime** |  | [optional] 
**ChkConsolidated** | **bool** |  | [optional] 
**SendAddress** | **bool** |  | [optional] 
**AccountingReasonForRegistration** | **string** |  | [optional] 
**BankAccount** | **string** |  | [optional] 
**ExpenseRegistration** | **double** |  | [optional] 
**ExpenseAccount** | **string** |  | [optional] 
**WithReputed** | **bool** |  | [optional] 
**OutcomeNotification** | **bool** |  | [optional] 
**Presentation** | **bool** |  | [optional] 
**FlgPriorbon** | **EFlgPriorbon** |  | [optional] 
**Seat** | **int** |  | [optional] 
**CodeSeat** | **int** |  | [optional] 
**IndTiporegban** | **int** |  | [optional] 
**GroupingType** | **int** |  | [optional] 
**StageGuid** | **Guid** |  | [optional] 
**Cg08Code** | **string** |  | [optional] 
**WithholdingProf** | **string** |  | [optional] 
**OtherWithProf** | **string** |  | [optional] 
**WithholdingRappr** | **string** |  | [optional] 
**WithholdingEnas** | **string** |  | [optional] 
**EnasCompany** | **string** |  | [optional] 
**EntiPrev** | **string** |  | [optional] 
**OneriPrev** | **string** |  | [optional] 
**IdEf10** | **long?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

