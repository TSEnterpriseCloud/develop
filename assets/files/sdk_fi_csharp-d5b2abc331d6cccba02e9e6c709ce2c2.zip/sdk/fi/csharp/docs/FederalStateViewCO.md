# It.TSEnterprise.Sdk.Model.FederalStateViewCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**A2iso3166Cg07** | **string** |  | [optional] 
**CodiceCg07** | **double** |  | [optional] 
**Descr** | **string** |  | [optional] 
**Iso3166statofed** | **string** |  | [optional] 
**Statofed** | **string** |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

