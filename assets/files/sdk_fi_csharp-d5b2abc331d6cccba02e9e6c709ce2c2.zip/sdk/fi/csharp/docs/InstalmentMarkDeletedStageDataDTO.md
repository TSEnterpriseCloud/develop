# It.TSEnterprise.Sdk.Model.InstalmentMarkDeletedStageDataDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StageGuid** | **Guid** |  | [optional] 
**RigacontCg42** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

