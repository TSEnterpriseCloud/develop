# It.TSEnterprise.Sdk.Model.InstalmentStageFIParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdStageGuid** | **Guid** |  | [optional] 
**TipoOp** | **int** |  | [optional] 
**TipoDoc** | **int** |  | [optional] 
**IdCg24** | **long** |  | [optional] 
**NumReg** | **string** |  | [optional] 
**CodiceCg08** | **string** |  | [optional] 
**TipoCF** | **int?** |  | [optional] 
**Clifor** | **int?** |  | [optional] 
**RigacontCg42** | **int?** |  | [optional] 
**CustomFilter** | [**SearchDTO**](SearchDTO.md) |  | [optional] 
**ListId** | **string** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

