# It.TSEnterprise.Sdk.Model.StageInstalmentAndHistoryParametersDTOExternalSearchGroupInner
DTO that identifies a search criteria node (abstract)

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Operator** | **SearchLogicalOperators** |  | [optional] 
**PropertyName** | **string** | Property on witch apply the filter | 
**Comparer** | **SearchComparer** |  | 
**Value** | **Object** |  | 
**Items** | [**List&lt;OneOfSearchNodeDTOSearchElementDTOSearchGroupDTO&gt;**](OneOfSearchNodeDTOSearchElementDTOSearchGroupDTO.md) | Items list to apply: any element can be a &#39;SearchGroupDTO&#39; or a &#39;SearchElementDTO&#39; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

