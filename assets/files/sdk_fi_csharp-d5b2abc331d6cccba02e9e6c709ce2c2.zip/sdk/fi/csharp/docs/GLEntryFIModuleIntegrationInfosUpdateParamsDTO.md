# It.TSEnterprise.Sdk.Model.GLEntryFIModuleIntegrationInfosUpdateParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**GlEntryId** | **long** |  | [optional] 
**OperationType** | **int** |  | [optional] 
**OperationState** | **int** |  | [optional] 
**ExternalRif** | **long?** |  | [optional] 
**IsDeleteOp** | **int?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

