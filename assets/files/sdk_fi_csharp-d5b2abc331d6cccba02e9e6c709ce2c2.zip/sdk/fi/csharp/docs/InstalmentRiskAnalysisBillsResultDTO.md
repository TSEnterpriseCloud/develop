# It.TSEnterprise.Sdk.Model.InstalmentRiskAnalysisBillsResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ConsolidBill** | **double** |  | [optional] 
**ToConsolidBill** | **double** |  | [optional] 
**EstimatedBill** | **double** |  | [optional] 
**OverdueNotUnpaid** | **double** |  | [optional] 
**OverdueUnpaid** | **double** |  | [optional] 
**DueNotUnpaid** | **double** |  | [optional] 
**DueUnpaid** | **double** |  | [optional] 
**CollectedDue** | **double** |  | [optional] 
**SentToBankNumber** | **int** |  | [optional] 
**SentToBankAmount** | **double** |  | [optional] 
**UnpaidNumber** | **int** |  | [optional] 
**UnpaidAmount** | **double** |  | [optional] 
**OpenDueNumber** | **int** |  | [optional] 
**DelayDays** | **double** |  | [optional] 
**DelayDaysOpen** | **double** |  | [optional] 
**DelayDaysClose** | **double** |  | [optional] 
**ActualDelayDays** | **double** |  | [optional] 
**ActualDelayDaysOpen** | **double** |  | [optional] 
**ActualDelayDaysClose** | **double** |  | [optional] 
**PaymentLateDays** | **double** |  | [optional] 
**PaymentLateDaysOpen** | **double** |  | [optional] 
**PaymentLateDaysClose** | **double** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

