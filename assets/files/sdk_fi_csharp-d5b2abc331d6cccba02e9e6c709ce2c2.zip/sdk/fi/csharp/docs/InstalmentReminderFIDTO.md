# It.TSEnterprise.Sdk.Model.InstalmentReminderFIDTO
EF05_SCADSOLLEC - InstalmentReminderFI<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Adatacalc** | **DateTime?** | EF05_ADATACALC - A data | [optional] 
**CodBlocMg25** | **string** | EF05_CODBLOC_MG25 - Codice Blocco | [optional] 
**Dadatacalc** | **DateTime?** | EF05_DADATACALC - Da data | [optional] 
**Dataavviso** | **DateTime** | EF05_DATAAVVISO - Data avviso | 
**Datadoc** | **DateTime?** | EF05_DATADOC - Data documento | [optional] 
**Datarifelab** | **DateTime** | EF05_DATARIFELAB - Data riferimento elaborazione | 
**DittaCg18** | **double** | EF05_DITTA_CG18 - Codice ditta | 
**DocumMg36** | **string** | EF05_DOCUM_MG36 - Tipo documento | [optional] 
**FlgAzlegal** | **double?** | EF05_FLGAZLEGAL - Azione legale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgCalcint** | **double?** | EF05_FLGCALCINT - Calcolo interessi&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgDocbis** | **double** | EF05_FLGDOCBIS - Documento bis | 
**FlgEmisdoc** | **double?** | EF05_FLGEMISDOC - Emissione documento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgInvioage** | **double?** | EF05_FLGINVIOAGE - Invio agente&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgPers1** | **double** | EF05_FLGPERS1 - Personalizzabile 1 | 
**FlgPers2** | **double** | EF05_FLGPERS2 - Personalizzabile 2 | 
**Id** | **long?** | EF05_ID - Id (Required only in PUT/PATCH) | [optional] 
**IdEf01** | **long** | EF05_ID_EF01 - IdEf01 | 
**Impadetr** | **double** | EF05_IMPADETR - Impadetr | 
**Impinteres** | **double?** | EF05_IMPINTERES - Importo interessi | [optional] 
**IndBloc** | **double?** | EF05_INDBLOC - Indicatore blocco&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Blocco fisso&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Blocco mobile&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Non applicato&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndImpadetr** | **int** | EF05_INDIMPADETR - IndImpadetr | 
**Numdist** | **int** | EF05_NUMDIST - Numero distinta | 
**Numdoc** | **double?** | EF05_NUMDOC - Numero documento | [optional] 
**NumregCo99** | **string** | EF05_NUMREG_CO99 - NumregCo99 | 
**NumregDo11** | **string** | EF05_NUMREG_DO11 - NumregDo11 | [optional] 
**ProgAvvisi** | **double** | EF05_PROGAVVISI - Progressivo avviso | 
**ProgEffEf01** | **double** | EF05_PROGEFF_EF01 - ProgEffEf01 | 
**ProgREf08** | **double?** | EF05_PROGR_EF08 - ProgREf08 | [optional] 
**ProgRigaSpeseint** | **double?** | EF05_PROGRIGA_SPESEINT - ProgRigaSpeseint | [optional] 
**ProgRigaSpeseprot** | **double?** | EF05_PROGRIGA_SPESEPROT - ProgRigaSpeseprot | [optional] 
**Riffiglia** | **int** | EF05_RIFFIGLIA - Riffiglia | 
**Rifpadre** | **int** | EF05_RIFPADRE - Rifpadre | 
**RigacontEf01** | **double** | EF05_RIGACONT_EF01 - RigacontEf01 | 
**Rowversion** | **byte[]** | EF05_ROWVERSION - Rowversion | [optional] 
**Sezdoc** | **string** | EF05_SEZDOC - Sezionale documento | [optional] 
**Siglalettera** | **string** | EF05_SIGLALETTERA - Sigla lettera | [optional] 
**Spbollo** | **double?** | EF05_SPBOLLO - Spese bollo | [optional] 
**Speserit** | **double?** | EF05_SPESERIT - Spese di ritorno | [optional] 
**Sppost** | **double?** | EF05_SPPOST - Spese postali | [optional] 
**Spvarie** | **double?** | EF05_SPVARIE - Spese varie | [optional] 
**Tassoint** | **double?** | EF05_TASSOINT - Tasso d&#39;interesse | [optional] 
**Testopers** | **string** | EF05_TESTOPERS - Nota | [optional] 
**CompanyBank** | [**CompanyBankFIDTO**](CompanyBankFIDTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

