# It.TSEnterprise.Sdk.Model.FinanceCompanySectionalProposalCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Sezionale** | **string** |  | [optional] 
**Pagregvenglob** | **double?** |  | [optional] 
**Pagregven** | **double?** |  | [optional] 
**Pagregunicanal** | **double?** |  | [optional] 
**Pagregcor** | **double?** |  | [optional] 
**Pagregacqglob** | **double?** |  | [optional] 
**Pagregacq** | **double?** |  | [optional] 
**IdmediaCg99** | **double?** |  | [optional] 
**DittaCg18** | **double** |  | [optional] 
**Anno** | **double** |  | [optional] 
**IdattivitaCg86** | **double?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

