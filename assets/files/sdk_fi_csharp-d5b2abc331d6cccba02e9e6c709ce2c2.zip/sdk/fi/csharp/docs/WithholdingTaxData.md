# It.TSEnterprise.Sdk.Model.WithholdingTaxData

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ImportoAltreRitenute** | **double?** |  | [optional] 
**ImportoEnasarcoAzienda** | **double?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

