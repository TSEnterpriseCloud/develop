# It.TSEnterprise.Sdk.Model.CustomerSupplierCIGCUPCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CliforCg44** | **double** |  | [optional] 
**DittaCg18** | **double** |  | [optional] 
**Id** | **int** |  | [optional] 
**IdcigcupCo1h** | **int** |  | [optional] 
**ProgREf08** | **double** |  | [optional] 
**ProgRMg35** | **int** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**TipocfCg44** | **double** |  | [optional] 
**Parent** | [**CustomerSupplierCO**](CustomerSupplierCO.md) |  | [optional] 
**CigcuPcode** | [**CIGCUPMasterDataCO**](CIGCUPMasterDataCO.md) |  | [optional] 
**CompanyBank** | [**CompanyBankCO**](CompanyBankCO.md) |  | [optional] 
**CsBankCO** | [**CSBankCO**](CSBankCO.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

