# It.TSEnterprise.Sdk.Model.VATTypeFI

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Agviaggio** | **int** |  | [optional] 
**Codice** | **double** |  | [optional] 
**CodiceCg0d** | **double?** |  | [optional] 
**Descr** | **string** |  | [optional] 
**IdEntityWithDescriptions** | **int?** |  | [optional] 
**IndAutofattura** | **int** |  | [optional] 
**IndTipo** | **double** |  | [optional] 
**Localizzazione** | **int** |  | [optional] 
**LanguageDescriptionFI** | [**List&lt;LanguageDescriptionFI&gt;**](LanguageDescriptionFI.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

