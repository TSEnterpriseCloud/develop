# It.TSEnterprise.Sdk.Model.IdRaggrAndPaymentCodeDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdRaggr** | **long** |  | [optional] 
**PaymentCode** | **string** |  | [optional] 
**EffectiveDate** | **DateTime?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

