# It.TSEnterprise.Sdk.Model.TSPaaSShowInvoicePDFParametersDTO
Parameters for show PDF invoice

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdXmlInvoice** | **string** |  | [optional] 
**IdSDI** | **string** |  | [optional] 
**Hubid** | **string** |  | [optional] 
**Mode** | **string** |  | [optional] 
**OutputType** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

