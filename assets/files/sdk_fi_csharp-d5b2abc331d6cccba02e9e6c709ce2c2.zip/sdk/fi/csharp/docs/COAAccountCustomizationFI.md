# It.TSEnterprise.Sdk.Model.COAAccountCustomizationFI

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ContoCg24** | **string** |  | [optional] 
**Descr** | **string** |  | [optional] 
**DittaCg18** | **double** |  | [optional] 
**GruppoCg10** | **double** |  | [optional] 
**IdCg24** | **long** |  | [optional] 
**Iddespcon** | **long** |  | [optional] 
**IdEntityWithDescriptions** | **int?** |  | [optional] 
**IdmediaCg99** | **double?** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**LanguageDescriptionFI** | [**List&lt;LanguageDescriptionFI&gt;**](LanguageDescriptionFI.md) |  | [optional] 
**Parent** | [**COAAccountFI**](COAAccountFI.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

