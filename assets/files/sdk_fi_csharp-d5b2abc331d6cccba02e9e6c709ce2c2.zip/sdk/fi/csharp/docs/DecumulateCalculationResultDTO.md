# It.TSEnterprise.Sdk.Model.DecumulateCalculationResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DecumulatedAmount** | **double?** |  | [optional] 
**TaxAmount** | **double?** |  | [optional] 
**TaxNdAmount** | **double?** |  | [optional] 
**DebitCreditIndicator** | **int?** |  | [optional] 
**DecumulatedAmountCC** | **double?** |  | [optional] 
**TaxAmountCC** | **double?** |  | [optional] 
**TaxNdAmountCC** | **double?** |  | [optional] 
**DataCambio** | **DateTime?** |  | [optional] 
**Cambio** | **double?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

