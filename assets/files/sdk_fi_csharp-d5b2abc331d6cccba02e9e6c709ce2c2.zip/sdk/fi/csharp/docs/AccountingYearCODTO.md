# It.TSEnterprise.Sdk.Model.AccountingYearCODTO
CG19_ANADITTAESER - AccountingYearCO<br>Proprietà chiave:<ul><li><b>Anno</b></li><li><b>DittaCg18</b></li><li><b>ProgEser</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Anno** | **double** | CG19_ANNO -  Esercizio | 
**Dataape** | **DateTime** | CG19_DATAAPE - Data inizio | 
**Datachiu** | **DateTime** | CG19_DATACHIU - Data fine | 
**DittaCg18** | **double** | CG19_DITTA_CG18 - Codice azienda | 
**FlgAdecbatt** | **double?** | CG19_FLGADECBATT - Adeguamento cambi conti attivi&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgAdecbcli** | **double?** | CG19_FLGADECBCLI - Adeguamento cambi clienti&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgAdecbfor** | **double?** | CG19_FLGADECBFOR - Adeguamento cambi fornitori&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgAdecbpas** | **double?** | CG19_FLGADECBPAS - Adeguamento cambi conti passivi&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgEserchiuso** | **double?** | CG19_FLGESERCHIUSO - Chiuso&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgEsercor** | **double?** | CG19_FLGESERCOR - Corrente&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgGencesp** | **double?** | CG19_FLGGENCESP - Ammortamenti generati&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgGenratei** | **int?** | CG19_FLGGENRATEI - FlgGenratei&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgGenrisc** | **double?** | CG19_FLGGENRISC - Risconti generati&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Id** | **long?** | CG19_ID - Id (Required only in PUT/PATCH) | [optional] 
**ProgEser** | **double** | CG19_PROGESER - Pr. | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

