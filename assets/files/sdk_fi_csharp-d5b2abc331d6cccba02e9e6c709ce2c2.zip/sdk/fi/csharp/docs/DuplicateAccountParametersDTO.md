# It.TSEnterprise.Sdk.Model.DuplicateAccountParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SourceAccountId** | **long** |  | [optional] 
**AccountCode** | **string** |  | [optional] 
**AccountDescription** | **string** |  | [optional] 
**FlgDuplLanguageDescriptions** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

