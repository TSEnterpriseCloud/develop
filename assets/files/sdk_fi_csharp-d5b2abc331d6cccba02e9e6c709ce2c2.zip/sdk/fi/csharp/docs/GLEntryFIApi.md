# It.TSEnterprise.Sdk.Api.GLEntryFIApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**ApiV1EnvironmentFIGLEntryFIArchiveB2BFileFepaPassPost**](GLEntryFIApi.md#apiv1environmentfiglentryfiarchiveb2bfilefepapasspost) | **POST** /api/v1/{environment}/FI/GLEntryFI/ArchiveB2BFileFepaPass | Archive B2B file Fepa pass |
| [**ApiV1EnvironmentFIGLEntryFIAutoArchiveB2BFileFepaPassPost**](GLEntryFIApi.md#apiv1environmentfiglentryfiautoarchiveb2bfilefepapasspost) | **POST** /api/v1/{environment}/FI/GLEntryFI/AutoArchiveB2BFileFepaPass | Auto archive B2B file Fepa pass |
| [**ApiV1EnvironmentFIGLEntryFICalculateNextGLEntryProtocolPost**](GLEntryFIApi.md#apiv1environmentfiglentryficalculatenextglentryprotocolpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/CalculateNextGLEntryProtocol | Calculate the next available protocol for gl entries |
| [**ApiV1EnvironmentFIGLEntryFICalculatecreditlinePost**](GLEntryFIApi.md#apiv1environmentfiglentryficalculatecreditlinepost) | **POST** /api/v1/{environment}/FI/GLEntryFI/calculatecreditline | Calculate credit line |
| [**ApiV1EnvironmentFIGLEntryFICheckConfigurationExchangeDiffPost**](GLEntryFIApi.md#apiv1environmentfiglentryficheckconfigurationexchangediffpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/CheckConfigurationExchangeDiff | Checks configuration exchange differences |
| [**ApiV1EnvironmentFIGLEntryFICloseVatOnPaymentsPost**](GLEntryFIApi.md#apiv1environmentfiglentryficlosevatonpaymentspost) | **POST** /api/v1/{environment}/FI/GLEntryFI/CloseVatOnPayments | Close Vat on payments |
| [**ApiV1EnvironmentFIGLEntryFICrossBorderDetailOperationPost**](GLEntryFIApi.md#apiv1environmentfiglentryficrossborderdetailoperationpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/CrossBorderDetailOperation | Cross-border operations (detail) |
| [**ApiV1EnvironmentFIGLEntryFICrossBorderOperationPost**](GLEntryFIApi.md#apiv1environmentfiglentryficrossborderoperationpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/CrossBorderOperation | Cross-border operations |
| [**ApiV1EnvironmentFIGLEntryFIDecumulateCalculationPost**](GLEntryFIApi.md#apiv1environmentfiglentryfidecumulatecalculationpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/DecumulateCalculation | Percentage unbundling calculation |
| [**ApiV1EnvironmentFIGLEntryFIDeleteClosingReopeningPost**](GLEntryFIApi.md#apiv1environmentfiglentryfideleteclosingreopeningpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/DeleteClosingReopening | Eliminates the records of the tables related to an accounting processing |
| [**ApiV1EnvironmentFIGLEntryFIDeleteExchangeDifferencePost**](GLEntryFIApi.md#apiv1environmentfiglentryfideleteexchangedifferencepost) | **POST** /api/v1/{environment}/FI/GLEntryFI/DeleteExchangeDifference | Eliminates the records of the tables related to an accounting processing |
| [**ApiV1EnvironmentFIGLEntryFIEnabledtoprojectsPost**](GLEntryFIApi.md#apiv1environmentfiglentryfienabledtoprojectspost) | **POST** /api/v1/{environment}/FI/GLEntryFI/enabledtoprojects | Check if the gl entry can open project entries |
| [**ApiV1EnvironmentFIGLEntryFIFilterglentriesPost**](GLEntryFIApi.md#apiv1environmentfiglentryfifilterglentriespost) | **POST** /api/v1/{environment}/FI/GLEntryFI/filterglentries | FilterGlentries |
| [**ApiV1EnvironmentFIGLEntryFIGLEntryPartialValidatePost**](GLEntryFIApi.md#apiv1environmentfiglentryfiglentrypartialvalidatepost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GLEntryPartialValidate | GL ENtry Header validations |
| [**ApiV1EnvironmentFIGLEntryFIGet**](GLEntryFIApi.md#apiv1environmentfiglentryfiget) | **GET** /api/v1/{environment}/FI/GLEntryFI | Get new |
| [**ApiV1EnvironmentFIGLEntryFIGetApplicationVersionPost**](GLEntryFIApi.md#apiv1environmentfiglentryfigetapplicationversionpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetApplicationVersion | Application version reading |
| [**ApiV1EnvironmentFIGLEntryFIGetBusinessTypeDataDefaultPost**](GLEntryFIApi.md#apiv1environmentfiglentryfigetbusinesstypedatadefaultpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetBusinessTypeDataDefault | Get default dbsiness type data |
| [**ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankMovementsPost**](GLEntryFIApi.md#apiv1environmentfiglentryfigeteligibleidsfrombankmovementspost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetEligibleIdsFromBankMovements | Request the list of bank movements to account |
| [**ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankReconcileMovementsPost**](GLEntryFIApi.md#apiv1environmentfiglentryfigeteligibleidsfrombankreconcilemovementspost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetEligibleIdsFromBankReconcileMovements | Request the list of reconcilable bank transactions |
| [**ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromTsDigitalPost**](GLEntryFIApi.md#apiv1environmentfiglentryfigeteligibleidsfromtsdigitalpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetEligibleIdsFromTsDigital | Request the list of TsDigital movements to account |
| [**ApiV1EnvironmentFIGLEntryFIGetFileFepaPassCOPost**](GLEntryFIApi.md#apiv1environmentfiglentryfigetfilefepapasscopost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetFileFepaPassCO | Read by key B2B file Fepa pass and fix it |
| [**ApiV1EnvironmentFIGLEntryFIGetGLEntryAccountingReasonCodeDataGet**](GLEntryFIApi.md#apiv1environmentfiglentryfigetglentryaccountingreasoncodedataget) | **GET** /api/v1/{environment}/FI/GLEntryFI/GetGLEntryAccountingReasonCodeData | Data reading for accounting reason code |
| [**ApiV1EnvironmentFIGLEntryFIGetGLEntryAdditionalDataPost**](GLEntryFIApi.md#apiv1environmentfiglentryfigetglentryadditionaldatapost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetGLEntryAdditionalData | Data reading for withholdings deadlines |
| [**ApiV1EnvironmentFIGLEntryFIGetGLEntryOffSetPost**](GLEntryFIApi.md#apiv1environmentfiglentryfigetglentryoffsetpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetGLEntryOffSet | Get gl entry off set |
| [**ApiV1EnvironmentFIGLEntryFIGetLinkedEntriesFromNumregPost**](GLEntryFIApi.md#apiv1environmentfiglentryfigetlinkedentriesfromnumregpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetLinkedEntriesFromNumreg | Returns all gl entries starting from a registration number. |
| [**ApiV1EnvironmentFIGLEntryFIGetNumregByDetailIdPost**](GLEntryFIApi.md#apiv1environmentfiglentryfigetnumregbydetailidpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetNumregByDetailId | Get GLEntry numreg by detail id |
| [**ApiV1EnvironmentFIGLEntryFIGetTracciatoDocumentalePost**](GLEntryFIApi.md#apiv1environmentfiglentryfigettracciatodocumentalepost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetTracciatoDocumentale | Retrieve document track |
| [**ApiV1EnvironmentFIGLEntryFIGetVatRegistryResultPost**](GLEntryFIApi.md#apiv1environmentfiglentryfigetvatregistryresultpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetVatRegistryResult | Get vat registry result |
| [**ApiV1EnvironmentFIGLEntryFIGetxsltPost**](GLEntryFIApi.md#apiv1environmentfiglentryfigetxsltpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/getxslt | Get XSLT |
| [**ApiV1EnvironmentFIGLEntryFIIdDelete**](GLEntryFIApi.md#apiv1environmentfiglentryfiiddelete) | **DELETE** /api/v1/{environment}/FI/GLEntryFI/{id} | Delete |
| [**ApiV1EnvironmentFIGLEntryFIIdGet**](GLEntryFIApi.md#apiv1environmentfiglentryfiidget) | **GET** /api/v1/{environment}/FI/GLEntryFI/{id} | Get by ID |
| [**ApiV1EnvironmentFIGLEntryFIIdPatch**](GLEntryFIApi.md#apiv1environmentfiglentryfiidpatch) | **PATCH** /api/v1/{environment}/FI/GLEntryFI/{id} | Update partial |
| [**ApiV1EnvironmentFIGLEntryFIIdPut**](GLEntryFIApi.md#apiv1environmentfiglentryfiidput) | **PUT** /api/v1/{environment}/FI/GLEntryFI/{id} | Update |
| [**ApiV1EnvironmentFIGLEntryFIImportDocB2BFileFepaPassPost**](GLEntryFIApi.md#apiv1environmentfiglentryfiimportdocb2bfilefepapasspost) | **POST** /api/v1/{environment}/FI/GLEntryFI/ImportDocB2BFileFepaPass | Import B2B file Fepa pass |
| [**ApiV1EnvironmentFIGLEntryFIImportInvoiceFepaPassFIPost**](GLEntryFIApi.md#apiv1environmentfiglentryfiimportinvoicefepapassfipost) | **POST** /api/v1/{environment}/FI/GLEntryFI/ImportInvoiceFepaPassFI | Import file Fepa pass |
| [**ApiV1EnvironmentFIGLEntryFIInsertmissingexchangeratesPost**](GLEntryFIApi.md#apiv1environmentfiglentryfiinsertmissingexchangeratespost) | **POST** /api/v1/{environment}/FI/GLEntryFI/insertmissingexchangerates | Insert missing exchange rate |
| [**ApiV1EnvironmentFIGLEntryFIIsCheckListEnabledGet**](GLEntryFIApi.md#apiv1environmentfiglentryfiischecklistenabledget) | **GET** /api/v1/{environment}/FI/GLEntryFI/IsCheckListEnabled | Returns if the checklist functionality on glentry landing is enabled |
| [**ApiV1EnvironmentFIGLEntryFIModuleintegrationinfosupdatePost**](GLEntryFIApi.md#apiv1environmentfiglentryfimoduleintegrationinfosupdatepost) | **POST** /api/v1/{environment}/FI/GLEntryFI/moduleintegrationinfosupdate | Updates module integration infos |
| [**ApiV1EnvironmentFIGLEntryFIMulticreatePost**](GLEntryFIApi.md#apiv1environmentfiglentryfimulticreatepost) | **POST** /api/v1/{environment}/FI/GLEntryFI/multicreate | Multiple creation of gl entries |
| [**ApiV1EnvironmentFIGLEntryFIMultiplecreatejobPost**](GLEntryFIApi.md#apiv1environmentfiglentryfimultiplecreatejobpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/multiplecreatejob | Job creation of multiple entry of gl entries |
| [**ApiV1EnvironmentFIGLEntryFIPaymentwithholdingtaxesaccountingPost**](GLEntryFIApi.md#apiv1environmentfiglentryfipaymentwithholdingtaxesaccountingpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/paymentwithholdingtaxesaccounting | Payment withholding taxes accounting |
| [**ApiV1EnvironmentFIGLEntryFIPlafondinfoPost**](GLEntryFIApi.md#apiv1environmentfiglentryfiplafondinfopost) | **POST** /api/v1/{environment}/FI/GLEntryFI/plafondinfo | Reading of the ceiling management indicator |
| [**ApiV1EnvironmentFIGLEntryFIPost**](GLEntryFIApi.md#apiv1environmentfiglentryfipost) | **POST** /api/v1/{environment}/FI/GLEntryFI | Create |
| [**ApiV1EnvironmentFIGLEntryFIPreviewPost**](GLEntryFIApi.md#apiv1environmentfiglentryfipreviewpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/preview | Preview of a gl entry |
| [**ApiV1EnvironmentFIGLEntryFIReadPost**](GLEntryFIApi.md#apiv1environmentfiglentryfireadpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/read | Read |
| [**ApiV1EnvironmentFIGLEntryFIReelaborateInvoiceFepaPassFIPost**](GLEntryFIApi.md#apiv1environmentfiglentryfireelaborateinvoicefepapassfipost) | **POST** /api/v1/{environment}/FI/GLEntryFI/ReelaborateInvoiceFepaPassFI | Reelaborate file Fepa pass |
| [**ApiV1EnvironmentFIGLEntryFIResidualCalculationPost**](GLEntryFIApi.md#apiv1environmentfiglentryfiresidualcalculationpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/ResidualCalculation | Residual accounting entry calculation |
| [**ApiV1EnvironmentFIGLEntryFIRestoreB2BFileFepaPassPost**](GLEntryFIApi.md#apiv1environmentfiglentryfirestoreb2bfilefepapasspost) | **POST** /api/v1/{environment}/FI/GLEntryFI/RestoreB2BFileFepaPass | Restore B2B file Fepa pass |
| [**ApiV1EnvironmentFIGLEntryFIRestoreInvoiceFepaPassFIPost**](GLEntryFIApi.md#apiv1environmentfiglentryfirestoreinvoicefepapassfipost) | **POST** /api/v1/{environment}/FI/GLEntryFI/RestoreInvoiceFepaPassFI | Restore file Fepa pass |
| [**ApiV1EnvironmentFIGLEntryFIRetrieveCurrenciesOfExchangeRatesAdjPost**](GLEntryFIApi.md#apiv1environmentfiglentryfiretrievecurrenciesofexchangeratesadjpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/RetrieveCurrenciesOfExchangeRatesAdj | Manages the recovery of all currencies and relative exchange rates belonging to an accounting process |
| [**ApiV1EnvironmentFIGLEntryFIRunreportrglentriesPost**](GLEntryFIApi.md#apiv1environmentfiglentryfirunreportrglentriespost) | **POST** /api/v1/{environment}/FI/GLEntryFI/runreportrglentries | RunReportGlentries |
| [**ApiV1EnvironmentFIGLEntryFISearchPost**](GLEntryFIApi.md#apiv1environmentfiglentryfisearchpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/search | Search |
| [**ApiV1EnvironmentFIGLEntryFISetGLEntryFromBankTransactionsMovPost**](GLEntryFIApi.md#apiv1environmentfiglentryfisetglentryfrombanktransactionsmovpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/SetGLEntryFromBankTransactionsMov | Import bank transactions |
| [**ApiV1EnvironmentFIGLEntryFISetGLEntryFromTsDigitalPost**](GLEntryFIApi.md#apiv1environmentfiglentryfisetglentryfromtsdigitalpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/SetGLEntryFromTsDigital | Import TsDigital entry |
| [**ApiV1EnvironmentFIGLEntryFISetGLEntryLinkedF24MovementsIdPost**](GLEntryFIApi.md#apiv1environmentfiglentryfisetglentrylinkedf24movementsidpost) | **POST** /api/v1/{environment}/FI/GLEntryFI/SetGLEntryLinkedF24MovementsId | Set GLEntry linked F24 movements |
| [**ApiV1EnvironmentFIGLEntryFIShowPDFInvoicePost**](GLEntryFIApi.md#apiv1environmentfiglentryfishowpdfinvoicepost) | **POST** /api/v1/{environment}/FI/GLEntryFI/showPDFInvoice | View the invoice in PDF format |
| [**ApiV1EnvironmentFIGLEntryFIStageCleanGLEntryPost**](GLEntryFIApi.md#apiv1environmentfiglentryfistagecleanglentrypost) | **POST** /api/v1/{environment}/FI/GLEntryFI/StageCleanGLEntry | Cleaning GLEntry and related stage tables |
| [**ApiV1EnvironmentFIGLEntryFIToConsolidatePost**](GLEntryFIApi.md#apiv1environmentfiglentryfitoconsolidatepost) | **POST** /api/v1/{environment}/FI/GLEntryFI/ToConsolidate | Returns all gl entries starting from a registration number. |
| [**ApiV1EnvironmentFIGLEntryFIUpdatehubidsdiPost**](GLEntryFIApi.md#apiv1environmentfiglentryfiupdatehubidsdipost) | **POST** /api/v1/{environment}/FI/GLEntryFI/updatehubidsdi | Update CG41_HUBID and CG41_IDSDI |
| [**ApiV1EnvironmentFIGLEntryFIValidatePost**](GLEntryFIApi.md#apiv1environmentfiglentryfivalidatepost) | **POST** /api/v1/{environment}/FI/GLEntryFI/validate | Validate |
| [**ApiV1EnvironmentFIGLEntryFIValidatePropertiesPost**](GLEntryFIApi.md#apiv1environmentfiglentryfivalidatepropertiespost) | **POST** /api/v1/{environment}/FI/GLEntryFI/validateProperties | Validation of one on more properties of Type |

<a id="apiv1environmentfiglentryfiarchiveb2bfilefepapasspost"></a>
# **ApiV1EnvironmentFIGLEntryFIArchiveB2BFileFepaPassPost**
> FIGLEntriesExecutionResultDTO ApiV1EnvironmentFIGLEntryFIArchiveB2BFileFepaPassPost (string environment, string authorizationScope, IdsListFIDTO idsListFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Archive B2B file Fepa pass

Archive B2B file Fepa pass

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIArchiveB2BFileFepaPassPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var idsListFIDTO = new IdsListFIDTO(); // IdsListFIDTO | Input params
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Archive B2B file Fepa pass
                FIGLEntriesExecutionResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIArchiveB2BFileFepaPassPost(environment, authorizationScope, idsListFIDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIArchiveB2BFileFepaPassPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIArchiveB2BFileFepaPassPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Archive B2B file Fepa pass
    ApiResponse<FIGLEntriesExecutionResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIArchiveB2BFileFepaPassPostWithHttpInfo(environment, authorizationScope, idsListFIDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIArchiveB2BFileFepaPassPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **idsListFIDTO** | [**IdsListFIDTO**](IdsListFIDTO.md) | Input params |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiautoarchiveb2bfilefepapasspost"></a>
# **ApiV1EnvironmentFIGLEntryFIAutoArchiveB2BFileFepaPassPost**
> FIGLEntriesExecutionResultDTO ApiV1EnvironmentFIGLEntryFIAutoArchiveB2BFileFepaPassPost (string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null)

Auto archive B2B file Fepa pass

Auto archive B2B file Fepa pass

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIAutoArchiveB2BFileFepaPassPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Auto archive B2B file Fepa pass
                FIGLEntriesExecutionResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIAutoArchiveB2BFileFepaPassPost(environment, authorizationScope, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIAutoArchiveB2BFileFepaPassPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIAutoArchiveB2BFileFepaPassPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Auto archive B2B file Fepa pass
    ApiResponse<FIGLEntriesExecutionResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIAutoArchiveB2BFileFepaPassPostWithHttpInfo(environment, authorizationScope, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIAutoArchiveB2BFileFepaPassPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryficalculatenextglentryprotocolpost"></a>
# **ApiV1EnvironmentFIGLEntryFICalculateNextGLEntryProtocolPost**
> ProtocolCalculationResultDTO ApiV1EnvironmentFIGLEntryFICalculateNextGLEntryProtocolPost (string environment, string authorizationScope, ProtocolCalculationParametersDTO protocolCalculationParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Calculate the next available protocol for gl entries

Calculate the next available protocol for gl entries

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFICalculateNextGLEntryProtocolPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var protocolCalculationParametersDTO = new ProtocolCalculationParametersDTO(); // ProtocolCalculationParametersDTO | Object that contains all the parameters that are used in the calculation
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Calculate the next available protocol for gl entries
                ProtocolCalculationResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFICalculateNextGLEntryProtocolPost(environment, authorizationScope, protocolCalculationParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFICalculateNextGLEntryProtocolPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFICalculateNextGLEntryProtocolPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Calculate the next available protocol for gl entries
    ApiResponse<ProtocolCalculationResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFICalculateNextGLEntryProtocolPostWithHttpInfo(environment, authorizationScope, protocolCalculationParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFICalculateNextGLEntryProtocolPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **protocolCalculationParametersDTO** | [**ProtocolCalculationParametersDTO**](ProtocolCalculationParametersDTO.md) | Object that contains all the parameters that are used in the calculation |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**ProtocolCalculationResultDTO**](ProtocolCalculationResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result of calculation |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryficalculatecreditlinepost"></a>
# **ApiV1EnvironmentFIGLEntryFICalculatecreditlinePost**
> CalculateCreditLineResultDTO ApiV1EnvironmentFIGLEntryFICalculatecreditlinePost (string environment, string authorizationScope, CalculateCreditLineParamsDTO calculateCreditLineParamsDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Calculate credit line

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFICalculatecreditlinePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var calculateCreditLineParamsDTO = new CalculateCreditLineParamsDTO(); // CalculateCreditLineParamsDTO | Input parameters for elaboration
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Calculate credit line
                CalculateCreditLineResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFICalculatecreditlinePost(environment, authorizationScope, calculateCreditLineParamsDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFICalculatecreditlinePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFICalculatecreditlinePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Calculate credit line
    ApiResponse<CalculateCreditLineResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFICalculatecreditlinePostWithHttpInfo(environment, authorizationScope, calculateCreditLineParamsDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFICalculatecreditlinePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **calculateCreditLineParamsDTO** | [**CalculateCreditLineParamsDTO**](CalculateCreditLineParamsDTO.md) | Input parameters for elaboration |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**CalculateCreditLineResultDTO**](CalculateCreditLineResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** |  |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryficheckconfigurationexchangediffpost"></a>
# **ApiV1EnvironmentFIGLEntryFICheckConfigurationExchangeDiffPost**
> FIGLEntriesExecutionResultDTO ApiV1EnvironmentFIGLEntryFICheckConfigurationExchangeDiffPost (string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null)

Checks configuration exchange differences

Checks configuration exchange differences

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFICheckConfigurationExchangeDiffPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Checks configuration exchange differences
                FIGLEntriesExecutionResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFICheckConfigurationExchangeDiffPost(environment, authorizationScope, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFICheckConfigurationExchangeDiffPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFICheckConfigurationExchangeDiffPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Checks configuration exchange differences
    ApiResponse<FIGLEntriesExecutionResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFICheckConfigurationExchangeDiffPostWithHttpInfo(environment, authorizationScope, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFICheckConfigurationExchangeDiffPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | GL entry |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryficlosevatonpaymentspost"></a>
# **ApiV1EnvironmentFIGLEntryFICloseVatOnPaymentsPost**
> void ApiV1EnvironmentFIGLEntryFICloseVatOnPaymentsPost (string environment, string authorizationScope, VatPaymentCloseFromVATReturnParametersDTO vatPaymentCloseFromVATReturnParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Close Vat on payments

Close Vat on payments

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFICloseVatOnPaymentsPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var vatPaymentCloseFromVATReturnParametersDTO = new VatPaymentCloseFromVATReturnParametersDTO(); // VatPaymentCloseFromVATReturnParametersDTO | Input params
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Close Vat on payments
                apiInstance.ApiV1EnvironmentFIGLEntryFICloseVatOnPaymentsPost(environment, authorizationScope, vatPaymentCloseFromVATReturnParametersDTO, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFICloseVatOnPaymentsPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFICloseVatOnPaymentsPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Close Vat on payments
    apiInstance.ApiV1EnvironmentFIGLEntryFICloseVatOnPaymentsPostWithHttpInfo(environment, authorizationScope, vatPaymentCloseFromVATReturnParametersDTO, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFICloseVatOnPaymentsPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **vatPaymentCloseFromVATReturnParametersDTO** | [**VatPaymentCloseFromVATReturnParametersDTO**](VatPaymentCloseFromVATReturnParametersDTO.md) | Input params |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryficrossborderdetailoperationpost"></a>
# **ApiV1EnvironmentFIGLEntryFICrossBorderDetailOperationPost**
> ValidateDTO ApiV1EnvironmentFIGLEntryFICrossBorderDetailOperationPost (string environment, string authorizationScope, CrossBorderDetailOperationParamsDTO crossBorderDetailOperationParamsDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Cross-border operations (detail)

Change IndNatura, FlgDeducibile and PercDetr of the GLVATDetailFI table

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFICrossBorderDetailOperationPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var crossBorderDetailOperationParamsDTO = new CrossBorderDetailOperationParamsDTO(); // CrossBorderDetailOperationParamsDTO | Parameters for operations
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Cross-border operations (detail)
                ValidateDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFICrossBorderDetailOperationPost(environment, authorizationScope, crossBorderDetailOperationParamsDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFICrossBorderDetailOperationPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFICrossBorderDetailOperationPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Cross-border operations (detail)
    ApiResponse<ValidateDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFICrossBorderDetailOperationPostWithHttpInfo(environment, authorizationScope, crossBorderDetailOperationParamsDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFICrossBorderDetailOperationPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **crossBorderDetailOperationParamsDTO** | [**CrossBorderDetailOperationParamsDTO**](CrossBorderDetailOperationParamsDTO.md) | Parameters for operations |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryficrossborderoperationpost"></a>
# **ApiV1EnvironmentFIGLEntryFICrossBorderOperationPost**
> ValidateDTO ApiV1EnvironmentFIGLEntryFICrossBorderOperationPost (string environment, string authorizationScope, CrossBorderOperationParamsDTO crossBorderOperationParamsDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Cross-border operations

Cross-border operations

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFICrossBorderOperationPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var crossBorderOperationParamsDTO = new CrossBorderOperationParamsDTO(); // CrossBorderOperationParamsDTO | Parameters for operations 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Cross-border operations
                ValidateDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFICrossBorderOperationPost(environment, authorizationScope, crossBorderOperationParamsDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFICrossBorderOperationPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFICrossBorderOperationPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Cross-border operations
    ApiResponse<ValidateDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFICrossBorderOperationPostWithHttpInfo(environment, authorizationScope, crossBorderOperationParamsDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFICrossBorderOperationPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **crossBorderOperationParamsDTO** | [**CrossBorderOperationParamsDTO**](CrossBorderOperationParamsDTO.md) | Parameters for operations  |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfidecumulatecalculationpost"></a>
# **ApiV1EnvironmentFIGLEntryFIDecumulateCalculationPost**
> DecumulateCalculationResultDTO ApiV1EnvironmentFIGLEntryFIDecumulateCalculationPost (string environment, string authorizationScope, DecumulateCalculationParametersDTO decumulateCalculationParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Percentage unbundling calculation

Calculate the value resulting from the separation of the percentage requested on the initial amount indicated

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIDecumulateCalculationPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var decumulateCalculationParametersDTO = new DecumulateCalculationParametersDTO(); // DecumulateCalculationParametersDTO | Input parameters for calculation
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Percentage unbundling calculation
                DecumulateCalculationResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIDecumulateCalculationPost(environment, authorizationScope, decumulateCalculationParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIDecumulateCalculationPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIDecumulateCalculationPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Percentage unbundling calculation
    ApiResponse<DecumulateCalculationResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIDecumulateCalculationPostWithHttpInfo(environment, authorizationScope, decumulateCalculationParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIDecumulateCalculationPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **decumulateCalculationParametersDTO** | [**DecumulateCalculationParametersDTO**](DecumulateCalculationParametersDTO.md) | Input parameters for calculation |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**DecumulateCalculationResultDTO**](DecumulateCalculationResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Detached value of the requested percentage |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfideleteclosingreopeningpost"></a>
# **ApiV1EnvironmentFIGLEntryFIDeleteClosingReopeningPost**
> DeleteClosingReopeningResultDTO ApiV1EnvironmentFIGLEntryFIDeleteClosingReopeningPost (string environment, string authorizationScope, DeleteClosingReopeningParamsDTO deleteClosingReopeningParamsDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Eliminates the records of the tables related to an accounting processing

Eliminates the records of the tables related to an accounting processing

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIDeleteClosingReopeningPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var deleteClosingReopeningParamsDTO = new DeleteClosingReopeningParamsDTO(); // DeleteClosingReopeningParamsDTO | An object that contains all the parameters that are used in the processing
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Eliminates the records of the tables related to an accounting processing
                DeleteClosingReopeningResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIDeleteClosingReopeningPost(environment, authorizationScope, deleteClosingReopeningParamsDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIDeleteClosingReopeningPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIDeleteClosingReopeningPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Eliminates the records of the tables related to an accounting processing
    ApiResponse<DeleteClosingReopeningResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIDeleteClosingReopeningPostWithHttpInfo(environment, authorizationScope, deleteClosingReopeningParamsDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIDeleteClosingReopeningPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **deleteClosingReopeningParamsDTO** | [**DeleteClosingReopeningParamsDTO**](DeleteClosingReopeningParamsDTO.md) | An object that contains all the parameters that are used in the processing |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**DeleteClosingReopeningResultDTO**](DeleteClosingReopeningResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Deletion result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfideleteexchangedifferencepost"></a>
# **ApiV1EnvironmentFIGLEntryFIDeleteExchangeDifferencePost**
> DeleteExchangeDifferenceResultDTO ApiV1EnvironmentFIGLEntryFIDeleteExchangeDifferencePost (string environment, string authorizationScope, DeleteExchangeDifferenceParamsDTO deleteExchangeDifferenceParamsDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Eliminates the records of the tables related to an accounting processing

Eliminates the records of the tables related to an accounting processing

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIDeleteExchangeDifferencePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var deleteExchangeDifferenceParamsDTO = new DeleteExchangeDifferenceParamsDTO(); // DeleteExchangeDifferenceParamsDTO | An object that contains all the parameters that are used in the processing
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Eliminates the records of the tables related to an accounting processing
                DeleteExchangeDifferenceResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIDeleteExchangeDifferencePost(environment, authorizationScope, deleteExchangeDifferenceParamsDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIDeleteExchangeDifferencePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIDeleteExchangeDifferencePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Eliminates the records of the tables related to an accounting processing
    ApiResponse<DeleteExchangeDifferenceResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIDeleteExchangeDifferencePostWithHttpInfo(environment, authorizationScope, deleteExchangeDifferenceParamsDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIDeleteExchangeDifferencePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **deleteExchangeDifferenceParamsDTO** | [**DeleteExchangeDifferenceParamsDTO**](DeleteExchangeDifferenceParamsDTO.md) | An object that contains all the parameters that are used in the processing |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**DeleteExchangeDifferenceResultDTO**](DeleteExchangeDifferenceResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Deletion result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfienabledtoprojectspost"></a>
# **ApiV1EnvironmentFIGLEntryFIEnabledtoprojectsPost**
> FIGLEntriesExecutionResultDTO ApiV1EnvironmentFIGLEntryFIEnabledtoprojectsPost (string environment, string authorizationScope, GLEntryFIParametersDTO gLEntryFIParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Check if the gl entry can open project entries

Check if the gl entry can open project entries

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIEnabledtoprojectsPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var gLEntryFIParametersDTO = new GLEntryFIParametersDTO(); // GLEntryFIParametersDTO | Registration number to check
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Check if the gl entry can open project entries
                FIGLEntriesExecutionResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIEnabledtoprojectsPost(environment, authorizationScope, gLEntryFIParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIEnabledtoprojectsPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIEnabledtoprojectsPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Check if the gl entry can open project entries
    ApiResponse<FIGLEntriesExecutionResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIEnabledtoprojectsPostWithHttpInfo(environment, authorizationScope, gLEntryFIParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIEnabledtoprojectsPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **gLEntryFIParametersDTO** | [**GLEntryFIParametersDTO**](GLEntryFIParametersDTO.md) | Registration number to check |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Returs if the project entries are enabled or not |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfifilterglentriespost"></a>
# **ApiV1EnvironmentFIGLEntryFIFilterglentriesPost**
> FilterGlentriesResultDTO ApiV1EnvironmentFIGLEntryFIFilterglentriesPost (string environment, string authorizationScope, FilterGLEntriesParamsDTO filterGLEntriesParamsDTO, string? company = null, string? user = null, string? acceptLanguage = null)

FilterGlentries

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIFilterglentriesPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var filterGLEntriesParamsDTO = new FilterGLEntriesParamsDTO(); // FilterGLEntriesParamsDTO | Input parameters for elaboration
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // FilterGlentries
                FilterGlentriesResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIFilterglentriesPost(environment, authorizationScope, filterGLEntriesParamsDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIFilterglentriesPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIFilterglentriesPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // FilterGlentries
    ApiResponse<FilterGlentriesResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIFilterglentriesPostWithHttpInfo(environment, authorizationScope, filterGLEntriesParamsDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIFilterglentriesPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **filterGLEntriesParamsDTO** | [**FilterGLEntriesParamsDTO**](FilterGLEntriesParamsDTO.md) | Input parameters for elaboration |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**FilterGlentriesResultDTO**](FilterGlentriesResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** |  |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiglentrypartialvalidatepost"></a>
# **ApiV1EnvironmentFIGLEntryFIGLEntryPartialValidatePost**
> GLEntryFIDTO ApiV1EnvironmentFIGLEntryFIGLEntryPartialValidatePost (string force, string environment, string authorizationScope, GLEntryFIDTO gLEntryFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

GL ENtry Header validations

Verify that the header informations of a GLEntryFI element are correct

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIGLEntryPartialValidatePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var force = "force_example";  // string | force
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var gLEntryFIDTO = new GLEntryFIDTO(); // GLEntryFIDTO | The gl entry to validate
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // GL ENtry Header validations
                GLEntryFIDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIGLEntryPartialValidatePost(force, environment, authorizationScope, gLEntryFIDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGLEntryPartialValidatePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIGLEntryPartialValidatePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // GL ENtry Header validations
    ApiResponse<GLEntryFIDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIGLEntryPartialValidatePostWithHttpInfo(force, environment, authorizationScope, gLEntryFIDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGLEntryPartialValidatePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **force** | **string** | force |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **gLEntryFIDTO** | [**GLEntryFIDTO**](GLEntryFIDTO.md) | The gl entry to validate |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**GLEntryFIDTO**](GLEntryFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Input Value |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | Error list found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiget"></a>
# **ApiV1EnvironmentFIGLEntryFIGet**
> GLEntryFIDTO ApiV1EnvironmentFIGLEntryFIGet (string op, string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null)

Get new

Get an empty object of type corresponding

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var op = "op_example";  // string | The value must be 'new'
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get new
                GLEntryFIDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIGet(op, environment, authorizationScope, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get new
    ApiResponse<GLEntryFIDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIGetWithHttpInfo(op, environment, authorizationScope, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **op** | **string** | The value must be &#39;new&#39; |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**GLEntryFIDTO**](GLEntryFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The empty object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfigetapplicationversionpost"></a>
# **ApiV1EnvironmentFIGLEntryFIGetApplicationVersionPost**
> ValidateDTO ApiV1EnvironmentFIGLEntryFIGetApplicationVersionPost (string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null, ApplicationVersionResultDTO? applicationVersionResultDTO = null)

Application version reading

Get the application version identifiers

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIGetApplicationVersionPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)
            var applicationVersionResultDTO = new ApplicationVersionResultDTO?(); // ApplicationVersionResultDTO? | Input parameters for caculation (optional) 

            try
            {
                // Application version reading
                ValidateDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIGetApplicationVersionPost(environment, authorizationScope, company, user, acceptLanguage, applicationVersionResultDTO);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetApplicationVersionPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIGetApplicationVersionPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Application version reading
    ApiResponse<ValidateDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIGetApplicationVersionPostWithHttpInfo(environment, authorizationScope, company, user, acceptLanguage, applicationVersionResultDTO);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetApplicationVersionPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |
| **applicationVersionResultDTO** | [**ApplicationVersionResultDTO?**](ApplicationVersionResultDTO?.md) | Input parameters for caculation | [optional]  |

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Application version informations |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfigetbusinesstypedatadefaultpost"></a>
# **ApiV1EnvironmentFIGLEntryFIGetBusinessTypeDataDefaultPost**
> BusinessTypeDataDefaultResultDTO ApiV1EnvironmentFIGLEntryFIGetBusinessTypeDataDefaultPost (string environment, string authorizationScope, BusinessTypeDataDefaultParamsDTO businessTypeDataDefaultParamsDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Get default dbsiness type data

Get default dbsiness type data

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIGetBusinessTypeDataDefaultPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var businessTypeDataDefaultParamsDTO = new BusinessTypeDataDefaultParamsDTO(); // BusinessTypeDataDefaultParamsDTO | Input params
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get default dbsiness type data
                BusinessTypeDataDefaultResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIGetBusinessTypeDataDefaultPost(environment, authorizationScope, businessTypeDataDefaultParamsDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetBusinessTypeDataDefaultPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIGetBusinessTypeDataDefaultPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get default dbsiness type data
    ApiResponse<BusinessTypeDataDefaultResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIGetBusinessTypeDataDefaultPostWithHttpInfo(environment, authorizationScope, businessTypeDataDefaultParamsDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetBusinessTypeDataDefaultPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **businessTypeDataDefaultParamsDTO** | [**BusinessTypeDataDefaultParamsDTO**](BusinessTypeDataDefaultParamsDTO.md) | Input params |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**BusinessTypeDataDefaultResultDTO**](BusinessTypeDataDefaultResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfigeteligibleidsfrombankmovementspost"></a>
# **ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankMovementsPost**
> IdsListFIDTO ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankMovementsPost (string environment, string authorizationScope, GLEntryFICreateFromBankMovementsParameters gLEntryFICreateFromBankMovementsParameters, string? company = null, string? user = null, string? acceptLanguage = null)

Request the list of bank movements to account

Request the list of bank movements to be accounted

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankMovementsPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var gLEntryFICreateFromBankMovementsParameters = new GLEntryFICreateFromBankMovementsParameters(); // GLEntryFICreateFromBankMovementsParameters | Input params
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Request the list of bank movements to account
                IdsListFIDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankMovementsPost(environment, authorizationScope, gLEntryFICreateFromBankMovementsParameters, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankMovementsPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankMovementsPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Request the list of bank movements to account
    ApiResponse<IdsListFIDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankMovementsPostWithHttpInfo(environment, authorizationScope, gLEntryFICreateFromBankMovementsParameters, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankMovementsPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **gLEntryFICreateFromBankMovementsParameters** | [**GLEntryFICreateFromBankMovementsParameters**](GLEntryFICreateFromBankMovementsParameters.md) | Input params |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**IdsListFIDTO**](IdsListFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The list of bank entries to account |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfigeteligibleidsfrombankreconcilemovementspost"></a>
# **ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankReconcileMovementsPost**
> IdsListFIDTO ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankReconcileMovementsPost (string environment, string authorizationScope, IdFIDTO idFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Request the list of reconcilable bank transactions

Request the list of reconcilable bank transactions

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankReconcileMovementsPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var idFIDTO = new IdFIDTO(); // IdFIDTO | Input params
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Request the list of reconcilable bank transactions
                IdsListFIDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankReconcileMovementsPost(environment, authorizationScope, idFIDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankReconcileMovementsPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankReconcileMovementsPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Request the list of reconcilable bank transactions
    ApiResponse<IdsListFIDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankReconcileMovementsPostWithHttpInfo(environment, authorizationScope, idFIDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankReconcileMovementsPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **idFIDTO** | [**IdFIDTO**](IdFIDTO.md) | Input params |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**IdsListFIDTO**](IdsListFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | List of reconcilable bank transactions |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfigeteligibleidsfromtsdigitalpost"></a>
# **ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromTsDigitalPost**
> IdsListFIDTO ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromTsDigitalPost (string environment, string authorizationScope, IdFIDTO idFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Request the list of TsDigital movements to account

Request the list of TsDigital movements to be accounted

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromTsDigitalPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var idFIDTO = new IdFIDTO(); // IdFIDTO | Input params
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Request the list of TsDigital movements to account
                IdsListFIDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromTsDigitalPost(environment, authorizationScope, idFIDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromTsDigitalPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromTsDigitalPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Request the list of TsDigital movements to account
    ApiResponse<IdsListFIDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromTsDigitalPostWithHttpInfo(environment, authorizationScope, idFIDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetEligibleIdsFromTsDigitalPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **idFIDTO** | [**IdFIDTO**](IdFIDTO.md) | Input params |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**IdsListFIDTO**](IdsListFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The list of TsDigital entries to account |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfigetfilefepapasscopost"></a>
# **ApiV1EnvironmentFIGLEntryFIGetFileFepaPassCOPost**
> FilesFepaPassCODTO ApiV1EnvironmentFIGLEntryFIGetFileFepaPassCOPost (string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null, IdFIDTO? idFIDTO = null)

Read by key B2B file Fepa pass and fix it

Read by key B2B file Fepa pass and fix it

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIGetFileFepaPassCOPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)
            var idFIDTO = new IdFIDTO?(); // IdFIDTO? | Input parameters for caculation (optional) 

            try
            {
                // Read by key B2B file Fepa pass and fix it
                FilesFepaPassCODTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIGetFileFepaPassCOPost(environment, authorizationScope, company, user, acceptLanguage, idFIDTO);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetFileFepaPassCOPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIGetFileFepaPassCOPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Read by key B2B file Fepa pass and fix it
    ApiResponse<FilesFepaPassCODTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIGetFileFepaPassCOPostWithHttpInfo(environment, authorizationScope, company, user, acceptLanguage, idFIDTO);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetFileFepaPassCOPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |
| **idFIDTO** | [**IdFIDTO?**](IdFIDTO?.md) | Input parameters for caculation | [optional]  |

### Return type

[**FilesFepaPassCODTO**](FilesFepaPassCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | DTO of entity FilesFepaPassCO |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfigetglentryaccountingreasoncodedataget"></a>
# **ApiV1EnvironmentFIGLEntryFIGetGLEntryAccountingReasonCodeDataGet**
> GLEntryFIAdditionalDataResultDTO ApiV1EnvironmentFIGLEntryFIGetGLEntryAccountingReasonCodeDataGet (string numreg, string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null)

Data reading for accounting reason code

Returns the minimum data of the accounting reason relating to the numreg supplied as a parameter

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIGetGLEntryAccountingReasonCodeDataGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var numreg = "numreg_example";  // string | numreg
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Data reading for accounting reason code
                GLEntryFIAdditionalDataResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIGetGLEntryAccountingReasonCodeDataGet(numreg, environment, authorizationScope, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetGLEntryAccountingReasonCodeDataGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIGetGLEntryAccountingReasonCodeDataGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Data reading for accounting reason code
    ApiResponse<GLEntryFIAdditionalDataResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIGetGLEntryAccountingReasonCodeDataGetWithHttpInfo(numreg, environment, authorizationScope, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetGLEntryAccountingReasonCodeDataGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **numreg** | **string** | numreg |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**GLEntryFIAdditionalDataResultDTO**](GLEntryFIAdditionalDataResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Data of accounting reason code |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfigetglentryadditionaldatapost"></a>
# **ApiV1EnvironmentFIGLEntryFIGetGLEntryAdditionalDataPost**
> GLEntryFIAdditionalDataResultDTO ApiV1EnvironmentFIGLEntryFIGetGLEntryAdditionalDataPost (string environment, string authorizationScope, GLEntryFIAdditionalDataParametersDTO gLEntryFIAdditionalDataParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Data reading for withholdings deadlines

Calculates the values ​​necessary to determine the withholding taxes / deadlines for the required registration

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIGetGLEntryAdditionalDataPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var gLEntryFIAdditionalDataParametersDTO = new GLEntryFIAdditionalDataParametersDTO(); // GLEntryFIAdditionalDataParametersDTO | Id/StageGuid entry
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Data reading for withholdings deadlines
                GLEntryFIAdditionalDataResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIGetGLEntryAdditionalDataPost(environment, authorizationScope, gLEntryFIAdditionalDataParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetGLEntryAdditionalDataPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIGetGLEntryAdditionalDataPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Data reading for withholdings deadlines
    ApiResponse<GLEntryFIAdditionalDataResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIGetGLEntryAdditionalDataPostWithHttpInfo(environment, authorizationScope, gLEntryFIAdditionalDataParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetGLEntryAdditionalDataPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **gLEntryFIAdditionalDataParametersDTO** | [**GLEntryFIAdditionalDataParametersDTO**](GLEntryFIAdditionalDataParametersDTO.md) | Id/StageGuid entry |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**GLEntryFIAdditionalDataResultDTO**](GLEntryFIAdditionalDataResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Data for withholdings / deadlines |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfigetglentryoffsetpost"></a>
# **ApiV1EnvironmentFIGLEntryFIGetGLEntryOffSetPost**
> GLEntryFIOffSetSummaryResultDTO ApiV1EnvironmentFIGLEntryFIGetGLEntryOffSetPost (string environment, string authorizationScope, GLEntryFIKeyDTO gLEntryFIKeyDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Get gl entry off set

Get gl entry off set

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIGetGLEntryOffSetPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var gLEntryFIKeyDTO = new GLEntryFIKeyDTO(); // GLEntryFIKeyDTO | Input params
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get gl entry off set
                GLEntryFIOffSetSummaryResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIGetGLEntryOffSetPost(environment, authorizationScope, gLEntryFIKeyDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetGLEntryOffSetPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIGetGLEntryOffSetPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get gl entry off set
    ApiResponse<GLEntryFIOffSetSummaryResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIGetGLEntryOffSetPostWithHttpInfo(environment, authorizationScope, gLEntryFIKeyDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetGLEntryOffSetPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **gLEntryFIKeyDTO** | [**GLEntryFIKeyDTO**](GLEntryFIKeyDTO.md) | Input params |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**GLEntryFIOffSetSummaryResultDTO**](GLEntryFIOffSetSummaryResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfigetlinkedentriesfromnumregpost"></a>
# **ApiV1EnvironmentFIGLEntryFIGetLinkedEntriesFromNumregPost**
> GLEntryFIGetLinkedEntriesFromNumregResultsDTO ApiV1EnvironmentFIGLEntryFIGetLinkedEntriesFromNumregPost (string environment, string authorizationScope, GLEntryFIGetLinkedEntriesFromNumregParametersDTO gLEntryFIGetLinkedEntriesFromNumregParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Returns all gl entries starting from a registration number.

Search for the parent registration and all related registrations of which the entered registration number is a part

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIGetLinkedEntriesFromNumregPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var gLEntryFIGetLinkedEntriesFromNumregParametersDTO = new GLEntryFIGetLinkedEntriesFromNumregParametersDTO(); // GLEntryFIGetLinkedEntriesFromNumregParametersDTO | Id or registration number to find
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Returns all gl entries starting from a registration number.
                GLEntryFIGetLinkedEntriesFromNumregResultsDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIGetLinkedEntriesFromNumregPost(environment, authorizationScope, gLEntryFIGetLinkedEntriesFromNumregParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetLinkedEntriesFromNumregPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIGetLinkedEntriesFromNumregPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Returns all gl entries starting from a registration number.
    ApiResponse<GLEntryFIGetLinkedEntriesFromNumregResultsDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIGetLinkedEntriesFromNumregPostWithHttpInfo(environment, authorizationScope, gLEntryFIGetLinkedEntriesFromNumregParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetLinkedEntriesFromNumregPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **gLEntryFIGetLinkedEntriesFromNumregParametersDTO** | [**GLEntryFIGetLinkedEntriesFromNumregParametersDTO**](GLEntryFIGetLinkedEntriesFromNumregParametersDTO.md) | Id or registration number to find |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**GLEntryFIGetLinkedEntriesFromNumregResultsDTO**](GLEntryFIGetLinkedEntriesFromNumregResultsDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Parent entry and all related entries |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfigetnumregbydetailidpost"></a>
# **ApiV1EnvironmentFIGLEntryFIGetNumregByDetailIdPost**
> GLEntryNumregResultDTO ApiV1EnvironmentFIGLEntryFIGetNumregByDetailIdPost (string environment, string authorizationScope, IdFIDTO idFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Get GLEntry numreg by detail id

Get GLEntry numreg starting from a detail id

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIGetNumregByDetailIdPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var idFIDTO = new IdFIDTO(); // IdFIDTO | An object that contains all the parameters that are used in the processing
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get GLEntry numreg by detail id
                GLEntryNumregResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIGetNumregByDetailIdPost(environment, authorizationScope, idFIDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetNumregByDetailIdPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIGetNumregByDetailIdPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get GLEntry numreg by detail id
    ApiResponse<GLEntryNumregResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIGetNumregByDetailIdPostWithHttpInfo(environment, authorizationScope, idFIDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetNumregByDetailIdPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **idFIDTO** | [**IdFIDTO**](IdFIDTO.md) | An object that contains all the parameters that are used in the processing |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**GLEntryNumregResultDTO**](GLEntryNumregResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Update result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfigettracciatodocumentalepost"></a>
# **ApiV1EnvironmentFIGLEntryFIGetTracciatoDocumentalePost**
> FIGLEntriesExecutionResultDTO ApiV1EnvironmentFIGLEntryFIGetTracciatoDocumentalePost (string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null)

Retrieve document track

Retrieve document track

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIGetTracciatoDocumentalePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Retrieve document track
                FIGLEntriesExecutionResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIGetTracciatoDocumentalePost(environment, authorizationScope, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetTracciatoDocumentalePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIGetTracciatoDocumentalePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Retrieve document track
    ApiResponse<FIGLEntriesExecutionResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIGetTracciatoDocumentalePostWithHttpInfo(environment, authorizationScope, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetTracciatoDocumentalePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Document track |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfigetvatregistryresultpost"></a>
# **ApiV1EnvironmentFIGLEntryFIGetVatRegistryResultPost**
> VatRegisterSerializedResultDTO ApiV1EnvironmentFIGLEntryFIGetVatRegistryResultPost (string environment, string authorizationScope, VatRegistryResultParametersDTO vatRegistryResultParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Get vat registry result

Get vat registry result

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIGetVatRegistryResultPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var vatRegistryResultParametersDTO = new VatRegistryResultParametersDTO(); // VatRegistryResultParametersDTO | Input params
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get vat registry result
                VatRegisterSerializedResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIGetVatRegistryResultPost(environment, authorizationScope, vatRegistryResultParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetVatRegistryResultPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIGetVatRegistryResultPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get vat registry result
    ApiResponse<VatRegisterSerializedResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIGetVatRegistryResultPostWithHttpInfo(environment, authorizationScope, vatRegistryResultParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetVatRegistryResultPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **vatRegistryResultParametersDTO** | [**VatRegistryResultParametersDTO**](VatRegistryResultParametersDTO.md) | Input params |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**VatRegisterSerializedResultDTO**](VatRegisterSerializedResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfigetxsltpost"></a>
# **ApiV1EnvironmentFIGLEntryFIGetxsltPost**
> XSLTResultDTO ApiV1EnvironmentFIGLEntryFIGetxsltPost (string environment, string authorizationScope, GLEntryFIGetXSLTParameters gLEntryFIGetXSLTParameters, string? company = null, string? user = null, string? acceptLanguage = null)

Get XSLT

Get XSLT

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIGetxsltPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var gLEntryFIGetXSLTParameters = new GLEntryFIGetXSLTParameters(); // GLEntryFIGetXSLTParameters | Input params
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get XSLT
                XSLTResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIGetxsltPost(environment, authorizationScope, gLEntryFIGetXSLTParameters, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetxsltPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIGetxsltPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get XSLT
    ApiResponse<XSLTResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIGetxsltPostWithHttpInfo(environment, authorizationScope, gLEntryFIGetXSLTParameters, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIGetxsltPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **gLEntryFIGetXSLTParameters** | [**GLEntryFIGetXSLTParameters**](GLEntryFIGetXSLTParameters.md) | Input params |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**XSLTResultDTO**](XSLTResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | XSLT |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiiddelete"></a>
# **ApiV1EnvironmentFIGLEntryFIIdDelete**
> void ApiV1EnvironmentFIGLEntryFIIdDelete (string id, string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null)

Delete

Deleting object of type 

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIIdDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var id = "id_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Delete
                apiInstance.ApiV1EnvironmentFIGLEntryFIIdDelete(id, environment, authorizationScope, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIIdDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIIdDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete
    apiInstance.ApiV1EnvironmentFIGLEntryFIIdDeleteWithHttpInfo(id, environment, authorizationScope, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIIdDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object has been deleted |  -  |
| **400** | if object has not been deleted: the content response contains the validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |
| **409** | If object has not been deleted due to business rules violation: the content response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiidget"></a>
# **ApiV1EnvironmentFIGLEntryFIIdGet**
> GLEntryFIDTO ApiV1EnvironmentFIGLEntryFIIdGet (string id, string environment, string authorizationScope, string? dlevel = null, string? dlevelkey = null, string? company = null, string? user = null, string? acceptLanguage = null)

Get by ID

Get an object of type corresponding the requested id

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIIdGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var id = "id_example";  // string | Id to get the object
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var dlevel = "dlevel_example";  // string? | Serialization level (optional) 
            var dlevelkey = "dlevelkey_example";  // string? | Serialization level key (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get by ID
                GLEntryFIDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIIdGet(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIIdGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIIdGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get by ID
    ApiResponse<GLEntryFIDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIIdGetWithHttpInfo(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIIdGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** | Id to get the object |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **dlevel** | **string?** | Serialization level | [optional]  |
| **dlevelkey** | **string?** | Serialization level key | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**GLEntryFIDTO**](GLEntryFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiidpatch"></a>
# **ApiV1EnvironmentFIGLEntryFIIdPatch**
> void ApiV1EnvironmentFIGLEntryFIIdPatch (string id, string environment, string authorizationScope, Object body, string? force = null, string? op = null, string? company = null, string? user = null, string? acceptLanguage = null)

Update partial

Patching an object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIIdPatchExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var id = "id_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var body = null;  // Object | Object of type to patch
            var force = "force_example";  // string? | The warning/s code to bypass (separated by ‘,’) during the execution (optional) 
            var op = "op_example";  // string? | Set 'reload', if you want the DTO updated in the response request (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Update partial
                apiInstance.ApiV1EnvironmentFIGLEntryFIIdPatch(id, environment, authorizationScope, body, force, op, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIIdPatch: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIIdPatchWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update partial
    apiInstance.ApiV1EnvironmentFIGLEntryFIIdPatchWithHttpInfo(id, environment, authorizationScope, body, force, op, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIIdPatchWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **body** | **Object** | Object of type to patch |  |
| **force** | **string?** | The warning/s code to bypass (separated by ‘,’) during the execution | [optional]  |
| **op** | **string?** | Set &#39;reload&#39;, if you want the DTO updated in the response request | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object has been updated |  -  |
| **400** | If the object has not been patched: the content response contains the validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |
| **409** | If object has not been patched due to business rules violation: the content response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiidput"></a>
# **ApiV1EnvironmentFIGLEntryFIIdPut**
> GLEntryFIDTO ApiV1EnvironmentFIGLEntryFIIdPut (string id, string environment, string authorizationScope, GLEntryFIDTO gLEntryFIDTO, string? force = null, string? op = null, string? company = null, string? user = null, string? acceptLanguage = null)

Update

Updating an object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIIdPutExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var id = "id_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var gLEntryFIDTO = new GLEntryFIDTO(); // GLEntryFIDTO | Object of type to update
            var force = "force_example";  // string? | The warning/s code to bypass (separated by ‘,’) during the execution (optional) 
            var op = "op_example";  // string? | Set 'reload', if you want the DTO updated in the response request, otherwise will be returned null value (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Update
                GLEntryFIDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIIdPut(id, environment, authorizationScope, gLEntryFIDTO, force, op, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIIdPut: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIIdPutWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update
    ApiResponse<GLEntryFIDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIIdPutWithHttpInfo(id, environment, authorizationScope, gLEntryFIDTO, force, op, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIIdPutWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **gLEntryFIDTO** | [**GLEntryFIDTO**](GLEntryFIDTO.md) | Object of type to update |  |
| **force** | **string?** | The warning/s code to bypass (separated by ‘,’) during the execution | [optional]  |
| **op** | **string?** | Set &#39;reload&#39;, if you want the DTO updated in the response request, otherwise will be returned null value | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**GLEntryFIDTO**](GLEntryFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object has been updated |  -  |
| **400** | If the object has not been updated: the content response contains the validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |
| **409** | If object has not been updated due to business rules violation: the content response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiimportdocb2bfilefepapasspost"></a>
# **ApiV1EnvironmentFIGLEntryFIImportDocB2BFileFepaPassPost**
> FIGLEntriesExecutionResultDTO ApiV1EnvironmentFIGLEntryFIImportDocB2BFileFepaPassPost (string environment, string authorizationScope, TsDigitalImportDocParametersDTO tsDigitalImportDocParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Import B2B file Fepa pass

Import B2B file Fepa pass

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIImportDocB2BFileFepaPassPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var tsDigitalImportDocParametersDTO = new TsDigitalImportDocParametersDTO(); // TsDigitalImportDocParametersDTO | Input Params
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Import B2B file Fepa pass
                FIGLEntriesExecutionResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIImportDocB2BFileFepaPassPost(environment, authorizationScope, tsDigitalImportDocParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIImportDocB2BFileFepaPassPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIImportDocB2BFileFepaPassPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Import B2B file Fepa pass
    ApiResponse<FIGLEntriesExecutionResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIImportDocB2BFileFepaPassPostWithHttpInfo(environment, authorizationScope, tsDigitalImportDocParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIImportDocB2BFileFepaPassPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **tsDigitalImportDocParametersDTO** | [**TsDigitalImportDocParametersDTO**](TsDigitalImportDocParametersDTO.md) | Input Params |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiimportinvoicefepapassfipost"></a>
# **ApiV1EnvironmentFIGLEntryFIImportInvoiceFepaPassFIPost**
> ImportInvoiceFepaPassResultDTO ApiV1EnvironmentFIGLEntryFIImportInvoiceFepaPassFIPost (string environment, string authorizationScope, ImportInvoiceFepaPassParamsDTO importInvoiceFepaPassParamsDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Import file Fepa pass

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIImportInvoiceFepaPassFIPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var importInvoiceFepaPassParamsDTO = new ImportInvoiceFepaPassParamsDTO(); // ImportInvoiceFepaPassParamsDTO | Input parameters for reelaborate
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Import file Fepa pass
                ImportInvoiceFepaPassResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIImportInvoiceFepaPassFIPost(environment, authorizationScope, importInvoiceFepaPassParamsDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIImportInvoiceFepaPassFIPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIImportInvoiceFepaPassFIPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Import file Fepa pass
    ApiResponse<ImportInvoiceFepaPassResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIImportInvoiceFepaPassFIPostWithHttpInfo(environment, authorizationScope, importInvoiceFepaPassParamsDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIImportInvoiceFepaPassFIPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **importInvoiceFepaPassParamsDTO** | [**ImportInvoiceFepaPassParamsDTO**](ImportInvoiceFepaPassParamsDTO.md) | Input parameters for reelaborate |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**ImportInvoiceFepaPassResultDTO**](ImportInvoiceFepaPassResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** |  |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiinsertmissingexchangeratespost"></a>
# **ApiV1EnvironmentFIGLEntryFIInsertmissingexchangeratesPost**
> InsertMissingExchangeRatesResultDTO ApiV1EnvironmentFIGLEntryFIInsertmissingexchangeratesPost (string environment, string authorizationScope, InsertMissingExchangeRatesParamsDTO insertMissingExchangeRatesParamsDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Insert missing exchange rate

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIInsertmissingexchangeratesPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var insertMissingExchangeRatesParamsDTO = new InsertMissingExchangeRatesParamsDTO(); // InsertMissingExchangeRatesParamsDTO | Input parameters for elaboration
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Insert missing exchange rate
                InsertMissingExchangeRatesResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIInsertmissingexchangeratesPost(environment, authorizationScope, insertMissingExchangeRatesParamsDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIInsertmissingexchangeratesPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIInsertmissingexchangeratesPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Insert missing exchange rate
    ApiResponse<InsertMissingExchangeRatesResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIInsertmissingexchangeratesPostWithHttpInfo(environment, authorizationScope, insertMissingExchangeRatesParamsDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIInsertmissingexchangeratesPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **insertMissingExchangeRatesParamsDTO** | [**InsertMissingExchangeRatesParamsDTO**](InsertMissingExchangeRatesParamsDTO.md) | Input parameters for elaboration |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InsertMissingExchangeRatesResultDTO**](InsertMissingExchangeRatesResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** |  |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiischecklistenabledget"></a>
# **ApiV1EnvironmentFIGLEntryFIIsCheckListEnabledGet**
> bool ApiV1EnvironmentFIGLEntryFIIsCheckListEnabledGet (string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null)

Returns if the checklist functionality on glentry landing is enabled

Returns if the checklist functionality on glentry landing is enabled

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIIsCheckListEnabledGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Returns if the checklist functionality on glentry landing is enabled
                bool result = apiInstance.ApiV1EnvironmentFIGLEntryFIIsCheckListEnabledGet(environment, authorizationScope, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIIsCheckListEnabledGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIIsCheckListEnabledGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Returns if the checklist functionality on glentry landing is enabled
    ApiResponse<bool> response = apiInstance.ApiV1EnvironmentFIGLEntryFIIsCheckListEnabledGetWithHttpInfo(environment, authorizationScope, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIIsCheckListEnabledGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

**bool**

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The checklist functionality is enabled |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfimoduleintegrationinfosupdatepost"></a>
# **ApiV1EnvironmentFIGLEntryFIModuleintegrationinfosupdatePost**
> GLEntryFIModuleIntegrationInfosUpdateResultDTO ApiV1EnvironmentFIGLEntryFIModuleintegrationinfosupdatePost (string environment, string authorizationScope, GLEntryFIModuleIntegrationInfosUpdateParamsDTO gLEntryFIModuleIntegrationInfosUpdateParamsDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Updates module integration infos

Updates module integration infos related to a glentry

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIModuleintegrationinfosupdatePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var gLEntryFIModuleIntegrationInfosUpdateParamsDTO = new GLEntryFIModuleIntegrationInfosUpdateParamsDTO(); // GLEntryFIModuleIntegrationInfosUpdateParamsDTO | An object that contains all the parameters that are used in the processing
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Updates module integration infos
                GLEntryFIModuleIntegrationInfosUpdateResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIModuleintegrationinfosupdatePost(environment, authorizationScope, gLEntryFIModuleIntegrationInfosUpdateParamsDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIModuleintegrationinfosupdatePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIModuleintegrationinfosupdatePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Updates module integration infos
    ApiResponse<GLEntryFIModuleIntegrationInfosUpdateResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIModuleintegrationinfosupdatePostWithHttpInfo(environment, authorizationScope, gLEntryFIModuleIntegrationInfosUpdateParamsDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIModuleintegrationinfosupdatePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **gLEntryFIModuleIntegrationInfosUpdateParamsDTO** | [**GLEntryFIModuleIntegrationInfosUpdateParamsDTO**](GLEntryFIModuleIntegrationInfosUpdateParamsDTO.md) | An object that contains all the parameters that are used in the processing |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**GLEntryFIModuleIntegrationInfosUpdateResultDTO**](GLEntryFIModuleIntegrationInfosUpdateResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Update result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfimulticreatepost"></a>
# **ApiV1EnvironmentFIGLEntryFIMulticreatePost**
> CollectionBaseResultDTO ApiV1EnvironmentFIGLEntryFIMulticreatePost (string environment, string authorizationScope, GLEntryFIMultipleDTOCollectionBaseDTO gLEntryFIMultipleDTOCollectionBaseDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Multiple creation of gl entries

Multiple creation of gl entries

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIMulticreatePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var gLEntryFIMultipleDTOCollectionBaseDTO = new GLEntryFIMultipleDTOCollectionBaseDTO(); // GLEntryFIMultipleDTOCollectionBaseDTO | List of accounting entries to be entered
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Multiple creation of gl entries
                CollectionBaseResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIMulticreatePost(environment, authorizationScope, gLEntryFIMultipleDTOCollectionBaseDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIMulticreatePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIMulticreatePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Multiple creation of gl entries
    ApiResponse<CollectionBaseResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIMulticreatePostWithHttpInfo(environment, authorizationScope, gLEntryFIMultipleDTOCollectionBaseDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIMulticreatePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **gLEntryFIMultipleDTOCollectionBaseDTO** | [**GLEntryFIMultipleDTOCollectionBaseDTO**](GLEntryFIMultipleDTOCollectionBaseDTO.md) | List of accounting entries to be entered |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**CollectionBaseResultDTO**](CollectionBaseResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Multiple entry result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfimultiplecreatejobpost"></a>
# **ApiV1EnvironmentFIGLEntryFIMultiplecreatejobPost**
> CreateMultiGLEntryJobResultDTO ApiV1EnvironmentFIGLEntryFIMultiplecreatejobPost (string environment, string authorizationScope, CreateMultiGLEntryJobParamsDTO createMultiGLEntryJobParamsDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Job creation of multiple entry of gl entries

Job creation of multiple entry of gl entries

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIMultiplecreatejobPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var createMultiGLEntryJobParamsDTO = new CreateMultiGLEntryJobParamsDTO(); // CreateMultiGLEntryJobParamsDTO | List of entries to insert 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Job creation of multiple entry of gl entries
                CreateMultiGLEntryJobResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIMultiplecreatejobPost(environment, authorizationScope, createMultiGLEntryJobParamsDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIMultiplecreatejobPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIMultiplecreatejobPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Job creation of multiple entry of gl entries
    ApiResponse<CreateMultiGLEntryJobResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIMultiplecreatejobPostWithHttpInfo(environment, authorizationScope, createMultiGLEntryJobParamsDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIMultiplecreatejobPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **createMultiGLEntryJobParamsDTO** | [**CreateMultiGLEntryJobParamsDTO**](CreateMultiGLEntryJobParamsDTO.md) | List of entries to insert  |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**CreateMultiGLEntryJobResultDTO**](CreateMultiGLEntryJobResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Multiple insert result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfipaymentwithholdingtaxesaccountingpost"></a>
# **ApiV1EnvironmentFIGLEntryFIPaymentwithholdingtaxesaccountingPost**
> PaymentWithholdingTaxesAccountingResultDTO ApiV1EnvironmentFIGLEntryFIPaymentwithholdingtaxesaccountingPost (string environment, string authorizationScope, PaymentWithholdingTaxesAccountingParametersDTO paymentWithholdingTaxesAccountingParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Payment withholding taxes accounting

Payment withholding taxes accounting

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIPaymentwithholdingtaxesaccountingPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var paymentWithholdingTaxesAccountingParametersDTO = new PaymentWithholdingTaxesAccountingParametersDTO(); // PaymentWithholdingTaxesAccountingParametersDTO | Object that contains all the parameters necessary for the payment withholding taxes accounting
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Payment withholding taxes accounting
                PaymentWithholdingTaxesAccountingResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIPaymentwithholdingtaxesaccountingPost(environment, authorizationScope, paymentWithholdingTaxesAccountingParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIPaymentwithholdingtaxesaccountingPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIPaymentwithholdingtaxesaccountingPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Payment withholding taxes accounting
    ApiResponse<PaymentWithholdingTaxesAccountingResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIPaymentwithholdingtaxesaccountingPostWithHttpInfo(environment, authorizationScope, paymentWithholdingTaxesAccountingParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIPaymentwithholdingtaxesaccountingPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **paymentWithholdingTaxesAccountingParametersDTO** | [**PaymentWithholdingTaxesAccountingParametersDTO**](PaymentWithholdingTaxesAccountingParametersDTO.md) | Object that contains all the parameters necessary for the payment withholding taxes accounting |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**PaymentWithholdingTaxesAccountingResultDTO**](PaymentWithholdingTaxesAccountingResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiplafondinfopost"></a>
# **ApiV1EnvironmentFIGLEntryFIPlafondinfoPost**
> PlafondInfoResultDTO ApiV1EnvironmentFIGLEntryFIPlafondinfoPost (string environment, string authorizationScope, PlafondInfoDTO plafondInfoDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Reading of the ceiling management indicator

Retrieves the ceiling management indicator

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIPlafondinfoPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var plafondInfoDTO = new PlafondInfoDTO(); // PlafondInfoDTO | Parameters relating to the selected entry
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Reading of the ceiling management indicator
                PlafondInfoResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIPlafondinfoPost(environment, authorizationScope, plafondInfoDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIPlafondinfoPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIPlafondinfoPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Reading of the ceiling management indicator
    ApiResponse<PlafondInfoResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIPlafondinfoPostWithHttpInfo(environment, authorizationScope, plafondInfoDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIPlafondinfoPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **plafondInfoDTO** | [**PlafondInfoDTO**](PlafondInfoDTO.md) | Parameters relating to the selected entry |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**PlafondInfoResultDTO**](PlafondInfoResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Ceiling management indicator |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfipost"></a>
# **ApiV1EnvironmentFIGLEntryFIPost**
> GLEntryFIDTO ApiV1EnvironmentFIGLEntryFIPost (string environment, string authorizationScope, GLEntryFIDTO gLEntryFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Create

Creating new object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var gLEntryFIDTO = new GLEntryFIDTO(); // GLEntryFIDTO | Object of type to create
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Create
                GLEntryFIDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIPost(environment, authorizationScope, gLEntryFIDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Create
    ApiResponse<GLEntryFIDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIPostWithHttpInfo(environment, authorizationScope, gLEntryFIDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **gLEntryFIDTO** | [**GLEntryFIDTO**](GLEntryFIDTO.md) | Object of type to create |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**GLEntryFIDTO**](GLEntryFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | If object has been created |  -  |
| **400** | If the object has not been created: the content response contains validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object has not been created due to business rules violation: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfipreviewpost"></a>
# **ApiV1EnvironmentFIGLEntryFIPreviewPost**
> PreviewResultDTO ApiV1EnvironmentFIGLEntryFIPreviewPost (string environment, string authorizationScope, IdFIDTO idFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Preview of a gl entry

Preview of a gl entry

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIPreviewPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var idFIDTO = new IdFIDTO(); // IdFIDTO | Id of selected gl entry 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Preview of a gl entry
                PreviewResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIPreviewPost(environment, authorizationScope, idFIDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIPreviewPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIPreviewPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Preview of a gl entry
    ApiResponse<PreviewResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIPreviewPostWithHttpInfo(environment, authorizationScope, idFIDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIPreviewPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **idFIDTO** | [**IdFIDTO**](IdFIDTO.md) | Id of selected gl entry  |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**PreviewResultDTO**](PreviewResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Contains the id file to download |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfireadpost"></a>
# **ApiV1EnvironmentFIGLEntryFIReadPost**
> GLEntryFIDTO ApiV1EnvironmentFIGLEntryFIReadPost (string environment, string authorizationScope, List<SearchElementDTO> searchElementDTO, string? dlevel = null, string? dlevelkey = null, string? company = null, string? user = null, string? acceptLanguage = null)

Read

Read among object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIReadPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var searchElementDTO = new List<SearchElementDTO>(); // List<SearchElementDTO> | Search criteria to apply
            var dlevel = "dlevel_example";  // string? | Serialization level (optional) 
            var dlevelkey = "dlevelkey_example";  // string? | Serialization level key (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Read
                GLEntryFIDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIReadPost(environment, authorizationScope, searchElementDTO, dlevel, dlevelkey, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIReadPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIReadPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Read
    ApiResponse<GLEntryFIDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIReadPostWithHttpInfo(environment, authorizationScope, searchElementDTO, dlevel, dlevelkey, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIReadPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **searchElementDTO** | [**List&lt;SearchElementDTO&gt;**](SearchElementDTO.md) | Search criteria to apply |  |
| **dlevel** | **string?** | Serialization level | [optional]  |
| **dlevelkey** | **string?** | Serialization level key | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**GLEntryFIDTO**](GLEntryFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfireelaborateinvoicefepapassfipost"></a>
# **ApiV1EnvironmentFIGLEntryFIReelaborateInvoiceFepaPassFIPost**
> OperationResultDTO ApiV1EnvironmentFIGLEntryFIReelaborateInvoiceFepaPassFIPost (string environment, string authorizationScope, IdFIDTO idFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Reelaborate file Fepa pass

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIReelaborateInvoiceFepaPassFIPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var idFIDTO = new IdFIDTO(); // IdFIDTO | Input parameters for reelaborate
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Reelaborate file Fepa pass
                OperationResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIReelaborateInvoiceFepaPassFIPost(environment, authorizationScope, idFIDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIReelaborateInvoiceFepaPassFIPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIReelaborateInvoiceFepaPassFIPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Reelaborate file Fepa pass
    ApiResponse<OperationResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIReelaborateInvoiceFepaPassFIPostWithHttpInfo(environment, authorizationScope, idFIDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIReelaborateInvoiceFepaPassFIPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **idFIDTO** | [**IdFIDTO**](IdFIDTO.md) | Input parameters for reelaborate |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**OperationResultDTO**](OperationResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** |  |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiresidualcalculationpost"></a>
# **ApiV1EnvironmentFIGLEntryFIResidualCalculationPost**
> ResidualCalculationResultDTO ApiV1EnvironmentFIGLEntryFIResidualCalculationPost (string environment, string authorizationScope, ResidualCalculationParametersDTO residualCalculationParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Residual accounting entry calculation

Calculate the residual amount of the accounting entry

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIResidualCalculationPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var residualCalculationParametersDTO = new ResidualCalculationParametersDTO(); // ResidualCalculationParametersDTO | Input parameters for calculation
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Residual accounting entry calculation
                ResidualCalculationResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIResidualCalculationPost(environment, authorizationScope, residualCalculationParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIResidualCalculationPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIResidualCalculationPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Residual accounting entry calculation
    ApiResponse<ResidualCalculationResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIResidualCalculationPostWithHttpInfo(environment, authorizationScope, residualCalculationParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIResidualCalculationPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **residualCalculationParametersDTO** | [**ResidualCalculationParametersDTO**](ResidualCalculationParametersDTO.md) | Input parameters for calculation |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**ResidualCalculationResultDTO**](ResidualCalculationResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Value of the remaining amount |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfirestoreb2bfilefepapasspost"></a>
# **ApiV1EnvironmentFIGLEntryFIRestoreB2BFileFepaPassPost**
> FIGLEntriesExecutionResultDTO ApiV1EnvironmentFIGLEntryFIRestoreB2BFileFepaPassPost (string environment, string authorizationScope, IdFIDTO idFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Restore B2B file Fepa pass

Restore B2B file Fepa pass

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIRestoreB2BFileFepaPassPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var idFIDTO = new IdFIDTO(); // IdFIDTO | Input params
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Restore B2B file Fepa pass
                FIGLEntriesExecutionResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIRestoreB2BFileFepaPassPost(environment, authorizationScope, idFIDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIRestoreB2BFileFepaPassPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIRestoreB2BFileFepaPassPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Restore B2B file Fepa pass
    ApiResponse<FIGLEntriesExecutionResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIRestoreB2BFileFepaPassPostWithHttpInfo(environment, authorizationScope, idFIDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIRestoreB2BFileFepaPassPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **idFIDTO** | [**IdFIDTO**](IdFIDTO.md) | Input params |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfirestoreinvoicefepapassfipost"></a>
# **ApiV1EnvironmentFIGLEntryFIRestoreInvoiceFepaPassFIPost**
> FilesFepaPassCODTO ApiV1EnvironmentFIGLEntryFIRestoreInvoiceFepaPassFIPost (string environment, string authorizationScope, IdFIDTO idFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Restore file Fepa pass

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIRestoreInvoiceFepaPassFIPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var idFIDTO = new IdFIDTO(); // IdFIDTO | Input parameters for reelaborate
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Restore file Fepa pass
                FilesFepaPassCODTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIRestoreInvoiceFepaPassFIPost(environment, authorizationScope, idFIDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIRestoreInvoiceFepaPassFIPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIRestoreInvoiceFepaPassFIPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Restore file Fepa pass
    ApiResponse<FilesFepaPassCODTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIRestoreInvoiceFepaPassFIPostWithHttpInfo(environment, authorizationScope, idFIDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIRestoreInvoiceFepaPassFIPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **idFIDTO** | [**IdFIDTO**](IdFIDTO.md) | Input parameters for reelaborate |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**FilesFepaPassCODTO**](FilesFepaPassCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** |  |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiretrievecurrenciesofexchangeratesadjpost"></a>
# **ApiV1EnvironmentFIGLEntryFIRetrieveCurrenciesOfExchangeRatesAdjPost**
> RetrieveCurrenciesOfExchangeRatesAdjResultDTO ApiV1EnvironmentFIGLEntryFIRetrieveCurrenciesOfExchangeRatesAdjPost (string environment, string authorizationScope, RetrieveCurrenciesOfExchangeRatesAdjParametersDTO retrieveCurrenciesOfExchangeRatesAdjParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Manages the recovery of all currencies and relative exchange rates belonging to an accounting process

manages the recovery of all currencies and relative exchange rates belonging to an accounting process

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIRetrieveCurrenciesOfExchangeRatesAdjPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var retrieveCurrenciesOfExchangeRatesAdjParametersDTO = new RetrieveCurrenciesOfExchangeRatesAdjParametersDTO(); // RetrieveCurrenciesOfExchangeRatesAdjParametersDTO | All necessary parameters for exchange rates 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Manages the recovery of all currencies and relative exchange rates belonging to an accounting process
                RetrieveCurrenciesOfExchangeRatesAdjResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIRetrieveCurrenciesOfExchangeRatesAdjPost(environment, authorizationScope, retrieveCurrenciesOfExchangeRatesAdjParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIRetrieveCurrenciesOfExchangeRatesAdjPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIRetrieveCurrenciesOfExchangeRatesAdjPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Manages the recovery of all currencies and relative exchange rates belonging to an accounting process
    ApiResponse<RetrieveCurrenciesOfExchangeRatesAdjResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIRetrieveCurrenciesOfExchangeRatesAdjPostWithHttpInfo(environment, authorizationScope, retrieveCurrenciesOfExchangeRatesAdjParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIRetrieveCurrenciesOfExchangeRatesAdjPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **retrieveCurrenciesOfExchangeRatesAdjParametersDTO** | [**RetrieveCurrenciesOfExchangeRatesAdjParametersDTO**](RetrieveCurrenciesOfExchangeRatesAdjParametersDTO.md) | All necessary parameters for exchange rates  |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**RetrieveCurrenciesOfExchangeRatesAdjResultDTO**](RetrieveCurrenciesOfExchangeRatesAdjResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | All currencies and relative exchange rates belonging to the accounting processing |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfirunreportrglentriespost"></a>
# **ApiV1EnvironmentFIGLEntryFIRunreportrglentriesPost**
> JobStatusDTO ApiV1EnvironmentFIGLEntryFIRunreportrglentriesPost (string environment, string authorizationScope, GLEntryRunReportJobParamsDTO gLEntryRunReportJobParamsDTO, string? company = null, string? user = null, string? acceptLanguage = null)

RunReportGlentries

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIRunreportrglentriesPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var gLEntryRunReportJobParamsDTO = new GLEntryRunReportJobParamsDTO(); // GLEntryRunReportJobParamsDTO | List of entries to insert 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // RunReportGlentries
                JobStatusDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIRunreportrglentriesPost(environment, authorizationScope, gLEntryRunReportJobParamsDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIRunreportrglentriesPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIRunreportrglentriesPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // RunReportGlentries
    ApiResponse<JobStatusDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIRunreportrglentriesPostWithHttpInfo(environment, authorizationScope, gLEntryRunReportJobParamsDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIRunreportrglentriesPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **gLEntryRunReportJobParamsDTO** | [**GLEntryRunReportJobParamsDTO**](GLEntryRunReportJobParamsDTO.md) | List of entries to insert  |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**JobStatusDTO**](JobStatusDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** |  |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfisearchpost"></a>
# **ApiV1EnvironmentFIGLEntryFISearchPost**
> GLEntryFIDTO ApiV1EnvironmentFIGLEntryFISearchPost (string environment, string authorizationScope, SearchDTO searchDTO, string? loadEntireDomain = null, string? gettotalcount = null, string? company = null, string? user = null, string? acceptLanguage = null)

Search

Search among object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFISearchPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var searchDTO = new SearchDTO(); // SearchDTO | Search criteria to apply
            var loadEntireDomain = "loadEntireDomain_example";  // string? | Specify 'loadEntireDomain=true' if you want all the aggregate (optional) 
            var gettotalcount = "gettotalcount_example";  // string? | Specify 'gettotalcount=true' if you want the total number of elements (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Search
                GLEntryFIDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFISearchPost(environment, authorizationScope, searchDTO, loadEntireDomain, gettotalcount, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFISearchPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFISearchPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Search
    ApiResponse<GLEntryFIDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFISearchPostWithHttpInfo(environment, authorizationScope, searchDTO, loadEntireDomain, gettotalcount, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFISearchPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **searchDTO** | [**SearchDTO**](SearchDTO.md) | Search criteria to apply |  |
| **loadEntireDomain** | **string?** | Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate | [optional]  |
| **gettotalcount** | **string?** | Specify &#39;gettotalcount&#x3D;true&#39; if you want the total number of elements | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**GLEntryFIDTO**](GLEntryFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The list of object of type as result of search |  -  |
| **400** | If the search criteria is not supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfisetglentryfrombanktransactionsmovpost"></a>
# **ApiV1EnvironmentFIGLEntryFISetGLEntryFromBankTransactionsMovPost**
> GLEntryFIDTO ApiV1EnvironmentFIGLEntryFISetGLEntryFromBankTransactionsMovPost (string environment, string authorizationScope, IdsListFIDTO idsListFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Import bank transactions

Prepares an accounting entry from a bank movement

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFISetGLEntryFromBankTransactionsMovPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var idsListFIDTO = new IdsListFIDTO(); // IdsListFIDTO | Ids to import
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Import bank transactions
                GLEntryFIDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFISetGLEntryFromBankTransactionsMovPost(environment, authorizationScope, idsListFIDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFISetGLEntryFromBankTransactionsMovPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFISetGLEntryFromBankTransactionsMovPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Import bank transactions
    ApiResponse<GLEntryFIDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFISetGLEntryFromBankTransactionsMovPostWithHttpInfo(environment, authorizationScope, idsListFIDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFISetGLEntryFromBankTransactionsMovPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **idsListFIDTO** | [**IdsListFIDTO**](IdsListFIDTO.md) | Ids to import |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**GLEntryFIDTO**](GLEntryFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | GL entry resulting from the banking movement |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfisetglentryfromtsdigitalpost"></a>
# **ApiV1EnvironmentFIGLEntryFISetGLEntryFromTsDigitalPost**
> GLEntryFIDTO ApiV1EnvironmentFIGLEntryFISetGLEntryFromTsDigitalPost (string environment, string authorizationScope, IdsListFIDTO idsListFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Import TsDigital entry

Import TsDigital entry

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFISetGLEntryFromTsDigitalPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var idsListFIDTO = new IdsListFIDTO(); // IdsListFIDTO | Ids to import
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Import TsDigital entry
                GLEntryFIDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFISetGLEntryFromTsDigitalPost(environment, authorizationScope, idsListFIDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFISetGLEntryFromTsDigitalPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFISetGLEntryFromTsDigitalPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Import TsDigital entry
    ApiResponse<GLEntryFIDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFISetGLEntryFromTsDigitalPostWithHttpInfo(environment, authorizationScope, idsListFIDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFISetGLEntryFromTsDigitalPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **idsListFIDTO** | [**IdsListFIDTO**](IdsListFIDTO.md) | Ids to import |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**GLEntryFIDTO**](GLEntryFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | GL Entry created from TsDigital entry |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfisetglentrylinkedf24movementsidpost"></a>
# **ApiV1EnvironmentFIGLEntryFISetGLEntryLinkedF24MovementsIdPost**
> FIGLEntriesExecutionResultDTO ApiV1EnvironmentFIGLEntryFISetGLEntryLinkedF24MovementsIdPost (string environment, string authorizationScope, SetGLEntryLinkedF24MovementsIdDTO setGLEntryLinkedF24MovementsIdDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Set GLEntry linked F24 movements

Set GLEntry linked F24 movements

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFISetGLEntryLinkedF24MovementsIdPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var setGLEntryLinkedF24MovementsIdDTO = new SetGLEntryLinkedF24MovementsIdDTO(); // SetGLEntryLinkedF24MovementsIdDTO | Input params
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Set GLEntry linked F24 movements
                FIGLEntriesExecutionResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFISetGLEntryLinkedF24MovementsIdPost(environment, authorizationScope, setGLEntryLinkedF24MovementsIdDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFISetGLEntryLinkedF24MovementsIdPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFISetGLEntryLinkedF24MovementsIdPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Set GLEntry linked F24 movements
    ApiResponse<FIGLEntriesExecutionResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFISetGLEntryLinkedF24MovementsIdPostWithHttpInfo(environment, authorizationScope, setGLEntryLinkedF24MovementsIdDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFISetGLEntryLinkedF24MovementsIdPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **setGLEntryLinkedF24MovementsIdDTO** | [**SetGLEntryLinkedF24MovementsIdDTO**](SetGLEntryLinkedF24MovementsIdDTO.md) | Input params |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | GL entry |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfishowpdfinvoicepost"></a>
# **ApiV1EnvironmentFIGLEntryFIShowPDFInvoicePost**
> TSPaaSShowInvoicePDFResultDTO ApiV1EnvironmentFIGLEntryFIShowPDFInvoicePost (string environment, string authorizationScope, TSPaaSShowInvoicePDFParametersDTO tSPaaSShowInvoicePDFParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

View the invoice in PDF format

The PDF format is ADEPDF or SOURCEPDF

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIShowPDFInvoicePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var tSPaaSShowInvoicePDFParametersDTO = new TSPaaSShowInvoicePDFParametersDTO(); // TSPaaSShowInvoicePDFParametersDTO | Object that contains parameters to generate PDF
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // View the invoice in PDF format
                TSPaaSShowInvoicePDFResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIShowPDFInvoicePost(environment, authorizationScope, tSPaaSShowInvoicePDFParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIShowPDFInvoicePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIShowPDFInvoicePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // View the invoice in PDF format
    ApiResponse<TSPaaSShowInvoicePDFResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIShowPDFInvoicePostWithHttpInfo(environment, authorizationScope, tSPaaSShowInvoicePDFParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIShowPDFInvoicePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **tSPaaSShowInvoicePDFParametersDTO** | [**TSPaaSShowInvoicePDFParametersDTO**](TSPaaSShowInvoicePDFParametersDTO.md) | Object that contains parameters to generate PDF |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**TSPaaSShowInvoicePDFResultDTO**](TSPaaSShowInvoicePDFResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Code, description and activation status of the WebServer |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In caso di errori nelle logiche di business: il contenuto della risposta contiene i messaggi di validazione |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfistagecleanglentrypost"></a>
# **ApiV1EnvironmentFIGLEntryFIStageCleanGLEntryPost**
> JobStatusDTO ApiV1EnvironmentFIGLEntryFIStageCleanGLEntryPost (string environment, string authorizationScope, StageCleanFIParametersDTO stageCleanFIParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Cleaning GLEntry and related stage tables

Queues an asynchronous job that cleans up outdated stage tables related to GLEntry and linked tables

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIStageCleanGLEntryPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var stageCleanFIParametersDTO = new StageCleanFIParametersDTO(); // StageCleanFIParametersDTO | Input parameters
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Cleaning GLEntry and related stage tables
                JobStatusDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIStageCleanGLEntryPost(environment, authorizationScope, stageCleanFIParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIStageCleanGLEntryPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIStageCleanGLEntryPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Cleaning GLEntry and related stage tables
    ApiResponse<JobStatusDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIStageCleanGLEntryPostWithHttpInfo(environment, authorizationScope, stageCleanFIParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIStageCleanGLEntryPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **stageCleanFIParametersDTO** | [**StageCleanFIParametersDTO**](StageCleanFIParametersDTO.md) | Input parameters |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**JobStatusDTO**](JobStatusDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Data related to the queued job |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfitoconsolidatepost"></a>
# **ApiV1EnvironmentFIGLEntryFIToConsolidatePost**
> GLEntryFIGetLinkedEntriesFromNumregResultsDTO ApiV1EnvironmentFIGLEntryFIToConsolidatePost (string environment, string authorizationScope, GLEntryFIToConsolidateParametersDTO gLEntryFIToConsolidateParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Returns all gl entries starting from a registration number.

Search for the parent registration and all related registrations of which the entered registration number is a part

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIToConsolidatePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var gLEntryFIToConsolidateParametersDTO = new GLEntryFIToConsolidateParametersDTO(); // GLEntryFIToConsolidateParametersDTO | Id or registration number to find
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Returns all gl entries starting from a registration number.
                GLEntryFIGetLinkedEntriesFromNumregResultsDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIToConsolidatePost(environment, authorizationScope, gLEntryFIToConsolidateParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIToConsolidatePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIToConsolidatePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Returns all gl entries starting from a registration number.
    ApiResponse<GLEntryFIGetLinkedEntriesFromNumregResultsDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIToConsolidatePostWithHttpInfo(environment, authorizationScope, gLEntryFIToConsolidateParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIToConsolidatePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **gLEntryFIToConsolidateParametersDTO** | [**GLEntryFIToConsolidateParametersDTO**](GLEntryFIToConsolidateParametersDTO.md) | Id or registration number to find |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**GLEntryFIGetLinkedEntriesFromNumregResultsDTO**](GLEntryFIGetLinkedEntriesFromNumregResultsDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Parent entry and all related entries |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiupdatehubidsdipost"></a>
# **ApiV1EnvironmentFIGLEntryFIUpdatehubidsdiPost**
> OperationResultDTO ApiV1EnvironmentFIGLEntryFIUpdatehubidsdiPost (string environment, string authorizationScope, GLEntryFIDTO gLEntryFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Update CG41_HUBID and CG41_IDSDI

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIUpdatehubidsdiPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var gLEntryFIDTO = new GLEntryFIDTO(); // GLEntryFIDTO | The gl entry to update
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Update CG41_HUBID and CG41_IDSDI
                OperationResultDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIUpdatehubidsdiPost(environment, authorizationScope, gLEntryFIDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIUpdatehubidsdiPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIUpdatehubidsdiPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update CG41_HUBID and CG41_IDSDI
    ApiResponse<OperationResultDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIUpdatehubidsdiPostWithHttpInfo(environment, authorizationScope, gLEntryFIDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIUpdatehubidsdiPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **gLEntryFIDTO** | [**GLEntryFIDTO**](GLEntryFIDTO.md) | The gl entry to update |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**OperationResultDTO**](OperationResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Update operation Ok |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfivalidatepost"></a>
# **ApiV1EnvironmentFIGLEntryFIValidatePost**
> void ApiV1EnvironmentFIGLEntryFIValidatePost (string environment, string authorizationScope, GLEntryFIDTO gLEntryFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Validate

Validation of object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIValidatePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var gLEntryFIDTO = new GLEntryFIDTO(); // GLEntryFIDTO | Object of type to validate
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Validate
                apiInstance.ApiV1EnvironmentFIGLEntryFIValidatePost(environment, authorizationScope, gLEntryFIDTO, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIValidatePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIValidatePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Validate
    apiInstance.ApiV1EnvironmentFIGLEntryFIValidatePostWithHttpInfo(environment, authorizationScope, gLEntryFIDTO, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIValidatePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **gLEntryFIDTO** | [**GLEntryFIDTO**](GLEntryFIDTO.md) | Object of type to validate |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object is VALID: the content response does NOT contain validation messages |  -  |
| **400** | If no object to validate was supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object is NOT VALID: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfivalidatepropertiespost"></a>
# **ApiV1EnvironmentFIGLEntryFIValidatePropertiesPost**
> ValidateDTO ApiV1EnvironmentFIGLEntryFIValidatePropertiesPost (string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null, string? body = null)

Validation of one on more properties of Type

Validation of object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIValidatePropertiesPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)
            var body = null;  // string? |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br> (optional) 

            try
            {
                // Validation of one on more properties of Type
                ValidateDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIValidatePropertiesPost(environment, authorizationScope, company, user, acceptLanguage, body);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIValidatePropertiesPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIValidatePropertiesPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Validation of one on more properties of Type
    ApiResponse<ValidateDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIValidatePropertiesPostWithHttpInfo(environment, authorizationScope, company, user, acceptLanguage, body);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIApi.ApiV1EnvironmentFIGLEntryFIValidatePropertiesPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |
| **body** | **string?** |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED&lt;br&gt; - The id of an existing object to validate properties, or &#39;&#39; if the object does not exist yet &lt;br&gt; | [optional]  |

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object is VALID: the content response does NOT contain validation messages |  -  |
| **400** | If no object to validate was supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object is NOT VALID: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

