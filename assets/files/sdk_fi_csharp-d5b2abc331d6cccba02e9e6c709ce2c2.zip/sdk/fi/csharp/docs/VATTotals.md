# It.TSEnterprise.Sdk.Model.VATTotals

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodiceIVA** | **string** |  | [optional] 
**TotaleImponibile** | **double?** |  | [optional] 
**TotaleImposta** | **double?** |  | [optional] 
**TotaleImpostaNonDet** | **double?** |  | [optional] 
**TotaleImponibileVal** | **double?** |  | [optional] 
**TotaleImpostaVal** | **double?** |  | [optional] 
**TotaleImpostaNonDetVal** | **double?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

