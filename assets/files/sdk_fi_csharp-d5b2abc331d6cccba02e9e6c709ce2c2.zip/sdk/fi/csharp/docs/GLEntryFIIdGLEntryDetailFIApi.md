# It.TSEnterprise.Sdk.Api.GLEntryFIIdGLEntryDetailFIApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIGet**](GLEntryFIIdGLEntryDetailFIApi.md#apiv1environmentfiglentryfiidglentrydetailfiget) | **GET** /api/v1/{environment}/FI/GLEntryFI/{id}/GLEntryDetailFI | Get new |
| [**ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdDelete**](GLEntryFIIdGLEntryDetailFIApi.md#apiv1environmentfiglentryfiidglentrydetailfiinternaliddelete) | **DELETE** /api/v1/{environment}/FI/GLEntryFI/{id}/GLEntryDetailFI/{internalId} | Delete |
| [**ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdGet**](GLEntryFIIdGLEntryDetailFIApi.md#apiv1environmentfiglentryfiidglentrydetailfiinternalidget) | **GET** /api/v1/{environment}/FI/GLEntryFI/{id}/GLEntryDetailFI/{internalId} | Get by ID |
| [**ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPatch**](GLEntryFIIdGLEntryDetailFIApi.md#apiv1environmentfiglentryfiidglentrydetailfiinternalidpatch) | **PATCH** /api/v1/{environment}/FI/GLEntryFI/{id}/GLEntryDetailFI/{internalId} | Update partial |
| [**ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPut**](GLEntryFIIdGLEntryDetailFIApi.md#apiv1environmentfiglentryfiidglentrydetailfiinternalidput) | **PUT** /api/v1/{environment}/FI/GLEntryFI/{id}/GLEntryDetailFI/{internalId} | Update |
| [**ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdValidatePost**](GLEntryFIIdGLEntryDetailFIApi.md#apiv1environmentfiglentryfiidglentrydetailfiinternalidvalidatepost) | **POST** /api/v1/{environment}/FI/GLEntryFI/{id}/GLEntryDetailFI/{internalId}/validate | Validate |
| [**ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIPost**](GLEntryFIIdGLEntryDetailFIApi.md#apiv1environmentfiglentryfiidglentrydetailfipost) | **POST** /api/v1/{environment}/FI/GLEntryFI/{id}/GLEntryDetailFI | Create |

<a id="apiv1environmentfiglentryfiidglentrydetailfiget"></a>
# **ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIGet**
> GLEntryDetailFIDTO ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIGet (string id, string op, string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null)

Get new

Get an empty object of type corresponding

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIIdGLEntryDetailFIApi(config);
            var id = "id_example";  // string | 
            var op = "op_example";  // string | The value must be 'new'
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get new
                GLEntryDetailFIDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIGet(id, op, environment, authorizationScope, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIIdGLEntryDetailFIApi.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get new
    ApiResponse<GLEntryDetailFIDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIGetWithHttpInfo(id, op, environment, authorizationScope, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIIdGLEntryDetailFIApi.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **op** | **string** | The value must be &#39;new&#39; |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**GLEntryDetailFIDTO**](GLEntryDetailFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The empty object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiidglentrydetailfiinternaliddelete"></a>
# **ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdDelete**
> void ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdDelete (string id, string internalId, string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null)

Delete

Deleting object of type 

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIIdGLEntryDetailFIApi(config);
            var id = "id_example";  // string | 
            var internalId = "internalId_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Delete
                apiInstance.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdDelete(id, internalId, environment, authorizationScope, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIIdGLEntryDetailFIApi.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete
    apiInstance.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdDeleteWithHttpInfo(id, internalId, environment, authorizationScope, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIIdGLEntryDetailFIApi.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **internalId** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object has been deleted |  -  |
| **400** | if object has not been deleted: the content response contains the validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |
| **409** | If object has not been deleted due to business rules violation: the content response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiidglentrydetailfiinternalidget"></a>
# **ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdGet**
> GLEntryDetailFIDTO ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdGet (string id, string internalId, string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null)

Get by ID

Get an object of type corresponding the requested id

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIIdGLEntryDetailFIApi(config);
            var id = "id_example";  // string | 
            var internalId = "internalId_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get by ID
                GLEntryDetailFIDTO result = apiInstance.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdGet(id, internalId, environment, authorizationScope, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIIdGLEntryDetailFIApi.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get by ID
    ApiResponse<GLEntryDetailFIDTO> response = apiInstance.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdGetWithHttpInfo(id, internalId, environment, authorizationScope, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIIdGLEntryDetailFIApi.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **internalId** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**GLEntryDetailFIDTO**](GLEntryDetailFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiidglentrydetailfiinternalidpatch"></a>
# **ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPatch**
> void ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPatch (string id, string internalId, string environment, string authorizationScope, Object body, string? force = null, string? op = null, string? company = null, string? user = null, string? acceptLanguage = null)

Update partial

Patching an object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPatchExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIIdGLEntryDetailFIApi(config);
            var id = "id_example";  // string | 
            var internalId = "internalId_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var body = null;  // Object | Object of type to patch
            var force = "force_example";  // string? | The warning/s code to bypass (separated by ‘,’) during the execution (optional) 
            var op = "op_example";  // string? | Set 'reload', if you want the DTO updated in the response request (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Update partial
                apiInstance.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPatch(id, internalId, environment, authorizationScope, body, force, op, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIIdGLEntryDetailFIApi.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPatch: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPatchWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update partial
    apiInstance.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPatchWithHttpInfo(id, internalId, environment, authorizationScope, body, force, op, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIIdGLEntryDetailFIApi.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPatchWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **internalId** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **body** | **Object** | Object of type to patch |  |
| **force** | **string?** | The warning/s code to bypass (separated by ‘,’) during the execution | [optional]  |
| **op** | **string?** | Set &#39;reload&#39;, if you want the DTO updated in the response request | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object has been updated |  -  |
| **400** | If the object has not been patched: the content response contains the validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |
| **409** | If object has not been patched due to business rules violation: the content response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiidglentrydetailfiinternalidput"></a>
# **ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPut**
> void ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPut (string id, string internalId, string environment, string authorizationScope, GLEntryDetailFIDTO gLEntryDetailFIDTO, string? force = null, string? op = null, string? company = null, string? user = null, string? acceptLanguage = null)

Update

Updating an object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPutExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIIdGLEntryDetailFIApi(config);
            var id = "id_example";  // string | 
            var internalId = "internalId_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var gLEntryDetailFIDTO = new GLEntryDetailFIDTO(); // GLEntryDetailFIDTO | Object of type to update
            var force = "force_example";  // string? | The warning/s code to bypass (separated by ‘,’) during the execution (optional) 
            var op = "op_example";  // string? | Set 'reload', if you want the DTO updated in the response request (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Update
                apiInstance.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPut(id, internalId, environment, authorizationScope, gLEntryDetailFIDTO, force, op, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIIdGLEntryDetailFIApi.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPut: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPutWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update
    apiInstance.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPutWithHttpInfo(id, internalId, environment, authorizationScope, gLEntryDetailFIDTO, force, op, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIIdGLEntryDetailFIApi.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPutWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **internalId** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **gLEntryDetailFIDTO** | [**GLEntryDetailFIDTO**](GLEntryDetailFIDTO.md) | Object of type to update |  |
| **force** | **string?** | The warning/s code to bypass (separated by ‘,’) during the execution | [optional]  |
| **op** | **string?** | Set &#39;reload&#39;, if you want the DTO updated in the response request | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object has been updated |  -  |
| **400** | If the object has not been updated: the content response contains the validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |
| **409** | If object has not been updated due to business rules violation: the content response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiidglentrydetailfiinternalidvalidatepost"></a>
# **ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdValidatePost**
> void ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdValidatePost (string id, string internalId, string environment, string authorizationScope, GLEntryDetailFIDTO gLEntryDetailFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Validate

Validation of object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdValidatePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIIdGLEntryDetailFIApi(config);
            var id = "id_example";  // string | 
            var internalId = "internalId_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var gLEntryDetailFIDTO = new GLEntryDetailFIDTO(); // GLEntryDetailFIDTO | Object of type to validate
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Validate
                apiInstance.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdValidatePost(id, internalId, environment, authorizationScope, gLEntryDetailFIDTO, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIIdGLEntryDetailFIApi.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdValidatePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdValidatePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Validate
    apiInstance.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdValidatePostWithHttpInfo(id, internalId, environment, authorizationScope, gLEntryDetailFIDTO, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIIdGLEntryDetailFIApi.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdValidatePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **internalId** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **gLEntryDetailFIDTO** | [**GLEntryDetailFIDTO**](GLEntryDetailFIDTO.md) | Object of type to validate |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object is VALID: the content response does NOT contain validation messages |  -  |
| **400** | If no object to validate was supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object is NOT VALID: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiglentryfiidglentrydetailfipost"></a>
# **ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIPost**
> void ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIPost (string id, string environment, string authorizationScope, GLEntryDetailFIDTO gLEntryDetailFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Create

Creating new object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GLEntryFIIdGLEntryDetailFIApi(config);
            var id = "id_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var gLEntryDetailFIDTO = new GLEntryDetailFIDTO(); // GLEntryDetailFIDTO | Object of type to create
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Create
                apiInstance.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIPost(id, environment, authorizationScope, gLEntryDetailFIDTO, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GLEntryFIIdGLEntryDetailFIApi.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Create
    apiInstance.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIPostWithHttpInfo(id, environment, authorizationScope, gLEntryDetailFIDTO, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GLEntryFIIdGLEntryDetailFIApi.ApiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **gLEntryDetailFIDTO** | [**GLEntryDetailFIDTO**](GLEntryDetailFIDTO.md) | Object of type to create |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | If object has been created |  -  |
| **400** | If the object has not been created: the content response contains validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object has not been created due to business rules violation: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

