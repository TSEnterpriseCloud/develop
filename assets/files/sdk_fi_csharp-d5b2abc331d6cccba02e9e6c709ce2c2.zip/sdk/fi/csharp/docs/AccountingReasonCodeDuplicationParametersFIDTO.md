# It.TSEnterprise.Sdk.Model.AccountingReasonCodeDuplicationParametersFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SourceAccountingReasonCode** | **string** |  | [optional] 
**TargetAccountingReasonCode** | **string** |  | [optional] 
**TargetAccountingReasonCodeDescription** | **string** |  | [optional] 
**IsDuplLangDescriptions** | **bool** |  | [optional] 
**IsDuplExtendedAttribute** | **bool** |  | [optional] 
**IsDuplAccountingReasonCodeProposal** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

