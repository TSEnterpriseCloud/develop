# It.TSEnterprise.Sdk.Model.InstalmentApplyRemoveIncomingFIResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionResult** | **bool** |  | [optional] 
**ChangedInstalmentIds** | **List&lt;long&gt;** |  | [optional] 
**ErrorInstalmentIds** | [**List&lt;Int64StringValueTuple&gt;**](Int64StringValueTuple.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

