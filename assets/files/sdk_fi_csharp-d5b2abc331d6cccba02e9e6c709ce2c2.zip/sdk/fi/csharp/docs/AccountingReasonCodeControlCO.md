# It.TSEnterprise.Sdk.Model.AccountingReasonCodeControlCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodiceCg33** | **string** |  | [optional] 
**ContomaxCg24** | **string** |  | [optional] 
**ContominCg24** | **string** |  | [optional] 
**GruppoCg10** | **double** |  | [optional] 
**IdmediaCg99** | **double?** |  | [optional] 
**IndDaav** | **double** |  | [optional] 
**ProgR** | **double** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**Parent** | [**AccountingReasonCodeCO**](AccountingReasonCodeCO.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

