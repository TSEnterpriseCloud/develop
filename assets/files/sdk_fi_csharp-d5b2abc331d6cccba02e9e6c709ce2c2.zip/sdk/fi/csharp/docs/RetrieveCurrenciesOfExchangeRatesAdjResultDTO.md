# It.TSEnterprise.Sdk.Model.RetrieveCurrenciesOfExchangeRatesAdjResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Currencies** | **List&lt;string&gt;** |  | [optional] 
**Exchanges** | **List&lt;double&gt;** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

