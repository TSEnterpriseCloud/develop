# It.TSEnterprise.Sdk.Model.NatureAssCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codice** | **string** |  | [optional] 
**Datafineval** | **DateTime?** |  | [optional] 
**Datainival** | **DateTime?** |  | [optional] 
**Descr** | **string** |  | [optional] 
**Idassosw** | **int** |  | [optional] 
**IdCg2m** | **int** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**Parent** | [**NatureEsCO**](NatureEsCO.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

