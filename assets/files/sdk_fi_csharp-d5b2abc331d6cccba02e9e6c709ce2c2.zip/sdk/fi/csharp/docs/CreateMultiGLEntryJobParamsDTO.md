# It.TSEnterprise.Sdk.Model.CreateMultiGLEntryJobParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Data** | [**GLEntryFIMultipleCreateParametersDTO**](GLEntryFIMultipleCreateParametersDTO.md) |  | [optional] 
**IdWorkflowProcess** | **string** |  | [optional] 
**VarEnvironment** | **string** |  | [optional] 
**Module** | **string** |  | [optional] 
**Job** | **string** |  | [optional] 
**Priority** | **int** |  | [optional] 
**RunSync** | **bool?** |  | [optional] 
**DetailLifeHours** | **int?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

