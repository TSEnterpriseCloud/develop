# It.TSEnterprise.Sdk.Model.InstalmentStageDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StageGuid** | **Guid** |  | [optional] 
**PaymentTerm** | **long** |  | [optional] 
**Conto** | **long** |  | [optional] 
**CliFor** | **int** |  | [optional] 
**NumRegCo99** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

