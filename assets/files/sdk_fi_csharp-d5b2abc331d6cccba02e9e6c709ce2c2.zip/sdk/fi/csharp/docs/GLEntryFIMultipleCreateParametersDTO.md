# It.TSEnterprise.Sdk.Model.GLEntryFIMultipleCreateParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**VatReverseIncoporated** | **bool** |  | [optional] 
**Items** | [**List&lt;GLEntryFIMultipleCreateParametersDTOItem&gt;**](GLEntryFIMultipleCreateParametersDTOItem.md) |  | [optional] 
**ExternalModule** | **string** |  | [optional] 
**NumDocAlreadyExistsAsError** | **bool** |  | [optional] 
**ForceAssignedNumReg** | **bool** |  | [optional] 
**ViewWarnings** | **bool** |  | [optional] 
**WarningsToByPass** | **List&lt;int&gt;** |  | [optional] 
**RecoverReverseChargeIfNotDefined** | **bool** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

