# It.TSEnterprise.Sdk.Api.InstalmentFIApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**ApiV1EnvironmentFIInstalmentFICalcexchangeratedifferencePost**](InstalmentFIApi.md#apiv1environmentfiinstalmentficalcexchangeratedifferencepost) | **POST** /api/v1/{environment}/FI/InstalmentFI/calcexchangeratedifference | Exchange rate difference services |
| [**ApiV1EnvironmentFIInstalmentFIChecknumpartisusedPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfichecknumpartisusedpost) | **POST** /api/v1/{environment}/FI/InstalmentFI/checknumpartisused | Verify Vat Number |
| [**ApiV1EnvironmentFIInstalmentFICollectioncontrachargePost**](InstalmentFIApi.md#apiv1environmentfiinstalmentficollectioncontrachargepost) | **POST** /api/v1/{environment}/FI/InstalmentFI/collectioncontracharge | TODO_DOCUMENTATION |
| [**ApiV1EnvironmentFIInstalmentFICommissionpercentageofinstalmentsPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentficommissionpercentageofinstalmentspost) | **POST** /api/v1/{environment}/FI/InstalmentFI/commissionpercentageofinstalments | Return a percentage to settle commissions with expired instalments |
| [**ApiV1EnvironmentFIInstalmentFIDeletepaymentdispositionPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfideletepaymentdispositionpost) | **POST** /api/v1/{environment}/FI/InstalmentFI/deletepaymentdisposition | Delete a payment order or bill of exchange belonging to the order |
| [**ApiV1EnvironmentFIInstalmentFIDeleterecessedarrangementPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfideleterecessedarrangementpost) | **POST** /api/v1/{environment}/FI/InstalmentFI/deleterecessedarrangement | Deletes a collection order or a draft belonging to the order |
| [**ApiV1EnvironmentFIInstalmentFIGet**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiget) | **GET** /api/v1/{environment}/FI/InstalmentFI | Get new |
| [**ApiV1EnvironmentFIInstalmentFIGetlastaccountingreasonPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfigetlastaccountingreasonpost) | **POST** /api/v1/{environment}/FI/InstalmentFI/getlastaccountingreason | Returns the last accounting reason |
| [**ApiV1EnvironmentFIInstalmentFIGroupinginstalmentcalculationPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfigroupinginstalmentcalculationpost) | **POST** /api/v1/{environment}/FI/InstalmentFI/groupinginstalmentcalculation | Grouping instalments calculation info |
| [**ApiV1EnvironmentFIInstalmentFIGroupingsavestagePost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfigroupingsavestagepost) | **POST** /api/v1/{environment}/FI/InstalmentFI/groupingsavestage | The service allows the writing of the origin and destination deadlines in stages belonging to a grouping of the processing Deadlines grouping |
| [**ApiV1EnvironmentFIInstalmentFIIdDelete**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiiddelete) | **DELETE** /api/v1/{environment}/FI/InstalmentFI/{id} | Delete |
| [**ApiV1EnvironmentFIInstalmentFIIdDeletenotlinkedinstalmentPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiiddeletenotlinkedinstalmentpost) | **POST** /api/v1/{environment}/FI/InstalmentFI/{id}/deletenotlinkedinstalment | Delete instalment not linked to GL entry |
| [**ApiV1EnvironmentFIInstalmentFIIdGet**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiidget) | **GET** /api/v1/{environment}/FI/InstalmentFI/{id} | Get by ID |
| [**ApiV1EnvironmentFIInstalmentFIIdPatch**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiidpatch) | **PATCH** /api/v1/{environment}/FI/InstalmentFI/{id} | Update partial |
| [**ApiV1EnvironmentFIInstalmentFIIdPut**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiidput) | **PUT** /api/v1/{environment}/FI/InstalmentFI/{id} | Update |
| [**ApiV1EnvironmentFIInstalmentFIInstalmentaccountingentriesPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiinstalmentaccountingentriespost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentaccountingentries | Writing in the first note stage of the movements of past collections / payments |
| [**ApiV1EnvironmentFIInstalmentFIInstalmentapplyremoveincomingPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiinstalmentapplyremoveincomingpost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentapplyremoveincoming | Suspension or deletion of collection suspension |
| [**ApiV1EnvironmentFIInstalmentFIInstalmentapplyremovesuspensionPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiinstalmentapplyremovesuspensionpost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentapplyremovesuspension | Suspension or cancellation of suspension expiration |
| [**ApiV1EnvironmentFIInstalmentFIInstalmentchangeexpirationdatePost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiinstalmentchangeexpirationdatepost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentchangeexpirationdate | Change maximum due date |
| [**ApiV1EnvironmentFIInstalmentFIInstalmentdeletemanualvariationPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiinstalmentdeletemanualvariationpost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentdeletemanualvariation | Deletion of manual variation of an expiration date. |
| [**ApiV1EnvironmentFIInstalmentFIInstalmentmanualvariationPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiinstalmentmanualvariationpost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentmanualvariation | Manual change of deadline |
| [**ApiV1EnvironmentFIInstalmentFIInstalmentreissuePost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiinstalmentreissuepost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentreissue | Massive effects reissue |
| [**ApiV1EnvironmentFIInstalmentFIInstalmentreplacecompanybankPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiinstalmentreplacecompanybankpost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentreplacecompanybank | Change the corporate bank linked to the bill |
| [**ApiV1EnvironmentFIInstalmentFIInstalmentriskanalysisbillsPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiinstalmentriskanalysisbillspost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentriskanalysisbills | Calculate bills for risck analysis from the instalments |
| [**ApiV1EnvironmentFIInstalmentFIInstalmentsadditionalinfoPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiinstalmentsadditionalinfopost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentsadditionalinfo | Instalments additional info |
| [**ApiV1EnvironmentFIInstalmentFIInstalmentsexchangeadditionalinfoPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiinstalmentsexchangeadditionalinfopost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentsexchangeadditionalinfo | Instalments exchange additional info |
| [**ApiV1EnvironmentFIInstalmentFIPaymentcontrachargePost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfipaymentcontrachargepost) | **POST** /api/v1/{environment}/FI/InstalmentFI/paymentcontracharge | TODO_DOCUMENTATION |
| [**ApiV1EnvironmentFIInstalmentFIPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfipost) | **POST** /api/v1/{environment}/FI/InstalmentFI | Create |
| [**ApiV1EnvironmentFIInstalmentFIPrintinstalmentgroupingPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiprintinstalmentgroupingpost) | **POST** /api/v1/{environment}/FI/InstalmentFI/printinstalmentgrouping | Return a MailRecipientDTO for print Instalment Grouping |
| [**ApiV1EnvironmentFIInstalmentFIReadPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfireadpost) | **POST** /api/v1/{environment}/FI/InstalmentFI/read | Read |
| [**ApiV1EnvironmentFIInstalmentFISaveinstalmentdispositionPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfisaveinstalmentdispositionpost) | **POST** /api/v1/{environment}/FI/InstalmentFI/saveinstalmentdisposition | Save an arrangement and transfer the effects and the history to the real tables |
| [**ApiV1EnvironmentFIInstalmentFISavepaymentdispositionPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfisavepaymentdispositionpost) | **POST** /api/v1/{environment}/FI/InstalmentFI/savepaymentdisposition | Saves a disposition and the transfer of the effects and history in the real tables |
| [**ApiV1EnvironmentFIInstalmentFISearchPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfisearchpost) | **POST** /api/v1/{environment}/FI/InstalmentFI/search | Search |
| [**ApiV1EnvironmentFIInstalmentFIStageinstalmentandhistoryPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfistageinstalmentandhistorypost) | **POST** /api/v1/{environment}/FI/InstalmentFI/stageinstalmentandhistory | Update effects and insert historical effects in the stage tables |
| [**ApiV1EnvironmentFIInstalmentFIStagepaymentinstalmentandhistoryPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfistagepaymentinstalmentandhistorypost) | **POST** /api/v1/{environment}/FI/InstalmentFI/stagepaymentinstalmentandhistory | Update effects and insert historical effects in the stage tables |
| [**ApiV1EnvironmentFIInstalmentFISuspensioncommissionliquidationPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfisuspensioncommissionliquidationpost) | **POST** /api/v1/{environment}/FI/InstalmentFI/suspensioncommissionliquidation | Commission settlement suspension / Commission settlement suspension deletion |
| [**ApiV1EnvironmentFIInstalmentFIUpdateallcsbankforinstalmentPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiupdateallcsbankforinstalmentpost) | **POST** /api/v1/{environment}/FI/InstalmentFI/updateallcsbankforinstalment | Update missing bank information |
| [**ApiV1EnvironmentFIInstalmentFIUpdatebankinstalmentsPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiupdatebankinstalmentspost) | **POST** /api/v1/{environment}/FI/InstalmentFI/updatebankinstalments | Update the CSBankCO for a list of instalments |
| [**ApiV1EnvironmentFIInstalmentFIUpdateidbankonopeninstalmentsPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiupdateidbankonopeninstalmentspost) | **POST** /api/v1/{environment}/FI/InstalmentFI/updateidbankonopeninstalments | Update idBank on open instalments. In TS10 even on Doc Table DO11_DOCTESTATA, DO79_DOCSCADENZE |
| [**ApiV1EnvironmentFIInstalmentFIUpdateinstalmentsourceselectstatePost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfiupdateinstalmentsourceselectstatepost) | **POST** /api/v1/{environment}/FI/InstalmentFI/updateinstalmentsourceselectstate | Instalments grouping source info |
| [**ApiV1EnvironmentFIInstalmentFIValidatePost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfivalidatepost) | **POST** /api/v1/{environment}/FI/InstalmentFI/validate | Validate |
| [**ApiV1EnvironmentFIInstalmentFIValidatePropertiesPost**](InstalmentFIApi.md#apiv1environmentfiinstalmentfivalidatepropertiespost) | **POST** /api/v1/{environment}/FI/InstalmentFI/validateProperties | Validation of one on more properties of Type |

<a id="apiv1environmentfiinstalmentficalcexchangeratedifferencepost"></a>
# **ApiV1EnvironmentFIInstalmentFICalcexchangeratedifferencePost**
> ExchangeRateDifferenceResultDTO ApiV1EnvironmentFIInstalmentFICalcexchangeratedifferencePost (string environment, string authorizationScope, ExchangeRateDifferenceParametersDTO exchangeRateDifferenceParametersDTO, string? stage = null, string? company = null, string? user = null, string? acceptLanguage = null)

Exchange rate difference services

Exchange rate difference services

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFICalcexchangeratedifferencePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var exchangeRateDifferenceParametersDTO = new ExchangeRateDifferenceParametersDTO(); // ExchangeRateDifferenceParametersDTO | Object that contains all the parameters necessary for the calculation of the exchange rate difference
            var stage = "stage_example";  // string? | if the stage parameter is true (stage = true), then the exchange difference is calculated by taking the necessary values ​​from the stage tables (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Exchange rate difference services
                ExchangeRateDifferenceResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFICalcexchangeratedifferencePost(environment, authorizationScope, exchangeRateDifferenceParametersDTO, stage, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFICalcexchangeratedifferencePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFICalcexchangeratedifferencePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Exchange rate difference services
    ApiResponse<ExchangeRateDifferenceResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFICalcexchangeratedifferencePostWithHttpInfo(environment, authorizationScope, exchangeRateDifferenceParametersDTO, stage, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFICalcexchangeratedifferencePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **exchangeRateDifferenceParametersDTO** | [**ExchangeRateDifferenceParametersDTO**](ExchangeRateDifferenceParametersDTO.md) | Object that contains all the parameters necessary for the calculation of the exchange rate difference |  |
| **stage** | **string?** | if the stage parameter is true (stage &#x3D; true), then the exchange difference is calculated by taking the necessary values ​​from the stage tables | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**ExchangeRateDifferenceResultDTO**](ExchangeRateDifferenceResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Exchange rate difference result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfichecknumpartisusedpost"></a>
# **ApiV1EnvironmentFIInstalmentFIChecknumpartisusedPost**
> CheckNpFIResultDTO ApiV1EnvironmentFIInstalmentFIChecknumpartisusedPost (string environment, string authorizationScope, CheckNpFIParametersDTO checkNpFIParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Verify Vat Number

Verify Vat Number

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIChecknumpartisusedPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var checkNpFIParametersDTO = new CheckNpFIParametersDTO(); // CheckNpFIParametersDTO | Object that contains all the parameters necessary for the check
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Verify Vat Number
                CheckNpFIResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIChecknumpartisusedPost(environment, authorizationScope, checkNpFIParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIChecknumpartisusedPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIChecknumpartisusedPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Verify Vat Number
    ApiResponse<CheckNpFIResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIChecknumpartisusedPostWithHttpInfo(environment, authorizationScope, checkNpFIParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIChecknumpartisusedPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **checkNpFIParametersDTO** | [**CheckNpFIParametersDTO**](CheckNpFIParametersDTO.md) | Object that contains all the parameters necessary for the check |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**CheckNpFIResultDTO**](CheckNpFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result check |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentficollectioncontrachargepost"></a>
# **ApiV1EnvironmentFIInstalmentFICollectioncontrachargePost**
> BankDispositionFIParamsResultDTO ApiV1EnvironmentFIInstalmentFICollectioncontrachargePost (string environment, string authorizationScope, BankDispositionFIParamsDTO bankDispositionFIParamsDTO, string? company = null, string? user = null, string? acceptLanguage = null)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFICollectioncontrachargePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var bankDispositionFIParamsDTO = new BankDispositionFIParamsDTO(); // BankDispositionFIParamsDTO | TODO_DOCUMENTATION
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // TODO_DOCUMENTATION
                BankDispositionFIParamsResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFICollectioncontrachargePost(environment, authorizationScope, bankDispositionFIParamsDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFICollectioncontrachargePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFICollectioncontrachargePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // TODO_DOCUMENTATION
    ApiResponse<BankDispositionFIParamsResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFICollectioncontrachargePostWithHttpInfo(environment, authorizationScope, bankDispositionFIParamsDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFICollectioncontrachargePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **bankDispositionFIParamsDTO** | [**BankDispositionFIParamsDTO**](BankDispositionFIParamsDTO.md) | TODO_DOCUMENTATION |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**BankDispositionFIParamsResultDTO**](BankDispositionFIParamsResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | TODO_DOCUMENTATION |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentficommissionpercentageofinstalmentspost"></a>
# **ApiV1EnvironmentFIInstalmentFICommissionpercentageofinstalmentsPost**
> CommissionPercentageInstalmentResultDTO ApiV1EnvironmentFIInstalmentFICommissionpercentageofinstalmentsPost (string environment, string authorizationScope, CommissionPercentageInstalmentParameterDTO commissionPercentageInstalmentParameterDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Return a percentage to settle commissions with expired instalments

Return a percentage to settle commissions with expired instalments

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFICommissionpercentageofinstalmentsPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var commissionPercentageInstalmentParameterDTO = new CommissionPercentageInstalmentParameterDTO(); // CommissionPercentageInstalmentParameterDTO | Input parameters
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Return a percentage to settle commissions with expired instalments
                CommissionPercentageInstalmentResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFICommissionpercentageofinstalmentsPost(environment, authorizationScope, commissionPercentageInstalmentParameterDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFICommissionpercentageofinstalmentsPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFICommissionpercentageofinstalmentsPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Return a percentage to settle commissions with expired instalments
    ApiResponse<CommissionPercentageInstalmentResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFICommissionpercentageofinstalmentsPostWithHttpInfo(environment, authorizationScope, commissionPercentageInstalmentParameterDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFICommissionpercentageofinstalmentsPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **commissionPercentageInstalmentParameterDTO** | [**CommissionPercentageInstalmentParameterDTO**](CommissionPercentageInstalmentParameterDTO.md) | Input parameters |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**CommissionPercentageInstalmentResultDTO**](CommissionPercentageInstalmentResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Percentage |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of error the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfideletepaymentdispositionpost"></a>
# **ApiV1EnvironmentFIInstalmentFIDeletepaymentdispositionPost**
> FIGLEntriesExecutionResultDTO ApiV1EnvironmentFIInstalmentFIDeletepaymentdispositionPost (string environment, string authorizationScope, DeleteRecessedArrangementParametersDTO deleteRecessedArrangementParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Delete a payment order or bill of exchange belonging to the order

Delete a payment order or bill of exchange belonging to the order

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIDeletepaymentdispositionPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var deleteRecessedArrangementParametersDTO = new DeleteRecessedArrangementParametersDTO(); // DeleteRecessedArrangementParametersDTO | Object containing the necessary parameters for the service
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Delete a payment order or bill of exchange belonging to the order
                FIGLEntriesExecutionResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIDeletepaymentdispositionPost(environment, authorizationScope, deleteRecessedArrangementParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIDeletepaymentdispositionPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIDeletepaymentdispositionPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete a payment order or bill of exchange belonging to the order
    ApiResponse<FIGLEntriesExecutionResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIDeletepaymentdispositionPostWithHttpInfo(environment, authorizationScope, deleteRecessedArrangementParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIDeletepaymentdispositionPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **deleteRecessedArrangementParametersDTO** | [**DeleteRecessedArrangementParametersDTO**](DeleteRecessedArrangementParametersDTO.md) | Object containing the necessary parameters for the service |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfideleterecessedarrangementpost"></a>
# **ApiV1EnvironmentFIInstalmentFIDeleterecessedarrangementPost**
> FIGLEntriesExecutionResultDTO ApiV1EnvironmentFIInstalmentFIDeleterecessedarrangementPost (string environment, string authorizationScope, DeleteRecessedArrangementParametersDTO deleteRecessedArrangementParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Deletes a collection order or a draft belonging to the order

Deletes a collection order or a draft belonging to the order

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIDeleterecessedarrangementPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var deleteRecessedArrangementParametersDTO = new DeleteRecessedArrangementParametersDTO(); // DeleteRecessedArrangementParametersDTO | Object containing the necessary parameters for the service
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Deletes a collection order or a draft belonging to the order
                FIGLEntriesExecutionResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIDeleterecessedarrangementPost(environment, authorizationScope, deleteRecessedArrangementParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIDeleterecessedarrangementPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIDeleterecessedarrangementPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Deletes a collection order or a draft belonging to the order
    ApiResponse<FIGLEntriesExecutionResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIDeleterecessedarrangementPostWithHttpInfo(environment, authorizationScope, deleteRecessedArrangementParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIDeleterecessedarrangementPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **deleteRecessedArrangementParametersDTO** | [**DeleteRecessedArrangementParametersDTO**](DeleteRecessedArrangementParametersDTO.md) | Object containing the necessary parameters for the service |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result of the operation or error messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiget"></a>
# **ApiV1EnvironmentFIInstalmentFIGet**
> InstalmentFIDTO ApiV1EnvironmentFIInstalmentFIGet (string op, string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null)

Get new

Get an empty object of type corresponding

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var op = "op_example";  // string | The value must be 'new'
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get new
                InstalmentFIDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIGet(op, environment, authorizationScope, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get new
    ApiResponse<InstalmentFIDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIGetWithHttpInfo(op, environment, authorizationScope, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **op** | **string** | The value must be &#39;new&#39; |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentFIDTO**](InstalmentFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The empty object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfigetlastaccountingreasonpost"></a>
# **ApiV1EnvironmentFIInstalmentFIGetlastaccountingreasonPost**
> LastAccountingReasonResultDTO ApiV1EnvironmentFIInstalmentFIGetlastaccountingreasonPost (string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null)

Returns the last accounting reason

Returns the last accounting reason

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIGetlastaccountingreasonPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Returns the last accounting reason
                LastAccountingReasonResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIGetlastaccountingreasonPost(environment, authorizationScope, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIGetlastaccountingreasonPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIGetlastaccountingreasonPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Returns the last accounting reason
    ApiResponse<LastAccountingReasonResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIGetlastaccountingreasonPostWithHttpInfo(environment, authorizationScope, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIGetlastaccountingreasonPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**LastAccountingReasonResultDTO**](LastAccountingReasonResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Accounting reason code |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfigroupinginstalmentcalculationpost"></a>
# **ApiV1EnvironmentFIInstalmentFIGroupinginstalmentcalculationPost**
> void ApiV1EnvironmentFIInstalmentFIGroupinginstalmentcalculationPost (string environment, string authorizationScope, GroupingInstalmentCalculationFIParametersDTO groupingInstalmentCalculationFIParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Grouping instalments calculation info

Grouping instalments calculation info

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIGroupinginstalmentcalculationPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var groupingInstalmentCalculationFIParametersDTO = new GroupingInstalmentCalculationFIParametersDTO(); // GroupingInstalmentCalculationFIParametersDTO | Stage id of the selected deadline
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Grouping instalments calculation info
                apiInstance.ApiV1EnvironmentFIInstalmentFIGroupinginstalmentcalculationPost(environment, authorizationScope, groupingInstalmentCalculationFIParametersDTO, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIGroupinginstalmentcalculationPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIGroupinginstalmentcalculationPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Grouping instalments calculation info
    apiInstance.ApiV1EnvironmentFIInstalmentFIGroupinginstalmentcalculationPostWithHttpInfo(environment, authorizationScope, groupingInstalmentCalculationFIParametersDTO, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIGroupinginstalmentcalculationPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **groupingInstalmentCalculationFIParametersDTO** | [**GroupingInstalmentCalculationFIParametersDTO**](GroupingInstalmentCalculationFIParametersDTO.md) | Stage id of the selected deadline |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | A boolean that indicates whether the deadline calculation was successful |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfigroupingsavestagepost"></a>
# **ApiV1EnvironmentFIInstalmentFIGroupingsavestagePost**
> InstalmentGroupingFIResultStageDTO ApiV1EnvironmentFIInstalmentFIGroupingsavestagePost (string environment, string authorizationScope, InstalmentGroupingStageParametersFIDTO instalmentGroupingStageParametersFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

The service allows the writing of the origin and destination deadlines in stages belonging to a grouping of the processing Deadlines grouping

The service allows the writing of the origin and destination deadlines in stages belonging to a grouping of the processing Deadlines grouping

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIGroupingsavestagePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentGroupingStageParametersFIDTO = new InstalmentGroupingStageParametersFIDTO(); // InstalmentGroupingStageParametersFIDTO | All necessaryparameters to the service
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // The service allows the writing of the origin and destination deadlines in stages belonging to a grouping of the processing Deadlines grouping
                InstalmentGroupingFIResultStageDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIGroupingsavestagePost(environment, authorizationScope, instalmentGroupingStageParametersFIDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIGroupingsavestagePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIGroupingsavestagePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // The service allows the writing of the origin and destination deadlines in stages belonging to a grouping of the processing Deadlines grouping
    ApiResponse<InstalmentGroupingFIResultStageDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIGroupingsavestagePostWithHttpInfo(environment, authorizationScope, instalmentGroupingStageParametersFIDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIGroupingsavestagePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentGroupingStageParametersFIDTO** | [**InstalmentGroupingStageParametersFIDTO**](InstalmentGroupingStageParametersFIDTO.md) | All necessaryparameters to the service |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentGroupingFIResultStageDTO**](InstalmentGroupingFIResultStageDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiiddelete"></a>
# **ApiV1EnvironmentFIInstalmentFIIdDelete**
> void ApiV1EnvironmentFIInstalmentFIIdDelete (string id, string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null)

Delete

Deleting object of type 

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIIdDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var id = "id_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Delete
                apiInstance.ApiV1EnvironmentFIInstalmentFIIdDelete(id, environment, authorizationScope, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIIdDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIIdDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete
    apiInstance.ApiV1EnvironmentFIInstalmentFIIdDeleteWithHttpInfo(id, environment, authorizationScope, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIIdDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object has been deleted |  -  |
| **400** | if object has not been deleted: the content response contains the validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |
| **409** | If object has not been deleted due to business rules violation: the content response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiiddeletenotlinkedinstalmentpost"></a>
# **ApiV1EnvironmentFIInstalmentFIIdDeletenotlinkedinstalmentPost**
> void ApiV1EnvironmentFIInstalmentFIIdDeletenotlinkedinstalmentPost (string id, string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null)

Delete instalment not linked to GL entry

Delete instalment not linked to GL entry

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIIdDeletenotlinkedinstalmentPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var id = "id_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Delete instalment not linked to GL entry
                apiInstance.ApiV1EnvironmentFIInstalmentFIIdDeletenotlinkedinstalmentPost(id, environment, authorizationScope, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIIdDeletenotlinkedinstalmentPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIIdDeletenotlinkedinstalmentPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete instalment not linked to GL entry
    apiInstance.ApiV1EnvironmentFIInstalmentFIIdDeletenotlinkedinstalmentPostWithHttpInfo(id, environment, authorizationScope, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIIdDeletenotlinkedinstalmentPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | a boolean equals to true if result is right false in any other case |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiidget"></a>
# **ApiV1EnvironmentFIInstalmentFIIdGet**
> InstalmentFIDTO ApiV1EnvironmentFIInstalmentFIIdGet (string id, string environment, string authorizationScope, string? dlevel = null, string? dlevelkey = null, string? company = null, string? user = null, string? acceptLanguage = null)

Get by ID

Get an object of type corresponding the requested id

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIIdGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var id = "id_example";  // string | Id to get the object
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var dlevel = "dlevel_example";  // string? | Serialization level (optional) 
            var dlevelkey = "dlevelkey_example";  // string? | Serialization level key (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get by ID
                InstalmentFIDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIIdGet(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIIdGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIIdGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get by ID
    ApiResponse<InstalmentFIDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIIdGetWithHttpInfo(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIIdGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** | Id to get the object |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **dlevel** | **string?** | Serialization level | [optional]  |
| **dlevelkey** | **string?** | Serialization level key | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentFIDTO**](InstalmentFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiidpatch"></a>
# **ApiV1EnvironmentFIInstalmentFIIdPatch**
> void ApiV1EnvironmentFIInstalmentFIIdPatch (string id, string environment, string authorizationScope, Object body, string? force = null, string? op = null, string? company = null, string? user = null, string? acceptLanguage = null)

Update partial

Patching an object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIIdPatchExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var id = "id_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var body = null;  // Object | Object of type to patch
            var force = "force_example";  // string? | The warning/s code to bypass (separated by ‘,’) during the execution (optional) 
            var op = "op_example";  // string? | Set 'reload', if you want the DTO updated in the response request (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Update partial
                apiInstance.ApiV1EnvironmentFIInstalmentFIIdPatch(id, environment, authorizationScope, body, force, op, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIIdPatch: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIIdPatchWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update partial
    apiInstance.ApiV1EnvironmentFIInstalmentFIIdPatchWithHttpInfo(id, environment, authorizationScope, body, force, op, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIIdPatchWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **body** | **Object** | Object of type to patch |  |
| **force** | **string?** | The warning/s code to bypass (separated by ‘,’) during the execution | [optional]  |
| **op** | **string?** | Set &#39;reload&#39;, if you want the DTO updated in the response request | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object has been updated |  -  |
| **400** | If the object has not been patched: the content response contains the validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |
| **409** | If object has not been patched due to business rules violation: the content response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiidput"></a>
# **ApiV1EnvironmentFIInstalmentFIIdPut**
> InstalmentFIDTO ApiV1EnvironmentFIInstalmentFIIdPut (string id, string environment, string authorizationScope, InstalmentFIDTO instalmentFIDTO, string? force = null, string? op = null, string? company = null, string? user = null, string? acceptLanguage = null)

Update

Updating an object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIIdPutExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var id = "id_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentFIDTO = new InstalmentFIDTO(); // InstalmentFIDTO | Object of type to update
            var force = "force_example";  // string? | The warning/s code to bypass (separated by ‘,’) during the execution (optional) 
            var op = "op_example";  // string? | Set 'reload', if you want the DTO updated in the response request, otherwise will be returned null value (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Update
                InstalmentFIDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIIdPut(id, environment, authorizationScope, instalmentFIDTO, force, op, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIIdPut: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIIdPutWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update
    ApiResponse<InstalmentFIDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIIdPutWithHttpInfo(id, environment, authorizationScope, instalmentFIDTO, force, op, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIIdPutWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentFIDTO** | [**InstalmentFIDTO**](InstalmentFIDTO.md) | Object of type to update |  |
| **force** | **string?** | The warning/s code to bypass (separated by ‘,’) during the execution | [optional]  |
| **op** | **string?** | Set &#39;reload&#39;, if you want the DTO updated in the response request, otherwise will be returned null value | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentFIDTO**](InstalmentFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object has been updated |  -  |
| **400** | If the object has not been updated: the content response contains the validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |
| **409** | If object has not been updated due to business rules violation: the content response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiinstalmentaccountingentriespost"></a>
# **ApiV1EnvironmentFIInstalmentFIInstalmentaccountingentriesPost**
> InstalmentAccountingEntriesFIResultDTO ApiV1EnvironmentFIInstalmentFIInstalmentaccountingentriesPost (string environment, string authorizationScope, InstalmentAccountingEntriesFIParametersDTO instalmentAccountingEntriesFIParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Writing in the first note stage of the movements of past collections / payments

Given a list of receipts / payments entries, the aggregated journal entries for OperationNumber are generated

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIInstalmentaccountingentriesPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentAccountingEntriesFIParametersDTO = new InstalmentAccountingEntriesFIParametersDTO(); // InstalmentAccountingEntriesFIParametersDTO | Object that contains the guid to recover receipts / payments through the InstalmentDataForReceiptsAndPayments service and the registration date
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Writing in the first note stage of the movements of past collections / payments
                InstalmentAccountingEntriesFIResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentaccountingentriesPost(environment, authorizationScope, instalmentAccountingEntriesFIParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentaccountingentriesPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIInstalmentaccountingentriesPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Writing in the first note stage of the movements of past collections / payments
    ApiResponse<InstalmentAccountingEntriesFIResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentaccountingentriesPostWithHttpInfo(environment, authorizationScope, instalmentAccountingEntriesFIParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentaccountingentriesPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentAccountingEntriesFIParametersDTO** | [**InstalmentAccountingEntriesFIParametersDTO**](InstalmentAccountingEntriesFIParametersDTO.md) | Object that contains the guid to recover receipts / payments through the InstalmentDataForReceiptsAndPayments service and the registration date |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentAccountingEntriesFIResultDTO**](InstalmentAccountingEntriesFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result of the operation and list of generated journal entries |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiinstalmentapplyremoveincomingpost"></a>
# **ApiV1EnvironmentFIInstalmentFIInstalmentapplyremoveincomingPost**
> InstalmentApplyRemoveIncomingFIResultDTO ApiV1EnvironmentFIInstalmentFIInstalmentapplyremoveincomingPost (string environment, string authorizationScope, InstalmentApplyRemoveIncomingFIParametersDTO instalmentApplyRemoveIncomingFIParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Suspension or deletion of collection suspension

Given a list of deadlines ids, they are suspended or the suspension is canceled for the purposes for which it is possible to carry out this operation

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIInstalmentapplyremoveincomingPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentApplyRemoveIncomingFIParametersDTO = new InstalmentApplyRemoveIncomingFIParametersDTO(); // InstalmentApplyRemoveIncomingFIParametersDTO | Object that contains the id of the expiration for which to carry out the suspension or cancel the suspension if possible
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Suspension or deletion of collection suspension
                InstalmentApplyRemoveIncomingFIResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentapplyremoveincomingPost(environment, authorizationScope, instalmentApplyRemoveIncomingFIParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentapplyremoveincomingPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIInstalmentapplyremoveincomingPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Suspension or deletion of collection suspension
    ApiResponse<InstalmentApplyRemoveIncomingFIResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentapplyremoveincomingPostWithHttpInfo(environment, authorizationScope, instalmentApplyRemoveIncomingFIParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentapplyremoveincomingPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentApplyRemoveIncomingFIParametersDTO** | [**InstalmentApplyRemoveIncomingFIParametersDTO**](InstalmentApplyRemoveIncomingFIParametersDTO.md) | Object that contains the id of the expiration for which to carry out the suspension or cancel the suspension if possible |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentApplyRemoveIncomingFIResultDTO**](InstalmentApplyRemoveIncomingFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiinstalmentapplyremovesuspensionpost"></a>
# **ApiV1EnvironmentFIInstalmentFIInstalmentapplyremovesuspensionPost**
> InstalmentApplyRemoveSuspensionFIResultDTO ApiV1EnvironmentFIInstalmentFIInstalmentapplyremovesuspensionPost (string environment, string authorizationScope, InstalmentApplyRemoveSuspensionFIParametersDTO instalmentApplyRemoveSuspensionFIParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Suspension or cancellation of suspension expiration

Suspension or cancellation of suspension expiration

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIInstalmentapplyremovesuspensionPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentApplyRemoveSuspensionFIParametersDTO = new InstalmentApplyRemoveSuspensionFIParametersDTO(); // InstalmentApplyRemoveSuspensionFIParametersDTO | Object that contains the id of the expiration for which to carry out the suspension or cancellation of the suspension if possible
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Suspension or cancellation of suspension expiration
                InstalmentApplyRemoveSuspensionFIResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentapplyremovesuspensionPost(environment, authorizationScope, instalmentApplyRemoveSuspensionFIParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentapplyremovesuspensionPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIInstalmentapplyremovesuspensionPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Suspension or cancellation of suspension expiration
    ApiResponse<InstalmentApplyRemoveSuspensionFIResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentapplyremovesuspensionPostWithHttpInfo(environment, authorizationScope, instalmentApplyRemoveSuspensionFIParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentapplyremovesuspensionPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentApplyRemoveSuspensionFIParametersDTO** | [**InstalmentApplyRemoveSuspensionFIParametersDTO**](InstalmentApplyRemoveSuspensionFIParametersDTO.md) | Object that contains the id of the expiration for which to carry out the suspension or cancellation of the suspension if possible |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentApplyRemoveSuspensionFIResultDTO**](InstalmentApplyRemoveSuspensionFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiinstalmentchangeexpirationdatepost"></a>
# **ApiV1EnvironmentFIInstalmentFIInstalmentchangeexpirationdatePost**
> InstalmentChangeExpirationDateFIResultDTO ApiV1EnvironmentFIInstalmentFIInstalmentchangeexpirationdatePost (string environment, string authorizationScope, InstalmentChangeExpirationDateFIParametersDTO instalmentChangeExpirationDateFIParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Change maximum due date

Given a list of expiration ids, the expiration dates for the effects for which this operation can be performed are modified

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIInstalmentchangeexpirationdatePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentChangeExpirationDateFIParametersDTO = new InstalmentChangeExpirationDateFIParametersDTO(); // InstalmentChangeExpirationDateFIParametersDTO | Object that contains the id of the deadlines for which to change the due date if possible
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Change maximum due date
                InstalmentChangeExpirationDateFIResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentchangeexpirationdatePost(environment, authorizationScope, instalmentChangeExpirationDateFIParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentchangeexpirationdatePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIInstalmentchangeexpirationdatePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Change maximum due date
    ApiResponse<InstalmentChangeExpirationDateFIResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentchangeexpirationdatePostWithHttpInfo(environment, authorizationScope, instalmentChangeExpirationDateFIParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentchangeexpirationdatePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentChangeExpirationDateFIParametersDTO** | [**InstalmentChangeExpirationDateFIParametersDTO**](InstalmentChangeExpirationDateFIParametersDTO.md) | Object that contains the id of the deadlines for which to change the due date if possible |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentChangeExpirationDateFIResultDTO**](InstalmentChangeExpirationDateFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiinstalmentdeletemanualvariationpost"></a>
# **ApiV1EnvironmentFIInstalmentFIInstalmentdeletemanualvariationPost**
> InstalmentDeleteManualVariationFIResultDTO ApiV1EnvironmentFIInstalmentFIInstalmentdeletemanualvariationPost (string environment, string authorizationScope, InstalmentDeleteManualVariationParametersDTO instalmentDeleteManualVariationParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Deletion of manual variation of an expiration date.

Deletion of manual variation of an expiration date and restoration of the historicized data.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIInstalmentdeletemanualvariationPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentDeleteManualVariationParametersDTO = new InstalmentDeleteManualVariationParametersDTO(); // InstalmentDeleteManualVariationParametersDTO | Object that contains the id of the expiration that contains the history to be deleted and the id of the real history to be deleted
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Deletion of manual variation of an expiration date.
                InstalmentDeleteManualVariationFIResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentdeletemanualvariationPost(environment, authorizationScope, instalmentDeleteManualVariationParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentdeletemanualvariationPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIInstalmentdeletemanualvariationPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Deletion of manual variation of an expiration date.
    ApiResponse<InstalmentDeleteManualVariationFIResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentdeletemanualvariationPostWithHttpInfo(environment, authorizationScope, instalmentDeleteManualVariationParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentdeletemanualvariationPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentDeleteManualVariationParametersDTO** | [**InstalmentDeleteManualVariationParametersDTO**](InstalmentDeleteManualVariationParametersDTO.md) | Object that contains the id of the expiration that contains the history to be deleted and the id of the real history to be deleted |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentDeleteManualVariationFIResultDTO**](InstalmentDeleteManualVariationFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiinstalmentmanualvariationpost"></a>
# **ApiV1EnvironmentFIInstalmentFIInstalmentmanualvariationPost**
> InstalmentManualVariationFIResultDTO ApiV1EnvironmentFIInstalmentFIInstalmentmanualvariationPost (string environment, string authorizationScope, InstalmentFIDTO instalmentFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Manual change of deadline

Manual variation of a deadline and data logging if required

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIInstalmentmanualvariationPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentFIDTO = new InstalmentFIDTO(); // InstalmentFIDTO | Object that contains all the necessary parameters
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Manual change of deadline
                InstalmentManualVariationFIResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentmanualvariationPost(environment, authorizationScope, instalmentFIDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentmanualvariationPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIInstalmentmanualvariationPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Manual change of deadline
    ApiResponse<InstalmentManualVariationFIResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentmanualvariationPostWithHttpInfo(environment, authorizationScope, instalmentFIDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentmanualvariationPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentFIDTO** | [**InstalmentFIDTO**](InstalmentFIDTO.md) | Object that contains all the necessary parameters |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentManualVariationFIResultDTO**](InstalmentManualVariationFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiinstalmentreissuepost"></a>
# **ApiV1EnvironmentFIInstalmentFIInstalmentreissuePost**
> InstalmentReissueResultDTO ApiV1EnvironmentFIInstalmentFIInstalmentreissuePost (string environment, string authorizationScope, InstalmentReissueParameterDTO instalmentReissueParameterDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Massive effects reissue

Given a list of bill of exchange ids and an expiration date, the bills for which it is possible to perform this operation are reissued

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIInstalmentreissuePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentReissueParameterDTO = new InstalmentReissueParameterDTO(); // InstalmentReissueParameterDTO | Object that contains all the parameters needed to reissue bills for an expiration date
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Massive effects reissue
                InstalmentReissueResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentreissuePost(environment, authorizationScope, instalmentReissueParameterDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentreissuePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIInstalmentreissuePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Massive effects reissue
    ApiResponse<InstalmentReissueResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentreissuePostWithHttpInfo(environment, authorizationScope, instalmentReissueParameterDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentreissuePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentReissueParameterDTO** | [**InstalmentReissueParameterDTO**](InstalmentReissueParameterDTO.md) | Object that contains all the parameters needed to reissue bills for an expiration date |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentReissueResultDTO**](InstalmentReissueResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiinstalmentreplacecompanybankpost"></a>
# **ApiV1EnvironmentFIInstalmentFIInstalmentreplacecompanybankPost**
> InstalmentReplaceCompanyBankFIResultDTO ApiV1EnvironmentFIInstalmentFIInstalmentreplacecompanybankPost (string environment, string authorizationScope, InstalmentReplaceCompanyBankFIParametersDTO instalmentReplaceCompanyBankFIParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Change the corporate bank linked to the bill

Given a list of id of bills, the company banks are modified for the bills for which it is possible to carry out this operation

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIInstalmentreplacecompanybankPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentReplaceCompanyBankFIParametersDTO = new InstalmentReplaceCompanyBankFIParametersDTO(); // InstalmentReplaceCompanyBankFIParametersDTO | Object that contains the id of the effects to be modified, id of the old connected corporate banks and id of the new corporate banks
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Change the corporate bank linked to the bill
                InstalmentReplaceCompanyBankFIResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentreplacecompanybankPost(environment, authorizationScope, instalmentReplaceCompanyBankFIParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentreplacecompanybankPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIInstalmentreplacecompanybankPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Change the corporate bank linked to the bill
    ApiResponse<InstalmentReplaceCompanyBankFIResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentreplacecompanybankPostWithHttpInfo(environment, authorizationScope, instalmentReplaceCompanyBankFIParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentreplacecompanybankPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentReplaceCompanyBankFIParametersDTO** | [**InstalmentReplaceCompanyBankFIParametersDTO**](InstalmentReplaceCompanyBankFIParametersDTO.md) | Object that contains the id of the effects to be modified, id of the old connected corporate banks and id of the new corporate banks |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentReplaceCompanyBankFIResultDTO**](InstalmentReplaceCompanyBankFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiinstalmentriskanalysisbillspost"></a>
# **ApiV1EnvironmentFIInstalmentFIInstalmentriskanalysisbillsPost**
> InstalmentRiskAnalysisBillsResultDTO ApiV1EnvironmentFIInstalmentFIInstalmentriskanalysisbillsPost (string environment, string authorizationScope, InstalmentRiskAnalysisBillsParametersDTO instalmentRiskAnalysisBillsParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Calculate bills for risck analysis from the instalments

Calculate bills for risck analysis from the instalments using DAL statement

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIInstalmentriskanalysisbillsPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentRiskAnalysisBillsParametersDTO = new InstalmentRiskAnalysisBillsParametersDTO(); // InstalmentRiskAnalysisBillsParametersDTO | Object containing the parameters necessary for editing effects
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Calculate bills for risck analysis from the instalments
                InstalmentRiskAnalysisBillsResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentriskanalysisbillsPost(environment, authorizationScope, instalmentRiskAnalysisBillsParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentriskanalysisbillsPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIInstalmentriskanalysisbillsPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Calculate bills for risck analysis from the instalments
    ApiResponse<InstalmentRiskAnalysisBillsResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentriskanalysisbillsPostWithHttpInfo(environment, authorizationScope, instalmentRiskAnalysisBillsParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentriskanalysisbillsPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentRiskAnalysisBillsParametersDTO** | [**InstalmentRiskAnalysisBillsParametersDTO**](InstalmentRiskAnalysisBillsParametersDTO.md) | Object containing the parameters necessary for editing effects |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentRiskAnalysisBillsResultDTO**](InstalmentRiskAnalysisBillsResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result of the operation |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiinstalmentsadditionalinfopost"></a>
# **ApiV1EnvironmentFIInstalmentFIInstalmentsadditionalinfoPost**
> InstalmentsAdditionalInfoResultDTO ApiV1EnvironmentFIInstalmentFIInstalmentsadditionalinfoPost (string environment, string authorizationScope, InstalmentsAdditionalInfoParametersDTO instalmentsAdditionalInfoParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Instalments additional info

Instalments additional info

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIInstalmentsadditionalinfoPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentsAdditionalInfoParametersDTO = new InstalmentsAdditionalInfoParametersDTO(); // InstalmentsAdditionalInfoParametersDTO | Object that contains all the necessary parameters
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Instalments additional info
                InstalmentsAdditionalInfoResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentsadditionalinfoPost(environment, authorizationScope, instalmentsAdditionalInfoParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentsadditionalinfoPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIInstalmentsadditionalinfoPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Instalments additional info
    ApiResponse<InstalmentsAdditionalInfoResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentsadditionalinfoPostWithHttpInfo(environment, authorizationScope, instalmentsAdditionalInfoParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentsadditionalinfoPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentsAdditionalInfoParametersDTO** | [**InstalmentsAdditionalInfoParametersDTO**](InstalmentsAdditionalInfoParametersDTO.md) | Object that contains all the necessary parameters |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentsAdditionalInfoResultDTO**](InstalmentsAdditionalInfoResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiinstalmentsexchangeadditionalinfopost"></a>
# **ApiV1EnvironmentFIInstalmentFIInstalmentsexchangeadditionalinfoPost**
> InstalmentsExchangeAdditionalInfoResultDTO ApiV1EnvironmentFIInstalmentFIInstalmentsexchangeadditionalinfoPost (string environment, string authorizationScope, InstalmentsExchangeAdditionalInfoParametersDTO instalmentsExchangeAdditionalInfoParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Instalments exchange additional info

Instalments exchange additional info

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIInstalmentsexchangeadditionalinfoPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentsExchangeAdditionalInfoParametersDTO = new InstalmentsExchangeAdditionalInfoParametersDTO(); // InstalmentsExchangeAdditionalInfoParametersDTO | Stage id of the selected deadline
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Instalments exchange additional info
                InstalmentsExchangeAdditionalInfoResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentsexchangeadditionalinfoPost(environment, authorizationScope, instalmentsExchangeAdditionalInfoParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentsexchangeadditionalinfoPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIInstalmentsexchangeadditionalinfoPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Instalments exchange additional info
    ApiResponse<InstalmentsExchangeAdditionalInfoResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIInstalmentsexchangeadditionalinfoPostWithHttpInfo(environment, authorizationScope, instalmentsExchangeAdditionalInfoParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIInstalmentsexchangeadditionalinfoPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentsExchangeAdditionalInfoParametersDTO** | [**InstalmentsExchangeAdditionalInfoParametersDTO**](InstalmentsExchangeAdditionalInfoParametersDTO.md) | Stage id of the selected deadline |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentsExchangeAdditionalInfoResultDTO**](InstalmentsExchangeAdditionalInfoResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfipaymentcontrachargepost"></a>
# **ApiV1EnvironmentFIInstalmentFIPaymentcontrachargePost**
> BankDispositionFIParamsResultDTO ApiV1EnvironmentFIInstalmentFIPaymentcontrachargePost (string environment, string authorizationScope, BankDispositionFIParamsDTO bankDispositionFIParamsDTO, string? company = null, string? user = null, string? acceptLanguage = null)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIPaymentcontrachargePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var bankDispositionFIParamsDTO = new BankDispositionFIParamsDTO(); // BankDispositionFIParamsDTO | TODO_DOCUMENTATION
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // TODO_DOCUMENTATION
                BankDispositionFIParamsResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIPaymentcontrachargePost(environment, authorizationScope, bankDispositionFIParamsDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIPaymentcontrachargePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIPaymentcontrachargePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // TODO_DOCUMENTATION
    ApiResponse<BankDispositionFIParamsResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIPaymentcontrachargePostWithHttpInfo(environment, authorizationScope, bankDispositionFIParamsDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIPaymentcontrachargePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **bankDispositionFIParamsDTO** | [**BankDispositionFIParamsDTO**](BankDispositionFIParamsDTO.md) | TODO_DOCUMENTATION |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**BankDispositionFIParamsResultDTO**](BankDispositionFIParamsResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | TODO_DOCUMENTATION |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfipost"></a>
# **ApiV1EnvironmentFIInstalmentFIPost**
> InstalmentFIDTO ApiV1EnvironmentFIInstalmentFIPost (string environment, string authorizationScope, InstalmentFIDTO instalmentFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Create

Creating new object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentFIDTO = new InstalmentFIDTO(); // InstalmentFIDTO | Object of type to create
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Create
                InstalmentFIDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIPost(environment, authorizationScope, instalmentFIDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Create
    ApiResponse<InstalmentFIDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIPostWithHttpInfo(environment, authorizationScope, instalmentFIDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentFIDTO** | [**InstalmentFIDTO**](InstalmentFIDTO.md) | Object of type to create |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentFIDTO**](InstalmentFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | If object has been created |  -  |
| **400** | If the object has not been created: the content response contains validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object has not been created due to business rules violation: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiprintinstalmentgroupingpost"></a>
# **ApiV1EnvironmentFIInstalmentFIPrintinstalmentgroupingPost**
> MailRecipientDTO ApiV1EnvironmentFIInstalmentFIPrintinstalmentgroupingPost (string environment, string authorizationScope, GroupingIdParametersDTO groupingIdParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Return a MailRecipientDTO for print Instalment Grouping

Print Instalment Grouping

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIPrintinstalmentgroupingPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var groupingIdParametersDTO = new GroupingIdParametersDTO(); // GroupingIdParametersDTO | Input parameters
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Return a MailRecipientDTO for print Instalment Grouping
                MailRecipientDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIPrintinstalmentgroupingPost(environment, authorizationScope, groupingIdParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIPrintinstalmentgroupingPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIPrintinstalmentgroupingPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Return a MailRecipientDTO for print Instalment Grouping
    ApiResponse<MailRecipientDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIPrintinstalmentgroupingPostWithHttpInfo(environment, authorizationScope, groupingIdParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIPrintinstalmentgroupingPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **groupingIdParametersDTO** | [**GroupingIdParametersDTO**](GroupingIdParametersDTO.md) | Input parameters |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**MailRecipientDTO**](MailRecipientDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of error the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfireadpost"></a>
# **ApiV1EnvironmentFIInstalmentFIReadPost**
> InstalmentFIDTO ApiV1EnvironmentFIInstalmentFIReadPost (string environment, string authorizationScope, List<SearchElementDTO> searchElementDTO, string? dlevel = null, string? dlevelkey = null, string? company = null, string? user = null, string? acceptLanguage = null)

Read

Read among object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIReadPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var searchElementDTO = new List<SearchElementDTO>(); // List<SearchElementDTO> | Search criteria to apply
            var dlevel = "dlevel_example";  // string? | Serialization level (optional) 
            var dlevelkey = "dlevelkey_example";  // string? | Serialization level key (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Read
                InstalmentFIDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIReadPost(environment, authorizationScope, searchElementDTO, dlevel, dlevelkey, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIReadPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIReadPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Read
    ApiResponse<InstalmentFIDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIReadPostWithHttpInfo(environment, authorizationScope, searchElementDTO, dlevel, dlevelkey, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIReadPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **searchElementDTO** | [**List&lt;SearchElementDTO&gt;**](SearchElementDTO.md) | Search criteria to apply |  |
| **dlevel** | **string?** | Serialization level | [optional]  |
| **dlevelkey** | **string?** | Serialization level key | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentFIDTO**](InstalmentFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfisaveinstalmentdispositionpost"></a>
# **ApiV1EnvironmentFIInstalmentFISaveinstalmentdispositionPost**
> SaveInstalmentDispositionResultDTO ApiV1EnvironmentFIInstalmentFISaveinstalmentdispositionPost (string environment, string authorizationScope, SaveInstalmentDispositionParametersDTO saveInstalmentDispositionParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Save an arrangement and transfer the effects and the history to the real tables

Save an arrangement and transfer the effects and the history to the real tables

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFISaveinstalmentdispositionPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var saveInstalmentDispositionParametersDTO = new SaveInstalmentDispositionParametersDTO(); // SaveInstalmentDispositionParametersDTO | Object containing the necessary parameters for the service
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Save an arrangement and transfer the effects and the history to the real tables
                SaveInstalmentDispositionResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFISaveinstalmentdispositionPost(environment, authorizationScope, saveInstalmentDispositionParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFISaveinstalmentdispositionPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFISaveinstalmentdispositionPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Save an arrangement and transfer the effects and the history to the real tables
    ApiResponse<SaveInstalmentDispositionResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFISaveinstalmentdispositionPostWithHttpInfo(environment, authorizationScope, saveInstalmentDispositionParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFISaveinstalmentdispositionPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **saveInstalmentDispositionParametersDTO** | [**SaveInstalmentDispositionParametersDTO**](SaveInstalmentDispositionParametersDTO.md) | Object containing the necessary parameters for the service |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**SaveInstalmentDispositionResultDTO**](SaveInstalmentDispositionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result of the operation and id of the created arrangement |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfisavepaymentdispositionpost"></a>
# **ApiV1EnvironmentFIInstalmentFISavepaymentdispositionPost**
> SavePaymentDispositionResultDTO ApiV1EnvironmentFIInstalmentFISavepaymentdispositionPost (string environment, string authorizationScope, SavePaymentDispositionParametersDTO savePaymentDispositionParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Saves a disposition and the transfer of the effects and history in the real tables

Saves a disposition and the transfer of the effects and history in the real tables

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFISavepaymentdispositionPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var savePaymentDispositionParametersDTO = new SavePaymentDispositionParametersDTO(); // SavePaymentDispositionParametersDTO | Object containing the necessary parameters for the service
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Saves a disposition and the transfer of the effects and history in the real tables
                SavePaymentDispositionResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFISavepaymentdispositionPost(environment, authorizationScope, savePaymentDispositionParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFISavepaymentdispositionPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFISavepaymentdispositionPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Saves a disposition and the transfer of the effects and history in the real tables
    ApiResponse<SavePaymentDispositionResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFISavepaymentdispositionPostWithHttpInfo(environment, authorizationScope, savePaymentDispositionParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFISavepaymentdispositionPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **savePaymentDispositionParametersDTO** | [**SavePaymentDispositionParametersDTO**](SavePaymentDispositionParametersDTO.md) | Object containing the necessary parameters for the service |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**SavePaymentDispositionResultDTO**](SavePaymentDispositionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfisearchpost"></a>
# **ApiV1EnvironmentFIInstalmentFISearchPost**
> InstalmentFIDTO ApiV1EnvironmentFIInstalmentFISearchPost (string environment, string authorizationScope, SearchDTO searchDTO, string? loadEntireDomain = null, string? getTotalCount = null, string? company = null, string? user = null, string? acceptLanguage = null)

Search

Search among object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFISearchPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var searchDTO = new SearchDTO(); // SearchDTO | Search criteria to apply
            var loadEntireDomain = "loadEntireDomain_example";  // string? | Specify 'loadEntireDomain=true' if you want all the aggregate (optional) 
            var getTotalCount = "getTotalCount_example";  // string? | Specify 'getTotalCount=true' if you want the total number of elements (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Search
                InstalmentFIDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFISearchPost(environment, authorizationScope, searchDTO, loadEntireDomain, getTotalCount, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFISearchPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFISearchPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Search
    ApiResponse<InstalmentFIDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFISearchPostWithHttpInfo(environment, authorizationScope, searchDTO, loadEntireDomain, getTotalCount, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFISearchPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **searchDTO** | [**SearchDTO**](SearchDTO.md) | Search criteria to apply |  |
| **loadEntireDomain** | **string?** | Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate | [optional]  |
| **getTotalCount** | **string?** | Specify &#39;getTotalCount&#x3D;true&#39; if you want the total number of elements | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentFIDTO**](InstalmentFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The list of object of type as result of search |  -  |
| **400** | If the search criteria is not supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfistageinstalmentandhistorypost"></a>
# **ApiV1EnvironmentFIInstalmentFIStageinstalmentandhistoryPost**
> StageInstalmentAndHistoryResultDTO ApiV1EnvironmentFIInstalmentFIStageinstalmentandhistoryPost (string environment, string authorizationScope, StageInstalmentAndHistoryParametersDTO stageInstalmentAndHistoryParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Update effects and insert historical effects in the stage tables

Update effects and insert historical effects in the stage tables

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIStageinstalmentandhistoryPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var stageInstalmentAndHistoryParametersDTO = new StageInstalmentAndHistoryParametersDTO(); // StageInstalmentAndHistoryParametersDTO | Object containing the necessary parameters for the service
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Update effects and insert historical effects in the stage tables
                StageInstalmentAndHistoryResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIStageinstalmentandhistoryPost(environment, authorizationScope, stageInstalmentAndHistoryParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIStageinstalmentandhistoryPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIStageinstalmentandhistoryPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update effects and insert historical effects in the stage tables
    ApiResponse<StageInstalmentAndHistoryResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIStageinstalmentandhistoryPostWithHttpInfo(environment, authorizationScope, stageInstalmentAndHistoryParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIStageinstalmentandhistoryPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **stageInstalmentAndHistoryParametersDTO** | [**StageInstalmentAndHistoryParametersDTO**](StageInstalmentAndHistoryParametersDTO.md) | Object containing the necessary parameters for the service |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**StageInstalmentAndHistoryResultDTO**](StageInstalmentAndHistoryResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result of the operation and list of id of modified effects |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfistagepaymentinstalmentandhistorypost"></a>
# **ApiV1EnvironmentFIInstalmentFIStagepaymentinstalmentandhistoryPost**
> StageInstalmentAndHistoryPaymentResultDTO ApiV1EnvironmentFIInstalmentFIStagepaymentinstalmentandhistoryPost (string environment, string authorizationScope, StagePaymentInstalmentAndHistoryParametersDTO stagePaymentInstalmentAndHistoryParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Update effects and insert historical effects in the stage tables

Update effects and insert historical effects in the stage tables

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIStagepaymentinstalmentandhistoryPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var stagePaymentInstalmentAndHistoryParametersDTO = new StagePaymentInstalmentAndHistoryParametersDTO(); // StagePaymentInstalmentAndHistoryParametersDTO | Object containing the necessary parameters for the service
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Update effects and insert historical effects in the stage tables
                StageInstalmentAndHistoryPaymentResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIStagepaymentinstalmentandhistoryPost(environment, authorizationScope, stagePaymentInstalmentAndHistoryParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIStagepaymentinstalmentandhistoryPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIStagepaymentinstalmentandhistoryPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update effects and insert historical effects in the stage tables
    ApiResponse<StageInstalmentAndHistoryPaymentResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIStagepaymentinstalmentandhistoryPostWithHttpInfo(environment, authorizationScope, stagePaymentInstalmentAndHistoryParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIStagepaymentinstalmentandhistoryPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **stagePaymentInstalmentAndHistoryParametersDTO** | [**StagePaymentInstalmentAndHistoryParametersDTO**](StagePaymentInstalmentAndHistoryParametersDTO.md) | Object containing the necessary parameters for the service |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**StageInstalmentAndHistoryPaymentResultDTO**](StageInstalmentAndHistoryPaymentResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result of the operation and list of id of modified effects in stage table |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfisuspensioncommissionliquidationpost"></a>
# **ApiV1EnvironmentFIInstalmentFISuspensioncommissionliquidationPost**
> InstalmentSuspensionCommissionLiquidationResultDTO ApiV1EnvironmentFIInstalmentFISuspensioncommissionliquidationPost (string environment, string authorizationScope, InstalmentSuspensionCommissionLiquidationParameterDTO instalmentSuspensionCommissionLiquidationParameterDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Commission settlement suspension / Commission settlement suspension deletion

The service allows you to activate or disable the Suspension of commission settlement, massively on a series of selected bills

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFISuspensioncommissionliquidationPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentSuspensionCommissionLiquidationParameterDTO = new InstalmentSuspensionCommissionLiquidationParameterDTO(); // InstalmentSuspensionCommissionLiquidationParameterDTO | Object that contains all the parameters necessary to perform the operation
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Commission settlement suspension / Commission settlement suspension deletion
                InstalmentSuspensionCommissionLiquidationResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFISuspensioncommissionliquidationPost(environment, authorizationScope, instalmentSuspensionCommissionLiquidationParameterDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFISuspensioncommissionliquidationPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFISuspensioncommissionliquidationPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Commission settlement suspension / Commission settlement suspension deletion
    ApiResponse<InstalmentSuspensionCommissionLiquidationResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFISuspensioncommissionliquidationPostWithHttpInfo(environment, authorizationScope, instalmentSuspensionCommissionLiquidationParameterDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFISuspensioncommissionliquidationPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentSuspensionCommissionLiquidationParameterDTO** | [**InstalmentSuspensionCommissionLiquidationParameterDTO**](InstalmentSuspensionCommissionLiquidationParameterDTO.md) | Object that contains all the parameters necessary to perform the operation |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentSuspensionCommissionLiquidationResultDTO**](InstalmentSuspensionCommissionLiquidationResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiupdateallcsbankforinstalmentpost"></a>
# **ApiV1EnvironmentFIInstalmentFIUpdateallcsbankforinstalmentPost**
> UpdateAllCSBankForInstalmentResultDTO ApiV1EnvironmentFIInstalmentFIUpdateallcsbankforinstalmentPost (string environment, string authorizationScope, UpdateAllCSBankForInstalmentParametersDTO updateAllCSBankForInstalmentParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Update missing bank information

Updating of the bank of an effect or all the effects belonging to the same registry

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIUpdateallcsbankforinstalmentPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var updateAllCSBankForInstalmentParametersDTO = new UpdateAllCSBankForInstalmentParametersDTO(); // UpdateAllCSBankForInstalmentParametersDTO | Object containing the parameters necessary for editing effects
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Update missing bank information
                UpdateAllCSBankForInstalmentResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIUpdateallcsbankforinstalmentPost(environment, authorizationScope, updateAllCSBankForInstalmentParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIUpdateallcsbankforinstalmentPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIUpdateallcsbankforinstalmentPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update missing bank information
    ApiResponse<UpdateAllCSBankForInstalmentResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIUpdateallcsbankforinstalmentPostWithHttpInfo(environment, authorizationScope, updateAllCSBankForInstalmentParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIUpdateallcsbankforinstalmentPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **updateAllCSBankForInstalmentParametersDTO** | [**UpdateAllCSBankForInstalmentParametersDTO**](UpdateAllCSBankForInstalmentParametersDTO.md) | Object containing the parameters necessary for editing effects |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**UpdateAllCSBankForInstalmentResultDTO**](UpdateAllCSBankForInstalmentResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result of the operation and list of id of modified effects |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiupdatebankinstalmentspost"></a>
# **ApiV1EnvironmentFIInstalmentFIUpdatebankinstalmentsPost**
> UpdateAllCSBankForInstalmentResultDTO ApiV1EnvironmentFIInstalmentFIUpdatebankinstalmentsPost (string environment, string authorizationScope, UpdateBankInstalmentsParametersDTO updateBankInstalmentsParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Update the CSBankCO for a list of instalments

Update the CSBankCO for a list of instalments

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIUpdatebankinstalmentsPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var updateBankInstalmentsParametersDTO = new UpdateBankInstalmentsParametersDTO(); // UpdateBankInstalmentsParametersDTO | Input parameters
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Update the CSBankCO for a list of instalments
                UpdateAllCSBankForInstalmentResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIUpdatebankinstalmentsPost(environment, authorizationScope, updateBankInstalmentsParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIUpdatebankinstalmentsPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIUpdatebankinstalmentsPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update the CSBankCO for a list of instalments
    ApiResponse<UpdateAllCSBankForInstalmentResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIUpdatebankinstalmentsPostWithHttpInfo(environment, authorizationScope, updateBankInstalmentsParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIUpdatebankinstalmentsPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **updateBankInstalmentsParametersDTO** | [**UpdateBankInstalmentsParametersDTO**](UpdateBankInstalmentsParametersDTO.md) | Input parameters |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**UpdateAllCSBankForInstalmentResultDTO**](UpdateAllCSBankForInstalmentResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Percentage |  -  |
| **400** | In case of missing parameters |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of error the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiupdateidbankonopeninstalmentspost"></a>
# **ApiV1EnvironmentFIInstalmentFIUpdateidbankonopeninstalmentsPost**
> UpdateAllCSBankForInstalmentResultDTO ApiV1EnvironmentFIInstalmentFIUpdateidbankonopeninstalmentsPost (string environment, string authorizationScope, UpdateIdBankOnOpenInstalmentsParametersDTO updateIdBankOnOpenInstalmentsParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Update idBank on open instalments. In TS10 even on Doc Table DO11_DOCTESTATA, DO79_DOCSCADENZE

Update idBank on open instalments using DAL statement. In TS10 even on Doc Table DO11_DOCTESTATA, DO79_DOCSCADENZE. This

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIUpdateidbankonopeninstalmentsPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var updateIdBankOnOpenInstalmentsParametersDTO = new UpdateIdBankOnOpenInstalmentsParametersDTO(); // UpdateIdBankOnOpenInstalmentsParametersDTO | Object containing the parameters necessary for editing effects
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Update idBank on open instalments. In TS10 even on Doc Table DO11_DOCTESTATA, DO79_DOCSCADENZE
                UpdateAllCSBankForInstalmentResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIUpdateidbankonopeninstalmentsPost(environment, authorizationScope, updateIdBankOnOpenInstalmentsParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIUpdateidbankonopeninstalmentsPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIUpdateidbankonopeninstalmentsPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update idBank on open instalments. In TS10 even on Doc Table DO11_DOCTESTATA, DO79_DOCSCADENZE
    ApiResponse<UpdateAllCSBankForInstalmentResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIUpdateidbankonopeninstalmentsPostWithHttpInfo(environment, authorizationScope, updateIdBankOnOpenInstalmentsParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIUpdateidbankonopeninstalmentsPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **updateIdBankOnOpenInstalmentsParametersDTO** | [**UpdateIdBankOnOpenInstalmentsParametersDTO**](UpdateIdBankOnOpenInstalmentsParametersDTO.md) | Object containing the parameters necessary for editing effects |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**UpdateAllCSBankForInstalmentResultDTO**](UpdateAllCSBankForInstalmentResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result of the operation and list of id of modified effects |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfiupdateinstalmentsourceselectstatepost"></a>
# **ApiV1EnvironmentFIInstalmentFIUpdateinstalmentsourceselectstatePost**
> void ApiV1EnvironmentFIInstalmentFIUpdateinstalmentsourceselectstatePost (string environment, string authorizationScope, SourceSelectionStateDTO sourceSelectionStateDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Instalments grouping source info

Update of selection flag on deadlines by grouping

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIUpdateinstalmentsourceselectstatePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var sourceSelectionStateDTO = new SourceSelectionStateDTO(); // SourceSelectionStateDTO | Parameters required to update the selection flag of a grouping deadline
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Instalments grouping source info
                apiInstance.ApiV1EnvironmentFIInstalmentFIUpdateinstalmentsourceselectstatePost(environment, authorizationScope, sourceSelectionStateDTO, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIUpdateinstalmentsourceselectstatePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIUpdateinstalmentsourceselectstatePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Instalments grouping source info
    apiInstance.ApiV1EnvironmentFIInstalmentFIUpdateinstalmentsourceselectstatePostWithHttpInfo(environment, authorizationScope, sourceSelectionStateDTO, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIUpdateinstalmentsourceselectstatePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **sourceSelectionStateDTO** | [**SourceSelectionStateDTO**](SourceSelectionStateDTO.md) | Parameters required to update the selection flag of a grouping deadline |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | a boolean equals to true if result is right false in any other case |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfivalidatepost"></a>
# **ApiV1EnvironmentFIInstalmentFIValidatePost**
> void ApiV1EnvironmentFIInstalmentFIValidatePost (string environment, string authorizationScope, InstalmentFIDTO instalmentFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Validate

Validation of object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIValidatePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentFIDTO = new InstalmentFIDTO(); // InstalmentFIDTO | Object of type to validate
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Validate
                apiInstance.ApiV1EnvironmentFIInstalmentFIValidatePost(environment, authorizationScope, instalmentFIDTO, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIValidatePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIValidatePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Validate
    apiInstance.ApiV1EnvironmentFIInstalmentFIValidatePostWithHttpInfo(environment, authorizationScope, instalmentFIDTO, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIValidatePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentFIDTO** | [**InstalmentFIDTO**](InstalmentFIDTO.md) | Object of type to validate |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object is VALID: the content response does NOT contain validation messages |  -  |
| **400** | If no object to validate was supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object is NOT VALID: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentfivalidatepropertiespost"></a>
# **ApiV1EnvironmentFIInstalmentFIValidatePropertiesPost**
> ValidateDTO ApiV1EnvironmentFIInstalmentFIValidatePropertiesPost (string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null, string? body = null)

Validation of one on more properties of Type

Validation of object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentFIValidatePropertiesPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)
            var body = null;  // string? |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br> (optional) 

            try
            {
                // Validation of one on more properties of Type
                ValidateDTO result = apiInstance.ApiV1EnvironmentFIInstalmentFIValidatePropertiesPost(environment, authorizationScope, company, user, acceptLanguage, body);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIValidatePropertiesPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentFIValidatePropertiesPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Validation of one on more properties of Type
    ApiResponse<ValidateDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentFIValidatePropertiesPostWithHttpInfo(environment, authorizationScope, company, user, acceptLanguage, body);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentFIApi.ApiV1EnvironmentFIInstalmentFIValidatePropertiesPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |
| **body** | **string?** |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED&lt;br&gt; - The id of an existing object to validate properties, or &#39;&#39; if the object does not exist yet &lt;br&gt; | [optional]  |

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object is VALID: the content response does NOT contain validation messages |  -  |
| **400** | If no object to validate was supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object is NOT VALID: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

