# It.TSEnterprise.Sdk.Model.InstalmentReplaceCompanyBankFIResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Result** | **bool** |  | [optional] 
**ChangedInstalmentIds** | **List&lt;long&gt;** |  | [optional] 
**ErrorInstalmentIds** | [**List&lt;Int64StringValueTuple&gt;**](Int64StringValueTuple.md) |  | [optional] 
**NotUpdatableIds** | **List&lt;long&gt;** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

