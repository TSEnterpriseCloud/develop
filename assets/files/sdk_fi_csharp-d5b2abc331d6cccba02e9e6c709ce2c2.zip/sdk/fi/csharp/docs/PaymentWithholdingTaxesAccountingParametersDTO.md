# It.TSEnterprise.Sdk.Model.PaymentWithholdingTaxesAccountingParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Ids** | **List&lt;long&gt;** |  | [optional] 
**AccountingReasonCode** | **string** |  | [optional] 
**AdditionalDescription** | **string** |  | [optional] 
**RegistrationDate** | **DateTime** |  | [optional] 
**DocumentDate** | **DateTime?** |  | [optional] 
**PaymentYearRA** | **int** |  | [optional] 
**PaymentMonthRA** | **int** |  | [optional] 
**PaymentDayRA** | **int** |  | [optional] 
**AbiCodeRA** | **long?** |  | [optional] 
**CabCodeRA** | **long?** |  | [optional] 
**PaymentYearRP** | **int** |  | [optional] 
**PaymentMonthRP** | **int** |  | [optional] 
**PaymentDayRP** | **int** |  | [optional] 
**AbiCodeRP** | **long?** |  | [optional] 
**CabCodeRP** | **long?** |  | [optional] 
**TreasuryAccountId** | **long?** |  | [optional] 
**SocialSecurityAccountId** | **long?** |  | [optional] 
**BankAccountId** | **long** |  | [optional] 
**WtTotalRA** | **double** |  | [optional] 
**WtTotalRP** | **double** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

