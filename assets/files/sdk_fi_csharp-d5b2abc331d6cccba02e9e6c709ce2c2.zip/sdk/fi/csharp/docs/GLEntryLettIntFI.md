# It.TSEnterprise.Sdk.Model.GLEntryLettIntFI

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DittaCg18** | **double** |  | [optional] 
**Id** | **long** |  | [optional] 
**IdCg41** | **long** |  | [optional] 
**IdMg28** | **int** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**Parent** | [**GLEntryFI**](GLEntryFI.md) |  | [optional] 
**CsLetterOfIntentCO** | [**CSLetterOfIntentCO**](CSLetterOfIntentCO.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

