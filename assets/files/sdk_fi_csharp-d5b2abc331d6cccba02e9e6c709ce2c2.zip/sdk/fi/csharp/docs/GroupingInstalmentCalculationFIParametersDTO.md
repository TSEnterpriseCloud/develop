# It.TSEnterprise.Sdk.Model.GroupingInstalmentCalculationFIParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InstalmentGroupingId** | **long** |  | [optional] 
**ElaborationGuid** | **Guid?** |  | [optional] 
**IndSubjects** | **int** |  | [optional] 
**CurrencyCode** | **string** |  | [optional] 
**SectionalCode** | **string** |  | [optional] 
**NumPart** | **double?** |  | [optional] 
**GroupingPaymentCode** | **string** |  | [optional] 
**GroupingEffectiveDate** | **DateTime?** |  | [optional] 
**SourceIdRaggr** | [**List&lt;IdRaggrAndPaymentCodeDTO&gt;**](IdRaggrAndPaymentCodeDTO.md) |  | [optional] 
**ReuseDataSourceInstalment** | **bool** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

