# It.TSEnterprise.Sdk.Model.XSLTResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ContentXSLT** | **string** |  | [optional] 
**ContentXml** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

