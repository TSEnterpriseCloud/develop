# It.TSEnterprise.Sdk.Model.ProtocolCalculationParametersDTO
Calculate the next protocol based on the parameters provided

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Anno** | **double** |  | [optional] 
**Sez** | **string** |  | [optional] 
**Tipodocint** | **double?** |  | [optional] 
**Causale** | **string** |  | [optional] 
**TipoMovimento** | **double** |  | [optional] 
**TipoOperazione** | **int** |  | [optional] 
**Datareg** | **string** |  | [optional] 
**NumDocDaAggiornare** | **int?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

