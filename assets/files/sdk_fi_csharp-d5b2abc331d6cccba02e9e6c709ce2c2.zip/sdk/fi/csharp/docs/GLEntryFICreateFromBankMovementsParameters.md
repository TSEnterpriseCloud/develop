# It.TSEnterprise.Sdk.Model.GLEntryFICreateFromBankMovementsParameters

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Ids** | **List&lt;long&gt;** |  | [optional] 
**IdProcessing** | **long** |  | [optional] 
**Service** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

