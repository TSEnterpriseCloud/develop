# It.TSEnterprise.Sdk.Model.TSDigitalInvoiceParams

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TransmitterId** | **string** |  | [optional] 
**SenderId** | **string** |  | [optional] 
**RecipientId** | **string** |  | [optional] 
**FileName** | **string** |  | [optional] 
**FlowType** | **string** |  | [optional] 
**HubId** | **string** |  | [optional] 
**SdiId** | **string** |  | [optional] 
**DocDate** | **string** |  | [optional] 
**DocId** | **string** |  | [optional] 
**Category** | **string** |  | [optional] 
**Format** | **string** |  | [optional] 
**RecipientName** | **string** |  | [optional] 
**SenderName** | **string** |  | [optional] 
**ReceiptDate** | **string** |  | [optional] 
**LastTimestamp** | **long** |  | [optional] 
**Active** | **bool** |  | [optional] 
**CurrentStatusName** | **string** |  | [optional] 
**CurrentStatusTimestamp** | **long** |  | [optional] 
**CurrentNotificationType** | **string** |  | [optional] 
**MessageCount** | **int** |  | [optional] 
**CurrentStatusDescription** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

