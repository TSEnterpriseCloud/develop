# It.TSEnterprise.Sdk.Model.Grouping3CO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodRaggrcf3** | **string** |  | [optional] 
**Descraggrcf3** | **string** |  | [optional] 
**DittaCg18** | **double** |  | [optional] 
**IdEntityWithDescriptions** | **int?** |  | [optional] 
**IdmediaCg99** | **double?** |  | [optional] 
**Idprov** | **int** |  | [optional] 
**Tipocf** | **double** |  | [optional] 
**DescrizioniLingua** | [**List&lt;LanguageDescriptionMGCO&gt;**](LanguageDescriptionMGCO.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

