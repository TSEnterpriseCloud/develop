# It.TSEnterprise.Sdk.Model.PlafondInfoResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DataComp** | **DateTime?** |  | [optional] 
**IndPlafond** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

