# It.TSEnterprise.Sdk.Model.CrossBorderOperationParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**GlEntryIDs** | **List&lt;long&gt;** |  | [optional] 
**TipoOperazione** | **int** |  | [optional] 
**TipoImpostato** | **int?** |  | [optional] 
**TipoDaImpostare** | **int?** |  | [optional] 
**DetraibilitaDaImpostare** | **double?** |  | [optional] 
**DataFinale** | **DateTime?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

