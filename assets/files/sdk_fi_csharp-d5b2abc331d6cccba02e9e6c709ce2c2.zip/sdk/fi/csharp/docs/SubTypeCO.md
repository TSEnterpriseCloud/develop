# It.TSEnterprise.Sdk.Model.SubTypeCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodiceCg07** | **double** |  | [optional] 
**CodPaguc** | **string** |  | [optional] 
**CodStipoeff** | **double** |  | [optional] 
**Descstipo** | **string** |  | [optional] 
**FlgAssegno** | **int** |  | [optional] 
**Ggoffset** | **double?** |  | [optional] 
**Id** | **long** |  | [optional] 
**IndModfatturapa** | **int** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**Tipoeff** | **double** |  | [optional] 
**ForeignPaymentCodeCO** | [**ForeignPaymentCodeCO**](ForeignPaymentCodeCO.md) |  | [optional] 
**NationCO** | [**NationCO**](NationCO.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

