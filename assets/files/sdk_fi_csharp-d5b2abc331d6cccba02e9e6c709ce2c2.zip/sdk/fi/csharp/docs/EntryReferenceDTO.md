# It.TSEnterprise.Sdk.Model.EntryReferenceDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdCliFor** | **int?** |  | [optional] 
**IdConto** | **long?** |  | [optional] 
**AnnoPart** | **double?** |  | [optional] 
**NumeroPart** | **double?** |  | [optional] 
**SezionalePart** | **string** |  | [optional] 
**BisPart** | **double?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

