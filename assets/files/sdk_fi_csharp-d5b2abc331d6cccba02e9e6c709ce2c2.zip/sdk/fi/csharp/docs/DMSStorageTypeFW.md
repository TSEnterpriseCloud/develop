# It.TSEnterprise.Sdk.Model.DMSStorageTypeFW

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Campoguid** | **string** |  | [optional] 
**Desc** | **string** |  | [optional] 
**Flagstd** | **int?** |  | [optional] 
**Id** | **int** |  | [optional] 
**Idvocets** | **int?** |  | [optional] 
**IndPostingType** | **int?** |  | [optional] 
**IndSyncType** | **int?** |  | [optional] 
**Oldconf** | **int** |  | [optional] 
**Sqljoin** | **string** |  | [optional] 
**Subidvocets** | **int** |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

