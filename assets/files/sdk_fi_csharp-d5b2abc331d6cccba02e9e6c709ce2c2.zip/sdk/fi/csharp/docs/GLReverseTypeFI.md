# It.TSEnterprise.Sdk.Model.GLReverseTypeFI

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdEntityWithDescriptions** | **int?** |  | [optional] 
**ReverseTypeCode** | **int** |  | [optional] 
**ReverseTypeDescription** | **string** |  | [optional] 
**LanguageDescriptionFI** | [**List&lt;LanguageDescriptionFI&gt;**](LanguageDescriptionFI.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

