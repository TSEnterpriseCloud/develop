# It.TSEnterprise.Sdk.Model.ExchangeRateCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Adegcambio** | **double?** |  | [optional] 
**Anno** | **double** |  | [optional] 
**Cambio** | **double?** |  | [optional] 
**CodiceCg08** | **string** |  | [optional] 
**CodicerifCg08** | **string** |  | [optional] 
**Giorno** | **double** |  | [optional] 
**IdmediaCg99** | **double?** |  | [optional] 
**IndCertoincerto** | **int** |  | [optional] 
**Mese** | **double** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**Parent** | [**CurrencyCO**](CurrencyCO.md) |  | [optional] 
**CurrencyCO** | [**CurrencyCO**](CurrencyCO.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

