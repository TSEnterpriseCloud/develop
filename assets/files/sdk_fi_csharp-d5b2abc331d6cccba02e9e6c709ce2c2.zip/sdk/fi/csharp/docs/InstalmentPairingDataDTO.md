# It.TSEnterprise.Sdk.Model.InstalmentPairingDataDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PairingMode** | **ModalitaAssociazioneScadenzeEnum** |  | [optional] 
**Instalments** | [**List&lt;InstalmentPairingDetailDTO&gt;**](InstalmentPairingDetailDTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

