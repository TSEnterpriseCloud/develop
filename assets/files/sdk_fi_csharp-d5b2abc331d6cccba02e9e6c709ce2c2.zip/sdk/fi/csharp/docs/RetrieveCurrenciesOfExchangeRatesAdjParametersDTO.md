# It.TSEnterprise.Sdk.Model.RetrieveCurrenciesOfExchangeRatesAdjParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExchangeType** | **int** |  | [optional] 
**EndYearDate** | **DateTime** |  | [optional] 
**IsSimulation** | **bool** |  | [optional] 
**CustomersAdjustment** | **bool** |  | [optional] 
**SuppliersAdjustment** | **bool** |  | [optional] 
**ActiveAccountsAdjustment** | **bool** |  | [optional] 
**PassiveAccountsAdjustment** | **bool** |  | [optional] 
**IncludeEstablishedTransactions** | **bool** |  | [optional] 
**IncludeNotEstablishedTransactions** | **bool** |  | [optional] 
**IncludeProjectedTransactions** | **bool** |  | [optional] 
**OfficeCode** | **string** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

