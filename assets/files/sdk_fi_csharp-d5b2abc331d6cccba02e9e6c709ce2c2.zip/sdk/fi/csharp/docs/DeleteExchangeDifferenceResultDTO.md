# It.TSEnterprise.Sdk.Model.DeleteExchangeDifferenceResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DeletedProcessingDetailId** | **long?** |  | [optional] 
**DeletedIdsCGY1** | **List&lt;long&gt;** |  | [optional] 
**DeletedIdsGLEntry** | **List&lt;long&gt;** |  | [optional] 
**Result** | **bool** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

