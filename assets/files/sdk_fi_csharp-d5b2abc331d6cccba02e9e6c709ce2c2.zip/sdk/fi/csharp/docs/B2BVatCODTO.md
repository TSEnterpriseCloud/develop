# It.TSEnterprise.Sdk.Model.B2BVatCODTO
IE87_B2BIVA - B2BVatCO<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Aliquota** | **double?** | IE87_ALIQUOTA - Aliquota | [optional] 
**Aswcodiva** | **string** | IE87_ASWCODIVA - Aswcodiva | [optional] 
**CodArtL** | **string** | IE87_CODART_L - CodArtL | [optional] 
**CodIvaCg28** | **string** | IE87_CODIVA_CG28 - CodIvaCg28 | [optional] 
**CodSedeCg31** | **double?** | IE87_CODSEDE_CG31 - CodSedeCg31 | [optional] 
**ContoCg24** | **string** | IE87_CONTO_CG24 - ContoCg24 | [optional] 
**Datafincomp** | **DateTime?** | IE87_DATAFINCOMP - Datafincomp | [optional] 
**Datainicomp** | **DateTime?** | IE87_DATAINICOMP - Datainicomp | [optional] 
**Descragg** | **string** | IE87_DESCRAGG - Descragg | [optional] 
**DescrizioneL** | **string** | IE87_DESCRIZIONE_L - DescrizioneL | [optional] 
**Esigibilita** | **string** | IE87_ESIGIBILITA - Esigibilita | [optional] 
**GruppoCg10** | **double?** | IE87_GRUPPO_CG10 - GruppoCg10 | [optional] 
**Id** | **int?** | IE87_ID - Id (Required only in PUT/PATCH) | [optional] 
**IdIe84** | **int** | IE87_ID_IE84 - IdIe84 | 
**Imponibile** | **double?** | IE87_IMPONIBILE - Imponibile | [optional] 
**ImponibileVal** | **double?** | IE87_IMPONIBILE_VAL - ImponibileVal | [optional] 
**Imposta** | **double?** | IE87_IMPOSTA - Imposta | [optional] 
**Impostand** | **double?** | IE87_IMPOSTAND - Impostand | [optional] 
**ImpostandVal** | **double?** | IE87_IMPOSTAND_VAL - ImpostandVal | [optional] 
**ImpostaVal** | **double?** | IE87_IMPOSTA_VAL - ImpostaVal | [optional] 
**NaturaL** | **string** | IE87_NATURA_L - NaturaL | [optional] 
**NumLineaL** | **string** | IE87_NUMLINEA_L - NumLineaL | [optional] 
**RitenutaL** | **string** | IE87_RITENUTA_L - RitenutaL | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

