# It.TSEnterprise.Sdk.Model.TributeCodeCODTO
CG0F_CODTRIBUTI - TributeCodeCO<br>Proprietà chiave:<ul><li><b>CodTributo</b></li><li><b>IndSezione</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodMatricolaCg0e** | **string** | CG0F_CODMATRICOLA_CG0E - Codice matricola | 
**CodPeriodo1** | **string** | CG0F_CODPERIODO1 - Codice 1° periodo | [optional] 
**CodPeriodo2** | **string** | CG0F_CODPERIODO2 - Codice 2° periodo | [optional] 
**CodTributo** | **string** | CG0F_CODTRIBUTO - Tributo | 
**Descr** | **string** | CG0F_DESCR - Descrizione ridotta | [optional] 
**Descrext** | **string** | CG0F_DESCREXT - Descrizione | [optional] 
**FlgCodenteloc** | **double?** | CG0F_FLGCODENTELOC - Ind. cod. ente loc.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgCodregione** | **double?** | CG0F_FLGCODREGIONE - Ind.cod.regione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgCredcompens** | **double?** | CG0F_FLGCREDCOMPENS - Cred. compens.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgDebnoncompens** | **double?** | CG0F_FLGDEBNONCOMPENS - Deb. non compens.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgDisattivato** | **int?** | CG0F_FLGDISATTIVATO - FlgDisattivato | [optional] 
**FlgIcicomuni** | **double?** | CG0F_FLGICICOMUNI - Ind. ICI o comuni&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgMeserif** | **double?** | CG0F_FLGMESERIF - Ind. mese rif.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgNumrate** | **double?** | CG0F_FLGNUMRATE - Ind. num. rate&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgRichcodatto** | **double?** | CG0F_FLGRICHCODATTO - Rich. cod. atto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgRichcoduff** | **double?** | CG0F_FLGRICHCODUFF - Rich. cod. ufficio&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgStpprov** | **double?** | CG0F_FLGSTPPROV - Ind. sigla prov.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Impdetrazioneici** | **double** | CG0F_IMPDETRAZIONEICI - Detrazione ICI | 
**IndSezione** | **double?** | CG0F_INDSEZIONE - Sezione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - 1-Erario&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - 2 - INPS&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - 3-Regione&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - 4-ICI e comuni&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - 5-INAIL&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - 6 - Altri&lt;/li&gt;&lt;/ul&gt; | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

