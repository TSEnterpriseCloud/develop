# It.TSEnterprise.Sdk.Model.OfficePACO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Cap** | **string** |  | [optional] 
**CodDestin** | **string** |  | [optional] 
**Codice** | **string** |  | [optional] 
**CodiceCg16** | **int** |  | [optional] 
**Comune** | **string** |  | [optional] 
**FlgPreferenziale** | **int** |  | [optional] 
**Idprovincia** | **int** |  | [optional] 
**Idregione** | **int** |  | [optional] 
**IndIrizzo** | **string** |  | [optional] 
**IndTypeb2b** | **int** |  | [optional] 
**LastupdateB2b** | **DateTime?** |  | [optional] 
**Nome** | **string** |  | [optional] 
**TipocfCg44** | **double** |  | [optional] 
**Parent** | [**CustomerSupplierCO**](CustomerSupplierCO.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

