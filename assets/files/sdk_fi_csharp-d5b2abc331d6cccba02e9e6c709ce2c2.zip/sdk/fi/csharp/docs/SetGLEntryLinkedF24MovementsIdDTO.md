# It.TSEnterprise.Sdk.Model.SetGLEntryLinkedF24MovementsIdDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdCg4t** | **int** |  | [optional] 
**StageGuidGLEntryFI** | **Guid** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

