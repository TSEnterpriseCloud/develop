# It.TSEnterprise.Sdk.Model.CheckNpFIParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ContoCg24** | **string** |  | [optional] 
**DataDoc** | **DateTime** |  | [optional] 
**NumPartita** | **double** |  | [optional] 
**SezPartita** | **string** |  | [optional] 
**FlagPartBis** | **double** |  | [optional] 
**NumReg** | **string** |  | [optional] 
**TipoCF** | **int?** |  | [optional] 
**Clifor** | **int?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

