# It.TSEnterprise.Sdk.Model.GLEntryFIOffSetSummaryResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StageGuid** | **Guid?** |  | [optional] 
**Id** | **double?** |  | [optional] 
**DebitAmount** | **double?** |  | [optional] 
**DebitValAmount** | **double?** |  | [optional] 
**CreditAmount** | **double?** |  | [optional] 
**CreditValAmount** | **double?** |  | [optional] 
**DebitOffset** | **double?** |  | [optional] 
**DebitValOffset** | **double?** |  | [optional] 
**CreditOffset** | **double?** |  | [optional] 
**CreditValOffset** | **double?** |  | [optional] 
**ForceCompanyCurrency** | **bool** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

