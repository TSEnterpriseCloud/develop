# It.TSEnterprise.Sdk.Model.NationCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**A2iso3166** | **string** |  | [optional] 
**A3iso3166** | **string** |  | [optional] 
**Codice** | **double** |  | [optional] 
**CodiceCg08** | **string** |  | [optional] 
**CodIso** | **string** |  | [optional] 
**CodSian** | **double?** |  | [optional] 
**Crtpiva** | **string** |  | [optional] 
**Datacee** | **DateTime?** |  | [optional] 
**Datafinblacklist** | **DateTime?** |  | [optional] 
**Datainiblacklist** | **DateTime?** |  | [optional] 
**Descr** | **string** |  | [optional] 
**Desiso3166** | **string** |  | [optional] 
**FlgIban** | **int** |  | [optional] 
**FlgSepa** | **int?** |  | [optional] 
**IdmediaCg99** | **double?** |  | [optional] 
**IndTipostato** | **double** |  | [optional] 
**Leniban** | **int?** |  | [optional] 
**Numiso3166** | **string** |  | [optional] 
**CurrencyCO** | [**CurrencyCO**](CurrencyCO.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

