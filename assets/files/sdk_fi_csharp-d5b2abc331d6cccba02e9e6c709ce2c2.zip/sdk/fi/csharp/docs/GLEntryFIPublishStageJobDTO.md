# It.TSEnterprise.Sdk.Model.GLEntryFIPublishStageJobDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExternalRif** | **string** |  | [optional] 
**ValidateDTO** | [**ValidateDTO**](ValidateDTO.md) |  | [optional] 
**Entries** | **List&lt;long&gt;** |  | [optional] 
**EntriesAdditionalInfo** | [**List&lt;GLEntryAdditionalInfoDTO&gt;**](GLEntryAdditionalInfoDTO.md) |  | [optional] 
**ValidateMessages** | [**List&lt;GLEntryFIMultipleCreateValidateMessagesDTO&gt;**](GLEntryFIMultipleCreateValidateMessagesDTO.md) |  | [optional] 
**ErrorMessages** | [**List&lt;GLEntryFIMultipleCreateErrorMessagesDTO&gt;**](GLEntryFIMultipleCreateErrorMessagesDTO.md) |  | [optional] 
**Instalments** | **List&lt;long&gt;** |  | [optional] 
**Purchases** | **List&lt;long&gt;** |  | [optional] 
**Info** | **List&lt;string&gt;** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

