# It.TSEnterprise.Sdk.Model.GLVATDetailFIDTO
CG43_MOVIVA - Castelletto IVA<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Causaleiva** | **double** | CG43_CAUSALEIVA - Tipo IVA | 
**DittaCg18** | **double** | CG43_DITTA_CG18 - Azienda | 
**FlgDeducibile** | **int** | CG43_FLGDEDUCIBILE - FlgDeducibile | 
**FlgTsescluso** | **int** | CG43_FLGTSESCLUSO - FlgTsescluso | 
**FlgTsinviato** | **int** | CG43_FLGTSINVIATO - FlgTsinviato | 
**Id** | **long?** | CG43_ID - ID (Required only in PUT/PATCH) | [optional] 
**IdCg41** | **long** | CG43_ID_CG41 - IdCg41 | 
**IdcontoCg24** | **long?** | CG43_IDCONTO_CG24 - IdcontoCg24 | [optional] 
**Imponibile** | **double?** | CG43_IMPONIBILE - Imponibile | [optional] 
**Imponibileval** | **double?** | CG43_IMPONIBILEVAL - Imponibile in valuta | [optional] 
**Imposta** | **double?** | CG43_IMPOSTA - Imposta | [optional] 
**Impostand** | **double?** | CG43_IMPOSTAND - Imposta non detraibile | [optional] 
**Impostandval** | **double?** | CG43_IMPOSTANDVAL - Imposta non detraibile in valuta | [optional] 
**Impostaval** | **double?** | CG43_IMPOSTAVAL - Imposta in valuta | [optional] 
**IndDetriva** | **int** | CG43_INDDETRIVA - Indicatore trattamento indetraibilità IVA | 
**IndIvaacqagric** | **double** | CG43_INDIVAACQAGRIC - IndIvaacqagric | 
**IndNatura** | **int?** | CG43_INDNATURA - Natura | [optional] 
**IndProrata** | **int?** | CG43_INDPRORATA - Tipo pro-rata&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Si tenuta distinta dal costo&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTipo** | **int** | CG43_INDTIPO - Tipo operazione | 
**IndTstipoop** | **int** | CG43_INDTSTIPOOP - IndTstipoop | 
**IndTstiposp** | **int** | CG43_INDTSTIPOSP - IndTstiposp | 
**IndTsvocesp** | **int** | CG43_INDTSVOCESP - IndTsvocesp | 
**Numrigaiva** | **double** | CG43_NUMRIGAIVA - Numero riga IVA | 
**Percdetr** | **double?** | CG43_PERCDETR - % indetraibilità | [optional] 
**Percforf** | **double?** | CG43_PERCFORF - % forfettiz. | [optional] 
**Tsdatadocori** | **DateTime?** | CG43_TSDATADOCORI - Tsdatadocori | [optional] 
**Tsdocorigine** | **string** | CG43_TSDOCORIGINE - Tsdocorigine | [optional] 
**CoaAccountFI** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**ReverseTypeFI** | [**GLReverseTypeFIDTO**](GLReverseTypeFIDTO.md) |  | [optional] 
**VatCodeCO** | [**VatCodeCODTO**](VatCodeCODTO.md) |  | [optional] 
**VatCodeCompensationCO** | [**VatCodeCODTO**](VatCodeCODTO.md) |  | [optional] 
**VatTypeFI** | [**VATTypeFIDTO**](VATTypeFIDTO.md) |  | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

