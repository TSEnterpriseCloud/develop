# It.TSEnterprise.Sdk.Model.InstalmentPaymentDataDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdInstalment** | **long?** |  | [optional] 
**EntryReference** | [**EntryReferenceDTO**](EntryReferenceDTO.md) |  | [optional] 
**NumRigaCont** | **double** |  | [optional] 
**ImportoPagato** | **double?** |  | [optional] 
**ImportoAbbuono** | **double?** |  | [optional] 
**NumeroAssegno** | **string** |  | [optional] 
**RiferimentiAssegno** | **string** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

