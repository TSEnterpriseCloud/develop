# It.TSEnterprise.Sdk.Api.InstalmentStageFIApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**ApiV1EnvironmentFIInstalmentStageFICalculateNextInstalmentStageNumberingPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstageficalculatenextinstalmentstagenumberingpost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/calculate_next_instalment_stage_numbering | TODO_DOCUMENTATION |
| [**ApiV1EnvironmentFIInstalmentStageFICheckglentrychangeallowedPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstageficheckglentrychangeallowedpost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/checkglentrychangeallowed | Check if a GLEnty can be modified or deleted |
| [**ApiV1EnvironmentFIInstalmentStageFICheckglentryrowchangeallowedPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstageficheckglentryrowchangeallowedpost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/checkglentryrowchangeallowed | TODO_DOCUMENTATION |
| [**ApiV1EnvironmentFIInstalmentStageFICheckinstalmentsstageamountsPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstageficheckinstalmentsstageamountspost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/checkinstalmentsstageamounts | TODO_DOCUMENTATION |
| [**ApiV1EnvironmentFIInstalmentStageFICheckstagedataPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstageficheckstagedatapost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/checkstagedata | Check instalment data on stage before save |
| [**ApiV1EnvironmentFIInstalmentStageFIClearinstalmentstagePost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstageficlearinstalmentstagepost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/clearinstalmentstage | Delete all Stage table of a pairing account |
| [**ApiV1EnvironmentFIInstalmentStageFIClearstagePost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstageficlearstagepost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/clearstage | TODO_DOCUMENTATION |
| [**ApiV1EnvironmentFIInstalmentStageFIDeleteinstalmenthistorystagePost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefideleteinstalmenthistorystagepost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/deleteinstalmenthistorystage | Delete Instalment History Stage |
| [**ApiV1EnvironmentFIInstalmentStageFIGet**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefiget) | **GET** /api/v1/{environment}/FI/InstalmentStageFI | Get new |
| [**ApiV1EnvironmentFIInstalmentStageFIGetInstalmentStageSearchParamsSettingsPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefigetinstalmentstagesearchparamssettingspost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/get_instalment_stage_search_params_settings | TODO_DOCUMENTATION |
| [**ApiV1EnvironmentFIInstalmentStageFIGetinstalmentdepositfromstagePost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefigetinstalmentdepositfromstagepost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/getinstalmentdepositfromstage | Retrieve deposit from stage |
| [**ApiV1EnvironmentFIInstalmentStageFIGetinstalmentondocumentPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefigetinstalmentondocumentpost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/getinstalmentondocument | Retrieve instalments of a document |
| [**ApiV1EnvironmentFIInstalmentStageFIGetinstalmentpairingondocumentPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefigetinstalmentpairingondocumentpost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/getinstalmentpairingondocument | Get Instalment paired on stage |
| [**ApiV1EnvironmentFIInstalmentStageFIIdDelete**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefiiddelete) | **DELETE** /api/v1/{environment}/FI/InstalmentStageFI/{id} | Delete |
| [**ApiV1EnvironmentFIInstalmentStageFIIdGet**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefiidget) | **GET** /api/v1/{environment}/FI/InstalmentStageFI/{id} | Get by ID |
| [**ApiV1EnvironmentFIInstalmentStageFIIdPatch**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefiidpatch) | **PATCH** /api/v1/{environment}/FI/InstalmentStageFI/{id} | Update partial |
| [**ApiV1EnvironmentFIInstalmentStageFIIdPut**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefiidput) | **PUT** /api/v1/{environment}/FI/InstalmentStageFI/{id} | Update |
| [**ApiV1EnvironmentFIInstalmentStageFIInitializePost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefiinitializepost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/initialize | Acquisition of deadlines in the staging tables |
| [**ApiV1EnvironmentFIInstalmentStageFIInsertinstalmenttostagePost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefiinsertinstalmenttostagepost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/insertinstalmenttostage | Insert instalments to stage |
| [**ApiV1EnvironmentFIInstalmentStageFIInstalmentcalculationPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefiinstalmentcalculationpost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/instalmentcalculation | TODO_DOCUMENTATION |
| [**ApiV1EnvironmentFIInstalmentStageFIInstalmentspairingPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefiinstalmentspairingpost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/instalmentspairing | Instalments pairing |
| [**ApiV1EnvironmentFIInstalmentStageFIInstalmentspairingblockedPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefiinstalmentspairingblockedpost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/instalmentspairingblocked | TODO_DOCUMENTATION |
| [**ApiV1EnvironmentFIInstalmentStageFIInstalmentspaymentPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefiinstalmentspaymentpost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/instalmentspayment | Instalments payment |
| [**ApiV1EnvironmentFIInstalmentStageFIInstalmentsunpairingPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefiinstalmentsunpairingpost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/instalmentsunpairing | Instalments unpairing |
| [**ApiV1EnvironmentFIInstalmentStageFIManagestageddataPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefimanagestageddatapost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/managestageddata | Insert InstalmentStageFI into InstalmentFI |
| [**ApiV1EnvironmentFIInstalmentStageFIMarkdeletedstagedataPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefimarkdeletedstagedatapost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/markdeletedstagedata | Mark deleted instalment data on stage |
| [**ApiV1EnvironmentFIInstalmentStageFIPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefipost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI | Create |
| [**ApiV1EnvironmentFIInstalmentStageFIReadPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefireadpost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/read | Read |
| [**ApiV1EnvironmentFIInstalmentStageFISearchPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefisearchpost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/search | Search |
| [**ApiV1EnvironmentFIInstalmentStageFIUpdatestageextensiondataPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefiupdatestageextensiondatapost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/updatestageextensiondata | TODO_DOCUMENTATION |
| [**ApiV1EnvironmentFIInstalmentStageFIValidatePost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefivalidatepost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/validate | Validate |
| [**ApiV1EnvironmentFIInstalmentStageFIValidatePropertiesPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefivalidatepropertiespost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/validateProperties | Validation of one on more properties of Type |
| [**ApiV1EnvironmentFIInstalmentStageFIWritestageoncontextualPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefiwritestageoncontextualpost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/writestageoncontextual | TODO_DOCUMENTATION |
| [**ApiV1EnvironmentFIInstalmentStageFIWritingstageoncollectionoperationPost**](InstalmentStageFIApi.md#apiv1environmentfiinstalmentstagefiwritingstageoncollectionoperationpost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/writingstageoncollectionoperation | Writing stage on collection operation |

<a id="apiv1environmentfiinstalmentstageficalculatenextinstalmentstagenumberingpost"></a>
# **ApiV1EnvironmentFIInstalmentStageFICalculateNextInstalmentStageNumberingPost**
> InstalmentNumberingCalculationResultDTO ApiV1EnvironmentFIInstalmentStageFICalculateNextInstalmentStageNumberingPost (string environment, string authorizationScope, InstalmentStageNumberingCalculationParametersDTO instalmentStageNumberingCalculationParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFICalculateNextInstalmentStageNumberingPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentStageNumberingCalculationParametersDTO = new InstalmentStageNumberingCalculationParametersDTO(); // InstalmentStageNumberingCalculationParametersDTO | TODO_DOCUMENTATION
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // TODO_DOCUMENTATION
                InstalmentNumberingCalculationResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFICalculateNextInstalmentStageNumberingPost(environment, authorizationScope, instalmentStageNumberingCalculationParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFICalculateNextInstalmentStageNumberingPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFICalculateNextInstalmentStageNumberingPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // TODO_DOCUMENTATION
    ApiResponse<InstalmentNumberingCalculationResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFICalculateNextInstalmentStageNumberingPostWithHttpInfo(environment, authorizationScope, instalmentStageNumberingCalculationParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFICalculateNextInstalmentStageNumberingPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentStageNumberingCalculationParametersDTO** | [**InstalmentStageNumberingCalculationParametersDTO**](InstalmentStageNumberingCalculationParametersDTO.md) | TODO_DOCUMENTATION |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentNumberingCalculationResultDTO**](InstalmentNumberingCalculationResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | TODO_DOCUMENTATION |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstageficheckglentrychangeallowedpost"></a>
# **ApiV1EnvironmentFIInstalmentStageFICheckglentrychangeallowedPost**
> ExecutionResultMessageDTO ApiV1EnvironmentFIInstalmentStageFICheckglentrychangeallowedPost (string environment, string authorizationScope, GLEntryChangeAllowedDTO gLEntryChangeAllowedDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Check if a GLEnty can be modified or deleted

Check if a GLEnty can be modified or deleted

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFICheckglentrychangeallowedPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var gLEntryChangeAllowedDTO = new GLEntryChangeAllowedDTO(); // GLEntryChangeAllowedDTO | Input parameter to verify if GLEntry can be modified, it contains the numReg
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Check if a GLEnty can be modified or deleted
                ExecutionResultMessageDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFICheckglentrychangeallowedPost(environment, authorizationScope, gLEntryChangeAllowedDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFICheckglentrychangeallowedPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFICheckglentrychangeallowedPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Check if a GLEnty can be modified or deleted
    ApiResponse<ExecutionResultMessageDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFICheckglentrychangeallowedPostWithHttpInfo(environment, authorizationScope, gLEntryChangeAllowedDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFICheckglentrychangeallowedPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **gLEntryChangeAllowedDTO** | [**GLEntryChangeAllowedDTO**](GLEntryChangeAllowedDTO.md) | Input parameter to verify if GLEntry can be modified, it contains the numReg |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**ExecutionResultMessageDTO**](ExecutionResultMessageDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result of the operation with any error messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstageficheckglentryrowchangeallowedpost"></a>
# **ApiV1EnvironmentFIInstalmentStageFICheckglentryrowchangeallowedPost**
> void ApiV1EnvironmentFIInstalmentStageFICheckglentryrowchangeallowedPost (string environment, string authorizationScope, GLEntryRowChangeAllowedDTO gLEntryRowChangeAllowedDTO, string? company = null, string? user = null, string? acceptLanguage = null)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFICheckglentryrowchangeallowedPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var gLEntryRowChangeAllowedDTO = new GLEntryRowChangeAllowedDTO(); // GLEntryRowChangeAllowedDTO | TODO_DOCUMENTATION
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // TODO_DOCUMENTATION
                apiInstance.ApiV1EnvironmentFIInstalmentStageFICheckglentryrowchangeallowedPost(environment, authorizationScope, gLEntryRowChangeAllowedDTO, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFICheckglentryrowchangeallowedPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFICheckglentryrowchangeallowedPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // TODO_DOCUMENTATION
    apiInstance.ApiV1EnvironmentFIInstalmentStageFICheckglentryrowchangeallowedPostWithHttpInfo(environment, authorizationScope, gLEntryRowChangeAllowedDTO, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFICheckglentryrowchangeallowedPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **gLEntryRowChangeAllowedDTO** | [**GLEntryRowChangeAllowedDTO**](GLEntryRowChangeAllowedDTO.md) | TODO_DOCUMENTATION |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | TODO_DOCUMENTATION |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstageficheckinstalmentsstageamountspost"></a>
# **ApiV1EnvironmentFIInstalmentStageFICheckinstalmentsstageamountsPost**
> FIGLEntriesExecutionResultDTO ApiV1EnvironmentFIInstalmentStageFICheckinstalmentsstageamountsPost (string environment, string authorizationScope, CheckInstalmentsStageAmountsParametersDTO checkInstalmentsStageAmountsParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFICheckinstalmentsstageamountsPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var checkInstalmentsStageAmountsParametersDTO = new CheckInstalmentsStageAmountsParametersDTO(); // CheckInstalmentsStageAmountsParametersDTO | TODO_DOCUMENTATION
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // TODO_DOCUMENTATION
                FIGLEntriesExecutionResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFICheckinstalmentsstageamountsPost(environment, authorizationScope, checkInstalmentsStageAmountsParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFICheckinstalmentsstageamountsPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFICheckinstalmentsstageamountsPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // TODO_DOCUMENTATION
    ApiResponse<FIGLEntriesExecutionResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFICheckinstalmentsstageamountsPostWithHttpInfo(environment, authorizationScope, checkInstalmentsStageAmountsParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFICheckinstalmentsstageamountsPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **checkInstalmentsStageAmountsParametersDTO** | [**CheckInstalmentsStageAmountsParametersDTO**](CheckInstalmentsStageAmountsParametersDTO.md) | TODO_DOCUMENTATION |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | TODO_DOCUMENTATION |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstageficheckstagedatapost"></a>
# **ApiV1EnvironmentFIInstalmentStageFICheckstagedataPost**
> void ApiV1EnvironmentFIInstalmentStageFICheckstagedataPost (string environment, string authorizationScope, CheckInstalmentStageDTO checkInstalmentStageDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Check instalment data on stage before save

Instalment check

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFICheckstagedataPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var checkInstalmentStageDTO = new CheckInstalmentStageDTO(); // CheckInstalmentStageDTO | Input parameter to precede for instalment check before save
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Check instalment data on stage before save
                apiInstance.ApiV1EnvironmentFIInstalmentStageFICheckstagedataPost(environment, authorizationScope, checkInstalmentStageDTO, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFICheckstagedataPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFICheckstagedataPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Check instalment data on stage before save
    apiInstance.ApiV1EnvironmentFIInstalmentStageFICheckstagedataPostWithHttpInfo(environment, authorizationScope, checkInstalmentStageDTO, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFICheckstagedataPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **checkInstalmentStageDTO** | [**CheckInstalmentStageDTO**](CheckInstalmentStageDTO.md) | Input parameter to precede for instalment check before save |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstageficlearinstalmentstagepost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIClearinstalmentstagePost**
> FIGLEntriesExecutionResultDTO ApiV1EnvironmentFIInstalmentStageFIClearinstalmentstagePost (string environment, string authorizationScope, ClearInstalmentStageDTO clearInstalmentStageDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Delete all Stage table of a pairing account

Delete all Stage table of a pairing account

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIClearinstalmentstagePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var clearInstalmentStageDTO = new ClearInstalmentStageDTO(); // ClearInstalmentStageDTO | StageGuid of a pairing
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Delete all Stage table of a pairing account
                FIGLEntriesExecutionResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIClearinstalmentstagePost(environment, authorizationScope, clearInstalmentStageDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIClearinstalmentstagePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIClearinstalmentstagePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete all Stage table of a pairing account
    ApiResponse<FIGLEntriesExecutionResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIClearinstalmentstagePostWithHttpInfo(environment, authorizationScope, clearInstalmentStageDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIClearinstalmentstagePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **clearInstalmentStageDTO** | [**ClearInstalmentStageDTO**](ClearInstalmentStageDTO.md) | StageGuid of a pairing |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The result of operation |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstageficlearstagepost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIClearstagePost**
> FIGLEntriesExecutionResultDTO ApiV1EnvironmentFIInstalmentStageFIClearstagePost (string environment, string authorizationScope, ClearInstalmentStageDTO clearInstalmentStageDTO, string? company = null, string? user = null, string? acceptLanguage = null)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIClearstagePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var clearInstalmentStageDTO = new ClearInstalmentStageDTO(); // ClearInstalmentStageDTO | TODO_DOCUMENTATION
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // TODO_DOCUMENTATION
                FIGLEntriesExecutionResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIClearstagePost(environment, authorizationScope, clearInstalmentStageDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIClearstagePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIClearstagePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // TODO_DOCUMENTATION
    ApiResponse<FIGLEntriesExecutionResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIClearstagePostWithHttpInfo(environment, authorizationScope, clearInstalmentStageDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIClearstagePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **clearInstalmentStageDTO** | [**ClearInstalmentStageDTO**](ClearInstalmentStageDTO.md) | TODO_DOCUMENTATION |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | TODO_DOCUMENTATION |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefideleteinstalmenthistorystagepost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIDeleteinstalmenthistorystagePost**
> FIGLEntriesExecutionResultDTO ApiV1EnvironmentFIInstalmentStageFIDeleteinstalmenthistorystagePost (string environment, string authorizationScope, ClearInstalmentStageDTO clearInstalmentStageDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Delete Instalment History Stage

Delete the instalment stage 

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIDeleteinstalmenthistorystagePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var clearInstalmentStageDTO = new ClearInstalmentStageDTO(); // ClearInstalmentStageDTO | The StageGuid of instalment
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Delete Instalment History Stage
                FIGLEntriesExecutionResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIDeleteinstalmenthistorystagePost(environment, authorizationScope, clearInstalmentStageDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIDeleteinstalmenthistorystagePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIDeleteinstalmenthistorystagePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete Instalment History Stage
    ApiResponse<FIGLEntriesExecutionResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIDeleteinstalmenthistorystagePostWithHttpInfo(environment, authorizationScope, clearInstalmentStageDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIDeleteinstalmenthistorystagePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **clearInstalmentStageDTO** | [**ClearInstalmentStageDTO**](ClearInstalmentStageDTO.md) | The StageGuid of instalment |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The result of operation |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefiget"></a>
# **ApiV1EnvironmentFIInstalmentStageFIGet**
> InstalmentStageFIDTO ApiV1EnvironmentFIInstalmentStageFIGet (string op, string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null)

Get new

Get an empty object of type corresponding

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var op = "op_example";  // string | The value must be 'new'
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get new
                InstalmentStageFIDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIGet(op, environment, authorizationScope, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get new
    ApiResponse<InstalmentStageFIDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIGetWithHttpInfo(op, environment, authorizationScope, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **op** | **string** | The value must be &#39;new&#39; |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentStageFIDTO**](InstalmentStageFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The empty object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefigetinstalmentstagesearchparamssettingspost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIGetInstalmentStageSearchParamsSettingsPost**
> InstalmentStageSearchParamsSettingsResultDTO ApiV1EnvironmentFIInstalmentStageFIGetInstalmentStageSearchParamsSettingsPost (string environment, string authorizationScope, GuidFIDTO guidFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIGetInstalmentStageSearchParamsSettingsPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var guidFIDTO = new GuidFIDTO(); // GuidFIDTO | TODO_DOCUMENTATION
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // TODO_DOCUMENTATION
                InstalmentStageSearchParamsSettingsResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIGetInstalmentStageSearchParamsSettingsPost(environment, authorizationScope, guidFIDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIGetInstalmentStageSearchParamsSettingsPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIGetInstalmentStageSearchParamsSettingsPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // TODO_DOCUMENTATION
    ApiResponse<InstalmentStageSearchParamsSettingsResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIGetInstalmentStageSearchParamsSettingsPostWithHttpInfo(environment, authorizationScope, guidFIDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIGetInstalmentStageSearchParamsSettingsPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **guidFIDTO** | [**GuidFIDTO**](GuidFIDTO.md) | TODO_DOCUMENTATION |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentStageSearchParamsSettingsResultDTO**](InstalmentStageSearchParamsSettingsResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | TODO_DOCUMENTATION |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefigetinstalmentdepositfromstagepost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIGetinstalmentdepositfromstagePost**
> Int64ListGLEntryGenericResultDTO ApiV1EnvironmentFIInstalmentStageFIGetinstalmentdepositfromstagePost (string environment, string authorizationScope, InstalmentToStageGuidParameterDTO instalmentToStageGuidParameterDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Retrieve deposit from stage

Retreve the list of Id of deposit in stage

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIGetinstalmentdepositfromstagePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentToStageGuidParameterDTO = new InstalmentToStageGuidParameterDTO(); // InstalmentToStageGuidParameterDTO | Input parameters
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Retrieve deposit from stage
                Int64ListGLEntryGenericResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIGetinstalmentdepositfromstagePost(environment, authorizationScope, instalmentToStageGuidParameterDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIGetinstalmentdepositfromstagePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIGetinstalmentdepositfromstagePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Retrieve deposit from stage
    ApiResponse<Int64ListGLEntryGenericResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIGetinstalmentdepositfromstagePostWithHttpInfo(environment, authorizationScope, instalmentToStageGuidParameterDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIGetinstalmentdepositfromstagePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentToStageGuidParameterDTO** | [**InstalmentToStageGuidParameterDTO**](InstalmentToStageGuidParameterDTO.md) | Input parameters |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**Int64ListGLEntryGenericResultDTO**](Int64ListGLEntryGenericResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Done |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of error the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefigetinstalmentondocumentpost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIGetinstalmentondocumentPost**
> DocumentInstalmentsResultDTO ApiV1EnvironmentFIInstalmentStageFIGetinstalmentondocumentPost (string environment, string authorizationScope, DocumentInstalmentsParametersDTO documentInstalmentsParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Retrieve instalments of a document

Retrieve instalments of a document

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIGetinstalmentondocumentPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var documentInstalmentsParametersDTO = new DocumentInstalmentsParametersDTO(); // DocumentInstalmentsParametersDTO | The Numreg of instalments
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Retrieve instalments of a document
                DocumentInstalmentsResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIGetinstalmentondocumentPost(environment, authorizationScope, documentInstalmentsParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIGetinstalmentondocumentPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIGetinstalmentondocumentPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Retrieve instalments of a document
    ApiResponse<DocumentInstalmentsResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIGetinstalmentondocumentPostWithHttpInfo(environment, authorizationScope, documentInstalmentsParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIGetinstalmentondocumentPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **documentInstalmentsParametersDTO** | [**DocumentInstalmentsParametersDTO**](DocumentInstalmentsParametersDTO.md) | The Numreg of instalments |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**DocumentInstalmentsResultDTO**](DocumentInstalmentsResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The list of instalment on a document |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefigetinstalmentpairingondocumentpost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIGetinstalmentpairingondocumentPost**
> DocumentInstalmentsResultDTO ApiV1EnvironmentFIInstalmentStageFIGetinstalmentpairingondocumentPost (string environment, string authorizationScope, DocumentInstalmentsStageParametersDTO documentInstalmentsStageParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Get Instalment paired on stage

Retrieve instalment paired on document and delete stage

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIGetinstalmentpairingondocumentPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var documentInstalmentsStageParametersDTO = new DocumentInstalmentsStageParametersDTO(); // DocumentInstalmentsStageParametersDTO | The StageGuid of pairing operation
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get Instalment paired on stage
                DocumentInstalmentsResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIGetinstalmentpairingondocumentPost(environment, authorizationScope, documentInstalmentsStageParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIGetinstalmentpairingondocumentPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIGetinstalmentpairingondocumentPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get Instalment paired on stage
    ApiResponse<DocumentInstalmentsResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIGetinstalmentpairingondocumentPostWithHttpInfo(environment, authorizationScope, documentInstalmentsStageParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIGetinstalmentpairingondocumentPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **documentInstalmentsStageParametersDTO** | [**DocumentInstalmentsStageParametersDTO**](DocumentInstalmentsStageParametersDTO.md) | The StageGuid of pairing operation |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**DocumentInstalmentsResultDTO**](DocumentInstalmentsResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The result of operation and the partial Guid of Document instalment |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefiiddelete"></a>
# **ApiV1EnvironmentFIInstalmentStageFIIdDelete**
> void ApiV1EnvironmentFIInstalmentStageFIIdDelete (string id, string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null)

Delete

Deleting object of type 

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIIdDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var id = "id_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Delete
                apiInstance.ApiV1EnvironmentFIInstalmentStageFIIdDelete(id, environment, authorizationScope, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIIdDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIIdDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete
    apiInstance.ApiV1EnvironmentFIInstalmentStageFIIdDeleteWithHttpInfo(id, environment, authorizationScope, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIIdDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object has been deleted |  -  |
| **400** | if object has not been deleted: the content response contains the validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |
| **409** | If object has not been deleted due to business rules violation: the content response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefiidget"></a>
# **ApiV1EnvironmentFIInstalmentStageFIIdGet**
> InstalmentStageFIDTO ApiV1EnvironmentFIInstalmentStageFIIdGet (string id, string environment, string authorizationScope, string? dlevel = null, string? dlevelkey = null, string? company = null, string? user = null, string? acceptLanguage = null)

Get by ID

Get an object of type corresponding the requested id

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIIdGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var id = "id_example";  // string | Id to get the object
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var dlevel = "dlevel_example";  // string? | Serialization level (optional) 
            var dlevelkey = "dlevelkey_example";  // string? | Serialization level key (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get by ID
                InstalmentStageFIDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIIdGet(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIIdGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIIdGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get by ID
    ApiResponse<InstalmentStageFIDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIIdGetWithHttpInfo(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIIdGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** | Id to get the object |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **dlevel** | **string?** | Serialization level | [optional]  |
| **dlevelkey** | **string?** | Serialization level key | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentStageFIDTO**](InstalmentStageFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefiidpatch"></a>
# **ApiV1EnvironmentFIInstalmentStageFIIdPatch**
> void ApiV1EnvironmentFIInstalmentStageFIIdPatch (string id, string environment, string authorizationScope, Object body, string? force = null, string? op = null, string? company = null, string? user = null, string? acceptLanguage = null)

Update partial

Patching an object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIIdPatchExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var id = "id_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var body = null;  // Object | Object of type to patch
            var force = "force_example";  // string? | The warning/s code to bypass (separated by ‘,’) during the execution (optional) 
            var op = "op_example";  // string? | Set 'reload', if you want the DTO updated in the response request (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Update partial
                apiInstance.ApiV1EnvironmentFIInstalmentStageFIIdPatch(id, environment, authorizationScope, body, force, op, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIIdPatch: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIIdPatchWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update partial
    apiInstance.ApiV1EnvironmentFIInstalmentStageFIIdPatchWithHttpInfo(id, environment, authorizationScope, body, force, op, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIIdPatchWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **body** | **Object** | Object of type to patch |  |
| **force** | **string?** | The warning/s code to bypass (separated by ‘,’) during the execution | [optional]  |
| **op** | **string?** | Set &#39;reload&#39;, if you want the DTO updated in the response request | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object has been updated |  -  |
| **400** | If the object has not been patched: the content response contains the validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |
| **409** | If object has not been patched due to business rules violation: the content response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefiidput"></a>
# **ApiV1EnvironmentFIInstalmentStageFIIdPut**
> InstalmentStageFIDTO ApiV1EnvironmentFIInstalmentStageFIIdPut (string id, string environment, string authorizationScope, InstalmentStageFIDTO instalmentStageFIDTO, string? force = null, string? op = null, string? company = null, string? user = null, string? acceptLanguage = null)

Update

Updating an object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIIdPutExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var id = "id_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentStageFIDTO = new InstalmentStageFIDTO(); // InstalmentStageFIDTO | Object of type to update
            var force = "force_example";  // string? | The warning/s code to bypass (separated by ‘,’) during the execution (optional) 
            var op = "op_example";  // string? | Set 'reload', if you want the DTO updated in the response request, otherwise will be returned null value (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Update
                InstalmentStageFIDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIIdPut(id, environment, authorizationScope, instalmentStageFIDTO, force, op, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIIdPut: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIIdPutWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update
    ApiResponse<InstalmentStageFIDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIIdPutWithHttpInfo(id, environment, authorizationScope, instalmentStageFIDTO, force, op, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIIdPutWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentStageFIDTO** | [**InstalmentStageFIDTO**](InstalmentStageFIDTO.md) | Object of type to update |  |
| **force** | **string?** | The warning/s code to bypass (separated by ‘,’) during the execution | [optional]  |
| **op** | **string?** | Set &#39;reload&#39;, if you want the DTO updated in the response request, otherwise will be returned null value | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentStageFIDTO**](InstalmentStageFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object has been updated |  -  |
| **400** | If the object has not been updated: the content response contains the validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |
| **409** | If object has not been updated due to business rules violation: the content response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefiinitializepost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIInitializePost**
> InstalmentStageFIResultDTO ApiV1EnvironmentFIInstalmentStageFIInitializePost (string environment, string authorizationScope, InstalmentStageFIParametersDTO instalmentStageFIParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Acquisition of deadlines in the staging tables

Acquisition of deadlines in the staging tables

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIInitializePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentStageFIParametersDTO = new InstalmentStageFIParametersDTO(); // InstalmentStageFIParametersDTO | Object that contains all the parameters necessary for the recovery and insertion in the stage of the deadlines
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Acquisition of deadlines in the staging tables
                InstalmentStageFIResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIInitializePost(environment, authorizationScope, instalmentStageFIParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIInitializePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIInitializePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Acquisition of deadlines in the staging tables
    ApiResponse<InstalmentStageFIResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIInitializePostWithHttpInfo(environment, authorizationScope, instalmentStageFIParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIInitializePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentStageFIParametersDTO** | [**InstalmentStageFIParametersDTO**](InstalmentStageFIParametersDTO.md) | Object that contains all the parameters necessary for the recovery and insertion in the stage of the deadlines |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentStageFIResultDTO**](InstalmentStageFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefiinsertinstalmenttostagepost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIInsertinstalmenttostagePost**
> BooleanGLEntryGenericResultDTO ApiV1EnvironmentFIInstalmentStageFIInsertinstalmenttostagePost (string environment, string authorizationScope, InstalmentToStageParameterDTO instalmentToStageParameterDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Insert instalments to stage

Insert instalments to stage

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIInsertinstalmenttostagePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentToStageParameterDTO = new InstalmentToStageParameterDTO(); // InstalmentToStageParameterDTO | Input parameters
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Insert instalments to stage
                BooleanGLEntryGenericResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIInsertinstalmenttostagePost(environment, authorizationScope, instalmentToStageParameterDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIInsertinstalmenttostagePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIInsertinstalmenttostagePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Insert instalments to stage
    ApiResponse<BooleanGLEntryGenericResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIInsertinstalmenttostagePostWithHttpInfo(environment, authorizationScope, instalmentToStageParameterDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIInsertinstalmenttostagePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentToStageParameterDTO** | [**InstalmentToStageParameterDTO**](InstalmentToStageParameterDTO.md) | Input parameters |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**BooleanGLEntryGenericResultDTO**](BooleanGLEntryGenericResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Inserted |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of error the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefiinstalmentcalculationpost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIInstalmentcalculationPost**
> InstalmentCalculationResultFIDTO ApiV1EnvironmentFIInstalmentStageFIInstalmentcalculationPost (string environment, string authorizationScope, InstalmentCalculationParametersFIDTO instalmentCalculationParametersFIDTO, string? create = null, string? company = null, string? user = null, string? acceptLanguage = null)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIInstalmentcalculationPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentCalculationParametersFIDTO = new InstalmentCalculationParametersFIDTO(); // InstalmentCalculationParametersFIDTO | TODO_DOCUMENTATION
            var create = "create_example";  // string? | create (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // TODO_DOCUMENTATION
                InstalmentCalculationResultFIDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIInstalmentcalculationPost(environment, authorizationScope, instalmentCalculationParametersFIDTO, create, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIInstalmentcalculationPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIInstalmentcalculationPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // TODO_DOCUMENTATION
    ApiResponse<InstalmentCalculationResultFIDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIInstalmentcalculationPostWithHttpInfo(environment, authorizationScope, instalmentCalculationParametersFIDTO, create, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIInstalmentcalculationPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentCalculationParametersFIDTO** | [**InstalmentCalculationParametersFIDTO**](InstalmentCalculationParametersFIDTO.md) | TODO_DOCUMENTATION |  |
| **create** | **string?** | create | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentCalculationResultFIDTO**](InstalmentCalculationResultFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | TODO_DOCUMENTATION |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefiinstalmentspairingpost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIInstalmentspairingPost**
> InstalmentsPairingResultDTO ApiV1EnvironmentFIInstalmentStageFIInstalmentspairingPost (string environment, string authorizationScope, InstalmentsPairingParametersDTO instalmentsPairingParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Instalments pairing

Instalments pairing

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIInstalmentspairingPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentsPairingParametersDTO = new InstalmentsPairingParametersDTO(); // InstalmentsPairingParametersDTO | Object that contains all the parameters necessary for the association of advances to deadlines
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Instalments pairing
                InstalmentsPairingResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIInstalmentspairingPost(environment, authorizationScope, instalmentsPairingParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIInstalmentspairingPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIInstalmentspairingPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Instalments pairing
    ApiResponse<InstalmentsPairingResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIInstalmentspairingPostWithHttpInfo(environment, authorizationScope, instalmentsPairingParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIInstalmentspairingPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentsPairingParametersDTO** | [**InstalmentsPairingParametersDTO**](InstalmentsPairingParametersDTO.md) | Object that contains all the parameters necessary for the association of advances to deadlines |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentsPairingResultDTO**](InstalmentsPairingResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefiinstalmentspairingblockedpost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIInstalmentspairingblockedPost**
> InstalmentsPairingBlockedResultDTO ApiV1EnvironmentFIInstalmentStageFIInstalmentspairingblockedPost (string environment, string authorizationScope, InstalmentsPairingBlockedParametersDTO instalmentsPairingBlockedParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIInstalmentspairingblockedPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentsPairingBlockedParametersDTO = new InstalmentsPairingBlockedParametersDTO(); // InstalmentsPairingBlockedParametersDTO | TODO_DOCUMENTATION
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // TODO_DOCUMENTATION
                InstalmentsPairingBlockedResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIInstalmentspairingblockedPost(environment, authorizationScope, instalmentsPairingBlockedParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIInstalmentspairingblockedPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIInstalmentspairingblockedPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // TODO_DOCUMENTATION
    ApiResponse<InstalmentsPairingBlockedResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIInstalmentspairingblockedPostWithHttpInfo(environment, authorizationScope, instalmentsPairingBlockedParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIInstalmentspairingblockedPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentsPairingBlockedParametersDTO** | [**InstalmentsPairingBlockedParametersDTO**](InstalmentsPairingBlockedParametersDTO.md) | TODO_DOCUMENTATION |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentsPairingBlockedResultDTO**](InstalmentsPairingBlockedResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | TODO_DOCUMENTATION |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefiinstalmentspaymentpost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIInstalmentspaymentPost**
> InstalmentsPaymentResultDTO ApiV1EnvironmentFIInstalmentStageFIInstalmentspaymentPost (string environment, string authorizationScope, InstalmentsPaymentParametersDTO instalmentsPaymentParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Instalments payment

Instalments payment

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIInstalmentspaymentPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentsPaymentParametersDTO = new InstalmentsPaymentParametersDTO(); // InstalmentsPaymentParametersDTO | Object that contains all the parameters necessary for payment / collection of deadlines
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Instalments payment
                InstalmentsPaymentResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIInstalmentspaymentPost(environment, authorizationScope, instalmentsPaymentParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIInstalmentspaymentPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIInstalmentspaymentPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Instalments payment
    ApiResponse<InstalmentsPaymentResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIInstalmentspaymentPostWithHttpInfo(environment, authorizationScope, instalmentsPaymentParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIInstalmentspaymentPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentsPaymentParametersDTO** | [**InstalmentsPaymentParametersDTO**](InstalmentsPaymentParametersDTO.md) | Object that contains all the parameters necessary for payment / collection of deadlines |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentsPaymentResultDTO**](InstalmentsPaymentResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefiinstalmentsunpairingpost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIInstalmentsunpairingPost**
> InstalmentsUnpairingResultDTO ApiV1EnvironmentFIInstalmentStageFIInstalmentsunpairingPost (string force, string environment, string authorizationScope, InstalmentsUnpairingParametersDTO instalmentsUnpairingParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Instalments unpairing

Instalments unpairing

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIInstalmentsunpairingPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var force = "force_example";  // string | force
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentsUnpairingParametersDTO = new InstalmentsUnpairingParametersDTO(); // InstalmentsUnpairingParametersDTO | Object that contains all the parameters necessary to disassociate advances from deadlines
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Instalments unpairing
                InstalmentsUnpairingResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIInstalmentsunpairingPost(force, environment, authorizationScope, instalmentsUnpairingParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIInstalmentsunpairingPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIInstalmentsunpairingPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Instalments unpairing
    ApiResponse<InstalmentsUnpairingResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIInstalmentsunpairingPostWithHttpInfo(force, environment, authorizationScope, instalmentsUnpairingParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIInstalmentsunpairingPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **force** | **string** | force |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentsUnpairingParametersDTO** | [**InstalmentsUnpairingParametersDTO**](InstalmentsUnpairingParametersDTO.md) | Object that contains all the parameters necessary to disassociate advances from deadlines |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentsUnpairingResultDTO**](InstalmentsUnpairingResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefimanagestageddatapost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIManagestageddataPost**
> InstalmentStageFIResultDTO ApiV1EnvironmentFIInstalmentStageFIManagestageddataPost (string environment, string authorizationScope, InstalmentStageDTO instalmentStageDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Insert InstalmentStageFI into InstalmentFI

Insert all instalments from stage that correspond to the GUID and registration number

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIManagestageddataPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentStageDTO = new InstalmentStageDTO(); // InstalmentStageDTO | TODO_DOCUMENTATION
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Insert InstalmentStageFI into InstalmentFI
                InstalmentStageFIResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIManagestageddataPost(environment, authorizationScope, instalmentStageDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIManagestageddataPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIManagestageddataPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Insert InstalmentStageFI into InstalmentFI
    ApiResponse<InstalmentStageFIResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIManagestageddataPostWithHttpInfo(environment, authorizationScope, instalmentStageDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIManagestageddataPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentStageDTO** | [**InstalmentStageDTO**](InstalmentStageDTO.md) | TODO_DOCUMENTATION |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentStageFIResultDTO**](InstalmentStageFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefimarkdeletedstagedatapost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIMarkdeletedstagedataPost**
> FIGLEntriesExecutionResultDTO ApiV1EnvironmentFIInstalmentStageFIMarkdeletedstagedataPost (string environment, string authorizationScope, InstalmentMarkDeletedStageDataDTO instalmentMarkDeletedStageDataDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Mark deleted instalment data on stage

Mark deleted instalment

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIMarkdeletedstagedataPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentMarkDeletedStageDataDTO = new InstalmentMarkDeletedStageDataDTO(); // InstalmentMarkDeletedStageDataDTO | Input parameter to precede for mark deleted instalment data
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Mark deleted instalment data on stage
                FIGLEntriesExecutionResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIMarkdeletedstagedataPost(environment, authorizationScope, instalmentMarkDeletedStageDataDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIMarkdeletedstagedataPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIMarkdeletedstagedataPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Mark deleted instalment data on stage
    ApiResponse<FIGLEntriesExecutionResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIMarkdeletedstagedataPostWithHttpInfo(environment, authorizationScope, instalmentMarkDeletedStageDataDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIMarkdeletedstagedataPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentMarkDeletedStageDataDTO** | [**InstalmentMarkDeletedStageDataDTO**](InstalmentMarkDeletedStageDataDTO.md) | Input parameter to precede for mark deleted instalment data |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Operation result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefipost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIPost**
> InstalmentStageFIDTO ApiV1EnvironmentFIInstalmentStageFIPost (string environment, string authorizationScope, InstalmentStageFIDTO instalmentStageFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Create

Creating new object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentStageFIDTO = new InstalmentStageFIDTO(); // InstalmentStageFIDTO | Object of type to create
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Create
                InstalmentStageFIDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIPost(environment, authorizationScope, instalmentStageFIDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Create
    ApiResponse<InstalmentStageFIDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIPostWithHttpInfo(environment, authorizationScope, instalmentStageFIDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentStageFIDTO** | [**InstalmentStageFIDTO**](InstalmentStageFIDTO.md) | Object of type to create |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentStageFIDTO**](InstalmentStageFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | If object has been created |  -  |
| **400** | If the object has not been created: the content response contains validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object has not been created due to business rules violation: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefireadpost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIReadPost**
> InstalmentStageFIDTO ApiV1EnvironmentFIInstalmentStageFIReadPost (string environment, string authorizationScope, List<SearchElementDTO> searchElementDTO, string? dlevel = null, string? dlevelkey = null, string? company = null, string? user = null, string? acceptLanguage = null)

Read

Read among object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIReadPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var searchElementDTO = new List<SearchElementDTO>(); // List<SearchElementDTO> | Search criteria to apply
            var dlevel = "dlevel_example";  // string? | Serialization level (optional) 
            var dlevelkey = "dlevelkey_example";  // string? | Serialization level key (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Read
                InstalmentStageFIDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIReadPost(environment, authorizationScope, searchElementDTO, dlevel, dlevelkey, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIReadPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIReadPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Read
    ApiResponse<InstalmentStageFIDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIReadPostWithHttpInfo(environment, authorizationScope, searchElementDTO, dlevel, dlevelkey, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIReadPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **searchElementDTO** | [**List&lt;SearchElementDTO&gt;**](SearchElementDTO.md) | Search criteria to apply |  |
| **dlevel** | **string?** | Serialization level | [optional]  |
| **dlevelkey** | **string?** | Serialization level key | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentStageFIDTO**](InstalmentStageFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefisearchpost"></a>
# **ApiV1EnvironmentFIInstalmentStageFISearchPost**
> InstalmentStageFIDTO ApiV1EnvironmentFIInstalmentStageFISearchPost (string environment, string authorizationScope, SearchDTO searchDTO, string? loadEntireDomain = null, string? getTotalCount = null, string? company = null, string? user = null, string? acceptLanguage = null)

Search

Search among object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFISearchPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var searchDTO = new SearchDTO(); // SearchDTO | Search criteria to apply
            var loadEntireDomain = "loadEntireDomain_example";  // string? | Specify 'loadEntireDomain=true' if you want all the aggregate (optional) 
            var getTotalCount = "getTotalCount_example";  // string? | Specify 'getTotalCount=true' if you want the total number of elements (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Search
                InstalmentStageFIDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFISearchPost(environment, authorizationScope, searchDTO, loadEntireDomain, getTotalCount, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFISearchPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFISearchPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Search
    ApiResponse<InstalmentStageFIDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFISearchPostWithHttpInfo(environment, authorizationScope, searchDTO, loadEntireDomain, getTotalCount, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFISearchPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **searchDTO** | [**SearchDTO**](SearchDTO.md) | Search criteria to apply |  |
| **loadEntireDomain** | **string?** | Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate | [optional]  |
| **getTotalCount** | **string?** | Specify &#39;getTotalCount&#x3D;true&#39; if you want the total number of elements | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentStageFIDTO**](InstalmentStageFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The list of object of type as result of search |  -  |
| **400** | If the search criteria is not supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefiupdatestageextensiondatapost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIUpdatestageextensiondataPost**
> FIGLEntriesExecutionResultDTO ApiV1EnvironmentFIInstalmentStageFIUpdatestageextensiondataPost (string environment, string authorizationScope, InstalmentStageFIDTO instalmentStageFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIUpdatestageextensiondataPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentStageFIDTO = new InstalmentStageFIDTO(); // InstalmentStageFIDTO | TODO_DOCUMENTATION
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // TODO_DOCUMENTATION
                FIGLEntriesExecutionResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIUpdatestageextensiondataPost(environment, authorizationScope, instalmentStageFIDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIUpdatestageextensiondataPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIUpdatestageextensiondataPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // TODO_DOCUMENTATION
    ApiResponse<FIGLEntriesExecutionResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIUpdatestageextensiondataPostWithHttpInfo(environment, authorizationScope, instalmentStageFIDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIUpdatestageextensiondataPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentStageFIDTO** | [**InstalmentStageFIDTO**](InstalmentStageFIDTO.md) | TODO_DOCUMENTATION |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | TODO_DOCUMENTATION |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefivalidatepost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIValidatePost**
> void ApiV1EnvironmentFIInstalmentStageFIValidatePost (string environment, string authorizationScope, InstalmentStageFIDTO instalmentStageFIDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Validate

Validation of object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIValidatePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentStageFIDTO = new InstalmentStageFIDTO(); // InstalmentStageFIDTO | Object of type to validate
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Validate
                apiInstance.ApiV1EnvironmentFIInstalmentStageFIValidatePost(environment, authorizationScope, instalmentStageFIDTO, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIValidatePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIValidatePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Validate
    apiInstance.ApiV1EnvironmentFIInstalmentStageFIValidatePostWithHttpInfo(environment, authorizationScope, instalmentStageFIDTO, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIValidatePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentStageFIDTO** | [**InstalmentStageFIDTO**](InstalmentStageFIDTO.md) | Object of type to validate |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object is VALID: the content response does NOT contain validation messages |  -  |
| **400** | If no object to validate was supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object is NOT VALID: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefivalidatepropertiespost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIValidatePropertiesPost**
> ValidateDTO ApiV1EnvironmentFIInstalmentStageFIValidatePropertiesPost (string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null, string? body = null)

Validation of one on more properties of Type

Validation of object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIValidatePropertiesPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)
            var body = null;  // string? |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br> (optional) 

            try
            {
                // Validation of one on more properties of Type
                ValidateDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIValidatePropertiesPost(environment, authorizationScope, company, user, acceptLanguage, body);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIValidatePropertiesPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIValidatePropertiesPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Validation of one on more properties of Type
    ApiResponse<ValidateDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIValidatePropertiesPostWithHttpInfo(environment, authorizationScope, company, user, acceptLanguage, body);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIValidatePropertiesPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |
| **body** | **string?** |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED&lt;br&gt; - The id of an existing object to validate properties, or &#39;&#39; if the object does not exist yet &lt;br&gt; | [optional]  |

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object is VALID: the content response does NOT contain validation messages |  -  |
| **400** | If no object to validate was supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object is NOT VALID: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefiwritestageoncontextualpost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIWritestageoncontextualPost**
> InstalmentStageContextualFIResultDTO ApiV1EnvironmentFIInstalmentStageFIWritestageoncontextualPost (string environment, string authorizationScope, InstalmentStageContextualFIParametersDTO instalmentStageContextualFIParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIWritestageoncontextualPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentStageContextualFIParametersDTO = new InstalmentStageContextualFIParametersDTO(); // InstalmentStageContextualFIParametersDTO | TODO_DOCUMENTATION
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // TODO_DOCUMENTATION
                InstalmentStageContextualFIResultDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIWritestageoncontextualPost(environment, authorizationScope, instalmentStageContextualFIParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIWritestageoncontextualPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIWritestageoncontextualPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // TODO_DOCUMENTATION
    ApiResponse<InstalmentStageContextualFIResultDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIWritestageoncontextualPostWithHttpInfo(environment, authorizationScope, instalmentStageContextualFIParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIWritestageoncontextualPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentStageContextualFIParametersDTO** | [**InstalmentStageContextualFIParametersDTO**](InstalmentStageContextualFIParametersDTO.md) | TODO_DOCUMENTATION |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**InstalmentStageContextualFIResultDTO**](InstalmentStageContextualFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | TODO_DOCUMENTATION |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentfiinstalmentstagefiwritingstageoncollectionoperationpost"></a>
# **ApiV1EnvironmentFIInstalmentStageFIWritingstageoncollectionoperationPost**
> ExecutionResultMessageDTO ApiV1EnvironmentFIInstalmentStageFIWritingstageoncollectionoperationPost (string environment, string authorizationScope, InstalmentStageCollectionOperationParametersDTO instalmentStageCollectionOperationParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Writing stage on collection operation

Writing stage on collection operation

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFIInstalmentStageFIWritingstageoncollectionoperationPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new InstalmentStageFIApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var instalmentStageCollectionOperationParametersDTO = new InstalmentStageCollectionOperationParametersDTO(); // InstalmentStageCollectionOperationParametersDTO | Object that contains all the parameters necessary for payment / collection of deadlines
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Writing stage on collection operation
                ExecutionResultMessageDTO result = apiInstance.ApiV1EnvironmentFIInstalmentStageFIWritingstageoncollectionoperationPost(environment, authorizationScope, instalmentStageCollectionOperationParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIWritingstageoncollectionoperationPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFIInstalmentStageFIWritingstageoncollectionoperationPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Writing stage on collection operation
    ApiResponse<ExecutionResultMessageDTO> response = apiInstance.ApiV1EnvironmentFIInstalmentStageFIWritingstageoncollectionoperationPostWithHttpInfo(environment, authorizationScope, instalmentStageCollectionOperationParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstalmentStageFIApi.ApiV1EnvironmentFIInstalmentStageFIWritingstageoncollectionoperationPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **instalmentStageCollectionOperationParametersDTO** | [**InstalmentStageCollectionOperationParametersDTO**](InstalmentStageCollectionOperationParametersDTO.md) | Object that contains all the parameters necessary for payment / collection of deadlines |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**ExecutionResultMessageDTO**](ExecutionResultMessageDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result of the operation with any error messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

