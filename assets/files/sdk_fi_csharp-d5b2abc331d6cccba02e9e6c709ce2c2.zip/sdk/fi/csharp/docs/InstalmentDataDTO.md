# It.TSEnterprise.Sdk.Model.InstalmentDataDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InstalmentId** | **long** |  | [optional] 
**ImpEffS** | **double** |  | [optional] 
**ImpEffSVal** | **double?** |  | [optional] 
**AmountToPay** | **double** |  | [optional] 
**CliFor** | **double** |  | [optional] 
**ScadeS** | **DateTime** |  | [optional] 
**Cig** | **string** |  | [optional] 
**Cup** | **string** |  | [optional] 
**Iban** | **string** |  | [optional] 
**NumDoc** | **double** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

