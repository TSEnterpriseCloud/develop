# It.TSEnterprise.Sdk.Model.UpdateAllCSBankForInstalmentParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DispositionType** | **EDispositionType** |  | [optional] 
**UpdateAllInstalment** | **bool** |  | [optional] 
**IndOperationType** | **EOperationType** |  | [optional] 
**PresentationBank** | **int** |  | [optional] 
**ChkConsolidated** | **bool** |  | [optional] 
**ChkToConsolidate** | **bool** |  | [optional] 
**ChkMavWithIdentifier** | **bool** |  | [optional] 
**InstalmentStartDate** | **DateTime** |  | [optional] 
**IndPresentationBank** | **long?** |  | [optional] 
**IndOrdering** | **EOrdering** |  | [optional] 
**IndGrouping** | **EGrouping** |  | [optional] 
**IndSddType** | **ESddType** |  | [optional] 
**IndGroupingMode** | **EGroupingMode** |  | [optional] 
**IndCheckPIvaCf** | **ECheckPIvaCf** |  | [optional] 
**ReasonForPayment** | **string** |  | [optional] 
**PartialPayment** | **bool** |  | [optional] 
**IndOrderingPayment** | **EOrderingPayment** |  | [optional] 
**IndSuspended** | **ESuspended** |  | [optional] 
**CreationDate** | **DateTime** |  | [optional] 
**Currency** | **string** |  | [optional] 
**MovementType** | **string** |  | [optional] 
**InstalmentType** | **string** |  | [optional] 
**GroupingInstalment** | **EGroupingInstalmentPayment** |  | [optional] 
**RecoverNegativeInstalment** | **ERecoverNegativeInstalment** |  | [optional] 
**RecipientType** | **ERecipientType** |  | [optional] 
**TransferModeType** | **ETransferModeType** |  | [optional] 
**IndBankFilter** | **EFilterBank** |  | [optional] 
**PresentationBankProgr** | **int** |  | [optional] 
**PresentationBankId** | **int** |  | [optional] 
**IndPresentation** | **EPresentationBank** |  | [optional] 
**TransferType** | **ETransferType** |  | [optional] 
**SendingRecipientAddress** | **bool** |  | [optional] 
**CreateStage** | **bool** |  | [optional] 
**ManualOperation** | **bool** |  | [optional] 
**StageGuid** | **Guid** |  | [optional] 
**InstalmentId** | **long?** |  | [optional] 
**ReasonForSepaPayment** | **string** |  | [optional] 
**BankId** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

