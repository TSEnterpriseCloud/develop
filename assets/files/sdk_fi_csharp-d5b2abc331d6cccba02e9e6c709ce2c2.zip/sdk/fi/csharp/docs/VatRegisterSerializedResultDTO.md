# It.TSEnterprise.Sdk.Model.VatRegisterSerializedResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IDs** | **List&lt;long&gt;** |  | [optional] 
**BusinessTypeDataCO** | [**List&lt;BusinessTypeDataCODTO&gt;**](BusinessTypeDataCODTO.md) |  | [optional] 
**CompanySectionalProposalCO** | [**List&lt;FinanceCompanySectionalProposalCODTO&gt;**](FinanceCompanySectionalProposalCODTO.md) |  | [optional] 
**IdClosedElaboration** | **long?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

