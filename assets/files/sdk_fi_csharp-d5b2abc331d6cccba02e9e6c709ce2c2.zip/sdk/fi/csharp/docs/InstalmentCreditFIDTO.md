# It.TSEnterprise.Sdk.Model.InstalmentCreditFIDTO
EF03_SCADCECAM - InstalmentCreditFI<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Debitore** | **string** | EF03_DEBITORE - Debitore | [optional] 
**DittaCg18** | **double** | EF03_DITTA_CG18 - Codice ditta | 
**DittagirEf01** | **double?** | EF03_DITTAGIR_EF01 - DittagirEf01 | [optional] 
**DittaricEf01** | **double?** | EF03_DITTARIC_EF01 - DittaricEf01 | [optional] 
**Id** | **long?** | EF03_ID - Id (Required only in PUT/PATCH) | [optional] 
**IdEf01** | **long** | EF03_ID_EF01 - IdEf01 | 
**IdgirEf01** | **long?** | EF03_IDGIR_EF01 - IdgirEf01 | [optional] 
**IdricEf01** | **long?** | EF03_IDRIC_EF01 - IdricEf01 | [optional] 
**NumregCo99** | **string** | EF03_NUMREG_CO99 - NumregCo99 | 
**NumreggirEf01** | **string** | EF03_NUMREGGIR_EF01 - NumreggirEf01 | [optional] 
**NumregricEf01** | **string** | EF03_NUMREGRIC_EF01 - NumregricEf01 | [optional] 
**Piazza** | **string** | EF03_PIAZZA - Piazza | [optional] 
**ProgEffEf01** | **double** | EF03_PROGEFF_EF01 - ProgEffEf01 | 
**ProgEffgirEf01** | **double?** | EF03_PROGEFFGIR_EF01 - ProgEffgirEf01 | [optional] 
**ProgEffricEf01** | **double?** | EF03_PROGEFFRIC_EF01 - ProgEffricEf01 | [optional] 
**RigacontEf01** | **double** | EF03_RIGACONT_EF01 - RigacontEf01 | 
**RigacontgirEf01** | **double?** | EF03_RIGACONTGIR_EF01 - RigacontgirEf01 | [optional] 
**RigacontricEf01** | **double?** | EF03_RIGACONTRIC_EF01 - RigacontricEf01 | [optional] 
**Rowversion** | **byte[]** | EF03_ROWVERSION - Rowversion | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

