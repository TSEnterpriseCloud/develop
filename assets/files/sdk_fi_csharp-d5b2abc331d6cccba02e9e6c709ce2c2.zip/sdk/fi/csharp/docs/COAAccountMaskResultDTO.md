# It.TSEnterprise.Sdk.Model.COAAccountMaskResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FlgFreeFormatCode** | **bool** |  | [optional] 
**Level** | **int** |  | [optional] 
**MaxLevel** | **int** |  | [optional] 
**MaskCG10** | **string** |  | [optional] 
**TsMask** | **string** |  | [optional] 
**RegExpMask** | **string** |  | [optional] 
**RegExpMaskAnyChar** | **List&lt;string&gt;** |  | [optional] 
**PrefixedPart** | **string** |  | [optional] 
**RegExpVariablePart** | **string** |  | [optional] 
**SuffixedPart** | **string** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

