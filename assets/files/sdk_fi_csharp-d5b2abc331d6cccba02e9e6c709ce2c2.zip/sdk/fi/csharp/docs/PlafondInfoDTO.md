# It.TSEnterprise.Sdk.Model.PlafondInfoDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DataDoc** | **DateTime?** |  | [optional] 
**DataReg** | **DateTime?** |  | [optional] 
**DataRegIva** | **DateTime?** |  | [optional] 
**CodAttivita** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

