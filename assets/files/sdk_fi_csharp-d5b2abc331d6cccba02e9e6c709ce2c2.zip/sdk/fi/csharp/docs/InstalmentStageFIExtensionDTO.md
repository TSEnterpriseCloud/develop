# It.TSEnterprise.Sdk.Model.InstalmentStageFIExtensionDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NumRata** | **double** |  | [optional] 
**ImportoPagato** | **double?** |  | [optional] 
**Abbuono** | **double?** |  | [optional] 
**FlagNote** | **double?** |  | [optional] 
**ScontoIncond** | **double?** |  | [optional] 
**OmaggioSenzaRiv** | **double?** |  | [optional] 
**ScontoIncondEURO** | **double?** |  | [optional] 
**OmaggioSenzaRivEURO** | **double?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

