# It.TSEnterprise.Sdk.Model.StageInstalmentAndHistoryParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InstalmentId** | **long?** |  | [optional] 
**StageGuid** | **Guid** |  | [optional] 
**ManualOperation** | **bool** |  | [optional] 
**CreateStage** | **bool** |  | [optional] 
**IndOperationType** | **EOperationType** |  | [optional] 
**IndPresentation** | **EPresentationBank** |  | [optional] 
**PresentationBank** | **int** |  | [optional] 
**ChkConsolidated** | **bool** |  | [optional] 
**ChkToConsolidate** | **bool** |  | [optional] 
**ChkMavWithIdentifier** | **bool** |  | [optional] 
**InstalmentStartDate** | **DateTime** |  | [optional] 
**CreationDate** | **DateTime** |  | [optional] 
**IndPresentationBank** | **long?** |  | [optional] 
**IndBankFilter** | **EFilterBank** |  | [optional] 
**IndOrdering** | **EOrdering** |  | [optional] 
**IndGrouping** | **EGrouping** |  | [optional] 
**IndSuspended** | **ESuspended** |  | [optional] 
**IndSddType** | **ESddType** |  | [optional] 
**ValoreAnticipato** | **double?** |  | [optional] 
**IndGroupingMode** | **EGroupingMode** |  | [optional] 
**ValoreAnticipatoVal** | **double?** |  | [optional] 
**IndRecCambio** | **int?** |  | [optional] 
**Cambio** | **double?** |  | [optional] 
**DataCambio** | **DateTime?** |  | [optional] 
**CodiceCG08** | **string** |  | [optional] 
**ImpCastelletto** | **double?** |  | [optional] 
**IndCheckPIvaCf** | **ECheckPIvaCf** |  | [optional] 
**ExternalSearchGroup** | [**List&lt;StageInstalmentAndHistoryParametersDTOExternalSearchGroupInner&gt;**](StageInstalmentAndHistoryParametersDTOExternalSearchGroupInner.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

