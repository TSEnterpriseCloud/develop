# It.TSEnterprise.Sdk.Model.InstalmentCalculationResultElementDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TipoEffetto** | **double** |  | [optional] 
**SottotipoEffetto** | **double?** |  | [optional] 
**DescSottotipoEffetto** | **string** |  | [optional] 
**DataScadenza** | **DateTime** |  | [optional] 
**IdBancaAziendale** | **long?** |  | [optional] 
**IdBancaCliFor** | **int?** |  | [optional] 
**ImportoScadenzaEuro** | **double** |  | [optional] 
**ImportoScadenzaValuta** | **double** |  | [optional] 
**ImportoIvaEuro** | **double** |  | [optional] 
**ImportoIvaValuta** | **double** |  | [optional] 
**ImportoRitenutaEuro** | **double** |  | [optional] 
**ImportoRitenutaValuta** | **double** |  | [optional] 
**DataDecorrenza** | **DateTime** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

