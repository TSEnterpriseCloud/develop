# It.TSEnterprise.Sdk.Model.InstalmentsPairingParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TipoAssociazioneScadenze** | **int** |  | [optional] 
**ModalitaAssociazioneScadenze** | **int** |  | [optional] 
**StageGuid** | **Guid** |  | [optional] 
**SelectedID** | **List&lt;string&gt;** |  | [optional] 
**CambioData** | **DateTime?** |  | [optional] 
**CambioValore** | **double?** |  | [optional] 
**CausaleContabile** | **string** |  | [optional] 
**ModalitaDifferenzaCambi** | **int** |  | [optional] 
**DiffCambiID** | **List&lt;string&gt;** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

