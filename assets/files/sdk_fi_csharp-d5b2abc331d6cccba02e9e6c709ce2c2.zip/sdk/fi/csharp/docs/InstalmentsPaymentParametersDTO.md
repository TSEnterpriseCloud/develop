# It.TSEnterprise.Sdk.Model.InstalmentsPaymentParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DataOperazione** | **DateTime** |  | [optional] 
**TipoOperazione** | **int** |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**InstalmentID** | **double** |  | [optional] 
**ImportoIncassoPagamento** | **double** |  | [optional] 
**ImportoAbbuono** | **double** |  | [optional] 
**Frazionamento** | **bool** |  | [optional] 
**TipoEffettoFrazionamento** | **double?** |  | [optional] 
**SottotipoEffettoFrazionamento** | **double?** |  | [optional] 
**DataScadenzaFrazionamento** | **DateTime?** |  | [optional] 
**NumeroAssegno** | **string** |  | [optional] 
**RiferimentoAssegno** | **string** |  | [optional] 
**DifferenzaCambio** | **bool** |  | [optional] 
**CambioData** | **DateTime?** |  | [optional] 
**CambioValore** | **double?** |  | [optional] 
**CausaleContabile** | **string** |  | [optional] 
**ModalitaDifferenzaCambi** | **int** |  | [optional] 
**NumReg** | **string** |  | [optional] 
**InstalmentHistoryId** | **long?** |  | [optional] 
**TipoMovimento** | **int?** |  | [optional] 
**SpeseInsoluto** | **int?** |  | [optional] 
**ImportoSpeseInsoluto** | **double?** |  | [optional] 
**IdContoSpese** | **long?** |  | [optional] 
**ImportoDiffCambio** | **double?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

