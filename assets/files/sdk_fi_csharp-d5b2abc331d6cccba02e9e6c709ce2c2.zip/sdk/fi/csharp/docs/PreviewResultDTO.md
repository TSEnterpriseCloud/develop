# It.TSEnterprise.Sdk.Model.PreviewResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ContentXML** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

