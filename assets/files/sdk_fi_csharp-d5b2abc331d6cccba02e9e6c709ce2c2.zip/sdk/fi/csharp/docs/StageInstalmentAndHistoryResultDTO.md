# It.TSEnterprise.Sdk.Model.StageInstalmentAndHistoryResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionResult** | **bool** |  | [optional] 
**InstalmentIds** | **List&lt;long&gt;** |  | [optional] 
**Instalments** | [**List&lt;InstalmentDataDTO&gt;**](InstalmentDataDTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

