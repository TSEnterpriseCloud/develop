# It.TSEnterprise.Sdk.Model.ResidualCalculationParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RowIdStage** | **long** |  | [optional] 
**StageGuid** | **Guid** |  | [optional] 
**Currency** | **string** |  | [optional] 
**DataCambio** | **DateTime?** |  | [optional] 
**Cambio** | **double?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

