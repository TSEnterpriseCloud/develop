# It.TSEnterprise.Sdk.Model.AreaCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodiceAreaMG** | **string** |  | [optional] 
**Descrarea** | **string** |  | [optional] 
**DittaCg18** | **double** |  | [optional] 
**IdEntityWithDescriptions** | **int?** |  | [optional] 
**IdmediaCg99** | **double?** |  | [optional] 
**Idprov** | **int** |  | [optional] 
**MacroareaMg07** | **string** |  | [optional] 
**TipocfMg07** | **double** |  | [optional] 
**DescrizioniLingua** | [**List&lt;LanguageDescriptionMGCO&gt;**](LanguageDescriptionMGCO.md) |  | [optional] 
**Zone** | [**List&lt;ZoneCO&gt;**](ZoneCO.md) |  | [optional] 
**MacroAreaCOParent** | [**MacroAreaCO**](MacroAreaCO.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

