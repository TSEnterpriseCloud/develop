# It.TSEnterprise.Sdk.Model.CityCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Cap** | **string** |  | [optional] 
**Ccesatt** | **string** |  | [optional] 
**Codice** | **string** |  | [optional] 
**CodiceCg02** | **double?** |  | [optional] 
**CodiceCg03** | **double?** |  | [optional] 
**CodiceCg04** | **double?** |  | [optional] 
**CodiceCg05** | **double?** |  | [optional] 
**CodUffcassa** | **double?** |  | [optional] 
**CodUffcciaa** | **double?** |  | [optional] 
**CodUffcom** | **double?** |  | [optional] 
**CodUffenas** | **double?** |  | [optional] 
**CodUffinail** | **double?** |  | [optional] 
**CodUffinps** | **double?** |  | [optional] 
**CodUffreg** | **double?** |  | [optional] 
**CodUfftrib** | **double?** |  | [optional] 
**Comvers** | **string** |  | [optional] 
**Descr** | **string** |  | [optional] 
**IdmediaCg99** | **double?** |  | [optional] 
**Istatcom** | **double?** |  | [optional] 
**Istatcomver** | **double?** |  | [optional] 
**Istatprov** | **double?** |  | [optional] 
**Istatprovver** | **double?** |  | [optional] 
**Prov** | **string** |  | [optional] 
**Regione** | **string** |  | [optional] 
**Telnum** | **string** |  | [optional] 
**Zonecens** | **double?** |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

