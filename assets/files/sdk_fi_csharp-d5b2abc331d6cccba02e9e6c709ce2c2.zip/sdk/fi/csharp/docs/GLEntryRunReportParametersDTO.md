# It.TSEnterprise.Sdk.Model.GLEntryRunReportParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdProcessingDetails** | **long** |  | [optional] 
**Parameters** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**ReportParameters** | [**List&lt;GLEntryReportParam&gt;**](GLEntryReportParam.md) |  | [optional] 
**FilterGlentriesParams** | [**FilterGLEntriesParamsDTO**](FilterGLEntriesParamsDTO.md) |  | [optional] 
**FilterOnly** | **bool?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

