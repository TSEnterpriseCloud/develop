# It.TSEnterprise.Sdk.Model.InstalmentReissueParameterDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InstalmentIds** | **List&lt;long&gt;** |  | [optional] 
**ExpirationDate** | **DateTime** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

