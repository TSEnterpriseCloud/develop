# It.TSEnterprise.Sdk.Model.InstalmentStageFIDTO
EF01_SCADENZE_STAGE - Stato scadenze<br>Proprietà chiave:<ul><li><b>IdStage</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdExtendedAttributeEntity** | **int** |  | [optional] 
**IdExtendedAttributeSubEntity** | **int** |  | [optional] 
**AgenappCg13** | **double?** | EF01_AGENAPP_CG13 - Agenzia d&#39;appoggio | [optional] 
**AgenpreScg13** | **double?** | EF01_AGENPRE_SCG13 - Agenzia di presentazione | [optional] 
**Annopart** | **double?** | EF01_ANNOPART - Anno partita | [optional] 
**BancaappCg12** | **double?** | EF01_BANCAAPP_CG12 - Banca d&#39;appoggio | [optional] 
**BancapreScg12** | **double?** | EF01_BANCAPRE_SCG12 - Banca di presentazione | [optional] 
**Bolli** | **double?** | EF01_BOLLI - Importo bolli in EURO | [optional] 
**Bollival** | **double?** | EF01_BOLLIVAL - Importo bolli in valuta | [optional] 
**Cambio** | **double?** | EF01_CAMBIO - Valore del cambio | [optional] 
**CausaleCg33** | **string** | EF01_CAUSALE_CG33 - Codice causale | [optional] 
**CausmgoMgfo** | **int?** | EF01_CAUSMGO_MGFO - Causale MGO | [optional] 
**Changed** | **bool?** | Changed - Changed | [optional] 
**Cig** | **string** | EF01_CIG - Codice Identificativo Gara | [optional] 
**CodCcred** | **string** | EF01_CODCCRED - Codice carta di credito | [optional] 
**CodiceCg08** | **string** | EF01_CODICE_CG08 - Divisa | 
**Cup** | **string** | EF01_CUP - Codice Unico di Progetto | [optional] 
**Datacambio** | **DateTime?** | EF01_DATACAMBIO - Data cambio | [optional] 
**Datadecorr** | **DateTime?** | EF01_DATADECORR - Data decorrenza per calcolo scadenza | [optional] 
**Datadoc** | **DateTime** | EF01_DATADOC - Data documento | 
**Datareg** | **DateTime** | EF01_DATAREG - Data registrazione effetto | 
**Descausale** | **string** | EF01_DESCAUSALE - Descrizione causale | [optional] 
**Descragg** | **string** | EF01_DESCRAGG - Descrizione aggiuntiva | [optional] 
**DittaCg18** | **double** | EF01_DITTA_CG18 - Codice azienda | 
**FlgAcconto** | **double?** | EF01_FLGACCONTO - Acconto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgDocbis** | **double?** | EF01_FLGDOCBIS - Bis&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgEffvar** | **double?** | EF01_FLGEFFVAR - Variato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgEstraz** | **double?** | EF01_FLGESTRAZ - Estratto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgGendarag** | **double?** | EF01_FLGGENDARAG - Da raggr.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgGiratoS** | **double?** | EF01_FLGGIRATO_S - Girato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgPartbis** | **double?** | EF01_FLGPARTBIS - Bis&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgRicevutoS** | **double?** | EF01_FLGRICEVUTO_S - Ricevuto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgSospeso** | **double?** | EF01_FLGSOSPESO - Sospeso&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgSteffS** | **double?** | EF01_FLGSTEFF_S - Stampato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Id** | **long?** | EF01_ID - Id Scadenza | [optional] 
**IdagenteMg17** | **int?** | EF01_IDAGENTE_MG17 - ID Agente | [optional] 
**IdCg24** | **long** | EF01_ID_CG24 - ID Conto | 
**IdCg44** | **int?** | EF01_ID_CG44 - ID cliente/fornitore | [optional] 
**IdCg62** | **long?** | EF01_ID_CG62 - ID Condizione di pagamento | [optional] 
**IdContoSpeseCg24** | **long?** | EF01_IDCONTOSPESE_CG24 - Conto spese | [optional] 
**IdEf08** | **long?** | EF01_ID_EF08 - Banca aziendale | [optional] 
**IdLinkEf01** | **long?** | EF01_IDLINK_EF01 - IdLinkEf01 | [optional] 
**IdMg29** | **int?** | EF01_ID_MG29 - ID RID | [optional] 
**IdMg35** | **int?** | EF01_ID_MG35 - ID CC | [optional] 
**IdpreEf08** | **long?** | EF01_IDPRE_EF08 - Id banca | [optional] 
**IdStage** | **long?** | EF01_ID_STAGE - IdStage (Required only in PUT/PATCH) | [optional] 
**IdStageLinkEf01** | **long?** | EF01_IDSTAGELINK_EF01 - IdStageLinkEf01 | [optional] 
**Impeffiva** | **double** | EF01_IMPEFFIVA - Importo IVA originario in EURO | 
**ImpeffivaVal** | **double?** | EF01_IMPEFFIVA_VAL - Importo IVA originario in valuta | [optional] 
**ImpeffnetprevS** | **double** | EF01_IMPEFFNETPREV_S - Importo effetto al netto dei mov. previsionali in EURO | 
**ImpeffnetprevvalS** | **double?** | EF01_IMPEFFNETPREVVAL_S - Importo effetto al netto dei mov. previsionali in valuta | [optional] 
**Impefforig** | **double** | EF01_IMPEFFORIG - Importo | 
**Impefforigval** | **double?** | EF01_IMPEFFORIGVAL - Importo origine in valuta | [optional] 
**ImpeffS** | **double** | EF01_IMPEFF_S - Importo | 
**ImpeffvalS** | **double?** | EF01_IMPEFFVAL_S - Importo in valuta | [optional] 
**ImportoDaAssociare** | **double?** | EF01_IMPORTODAASSOCIARE - Imp. da associare | [optional] 
**Impritacc** | **double?** | EF01_IMPRITACC - Importo residuo della ritenuta di acconto in Euro | [optional] 
**Impritaccorig** | **double?** | EF01_IMPRITACCORIG - Importo origine della ritenuta di acconto in EURO | [optional] 
**Impritaccorigval** | **double?** | EF01_IMPRITACCORIGVAL - Importo origine della ritenuta di acconto in valuta | [optional] 
**Impritaccval** | **double?** | EF01_IMPRITACCVAL - Importo residuo della ritenuta di acconto in valuta | [optional] 
**IndConto** | **double?** | EF01_INDCONTO - Tipo conto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Attivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Passivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Conto attivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Conto passivo&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndGenstatoS** | **double?** | EF01_INDGENSTATO_S - Operazione che ha determinato lo stato dell&#39;effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Creazione iniziale&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Pagamento/Riscossione&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Chiusura effetti&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  Insoluto&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; -  Raggruppato&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; -  Riemissione&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; -  Richiamato&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndLiqprov** | **double?** | EF01_INDLIQPROV - Liquidazione provvigioni&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Liquidabile&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Liquidabile se tot. incassato&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Sospesa&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndMerceart62** | **int?** | EF01_INDMERCEART62 - Tipo merce in riferimento all&#39;Art. 62&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Non soggetta&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Deperibile&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Non deperibile&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndPresS** | **double?** | EF01_INDPRES_S - Presentazione dell&#39;effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Non soggetto&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  In portafoglio&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  S.b.f. ordinario&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  S.b.f. a maturazione valuta&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; -  S.b.f. anticipato&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; -  Dopo incasso&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; -  Allo sconto&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; -  Altre presentazioni&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; -  Sconto fatture&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; -  Cessione a factoring&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndSperitS** | **double?** | EF01_INDSPERIT_S - Modalità di gestione delle spese di ritorno&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Nessun addebito&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Solo annotate&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Sommate&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  Nuovo effetto&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndStatoS** | **double?** | EF01_INDSTATO_S - Stato effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Aperto&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Chiuso&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTipomov** | **double?** | EF01_INDTIPOMOV - Tipo movimento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Consolidato&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Da consolidare&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Previsionale&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  Previsionale per simulaz.&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; -  Previsionale per cash flow&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Numdoc** | **double** | EF01_NUMDOC - Nr documento/Protocollo | 
**Numdocorig** | **string** | EF01_NUMDOCORIG - Numero documento originario | [optional] 
**Numeff** | **double?** | EF01_NUMEFF - Numero scadenza | [optional] 
**Numpart** | **double?** | EF01_NUMPART - Numero partita | [optional] 
**Numrata** | **double** | EF01_NUMRATA - Nr. rata | 
**NumregCo99** | **string** | EF01_NUMREG_CO99 - Numero di registrazione | [optional] 
**Recordtype** | **int?** | RecordType - Recordtype | [optional] 
**RigacontCg42** | **double?** | EF01_RIGACONT_CG42 - Riga contabile | [optional] 
**Rowversion** | **byte[]** | EF01_ROWVERSION - RowVersion | [optional] 
**Scadeorig** | **DateTime** | EF01_SCADEORIG - Data scadenza originaria | 
**ScadeS** | **DateTime** | EF01_SCADE_S - Data scadenza | 
**Sezdoc** | **string** | EF01_SEZDOC - Sezionale documento | 
**Sezpart** | **string** | EF01_SEZPART - Sezionale partita | [optional] 
**SpeseritS** | **double?** | EF01_SPESERIT_S - Spese di ritorno | [optional] 
**Spinc** | **double?** | EF01_SPINC - Spese incasso in EURO | [optional] 
**Spincval** | **double?** | EF01_SPINCVAL - Spese incasso in valuta | [optional] 
**Stageguid** | **Guid?** | StageGuid - Stageguid | [optional] 
**Stagestate** | **int?** | StageState - Stagestate&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - None&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Add&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Update&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Delete&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Hidden&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Stipoeff** | **double?** | EF01_STIPOEFF - Sottotipo effetto | [optional] 
**Tipoeff** | **double?** | EF01_TIPOEFF - Tipo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Contanti&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Ricevuta bancaria&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Tratta&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Tratta accettata&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Cessione&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Cambiale&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Carta di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Bancomat&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Contrassegno&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Lettera di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - SDD&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Leasing&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Rimessa diretta&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Bonifico Bancario&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - C/C postale&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - MAV&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Totdoc** | **double** | EF01_TOTDOC - Totale documento in EURO | 
**Totdocval** | **double?** | EF01_TOTDOCVAL - Totale documento in valuta | [optional] 
**Totrate** | **double** | EF01_TOTRATE - Totale rate | 
**InstalmentNoteStageFIDTO** | [**List&lt;InstalmentNoteStageFIDTO&gt;**](InstalmentNoteStageFIDTO.md) |  | [optional] 
**InstalmentStageHistoryFIDTO** | [**List&lt;InstalmentHistoryStageFIDTO&gt;**](InstalmentHistoryStageFIDTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

