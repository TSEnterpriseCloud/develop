# It.TSEnterprise.Sdk.Model.ISTATActivityCODTO
CG06_TABATTISTAT - ISTATActivityCO<br>Proprietà chiave:<ul><li><b>Codice</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codice** | **string** | CG06_CODICE - Codice | 
**Descr** | **string** | CG06_DESCR - Descrizione | [optional] 
**IdmediaCg99** | **double?** | CG06_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

