# It.TSEnterprise.Sdk.Model.StoreCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Cap** | **string** |  | [optional] 
**Citta** | **string** |  | [optional] 
**Datafinegest** | **DateTime?** |  | [optional] 
**Datainizgest** | **DateTime?** |  | [optional] 
**DefNumrea** | **string** |  | [optional] 
**DefProgRea** | **double?** |  | [optional] 
**DefProv** | **string** |  | [optional] 
**Descrizione** | **string** |  | [optional] 
**DittaCg18** | **double** |  | [optional] 
**FlgReqdimen** | **double** |  | [optional] 
**FlgVentil** | **double** |  | [optional] 
**IndIrizzo** | **string** |  | [optional] 
**ProNumrea** | **string** |  | [optional] 
**ProProgRea** | **double?** |  | [optional] 
**ProProv** | **string** |  | [optional] 
**Prov** | **string** |  | [optional] 
**Puntoven** | **double** |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

