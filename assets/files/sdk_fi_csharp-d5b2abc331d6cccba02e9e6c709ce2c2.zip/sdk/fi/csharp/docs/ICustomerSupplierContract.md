# It.TSEnterprise.Sdk.Model.ICustomerSupplierContract

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdCliFor** | **int** |  | [optional] [readonly] 
**CliFor** | **double** |  | [optional] [readonly] 
**TipoCf** | **double** |  | [optional] [readonly] 
**DittaCg18** | **double** |  | [optional] [readonly] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

