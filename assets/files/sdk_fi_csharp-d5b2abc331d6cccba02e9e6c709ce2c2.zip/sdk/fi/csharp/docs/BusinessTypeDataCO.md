# It.TSEnterprise.Sdk.Model.BusinessTypeDataCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Annoliq** | **double?** |  | [optional] 
**CodAttivita** | **double** |  | [optional] 
**CodiceCg06** | **string** |  | [optional] 
**CodiceCg6a** | **string** |  | [optional] 
**Datastpliqiva** | **DateTime?** |  | [optional] 
**Datastpplafon** | **DateTime?** |  | [optional] 
**Datastpregacq** | **DateTime?** |  | [optional] 
**Datastpregacqglob** | **DateTime?** |  | [optional] 
**Datastpregcor** | **DateTime?** |  | [optional] 
**Datastpregrie** | **DateTime?** |  | [optional] 
**Datastpregunicanal** | **DateTime?** |  | [optional] 
**Datastpregven** | **DateTime?** |  | [optional] 
**Datastpregvenglob** | **DateTime?** |  | [optional] 
**Descrattivita** | **string** |  | [optional] 
**DittaCg18** | **double** |  | [optional] 
**FlgIvaedit** | **double** |  | [optional] 
**IndAgric** | **double** |  | [optional] 
**IndCatpart** | **double** |  | [optional] 
**IndRegimefiscale** | **int** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**CodAteco** | [**AtecoCodeCO**](AtecoCodeCO.md) |  | [optional] 
**IstatActivityCO** | [**ISTATActivityCO**](ISTATActivityCO.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

