# It.TSEnterprise.Sdk.Model.CompanyBankFIDTO
EF08_BANCHE - CompanyBankFI<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BancaCg12** | **double?** | EF08_BANCA_CG12 - Abi | [optional] 
**ConanticipiCg24** | **string** | EF08_CONANTICIPI_CG24 - ConanticipiCg24 | [optional] 
**ConccbancaCg24** | **string** | EF08_CONCCBANCA_CG24 - ConccbancaCg24 | [optional] 
**ConspcommCg24** | **string** | EF08_CONSPCOMM_CG24 - ConspcommCg24 | [optional] 
**Descr** | **string** | EF08_DESCR - Banca | [optional] 
**DittaCg18** | **double** | EF08_DITTA_CG18 - Ditta | 
**FlgPref** | **double** | EF08_FLGPREF - Banca preferenziale | 
**GruanticipiCg24** | **double?** | EF08_GRUANTICIPI_CG24 - GruanticipiCg24 | [optional] 
**GruccbancaCg24** | **double?** | EF08_GRUCCBANCA_CG24 - GruccbancaCg24 | [optional] 
**GruspcommCg24** | **double?** | EF08_GRUSPCOMM_CG24 - GruspcommCg24 | [optional] 
**Id** | **long?** | EF08_ID - ID (Required only in PUT/PATCH) | [optional] 
**IdanticipiCg24** | **long?** | EF08_IDANTICIPI_CG24 - IdanticipiCg24 | [optional] 
**IdccbancaCg24** | **long?** | EF08_IDCCBANCA_CG24 - IdccbancaCg24 | [optional] 
**IdspcommCg24** | **long?** | EF08_IDSPCOMM_CG24 - IdspcommCg24 | [optional] 
**ProgR** | **double** | EF08_PROGR -  Progressivo | 
**Rowversion** | **byte[]** | EF08_ROWVERSION - Rowversion | [optional] 
**AdvancedPaymentAccount** | [**COAAccountDescrFIDTO**](COAAccountDescrFIDTO.md) |  | [optional] 
**BankAccount** | [**COAAccountDescrFIDTO**](COAAccountDescrFIDTO.md) |  | [optional] 
**CommissionFeesAccount** | [**COAAccountDescrFIDTO**](COAAccountDescrFIDTO.md) |  | [optional] 
**CompanyBankMiscellaneousAccountFI** | [**List&lt;CompanyBankMiscellaneousAccountFIDTO&gt;**](CompanyBankMiscellaneousAccountFIDTO.md) |  | [optional] 
**CompanyBankPresentationAccountFI** | [**List&lt;CompanyBankPresentationAccountFIDTO&gt;**](CompanyBankPresentationAccountFIDTO.md) |  | [optional] 
**CompanyBankSupplierCreditCardAccountFI** | [**List&lt;CompanyBankSupplierCreditCardAccountFIDTO&gt;**](CompanyBankSupplierCreditCardAccountFIDTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

