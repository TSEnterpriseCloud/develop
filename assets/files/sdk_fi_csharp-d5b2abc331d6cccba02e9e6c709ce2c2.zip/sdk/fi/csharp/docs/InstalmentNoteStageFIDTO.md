# It.TSEnterprise.Sdk.Model.InstalmentNoteStageFIDTO
EF04_SCADNOTE_STAGE - InstalmentNoteStageFI<br>Proprietà chiave:<ul><li><b>IdStage</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Changed** | **bool?** | Changed - Changed | [optional] 
**Id** | **long** | EF04_ID - Id | 
**IdEf01** | **long** | EF04_ID_EF01 - IdEf01 | 
**IdEf01Stage** | **long** | EF04_ID_EF01_STAGE - IdEf01Stage | 
**IdStage** | **long?** | EF04_ID_STAGE - IdStage (Required only in PUT/PATCH) | [optional] 
**Noteammin** | **string** | EF04_NOTEAMMIN - Noteammin | [optional] 
**Noteraggr** | **string** | EF04_NOTERAGGR - Noteraggr | [optional] 
**Recordtype** | **int?** | RecordType - Recordtype | [optional] 
**Rowversion** | **byte[]** | EF04_ROWVERSION - Rowversion | [optional] 
**Stageguid** | **Guid?** | StageGuid - Stageguid | [optional] 
**Stagestate** | **int** | Stagestate - Stagestate | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

