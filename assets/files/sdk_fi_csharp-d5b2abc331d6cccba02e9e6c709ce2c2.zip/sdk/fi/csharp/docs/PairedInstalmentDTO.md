# It.TSEnterprise.Sdk.Model.PairedInstalmentDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Numrata** | **double** |  | [optional] 
**Tipoeff** | **double** |  | [optional] 
**Stipoeff** | **double?** |  | [optional] 
**Datadoc** | **DateTime** |  | [optional] 
**Numdoc** | **double** |  | [optional] 
**Sezdoc** | **string** |  | [optional] 
**Numdocorig** | **string** |  | [optional] 
**Impefforig** | **double** |  | [optional] 
**ScadeS** | **DateTime** |  | [optional] 
**AmountPaired** | **double** |  | [optional] 
**AmountPairedDoc** | **double** |  | [optional] 
**PairingMode** | **int** |  | [optional] 
**IdEf01** | **long** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

