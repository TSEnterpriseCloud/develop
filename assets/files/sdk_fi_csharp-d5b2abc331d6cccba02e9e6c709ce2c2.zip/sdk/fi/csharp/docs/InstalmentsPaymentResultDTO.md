# It.TSEnterprise.Sdk.Model.InstalmentsPaymentResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InstalmentId** | **double?** |  | [optional] 
**DescriptionResult** | **string** |  | [optional] 
**Result** | **int** |  | [optional] 
**StageGuid** | **Guid** |  | [optional] 
**IdStage** | **int?** |  | [optional] 
**ImpPagato** | **double?** |  | [optional] 
**ImpAbbuono** | **double?** |  | [optional] 
**ImpAcconto** | **double?** |  | [optional] 
**PurchasePaymentStageGuid** | **Guid?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

