# It.TSEnterprise.Sdk.Model.InstalmentNumberingCalculationResultDTO
Results of the calculation of subsequent numbering of deadlines

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionResult** | **bool** |  | [optional] 
**Numdoc** | **double?** |  | [optional] 
**Datadoc** | **DateTime?** |  | [optional] 
**Anno** | **double?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

