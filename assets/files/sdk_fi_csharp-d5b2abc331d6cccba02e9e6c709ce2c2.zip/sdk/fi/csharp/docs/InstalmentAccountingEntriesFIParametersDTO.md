# It.TSEnterprise.Sdk.Model.InstalmentAccountingEntriesFIParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Guid** | **Guid** |  | [optional] 
**JoinDate** | **DateTime** |  | [optional] 
**OpType** | **OperationType** |  | [optional] 
**Edited** | **bool** |  | [optional] 
**IsGrouped** | **bool** |  | [optional] 
**BankTransactionId** | **long?** |  | [optional] 
**TreasuryTransactionId** | **long?** |  | [optional] 
**OperationBankId** | **long?** |  | [optional] 
**GroupedInstalments** | **bool** |  | [optional] 
**GlEntryId** | **long?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

