# It.TSEnterprise.Sdk.Model.InstalmentsAdditionalInfoParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InStage** | **bool** |  | [optional] 
**NumReg** | **string** |  | [optional] 
**StageGuid** | **Guid** |  | [optional] 
**RigaContCG42** | **int?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

