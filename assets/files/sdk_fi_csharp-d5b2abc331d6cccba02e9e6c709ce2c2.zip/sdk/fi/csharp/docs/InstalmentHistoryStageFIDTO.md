# It.TSEnterprise.Sdk.Model.InstalmentHistoryStageFIDTO
EF06_SCADSTO_STAGE - InstalmentHistoryStageFI<br>Proprietà chiave:<ul><li><b>IdStage</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AgenzpreS** | **double?** | EF06_AGENZPRE_S - Agenzia di presentazione | [optional] 
**BancapreS** | **double?** | EF06_BANCAPRE_S - Banca di presentazione | [optional] 
**Cambio** | **double?** | EF06_CAMBIO - Valore del cambio | [optional] 
**CambioadcontoS** | **double?** | EF06_CAMBIOADCONTO_S - Valore cambio su movimento adeguamento conto | [optional] 
**Changed** | **bool?** | Changed - Changed | [optional] 
**Datacambio** | **DateTime?** | EF06_DATACAMBIO - Data cambio | [optional] 
**DatacambioadcontoS** | **DateTime?** | EF06_DATACAMBIOADCONTO_S - Data cambio dell&#39;adeguamento | [optional] 
**Datareg** | **DateTime** | EF06_DATAREG - Data registrazione | 
**Diffcambio** | **double?** | EF06_DIFFCAMBIO - Differenza cambio | [optional] 
**Diffcambioconto** | **double?** | EF06_DIFFCAMBIOCONTO - Diffcambioconto | [optional] 
**FlgGiratoS** | **double?** | EF06_FLGGIRATO_S - Effetto girato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgIncassobfS** | **int?** | EF06_FLGINCASSOBF_S - Incasso buon fine&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgProformadef** | **int?** | EF06_FLGPROFORMADEF - Flag generata fattura definitiva da proforma&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgRicevutoS** | **double?** | EF06_FLGRICEVUTO_S - Effetto ricevuto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgSteffS** | **double?** | EF06_FLGSTEFF_S - Stampato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgVariatoMg29** | **double?** | EF06_FLGVARIATO_MG29 - Flag variato RID&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Id** | **long** | EF06_ID - ID storico | 
**IdassEf01** | **long?** | EF06_IDASS_EF01 - IdassEf01 | [optional] 
**IdEf01** | **long** | EF06_ID_EF01 - Id Scadenza | 
**IdEf01Stage** | **long** | EF06_ID_EF01_STAGE - IdEf01Stage | 
**IdpreEf08S** | **long?** | EF06_IDPRE_EF08_S - ID Banca di presentazione | [optional] 
**IdStage** | **long?** | EF06_ID_STAGE - IdStage (Required only in PUT/PATCH) | [optional] 
**ImpadegcambioS** | **double?** | EF06_IMPADEGCAMBIO_S - Valore adeguamento cambio | [optional] 
**ImpeffnetprevS** | **double** | EF06_IMPEFFNETPREV_S - Importo effetto al netto dei mov. previsionali in EURO | 
**ImpeffnetprevvalS** | **double?** | EF06_IMPEFFNETPREVVAL_S - Importo effetto al netto dei mov. previsionali in valuta | [optional] 
**ImpeffS** | **double** | EF06_IMPEFF_S - Importo | 
**ImpeffvalS** | **double?** | EF06_IMPEFFVAL_S - Importo in valuta | [optional] 
**Impmovabb** | **double?** | EF06_IMPMOVABB - Importo abbuono in Euro | [optional] 
**Impmovabbval** | **double?** | EF06_IMPMOVABBVAL - Importo abbuono in valuta | [optional] 
**Impmovacc** | **double?** | EF06_IMPMOVACC - Importo acconto in EURO | [optional] 
**Impmovaccval** | **double?** | EF06_IMPMOVACCVAL - Importo acconto in valuta | [optional] 
**Impmovomanoriv** | **double?** | EF06_IMPMOVOMANORIV - Importo omaggio senza rivalsa in EURO | [optional] 
**Impmovomanorivval** | **double?** | EF06_IMPMOVOMANORIVVAL - Importo omaggio senza rivalsa in valuta | [optional] 
**Impmovpag** | **double** | EF06_IMPMOVPAG - Importo pagato in Euro | 
**Impmovpagrit** | **double?** | EF06_IMPMOVPAGRIT - Impmovpagrit | [optional] 
**Impmovpagritval** | **double?** | EF06_IMPMOVPAGRITVAL - Impmovpagritval | [optional] 
**Impmovpagval** | **double?** | EF06_IMPMOVPAGVAL - Importo pagato in valuta | [optional] 
**Impmovrit** | **double?** | EF06_IMPMOVRIT - Impmovrit | [optional] 
**Impmovritval** | **double?** | EF06_IMPMOVRITVAL - Impmovritval | [optional] 
**Impmovscind** | **double?** | EF06_IMPMOVSCIND - Importo sconto incondizionato in EURO | [optional] 
**Impmovscindval** | **double?** | EF06_IMPMOVSCINDVAL - Importo sconto incondizionato in valuta | [optional] 
**IndAssoc** | **int?** | EF06_INDASSOC - Modalità associazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Non associata&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Associata con metodo progressivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Associata con metodo proporzionale&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndGenstatoS** | **double?** | EF06_INDGENSTATO_S - Specifica generazione stato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Creazione iniziale&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Pagamento/Riscossione&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Chiusura effetti&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  Insoluto&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; -  Raggruppato&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; -  Riemissione&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; -  Richiamato&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndPresS** | **double?** | EF06_INDPRES_S - Presentazione dell&#39;effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Non soggetto&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  In portafoglio&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  S.b.f. ordinario&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  S.b.f. a maturazione valuta&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; -  S.b.f. anticipato&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; -  Dopo incasso&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; -  Allo sconto&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; -  Altre presentazioni&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; -  Sconto fatture&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; -  Cessione a factoring&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndSperitS** | **double?** | EF06_INDSPERIT_S - Modalità di registrazione delle spese di ritorno&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Nessun addebito&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Solo annotate sull&#39;effetto&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Sommate all&#39;importo dell&#39;effetto&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  Creazione di un nuovo effetto&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndStatoS** | **double?** | EF06_INDSTATO_S - Stato dell&#39;effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Aperto&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Chiuso&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTipoincMg29** | **int?** | EF06_INDTIPOINC_MG29 - Tipo sequenza RID&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - First&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Recurrent&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Final&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - OneOff&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTipoper** | **double?** | EF06_INDTIPOPER - Tipo operazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Variazione manuale&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Pagamento/Riscossione&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Chiusura effetti&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  Presentazione effetti&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; -  Insoluto&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; -  Raggruppamento&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; -  Riemissione&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; -  Girata&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; -  Storno chiusura eff.&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; -  Adeguamento valutario&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; -  Richiamato&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; -  Incasso buon fine&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; -  Frazionamento scadenza&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; -  Rilevazione assegno&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; -  Perdite su crediti&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; -  Spese esiti&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; -  Pag./Risc. split payment&lt;/li&gt;&lt;li&gt;&lt;i&gt;17&lt;/i&gt; - Compensazione nota di credito&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Numassegno** | **string** | EF06_NUMASSEGNO - Numero di assegno | [optional] 
**Numccassegn** | **string** | EF06_NUMCCASSEGN - Conto corrente assegno | [optional] 
**NumregmovCo99** | **string** | EF06_NUMREGMOV_CO99 - Numero di registrazione | [optional] 
**NumriemisS** | **double?** | EF06_NUMRIEMIS_S - Numero di riemissione | [optional] 
**NumsteffS** | **double?** | EF06_NUMSTEFF_S - Numero stampa effetti | [optional] 
**OrdbonabiCg13** | **double?** | EF06_ORDBONABI_CG13 - OrdbonabiCg13 | [optional] 
**OrdboncabCg13** | **double?** | EF06_ORDBONCAB_CG13 - OrdboncabCg13 | [optional] 
**Ordboncaupag** | **string** | EF06_ORDBONCAUPAG - Ordboncaupag | [optional] 
**Ordboniban** | **string** | EF06_ORDBONIBAN - Ordboniban | [optional] 
**Ordbonmotivo** | **string** | EF06_ORDBONMOTIVO - Ordbonmotivo | [optional] 
**ProgSto** | **double** | EF06_PROGSTO - Progressivo storico | 
**Recordtype** | **int?** | RecordType - Recordtype | [optional] 
**RigacontmovAlRitCg42** | **double?** | EF06_RIGACONTMOVALRIT_CG42 - Riga contabile altre ritenute | [optional] 
**RigacontmovAlRitCpCg42** | **double?** | EF06_RIGACONTMOVALRITCP_CG42 - Riga contabile altre ritenute - contropartita | [optional] 
**RigacontmovCg42** | **double?** | EF06_RIGACONTMOV_CG42 - Riga contabile | [optional] 
**RigacontmovCpCg42** | **double?** | EF06_RIGACONTMOVCP_CG42 - Riga contabile - contropartita | [optional] 
**RigacontmovRitCg42** | **double?** | EF06_RIGACONTMOVRIT_CG42 - Riga contabile ritenuta acconto | [optional] 
**RigacontmovRitCpCg42** | **double?** | EF06_RIGACONTMOVRITCP_CG42 - Riga contabile ritenuta acconto - contropartita | [optional] 
**Rowversion** | **byte[]** | EF06_ROWVERSION - RowVersion | [optional] 
**ScadeS** | **DateTime** | EF06_SCADE_S - Data scadenza | 
**SpeseritbanS** | **double?** | EF06_SPESERITBAN_S - Spese di ritorno addebitate dalla banca | [optional] 
**SpeseritS** | **double?** | EF06_SPESERIT_S - Spese di ritorno addebitate al cliente | [optional] 
**Stageguid** | **Guid?** | StageGuid - Stageguid | [optional] 
**Stagestate** | **int?** | StageState - Stagestate&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - None&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Add&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Update&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Delete&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Hidden&lt;/li&gt;&lt;/ul&gt; | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

