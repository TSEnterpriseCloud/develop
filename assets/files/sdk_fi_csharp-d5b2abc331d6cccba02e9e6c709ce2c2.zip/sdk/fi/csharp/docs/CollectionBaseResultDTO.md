# It.TSEnterprise.Sdk.Model.CollectionBaseResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Result** | [**List&lt;BaseEntity&gt;**](BaseEntity.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

