# It.TSEnterprise.Sdk.Model.StagePaymentInstalmentAndHistoryParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InstalmentId** | **long?** |  | [optional] 
**StageGuid** | **Guid** |  | [optional] 
**ManualOperation** | **bool** |  | [optional] 
**CreateStage** | **bool** |  | [optional] 
**SendingRecipientAddress** | **bool** |  | [optional] 
**TransferType** | **ETransferType** |  | [optional] 
**IndPresentation** | **EPresentationBank** |  | [optional] 
**PresentationBankId** | **int** |  | [optional] 
**PresentationBankProgr** | **int** |  | [optional] 
**IndBankFilter** | **EFilterBank** |  | [optional] 
**TransferModeType** | **ETransferModeType** |  | [optional] 
**RecipientType** | **ERecipientType** |  | [optional] 
**RecoverNegativeInstalment** | **ERecoverNegativeInstalment** |  | [optional] 
**GroupingInstalment** | **EGroupingInstalmentPayment** |  | [optional] 
**InstalmentType** | **string** |  | [optional] 
**MovementType** | **string** |  | [optional] 
**Currency** | **string** |  | [optional] 
**CreationDate** | **DateTime** |  | [optional] 
**RegistrationDate** | **DateTime** |  | [optional] 
**IndSuspended** | **ESuspended** |  | [optional] 
**IndOrderingPayment** | **EOrderingPayment** |  | [optional] 
**PartialPayment** | **bool** |  | [optional] 
**ReasonForPayment** | **string** |  | [optional] 
**ReasonForSepaPayment** | **string** |  | [optional] 
**BankId** | **int?** |  | [optional] 
**PaymentAmount** | **double?** |  | [optional] 
**IndPaymentGroupingMode** | **EPaymentGroupingMode** |  | [optional] 
**AmountToSelect** | **double?** |  | [optional] 
**ExternalSearchGroup** | [**List&lt;StageInstalmentAndHistoryParametersDTOExternalSearchGroupInner&gt;**](StageInstalmentAndHistoryParametersDTOExternalSearchGroupInner.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

