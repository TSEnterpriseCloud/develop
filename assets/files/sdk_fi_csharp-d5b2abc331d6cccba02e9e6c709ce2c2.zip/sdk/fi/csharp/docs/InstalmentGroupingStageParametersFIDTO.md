# It.TSEnterprise.Sdk.Model.InstalmentGroupingStageParametersFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ElaborationGuid** | **Guid** |  | [optional] 
**InstalmentsSourceIds** | **List&lt;long&gt;** |  | [optional] 
**InstalmentsDestination** | [**List&lt;InstalmentGroupingDestStageParamsFIDTO&gt;**](InstalmentGroupingDestStageParamsFIDTO.md) |  | [optional] 
**GroupId** | **long** |  | [optional] 
**PaymentCode** | **string** |  | [optional] 
**CurrencyCode** | **string** |  | [optional] 
**NotCleanDestinations** | **bool** |  | [optional] 
**ReuseDataSourceInstalment** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

