# It.TSEnterprise.Sdk.Model.GLEntryFIGetXSLTParameters

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int** |  | [optional] 
**IdSdi** | **string** |  | [optional] 
**Hubid** | **string** |  | [optional] 
**IsAssoSoftware** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

