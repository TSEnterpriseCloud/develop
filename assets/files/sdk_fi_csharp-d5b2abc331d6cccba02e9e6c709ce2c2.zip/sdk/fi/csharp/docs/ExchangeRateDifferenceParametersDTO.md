# It.TSEnterprise.Sdk.Model.ExchangeRateDifferenceParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AmountInCurrencyReg** | **double** |  | [optional] 
**AmountInReg** | **double** |  | [optional] 
**CurrencyReg** | **string** |  | [optional] 
**ExchangeDifferenceMode** | **int** |  | [optional] 
**ExchangeReg** | **double** |  | [optional] 
**Id** | **double** |  | [optional] 
**AccountingReasonCode** | **string** |  | [optional] 
**RegistrationDate** | **DateTime** |  | [optional] 
**TypeReg** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

