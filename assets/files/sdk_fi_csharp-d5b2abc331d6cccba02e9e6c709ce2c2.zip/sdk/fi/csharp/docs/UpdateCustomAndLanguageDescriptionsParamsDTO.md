# It.TSEnterprise.Sdk.Model.UpdateCustomAndLanguageDescriptionsParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccountId** | **long** |  | [optional] 
**LanguageDescription** | **string** |  | [optional] 
**CustomDescription** | **string** |  | [optional] 
**CustomLanguageDescription** | **string** |  | [optional] 
**LanguageCode** | **string** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

