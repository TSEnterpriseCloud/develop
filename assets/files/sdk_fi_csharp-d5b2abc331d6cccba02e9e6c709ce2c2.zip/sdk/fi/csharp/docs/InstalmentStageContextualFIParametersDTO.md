# It.TSEnterprise.Sdk.Model.InstalmentStageContextualFIParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StageGuid** | **Guid** |  | [optional] 
**StageId** | **long** |  | [optional] 
**TipoEffetto** | **int** |  | [optional] 
**SottotipoEffetto** | **int?** |  | [optional] 
**ScadeS** | **DateTime** |  | [optional] 
**FlgSospeso** | **double** |  | [optional] 
**IdEf08** | **long?** |  | [optional] 
**ProgrEf08** | **int?** |  | [optional] 
**IdMg29** | **int?** |  | [optional] 
**IdMg35** | **int?** |  | [optional] 
**Bolli** | **double** |  | [optional] 
**BolliVal** | **double** |  | [optional] 
**SpInc** | **double** |  | [optional] 
**SpIncVal** | **double** |  | [optional] 
**ImpPagatoContestuale** | **double** |  | [optional] 
**ImpPagatoContestualeVal** | **double?** |  | [optional] 
**ImpAbbuono** | **double** |  | [optional] 
**ImpAbbuonoVal** | **double?** |  | [optional] 
**ImpScontoIncondizionato** | **double** |  | [optional] 
**ImpScontoIncondizionatoVal** | **double?** |  | [optional] 
**ImpScontoOmaggio** | **double** |  | [optional] 
**ImpScontoOmaggioVal** | **double?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**IdExtendedAttributeSubEntity** | **int** |  | [optional] 
**NoteAmm** | **string** |  | [optional] 
**NoteRaggr** | **string** |  | [optional] 
**ImpOrigine** | **double** |  | [optional] 
**ImpOrigineVal** | **double?** |  | [optional] 
**ImpIva** | **double** |  | [optional] 
**ImpIvaVal** | **double?** |  | [optional] 
**ImpRitenute** | **double** |  | [optional] 
**ImpRitenuteVal** | **double?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

