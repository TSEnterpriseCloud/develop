# It.TSEnterprise.Sdk.Model.GLEntryFIMultipleCreateParametersDTOItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExternalRif** | **string** |  | [optional] 
**AutoVatRow** | **bool** |  | [optional] 
**ExternalInfo** | **Dictionary&lt;string, string&gt;** |  | [optional] 
**Entry** | [**GLEntryFIDTO**](GLEntryFIDTO.md) |  | [optional] 
**Instalments** | [**List&lt;InstalmentStageFIDTO&gt;**](InstalmentStageFIDTO.md) |  | [optional] 
**InstalmentsExtension** | [**List&lt;InstalmentStageFIExtensionDTO&gt;**](InstalmentStageFIExtensionDTO.md) |  | [optional] 
**WtPurchases** | [**List&lt;PurchaseEntryWTInternalDTO&gt;**](PurchaseEntryWTInternalDTO.md) |  | [optional] 
**VatTotals** | [**List&lt;VATTotals&gt;**](VATTotals.md) |  | [optional] 
**InstalmentsToPay** | [**List&lt;InstalmentPaymentDataDTO&gt;**](InstalmentPaymentDataDTO.md) |  | [optional] 
**ManageWithholdingTax** | **bool** |  | [optional] 
**WithholdingTaxData** | [**WithholdingTaxData**](WithholdingTaxData.md) |  | [optional] 
**InstalmentsPairing** | [**InstalmentPairingDataDTO**](InstalmentPairingDataDTO.md) |  | [optional] 
**OutTransactionNumbering** | **bool** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

