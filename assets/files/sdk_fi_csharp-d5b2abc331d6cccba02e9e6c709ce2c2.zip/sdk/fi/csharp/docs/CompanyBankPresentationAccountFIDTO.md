# It.TSEnterprise.Sdk.Model.CompanyBankPresentationAccountFIDTO
EF12_BANCHECONPRES - CompanyBankPresentationAccountFI<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BancaCg12** | **double?** | EF12_BANCA_CG12 - Abi | [optional] 
**ConpreseffCg24** | **string** | EF12_CONPRESEFF_CG24 - Conto presentazione effetti | [optional] 
**ConpresspeCg24** | **string** | EF12_CONPRESSPE_CG24 - Conto per spese di presentazione | [optional] 
**DittaCg18** | **double** | EF12_DITTA_CG18 - DittaCg18 | 
**GrupreseffCg24** | **double?** | EF12_GRUPRESEFF_CG24 - GrupreseffCg24 | [optional] 
**GrupresspeCg24** | **double?** | EF12_GRUPRESSPE_CG24 - GrupresspeCg24 | [optional] 
**Id** | **long?** | EF12_ID - ID (Required only in PUT/PATCH) | [optional] 
**IdEf08** | **long?** | EF12_ID_EF08 - IdEf08 | [optional] 
**IdpreseffCg24** | **long?** | EF12_IDPRESEFF_CG24 - IdpreseffCg24 | [optional] 
**IdpresspeCg24** | **long?** | EF12_IDPRESSPE_CG24 - IdpresspeCg24 | [optional] 
**IndEffclifor** | **double?** | EF12_INDEFFCLIFOR - Cliente / Fornitore&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Clienti&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Fornitori&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndPres** | **double?** | EF12_INDPRES - Tipo presentazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Sbf a maturazione valuta&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Sbf ordinario&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Sbf anticipato&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - All&#39;incasso&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Allo sconto&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTipoeff** | **double?** | EF12_INDTIPOEFF - Tipo effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Ri.Ba.&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Tratte, Tratte acc.&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Cessioni, Cambiali&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - RID&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - MAV&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Rowversion** | **byte[]** | EF12_ROWVERSION - Rowversion | [optional] 
**BankCO** | [**BankCODTO**](BankCODTO.md) |  | [optional] 
**PresentationBill** | [**COAAccountDescrFIDTO**](COAAccountDescrFIDTO.md) |  | [optional] 
**PresentationFee** | [**COAAccountDescrFIDTO**](COAAccountDescrFIDTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

