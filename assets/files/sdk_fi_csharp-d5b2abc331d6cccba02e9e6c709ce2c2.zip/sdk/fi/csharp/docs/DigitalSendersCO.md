# It.TSEnterprise.Sdk.Model.DigitalSendersCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Cap** | **string** |  | [optional] 
**Capleg** | **string** |  | [optional] 
**Citta** | **string** |  | [optional] 
**Cittaleg** | **string** |  | [optional] 
**CodFiscale** | **string** |  | [optional] 
**Codice** | **double** |  | [optional] 
**CodiceCg16** | **int** |  | [optional] 
**Dirtecnico** | **string** |  | [optional] 
**FlgSededec** | **double** |  | [optional] 
**Id** | **int** |  | [optional] 
**IndInviotel** | **double** |  | [optional] 
**Indirizzo** | **string** |  | [optional] 
**IndIrleg** | **string** |  | [optional] 
**Niscrcaf** | **string** |  | [optional] 
**Prov** | **string** |  | [optional] 
**Provleg** | **string** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**Sedeivaann** | **double?** |  | [optional] 
**Sedeivaper** | **double?** |  | [optional] 
**Ultprotivaann** | **double?** |  | [optional] 
**Ultprotivaper** | **double?** |  | [optional] 
**GeneralMasterDataCO** | [**GeneralMasterDataCO**](GeneralMasterDataCO.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

