# It.TSEnterprise.Sdk.Model.ConcessionCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Cap** | **string** |  | [optional] 
**Ccici** | **string** |  | [optional] 
**Ccimposte** | **string** |  | [optional] 
**Citta** | **string** |  | [optional] 
**Codice** | **double** |  | [optional] 
**Concess** | **string** |  | [optional] 
**Descr** | **string** |  | [optional] 
**Faxnum** | **string** |  | [optional] 
**IdmediaCg99** | **double?** |  | [optional] 
**IndIrizzo** | **string** |  | [optional] 
**Orariouff** | **string** |  | [optional] 
**Prov** | **string** |  | [optional] 
**Resp1nota** | **string** |  | [optional] 
**Resp1qual** | **string** |  | [optional] 
**Resp1telnum** | **string** |  | [optional] 
**Resp1uff** | **string** |  | [optional] 
**Resp2nota** | **string** |  | [optional] 
**Resp2qual** | **string** |  | [optional] 
**Resp2telnum** | **string** |  | [optional] 
**Resp2uff** | **string** |  | [optional] 
**Resp3nota** | **string** |  | [optional] 
**Resp3qual** | **string** |  | [optional] 
**Resp3telnum** | **string** |  | [optional] 
**Resp3uff** | **string** |  | [optional] 
**Tel1num** | **string** |  | [optional] 
**Tel2num** | **string** |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

