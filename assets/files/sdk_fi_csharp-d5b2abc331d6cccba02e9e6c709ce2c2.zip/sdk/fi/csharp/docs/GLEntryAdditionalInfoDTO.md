# It.TSEnterprise.Sdk.Model.GLEntryAdditionalInfoDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long** |  | [optional] 
**NumeroRegistrazione** | **string** |  | [optional] 
**Sezionale** | **string** |  | [optional] 
**Protocollo** | **double** |  | [optional] 
**DataRegistrazione** | **DateTime** |  | [optional] 
**Esercizio** | **double** |  | [optional] 
**ProgressivoEsercizio** | **double** |  | [optional] 
**NumeroDocumento** | **string** |  | [optional] 
**DataDocumento** | **DateTime?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

