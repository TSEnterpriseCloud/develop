# It.TSEnterprise.Sdk.Model.CSPaymentRangeCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Aimpdoc** | **double** |  | [optional] 
**CliforCg44** | **double** |  | [optional] 
**CodPagCg62** | **string** |  | [optional] 
**CodScagl** | **double** |  | [optional] 
**DittaCg18** | **double** |  | [optional] 
**Id** | **long** |  | [optional] 
**IdCg62** | **long** |  | [optional] 
**IdmediaCg99** | **double** |  | [optional] 
**IndPagpart** | **double** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**TipocfCg44** | **double** |  | [optional] 
**ValutaCg08** | **string** |  | [optional] 
**Parent** | [**CustomerSupplierCO**](CustomerSupplierCO.md) |  | [optional] 
**CurrencyCO** | [**CurrencyCO**](CurrencyCO.md) |  | [optional] 
**PaymentTermCO** | [**PaymentTermCO**](PaymentTermCO.md) |  | [optional] 
**StageGuid** | **Guid** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long** |  | [optional] 
**StageParentId** | **long** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

