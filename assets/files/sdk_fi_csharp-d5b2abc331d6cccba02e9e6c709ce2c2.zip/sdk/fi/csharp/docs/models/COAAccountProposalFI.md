# It.TSEnterprise.Sdk.Model.COAAccountProposalFI

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codice** | **double** |  | [optional] 
**ContoCg24** | **string** |  | [optional] 
**GruppoCg10** | **double** |  | [optional] 
**Id** | **long** |  | [optional] 
**IdCg24** | **long** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**Parent** | [**COAGroupCodeFI**](COAGroupCodeFI.md) |  | [optional] 
**CoaAccountFI** | [**COAAccountFI**](COAAccountFI.md) |  | [optional] 
**CoaAccountProposalDefinitionFI** | [**COAAccountProposalDefinitionFI**](COAAccountProposalDefinitionFI.md) |  | [optional] 
**StageGuid** | **Guid** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long** |  | [optional] 
**StageParentId** | **long** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

