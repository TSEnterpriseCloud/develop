# It.TSEnterprise.Sdk.Model.COAAccountBalanceParameters

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccountId** | **long** |  | [optional] 
**CustSupplId** | **int** |  | [optional] 
**StartDate** | **DateTime** |  | [optional] 
**EndDate** | **DateTime** |  | [optional] 
**Year** | **double** |  | [optional] 
**ProgrYear** | **long** |  | [optional] 
**Currencies** | **List&lt;string&gt;** |  | [optional] 
**Sites** | **List&lt;string&gt;** |  | [optional] 
**Holdings** | **List&lt;string&gt;** |  | [optional] 
**MovementTypes** | **List&lt;double&gt;** |  | [optional] 
**IndTipoData** | **int** |  | [optional] 
**SqlFilter** | **string** |  | [optional] 
**ParamFilter** | [**QuerySqlParamsValues**](QuerySqlParamsValues.md) |  | [optional] 
**SqlMovementType** | **string** |  | [optional] 
**ParentHolding** | **double** |  | [optional] 
**IndTipoSaldo** | **double** |  | [optional] 
**ListHolding** | **List&lt;double&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

