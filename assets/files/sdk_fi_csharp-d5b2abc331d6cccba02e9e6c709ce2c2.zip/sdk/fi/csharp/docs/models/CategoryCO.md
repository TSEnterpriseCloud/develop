# It.TSEnterprise.Sdk.Model.CategoryCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Categ** | **string** |  | [optional] 
**Descrcat** | **string** |  | [optional] 
**DittaCg18** | **double** |  | [optional] 
**IdEntityWithDescriptions** | **int** |  | [optional] 
**IdmediaCg99** | **double** |  | [optional] 
**Idprov** | **int** |  | [optional] 
**MacrocatMg10** | **string** |  | [optional] 
**TipocfMg10** | **double** |  | [optional] 
**Parent** | [**MacroCategoryCO**](MacroCategoryCO.md) |  | [optional] 
**StageGuid** | **Guid** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long** |  | [optional] 
**StageParentId** | **long** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

