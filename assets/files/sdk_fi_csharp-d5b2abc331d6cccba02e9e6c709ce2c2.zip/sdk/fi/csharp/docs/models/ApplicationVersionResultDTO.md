# It.TSEnterprise.Sdk.Model.ApplicationVersionResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Major** | **long** |  | [optional] 
**Minor** | **long** |  | [optional] 
**Patch** | **long** |  | [optional] 
**Build** | **long** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

