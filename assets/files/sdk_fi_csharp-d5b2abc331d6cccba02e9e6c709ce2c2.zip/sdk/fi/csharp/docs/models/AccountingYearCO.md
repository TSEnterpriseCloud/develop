# It.TSEnterprise.Sdk.Model.AccountingYearCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Anno** | **double** |  | [optional] 
**Dataape** | **DateTime** |  | [optional] 
**Datachiu** | **DateTime** |  | [optional] 
**DittaCg18** | **double** |  | [optional] 
**FlgAdecbatt** | **double** |  | [optional] 
**FlgAdecbcli** | **double** |  | [optional] 
**FlgAdecbfor** | **double** |  | [optional] 
**FlgAdecbpas** | **double** |  | [optional] 
**FlgEserchiuso** | **double** |  | [optional] 
**FlgEsercor** | **double** |  | [optional] 
**FlgGencesp** | **double** |  | [optional] 
**FlgGenratei** | **int** |  | [optional] 
**FlgGenrisc** | **double** |  | [optional] 
**Id** | **long** |  | [optional] 
**IdmediaCg99** | **double** |  | [optional] 
**ProgEser** | **double** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**StageGuid** | **Guid** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long** |  | [optional] 
**StageParentId** | **long** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

