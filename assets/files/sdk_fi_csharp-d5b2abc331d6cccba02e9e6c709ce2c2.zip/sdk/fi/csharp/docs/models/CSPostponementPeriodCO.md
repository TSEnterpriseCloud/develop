# It.TSEnterprise.Sdk.Model.CSPostponementPeriodCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Ammgg** | **double** |  | [optional] 
**CliforCg44** | **double** |  | [optional] 
**Dammgg** | **double** |  | [optional] 
**DittaCg18** | **double** |  | [optional] 
**Ggmmfixslit** | **double** |  | [optional] 
**Ggslsucc** | **double** |  | [optional] 
**Id** | **long** |  | [optional] 
**IdmediaCg99** | **double** |  | [optional] 
**IndAppggfix** | **int** |  | [optional] 
**IndTiposlit** | **double** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**TipocfCg44** | **double** |  | [optional] 
**Tipoeff** | **double** |  | [optional] 
**Parent** | [**CustomerSupplierCO**](CustomerSupplierCO.md) |  | [optional] 
**StageGuid** | **Guid** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long** |  | [optional] 
**StageParentId** | **long** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

