# It.TSEnterprise.Sdk.Model.BusinessTypeDataCODTO
CG96_ANAGATTIVITA - BusinessTypeDataCO<br>Proprietà chiave:<ul><li><b>CodAttivita</b></li><li><b>DittaCg18</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodAttivita** | **double** | CG96_CODATTIVITA - Codice Attività | 
**DittaCg18** | **double** | CG96_DITTA_CG18 - Ditta | 
**FlgIvaedit** | **double** | CG96_FLGIVAEDIT - IVA per editoria | 
**Annoliq** | **double** | CG96_ANNOLIQ - Anno ultima stampa liquidazione annuale | [optional] 
**CodiceCg06** | **string** | CG96_CODICE_CG06 - CodiceCg06 | [optional] 
**CodiceCg6a** | **string** | CG96_CODICE_CG6A - Codice attività ATECO 2007 | [optional] 
**Datastpliqiva** | **DateTime** | CG96_DATASTPLIQIVA - Data ultima stampa registro liquidazione IVA | [optional] 
**Datastpplafon** | **DateTime** | CG96_DATASTPPLAFON - Data ultima stampa plafond su registro liquidazione IVA | [optional] 
**Datastpregacq** | **DateTime** | CG96_DATASTPREGACQ - Data ultima stampa registro acquisti | [optional] 
**Datastpregacqglob** | **DateTime** | CG96_DATASTPREGACQGLOB - Data ultima stampa registro acquisti regime del margine globale | [optional] 
**Datastpregcor** | **DateTime** | CG96_DATASTPREGCOR - Data ultima stampa registro corrispettivi | [optional] 
**Datastpregrie** | **DateTime** | CG96_DATASTPREGRIE - Data ultima stampa registro riepilogativo | [optional] 
**Datastpregunicanal** | **DateTime** | CG96_DATASTPREGUNICANAL - Data ultima stampa registro unico regime del margine analitico | [optional] 
**Datastpregven** | **DateTime** | CG96_DATASTPREGVEN - Data ultima stampa registro vendite  | [optional] 
**Datastpregvenglob** | **DateTime** | CG96_DATASTPREGVENGLOB - Data ultima stampa registro vendite regime del margine globale | [optional] 
**Descrattivita** | **string** | CG96_DESCRATTIVITA - Descrizione | [optional] 
**IndAgric** | **double** | CG96_INDAGRIC - Tipo impresa agricola&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Azienda agricola&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Cooperativa&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Assoc. categoria agricoltori&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Agriturismo&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Cessione bovini e suini&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Attività connesse agricoltura&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndCatpart** | **double** | CG96_INDCATPART - Regimi speciali&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Autotrasportatori di merci per conto terzi&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Esercenti impianti distribuzione carburanti&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Società sportive dilettantistiche (L.398/91)&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Agricoltura&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Editoria&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Agenzie di viaggio&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndRegimefiscale** | **int** | CG96_INDREGIMEFISCALE - Regime fiscale (per Fatture PA)&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - RF01 - Ordinario&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - RF02 - Contribuenti minimi (art.1, c.96-117, L. 244/07)&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - RF03 - Nuove iniziative produttive (art.13, L. 388/00)&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - RF04 - Agricoltura e attività connesse e pesca (artt.34 e 34-bis, DPR 633/72)&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - RF05 - Vendita sali e tabacchi (art.74, c.1, DPR. 633/72)&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - RF06 - Commercio fiammiferi (art.74, c.1, DPR 633/72)&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - RF07 - Editoria (art.74, c.1, DPR 633/72)&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - RF08 - Gestione servizi telefonia pubblica (art.74, c.1, DPR 633/72)&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - RF09 - Rivendita documenti di trasporto pubblico e di sosta (art.74, c.1, DPR 633/72)&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - RF10 - Intrattenimenti, giochi e altre attività di cui alla tariffa allegata al DPR 640/72 (art.74, c.6, DPR 633/72)&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - RF11 - Agenzie viaggi e turismo (art.74-ter, DPR 633/72)&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - RF12 - Agriturismo (art.5, c.2, L. 413/91)&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - RF13 - Vendite a domicilio (art.25-bis, c.6, DPR 600/73)&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - RF14 - Rivendita beni usati, oggetti d’arte, d’antiquariato o da collezione (art.36, DL 41/95)&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - RF15 - Agenzie di vendite all’asta di oggetti d’arte, antiquariato o da collezione (art.40-bis, DL 41/95)&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - RF16 - IVA per cassa P.A. (art.6, c.5, DPR 633/72)&lt;/li&gt;&lt;li&gt;&lt;i&gt;17&lt;/i&gt; - RF17 - IVA per cassa soggetti con vol. d’affari inferiore ad euro 200.000 (art.7, DL 185/2008)&lt;/li&gt;&lt;li&gt;&lt;i&gt;18&lt;/i&gt; - RF18 - Altro&lt;/li&gt;&lt;li&gt;&lt;i&gt;19&lt;/i&gt; - RF19 - Regime forfettario&lt;/li&gt;&lt;li&gt;&lt;i&gt;20&lt;/i&gt; - RF20 - Regime transfrontaliero di Franchigia IVA (Direttiva UE 2020/285)&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Rowversion** | **byte[]** | CG96_ROWVERSION - Rowversion | [optional] 
**CodAteco** | [**AtecoCodeCODTO**](AtecoCodeCODTO.md) |  | [optional] 
**IstatActivityCO** | [**ISTATActivityCODTO**](ISTATActivityCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

