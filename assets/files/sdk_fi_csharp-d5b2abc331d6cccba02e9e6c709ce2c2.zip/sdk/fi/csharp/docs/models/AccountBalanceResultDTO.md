# It.TSEnterprise.Sdk.Model.AccountBalanceResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**OpenBalance** | **double** |  | [optional] 
**PreviousBalance** | **double** |  | [optional] 
**DebitTotal** | **double** |  | [optional] 
**CreditTotal** | **double** |  | [optional] 
**DebitCreditBalance** | **double** |  | [optional] 
**FinalBalance** | **double** |  | [optional] 
**OpenBalanceCurrency** | **double** |  | [optional] 
**PreviousBalanceCurrency** | **double** |  | [optional] 
**DebitTotalCurrency** | **double** |  | [optional] 
**CreditTotalCurrency** | **double** |  | [optional] 
**DebitCreditBalanceCurrency** | **double** |  | [optional] 
**FinalBalanceCurrency** | **double** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

