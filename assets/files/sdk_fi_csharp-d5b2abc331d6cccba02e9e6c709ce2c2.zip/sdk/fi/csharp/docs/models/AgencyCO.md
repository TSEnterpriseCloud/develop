# It.TSEnterprise.Sdk.Model.AgencyCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodiceAgenziaCO** | **double** |  | [optional] 
**CodiceBanca** | **double** |  | [optional] 
**Descr** | **string** |  | [optional] 
**IdmediaCg99** | **double** |  | [optional] 
**Localita** | **string** |  | [optional] 
**Prov** | **string** |  | [optional] 
**BankCO** | [**BankCO**](BankCO.md) |  | [optional] 
**StageGuid** | **Guid** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long** |  | [optional] 
**StageParentId** | **long** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

