# It.TSEnterprise.Sdk.Model.COAAccountStateFI

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ConsosCg24** | **string** |  | [optional] 
**ContoCg24** | **string** |  | [optional] 
**DittaCg18** | **double** |  | [optional] 
**Dtconsos** | **DateTime** |  | [optional] 
**Dtdisatt** | **DateTime** |  | [optional] 
**FlgDisatt** | **double** |  | [optional] 
**GruppoCg10** | **double** |  | [optional] 
**GrusosCg10** | **double** |  | [optional] 
**IdCg24** | **long** |  | [optional] 
**Idstatipdc** | **long** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**Parent** | [**COAAccountFI**](COAAccountFI.md) |  | [optional] 
**StageGuid** | **Guid** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long** |  | [optional] 
**StageParentId** | **long** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

