# It.TSEnterprise.Sdk.Model.COAAccountDescrFIDTO
COAAccountDescrFI - COAAccountDescrFI<br>Proprietà chiave:<ul><li><b>DittaCg18</b></li><li><b>Idconto</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Conto** | **string** | CG24_CONTO - Conto | 
**DittaCg18** | **double** | CG18_DITTA - DittaCg18 | 
**FlgAnalit** | **int** | CG24_FLGANALIT - FlgAnalit | 
**GruppoCg10** | **double** | CG24_GRUPPO_CG10 - GruppoCg10 | 
**Idconto** | **long** | CG24_IDCONTO - Idconto | 
**Idparent** | **long** | CG24_IDPARENT - Idparent | 
**CoaAccountFI** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | 
**ContoFormattato** | **string** | CG24_CONTO_FORMATTATO - ContoFormattato | [optional] 
**Descr** | **string** | CG24_DESCR - Descr | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

