# It.TSEnterprise.Sdk.Model.CSCompanyBankCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CliforCg44** | **double** |  | [optional] 
**DittaCg18** | **double** |  | [optional] 
**FlgPref** | **int** |  | [optional] 
**Id** | **int** |  | [optional] 
**ProgR** | **int** |  | [optional] 
**ProgREf08** | **double** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**TipocfCg44** | **double** |  | [optional] 
**Parent** | [**CustomerSupplierCO**](CustomerSupplierCO.md) |  | [optional] 
**CompanyBankCO** | [**CompanyBankCO**](CompanyBankCO.md) |  | [optional] 
**StageGuid** | **Guid** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long** |  | [optional] 
**StageParentId** | **long** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

