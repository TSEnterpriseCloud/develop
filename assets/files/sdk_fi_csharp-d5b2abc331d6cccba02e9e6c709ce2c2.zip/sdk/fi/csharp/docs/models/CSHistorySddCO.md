# It.TSEnterprise.Sdk.Model.CSHistorySddCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodBicswift** | **string** |  | [optional] 
**CodClideb** | **string** |  | [optional] 
**CodIndiv** | **double** |  | [optional] 
**Datavar** | **DateTime** |  | [optional] 
**Id** | **int** |  | [optional] 
**IndStorno** | **double** |  | [optional] 
**IndTipoinc** | **int** |  | [optional] 
**IndTiposdd** | **double** |  | [optional] 
**IndTipovar** | **double** |  | [optional] 
**Ridiban** | **string** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**SoggtitibanCg16** | **int** |  | [optional] 
**Tipologia** | **double** |  | [optional] 
**Parent** | [**CSSddCO**](CSSddCO.md) |  | [optional] 
**StageGuid** | **Guid** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long** |  | [optional] 
**StageParentId** | **long** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

