# It.TSEnterprise.Sdk.Model.CIGCUPMasterDataCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Cig** | **string** |  | [optional] 
**Cup** | **string** |  | [optional] 
**Descrizione** | **string** |  | [optional] 
**DocrifData** | **DateTime** |  | [optional] 
**DocrifId** | **string** |  | [optional] 
**FlgAttivo** | **double** |  | [optional] 
**Id** | **int** |  | [optional] 
**IndTipocontr** | **int** |  | [optional] 
**IndTipodocrif** | **int** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**StageGuid** | **Guid** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long** |  | [optional] 
**StageParentId** | **long** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

