# It.TSEnterprise.Sdk.Model.BankDispositionFIParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IndPresentationBank** | **double** |  | [optional] 
**PresentationBank** | **double** |  | [optional] 
**CreationDate** | **string** |  | [optional] 
**Office** | **double** |  | [optional] 
**IndPresentation** | **double** |  | [optional] 
**IndTipoEff** | **double** |  | [optional] 
**GruppoCg10** | **double** |  | [optional] 
**IsDiscount** | **bool** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

