# It.TSEnterprise.Sdk.Model.BusinessTypeDataDefaultParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Datareg** | **DateTime** |  | [optional] 
**Sez** | **string** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

