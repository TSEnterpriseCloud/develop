# It.TSEnterprise.Sdk.Model.COAAccountFIDTO
CG24_TABPDC - Conto contabile<br>Proprietà chiave:<ul><li><b>Idconto</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codeformatted** | **string** | Codice | 
**Conto** | **string** | CG24_CONTO - Codice conto | 
**GruppoCg10** | **double** | CG24_GRUPPO_CG10 - Piano dei conti | 
**Idparent** | **long** | CG24_IDPARENT - Id conto padre | 
**CoaGroupCodeFI** | [**COAGroupCodeFIDTO**](COAGroupCodeFIDTO.md) |  | 
**VatTypeFI** | [**VATTypeFIDTO**](VATTypeFIDTO.md) |  | 
**AccountType** | **int** | Tipo conto | [optional] 
**Alias** | **string** | CG24_ALIAS - Alias | [optional] 
**CodiceCg22** | **double** | CG24_CODICE_CG22 - Cod.imm. | [optional] 
**CodiceCgc0** | **double** | CG24_CODICE_CGC0 - Codice intercompany | [optional] 
**CogeprogeAbil** | **int** | CG24_COGEPROGE_ABIL - Abilitato alla correlazione progetti/commesse | [optional] [default to 0]
**CogeprogeAttivita** | **int** | CG24_COGEPROGE_ATTIVITA - Correla attività | [optional] [default to 0]
**CogeprogeMateriali** | **int** | CG24_COGEPROGE_MATERIALI - Correla materiali | [optional] [default to 0]
**CogeprogeNodo** | **int** | CG24_COGEPROGE_NODO - Correla nodo | [optional] [default to 0]
**CogeprogeSpese** | **int** | CG24_COGEPROGE_SPESE - Correla spese | [optional] [default to 0]
**Contoape** | **string** | CG24_CONTOAPE - Conto apertura | [optional] 
**Contochiu** | **string** | CG24_CONTOCHIU - Conto chiusura | [optional] 
**Contocrsosp** | **string** | CG24_CONTOCRSOSP - Conto specifico | [optional] 
**Contoratatt** | **string** | CG24_CONTORATATT - Conto rateo att. | [optional] 
**Contoratpass** | **string** | CG24_CONTORATPASS - Conto rateo pass. | [optional] 
**Contorisatt** | **string** | CG24_CONTORISATT - Conto risc. att. | [optional] 
**Contorispass** | **string** | CG24_CONTORISPASS - Conto risc. pass. | [optional] 
**Descr** | **string** | CG24_DESCR - Descrizione | [optional] 
**FlgAggfatt** | **int** | CG24_FLGAGGFATT - Agg.fatt.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgAggfattEnum.NUMBER_0]
**FlgAnalit** | **int** | CG24_FLGANALIT - Conto analitico&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgAnalitEnum.NUMBER_1]
**FlgBilconsattpassdist** | **int** | CG24_FLGBILCONSATTPASSDIST - Non utilizzato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgBilconsattpassdistEnum.NUMBER_0]
**FlgContoimm** | **int** | CG24_FLGCONTOIMM - Imm.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgContoimmEnum.NUMBER_0]
**FlgGesec** | **int** | CG24_FLGGESEC - Gest.EC&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgGesecEnum.NUMBER_0]
**FlgGespor** | **int** | CG24_FLGGESPOR - Gest.port.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgGesporEnum.NUMBER_0]
**FlgIntercompany** | **int** | CG24_FLGINTERCOMPANY - Gestione Intercompany&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgIntercompanyEnum.NUMBER_0]
**FlgOpnonfin** | **double** | CG24_FLGOPNONFIN - Cont.per cassa&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to 0D]
**FlgRaganal** | **int** | CG24_FLGRAGANAL - Raggr.anal.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgRaganalEnum.NUMBER_0]
**FlgRarp** | **int** | CG24_FLGRARP - Base imp.rit.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgRarpEnum.NUMBER_0]
**FlgSaldog** | **int** | CG24_FLGSALDOG - Saldo data reg.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgSaldogEnum.NUMBER_0]
**FlgValutaest** | **int** | CG24_FLGVALUTAEST - Valuta est.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgValutaestEnum.NUMBER_0]
**Idconto** | **long** | CG24_IDCONTO - ID Conto (Required only in PUT/PATCH) | [optional] 
**IdcontoapeCg24** | **long** | CG24_IDCONTOAPE_CG24 - Conto riapertura | [optional] 
**IdcontochiuCg24** | **long** | CG24_IDCONTOCHIU_CG24 - Conto chiusura | [optional] 
**IdcontoratattCg24** | **long** | CG24_IDCONTORATATT_CG24 - Conto rateo att. | [optional] 
**IdcontoratpassCg24** | **long** | CG24_IDCONTORATPASS_CG24 - Conto rateo pass. | [optional] 
**IdcontorisattCg24** | **long** | CG24_IDCONTORISATT_CG24 - Conto risc. att. | [optional] 
**IdcontorispassCg24** | **long** | CG24_IDCONTORISPASS_CG24 - Conto risc. pass. | [optional] 
**Idreverse** | **int** | CG24_IDREVERSE - Tipo reverse charge | [optional] 
**IdRifPdC80** | **long** | CG24_IDRIFPDC80 - Conto correlazione AI P.d.C 80 | [optional] 
**IndAttpasspor** | **int** | CG24_INDATTPASSPOR - Natura&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Attivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Passivo&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndAttpassporEnum.NUMBER_0]
**IndContoricav** | **int** | CG24_INDCONTORICAV - Tipo conto econ.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Ricavo&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Costo&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndContoricavEnum.NUMBER_0]
**IndCosvend** | **int** | CG24_INDCOSVEND - Costo venduto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Ricavi inerenti attivita&#39;&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Ricavi diversi&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Costi merci e mat. suss.&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Altri costi&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Retribuzioni&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Consumi carb. e lubrif.&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Consumi energia&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Altri consumi&lt;/li&gt;&lt;li&gt;&lt;i&gt;98&lt;/i&gt; - Rimanenze iniziali&lt;/li&gt;&lt;li&gt;&lt;i&gt;99&lt;/i&gt; - Rimanenze finali&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndCosvendEnum.NUMBER_0]
**IndDaav** | **int** | CG24_INDDAAV - Segno esp.bilancio&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Dare&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Avere&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndDaavEnum.NUMBER_0]
**IndDaavec** | **int** | CG24_INDDAAVEC - Segno&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Dare&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Avere&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndDaavecEnum.NUMBER_0]
**IndLivchius** | **int** | CG24_INDLIVCHIUS - Livello di chiusura | [optional] [default to 0]
**IndMastroCliFor** | **double** | CG24_INDMASTROCLIFOR - Indicatore mastro clienti/fornitori&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;99&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Mastro clienti&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Mastro fornitori&lt;/li&gt;&lt;/ul&gt; | [optional] [default to 99D]
**IndTipoconto** | **int** | CG24_INDTIPOCONTO - Natura conto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Conto d&#39;ordine&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Patrimoniale&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Economico&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Da non stampare&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndTipocontoEnum.NUMBER_0]
**Percindeduc** | **double** | CG24_PERCINDEDUC - % IRAP | [optional] 
**Percindetra** | **double** | CG24_PERCINDETRA - % IRES/IRPEF | [optional] 
**Suddconti** | **double** | CG24_SUDDCONTI - Informazioni riguardanti la compilazione quadro A modello IVA 11 | [optional] [default to 0D]
**CoaAccountCustomizationFI** | [**List&lt;COAAccountCustomizationFIDTO&gt;**](COAAccountCustomizationFIDTO.md) |  | [optional] 
**CoaAccountFIApe** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**CoaAccountFIChiu** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**CoaAccountFIParent** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**CoaAccountFIRatatt** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**CoaAccountFIRatpass** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**CoaAccountFIRisatt** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**CoaAccountFIRispass** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**CoaAccountStateFI** | [**List&lt;COAAccountStateFIDTO&gt;**](COAAccountStateFIDTO.md) |  | [optional] 
**CoaInternationalCustomizationFI** | [**List&lt;COAInternationalCustomizationFIDTO&gt;**](COAInternationalCustomizationFIDTO.md) |  | [optional] 
**IntragroupStructureCO** | [**IntragroupStructureCODTO**](IntragroupStructureCODTO.md) |  | [optional] 
**ReverseTypeFI** | [**GLReverseTypeFIDTO**](GLReverseTypeFIDTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

