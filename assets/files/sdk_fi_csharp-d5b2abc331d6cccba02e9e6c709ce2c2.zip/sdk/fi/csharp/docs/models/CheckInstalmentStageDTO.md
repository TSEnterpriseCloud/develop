# It.TSEnterprise.Sdk.Model.CheckInstalmentStageDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StageGuid** | **Guid** |  | [optional] 
**Taxable** | **double** |  | [optional] 
**Vat** | **double** |  | [optional] 
**WithholdingTax** | **double** |  | [optional] 
**TaxableCurrency** | **double** |  | [optional] 
**VatCurrency** | **double** |  | [optional] 
**WithholdingTaxCurrency** | **double** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

