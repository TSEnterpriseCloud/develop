# It.TSEnterprise.Sdk.Model.COAInternationalCustomizationFI

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Categoria** | **int?** |  | [optional] 
**ContoCg24** | **string** |  | [optional] 
**EsModulo347** | **int?** |  | [optional] 
**GbDeferralcode** | **string** |  | [optional] 
**GruppoCg10** | **double** |  | [optional] 
**Id** | **long** |  | [optional] 
**IdCg24** | **long** |  | [optional] 
**Iso3166A2** | **string** |  | [optional] 
**Rowversion** | **byte[]** |  | [optional] 
**Subcategoria** | **int?** |  | [optional] 
**Parent** | [**COAAccountFI**](COAAccountFI.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

