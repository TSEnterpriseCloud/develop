# It.TSEnterprise.Sdk.Model.DMSPublishedEntityFW

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Annofisc** | **int?** |  | [optional] 
**Datafin** | **DateTime?** |  | [optional] 
**Dataini** | **DateTime?** |  | [optional] 
**Datapub** | **DateTime?** |  | [optional] 
**DittaCg18** | **double?** |  | [optional] 
**FlgInvalid** | **int** |  | [optional] 
**FlgUploadFile** | **int** |  | [optional] 
**Guid** | **Guid** |  | [optional] 
**Hubid** | **string** |  | [optional] 
**Idcct** | **int?** |  | [optional] 
**IddbArchivia** | **string** |  | [optional] 
**IdHm33** | **int** |  | [optional] 
**Idknos** | **int?** |  | [optional] 
**Nome** | **string** |  | [optional] 
**Percorso** | **string** |  | [optional] 
**Protocollo** | **string** |  | [optional] 
**RecordArchivia** | **int?** |  | [optional] 
**SerialArchivia** | **string** |  | [optional] 
**Stampadesc** | **string** |  | [optional] 
**TipoarchHm30** | **int** |  | [optional] 
**DmsStorageTypeFW** | [**DMSStorageTypeFW**](DMSStorageTypeFW.md) |  | [optional] 
**StageGuid** | **Guid?** |  | [optional] 
**StageState** | **StageState** |  | [optional] 
**StageId** | **long?** |  | [optional] 
**StageParentId** | **long?** |  | [optional] 
**DomainState** | **DomainState** |  | [optional] 
**State** | **State** |  | [optional] 
**InternalState** | **State** |  | [optional] 
**CurrentDeserializationLevel** | **string** |  | [optional] 
**ModifiedProperties** | **List&lt;string&gt;** |  | [optional] 
**IsTransferring** | **bool** |  | [optional] 
**IsExternalSyncEnabled** | **bool** |  | [optional] 
**IsInMapping** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

