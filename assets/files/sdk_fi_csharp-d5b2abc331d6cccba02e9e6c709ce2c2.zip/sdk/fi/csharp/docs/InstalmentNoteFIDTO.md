# It.TSEnterprise.Sdk.Model.InstalmentNoteFIDTO
EF04_SCADNOTE - InstalmentNoteFI<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | EF04_ID - ID note (Required only in PUT/PATCH) | [optional] 
**IdEf01** | **long** | EF04_ID_EF01 - Id Scadenza | 
**IdmediaCg99** | **double?** | EF04_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**Noteammin** | **string** | EF04_NOTEAMMIN - Note amministrazione | [optional] 
**Noteraggr** | **string** | EF04_NOTERAGGR - Note raggruppamento effetti | [optional] 
**Rowversion** | **byte[]** | EF04_ROWVERSION - RowVersion | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

