# It.TSEnterprise.Sdk.Model.VatPaymentCloseFromVATReturnParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdCg41List** | **List&lt;long&gt;** |  | [optional] 
**DateVATReturn** | **DateTime** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

