# It.TSEnterprise.Sdk.Model.SepaReasonCodesFIDTO
CG6G_CAUSPAGSEPA - SepaReasonCodesFI<br>Proprietà chiave:<ul><li><b>Codice</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codice** | **string** | CG6G_CODICE - Codice | 
**Descr** | **string** | CG6G_DESCR - Descr | [optional] 
**IndTipomov** | **int** | CG6G_INDTIPOMOV - IndTipomov | 
**Note** | **string** | CG6G_NOTE - Note | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

