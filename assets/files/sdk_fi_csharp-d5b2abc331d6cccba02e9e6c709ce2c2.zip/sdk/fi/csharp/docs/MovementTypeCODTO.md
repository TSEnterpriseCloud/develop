# It.TSEnterprise.Sdk.Model.MovementTypeCODTO
CGT0_TIPOMOV - Tipo movimento<br>Proprietà chiave:<ul><li><b>Codice</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codice** | **int** | CGT0_CODICE - Codice | 
**Descr** | **string** | CGT0_DESCR - Descr | [optional] 
**Descrbreve** | **string** | CGT0_DESCRBREVE - Descr.breve | [optional] 
**Descrmedia** | **string** | CGT0_DESCRMEDIA - Descrmedia | [optional] 
**FlgBilanci** | **int** | CGT0_FLGBILANCI - Bilanci | 
**FlgBilancicons** | **int** | CGT0_FLGBILANCICONS - FlgBilancicons | 
**FlgCanrevoke** | **int** | CGT0_FLGCANREVOKE - Revoke | 
**FlgCoan** | **int** | CGT0_FLGCOAN - Movimenti CoAn | 
**FlgContrsaldi** | **int** | CGT0_FLGCONTRSALDI - FlgContrsaldi | 
**FlgDoc** | **int** | CGT0_FLGDOC - FlgDoc | 
**FlgEc** | **int** | CGT0_FLGEC - FlgEc | 
**FlgElabiva** | **int** | CGT0_FLGELABIVA - FlgElabiva | 
**FlgHyperion** | **int** | CGT0_FLGHYPERION - Hyperion | 
**FlgMovcont** | **int** | CGT0_FLGMOVCONT - Mov.cont. | 
**FlgMoviva** | **int** | CGT0_FLGMOVIVA - Movimenti IVA | 
**FlgPartitari** | **int** | CGT0_FLGPARTITARI - Partitari | 
**FlgPf** | **int** | CGT0_FLGPF - FlgPf | 
**FlgQuerypn** | **int** | CGT0_FLGQUERYPN - FlgQuerypn | 
**IndAcconti** | **int** | CGT0_INDACCONTI - Acconti | 
**IndCambiali** | **int** | CGT0_INDCAMBIALI - Cambiali | 
**IndChiuseff** | **int** | CGT0_INDCHIUSEFF - Chiusura effetti | 
**IndConsolidamento** | **int** | CGT0_INDCONSOLIDAMENTO - Consolidamento | 
**IndDatabilanci** | **int** | CGT0_INDDATABILANCI - IndDatabilanci | 
**IndEcportaper** | **int** | CGT0_INDECPORTAPER - IndEcportaper | 
**IndEcportchius** | **int** | CGT0_INDECPORTCHIUS - IndEcportchius | 
**IndIncassobf** | **int** | CGT0_INDINCASSOBF - Incasso b.f. | 
**IndInsoluti** | **int** | CGT0_INDINSOLUTI - IndInsoluti | 
**IndProforma** | **int** | CGT0_INDPROFORMA - Proforma | 
**IndRaggr** | **int** | CGT0_INDRAGGR - IndRaggr | 
**IndRatrisc** | **int** | CGT0_INDRATRISC - IndRatrisc | 
**IndRettifica** | **int** | CGT0_INDRETTIFICA - Rettifica | 
**IndSimulbilanci** | **int** | CGT0_INDSIMULBILANCI - Simulazione bilanci | 
**IndTipoifrs** | **int** | CGT0_INDTIPOIFRS - IndTipoifrs | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

