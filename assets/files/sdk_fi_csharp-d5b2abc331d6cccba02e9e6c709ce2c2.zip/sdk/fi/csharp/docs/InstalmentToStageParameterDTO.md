# It.TSEnterprise.Sdk.Model.InstalmentToStageParameterDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Numreg** | **string** |  | [optional] 
**RigacontCg42** | **int?** |  | [optional] 
**Guid** | **Guid** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

