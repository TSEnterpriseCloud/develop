# TseCloudMg.RecipientMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**areaMGMg08** | **String** | MG22_AREA_MG08 - Area | [optional] 
**cliforCg44** | **Number** | MG22_CLIFOR_CG44 - Codice cliente fornitore | 
**codAlf** | **String** | MG22_CODALF - Cod. alfanumerico | [optional] 
**codDestin** | **String** | MG22_CODDESTIN - Codice destinatario | 
**datavaliva** | **Date** | MG22_DATAVALIVA - Data fine validità | [optional] 
**destcap** | **Number** | MG22_DESTCAP - Cap | [optional] 
**destcapchar** | **String** | MG22_DESTCAPCHAR - Cap | [optional] 
**destcell** | **String** | MG22_DESTCELL - Cellulare | [optional] 
**destcitta** | **String** | MG22_DESTCITTA - Città | [optional] 
**destemail** | **String** | MG22_DESTEMAIL - Email | [optional] 
**destfax** | **String** | MG22_DESTFAX - Fax | [optional] 
**destind** | **String** | MG22_DESTIND - Indirizzo | [optional] 
**destindex** | **String** | MG22_DESTINDEX - Indirizzo esteso | [optional] 
**destnote** | **String** | MG22_DESTNOTE - Note | [optional] 
**destpec** | **String** | MG22_DESTPEC - PEC | [optional] 
**destprov** | **String** | MG22_DESTPROV - Provincia | [optional] 
**destragsoc** | **String** | MG22_DESTRAGSOC - Ragione sociale | [optional] 
**destragsocex** | **String** | MG22_DESTRAGSOCEX - Ragione sociale estesa | [optional] 
**desttel** | **String** | MG22_DESTTEL - Numero di telefono | [optional] 
**dittaCg18** | **Number** | MG22_DITTA_CG18 - Ditta | [optional] [default to 0]
**flgAppiva** | **Number** | MG22_FLGAPPIVA - FlgAppiva | 
**flgApptaxdata** | **Number** | MG22_FLGAPPTAXDATA - FlgApptaxdata&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgStetic** | **Number** | MG22_FLGSTETIC - Stampa etichette | [optional] [default to 1]
**flgTaxliable** | **Number** | MG22_FLGTAXLIABLE - FlgTaxliable&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indPrefstdoc** | **Number** | MG22_INDPREFSTDOC - Stampa pref. documento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Stampa&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Fax&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Mail&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - PEC&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Pdf&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Nessuna preferenza&lt;/li&gt;&lt;/ul&gt; | [optional] 
**macroareaMg07** | **String** | MG22_MACROAREA_MG07 - Macroarea | [optional] 
**taxexemptionno** | **String** | MG22_TAXEXEMPTIONNO - Taxexemptionno | [optional] 
**tipocfCg44** | **Number** | MG22_TIPOCF_CG44 - Tipo Cliente/Fornitore | 
**tipodestxdoc** | **Number** | MG22_TIPODESTXDOC - Dest. x doc.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Predef. Cli.&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Italia&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Estero&lt;/li&gt;&lt;/ul&gt; | [optional] 
**zonaMg09** | **String** | MG22_ZONA_MG09 -  Zona | [optional] 
**generalMasterDataCO** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | [optional] 
**nationCO** | [**NationCODTO**](NationCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgApptaxdataEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgTaxliableEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndPrefstdocEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `4` (value: `4`)

* `5` (value: `5`)

* `3` (value: `3`)





## Enum: TipodestxdocEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)




