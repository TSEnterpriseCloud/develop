# TseCloudMg.SpesaVariaMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codice** | **String** | MG04_CODICE - Codice spesa | 
**descr** | **String** | MG04_DESCR - Descrizione | [optional] 
**flgIvaincl** | **Number** | MG04_FLGIVAINCL - Importo fisso IVA inclusa&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgOramin** | **Number** | MG04_FLGORAMIN - Calcolo importo con quantità espressa in ore e minuti&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgRicfatriep** | **Number** | MG04_FLGRICFATRIEP - Forza ricalcolo importo spesa in trasformazione documenti&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgVentamm** | **Number** | MG04_FLGVENTAMM - Incrementa ammontare delle operazioni | [optional] [default to 1]
**flgVentstat** | **Number** | MG04_FLGVENTSTAT - Incrementa valore statistico | [optional] [default to 1]
**idmediaCg99** | **Number** | MG04_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**indFatriep** | **Number** | MG04_INDFATRIEP - Calc. in trasf. doc.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuna operazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Sommatoria singoli documenti (solo fatt.riep.)&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Unico importo ricalcolato (solo fatt.riep.)&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Sommatoria singoli documenti (tutti doc.)&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Unico importo ricalcolato (tutti doc.)&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Sommat. sing. doc. (tutti doc. tranne riep.)&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Unico imp. ricalc. (tutti doc. tranne riep.)&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indGesintra** | **Number** | MG04_INDGESINTRA - Modalità di gestione INTRA&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Ventilazione sulla base dell&#39;ammontare operazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuna rilevazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Rilevazione come servizio&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indRotturacorpo** | **Number** | MG04_INDROTTURACORPO - Modalità trasformazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Riporta su tutti i documenti&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Riporta solo sul primo documento&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTipoaliq** | **Number** | MG04_INDTIPOALIQ - Tipo aliquota IVA&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Aliquota fissa&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Aliquota proporzionale&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Aliquota maggiore&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Aliquota prevalente&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTipoevas** | **Number** | MG04_INDTIPOEVAS - Tipo trasf. documenti&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si trasformazione, solo la 1^ volta in automatico&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No trasformazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Si trasformazione, sempre in automatico&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Si trasformazione, solo la 1^ volta con conferma manuale&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Si trasformazione, sempre con conferma manuale&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Si trasformazione, se trasformata riga di riferimento&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTipospesa** | **Number** | MG04_INDTIPOSPESA - Tipo calcolo spesa&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Ad importo fisso&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - A percentuale fissa&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Ad importo e percentuale fissa&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - A scaglione di importo, calcolo ad importo&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - A scaglione di importo, calcolo a percentuale&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - A scaglione di importo, calcolo ad importo e perc.&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTipotot** | **Number** | MG04_INDTIPOTOT - Tipo calc. su totale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Netto merce&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Lordo merce&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Su conti merce&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Su totale fattura&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTotspese** | **Number** | MG04_INDTOTSPESE - Tot.spese su docum.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Non totalizza&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Su totale spese 1&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Su totale spese 2&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Su totale spese 3&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Su totale spese 4&lt;/li&gt;&lt;/ul&gt; | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgIvainclEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgOraminEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgRicfatriepEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndFatriepEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)





## Enum: IndGesintraEnum


* `1` (value: `1`)

* `0` (value: `0`)

* `2` (value: `2`)





## Enum: IndRotturacorpoEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndTipoaliqEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: IndTipoevasEnum


* `1` (value: `1`)

* `0` (value: `0`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)





## Enum: IndTipospesaEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)





## Enum: IndTipototEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: IndTotspeseEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)




