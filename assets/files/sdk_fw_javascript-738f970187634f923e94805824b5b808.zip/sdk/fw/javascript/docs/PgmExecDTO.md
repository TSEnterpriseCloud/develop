# TseCloudFw.PgmExecDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idTaskScheduled** | **String** | Id for Scheduled Task | 
**timeoutSeconds** | **Number** | Timeout in seconds for Scheduled Task | [optional] [default to 90]
**skipIfRunning** | **Boolean** | Skip if a task with same id is running | [optional] [default to true]


