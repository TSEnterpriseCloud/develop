# TseCloudFw.PgmExecApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiV1EnvironmentFWPgmExecPgmexecschedulerasyncPost**](PgmExecApi.md#apiV1EnvironmentFWPgmExecPgmexecschedulerasyncPost) | **POST** /api/v1/{environment}/FW/PgmExec/pgmexecschedulerasync | Schedule and Execute program



## apiV1EnvironmentFWPgmExecPgmexecschedulerasyncPost

> Object apiV1EnvironmentFWPgmExecPgmexecschedulerasyncPost(environment, authorizationScope, pgmExecDTO, opts)

Schedule and Execute program

Schedule and Execute program exe

### Example

```javascript
import TseCloudFw from 'tse_cloud_fw';
let defaultClient = TseCloudFw.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFw.PgmExecApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let pgmExecDTO = new TseCloudFw.PgmExecDTO(); // PgmExecDTO | Arguments Array List
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFWPgmExecPgmexecschedulerasyncPost(environment, authorizationScope, pgmExecDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **pgmExecDTO** | [**PgmExecDTO**](PgmExecDTO.md)| Arguments Array List | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

**Object**

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml

