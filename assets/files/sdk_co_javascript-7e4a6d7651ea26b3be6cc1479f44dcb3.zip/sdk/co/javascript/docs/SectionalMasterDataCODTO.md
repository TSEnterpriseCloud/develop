# TseCloudCo.SectionalMasterDataCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**caustcoll** | **String** | CG68_CAUSTCOLL - Causale trasporto collegata | [optional] 
**descsez** | **String** | CG68_DESCSEZ - Descrizione Sezionale | [optional] 
**dittaCg18** | **Number** | CG68_DITTA_CG18 - Ditta | 
**flgNoLiqIva** | **Number** | CG68_FLGNOLIQIVA - Escludi elaborazioni IVA&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgNoLiqIvaEnum.0]
**idagentecoll** | **Number** | CG68_IDAGENTECOLL - Agente collegato | [optional] 
**idprov** | **Number** | CG68_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**indIntra1213** | **Number** | CG68_INDINTRA1213 - Modelli INTRA 12 e INTRA 13&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - INTRA 12&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - INTRA 13&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndIntra1213Enum.0]
**indRegione** | **Number** | CG68_INDREGIONE - Regione attività&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - non specificata&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Abruzzo&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Basilicata&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Bolzano&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Calabria&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Campania&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Emilia Romagna&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Friuli Venezia Giulia&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Lazio&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Liguria&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Lombardia&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - Marche&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Molise&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Piemonte&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Puglia&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - Sardegna&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - Sicilia&lt;/li&gt;&lt;li&gt;&lt;i&gt;17&lt;/i&gt; - Toscana&lt;/li&gt;&lt;li&gt;&lt;i&gt;18&lt;/i&gt; - Trento&lt;/li&gt;&lt;li&gt;&lt;i&gt;19&lt;/i&gt; - Umbria&lt;/li&gt;&lt;li&gt;&lt;i&gt;20&lt;/i&gt; - Valle D&#39;Aosta&lt;/li&gt;&lt;li&gt;&lt;i&gt;21&lt;/i&gt; - Veneto&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndRegioneEnum.0]
**indTipologia** | **Number** | CG68_INDTIPOLOGIA - Tipologia&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Iva&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Gestionale area amministrativa&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Gestionale area commerciale&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Gestionale area amministrativa/commerciale&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Registro IVA riepilogativo&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndTipologiaEnum.0]
**puntovenCg7a** | **Number** | CG68_PUNTOVEN_CG7A - Punto vendita | [optional] 
**sezionale** | **String** | CG68_SEZIONALE - Sezionale | 
**storeCO** | [**StoreCODTO**](StoreCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgNoLiqIvaEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndIntra1213Enum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndRegioneEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)

* `10` (value: `10`)

* `11` (value: `11`)

* `12` (value: `12`)

* `13` (value: `13`)

* `14` (value: `14`)

* `15` (value: `15`)

* `16` (value: `16`)

* `17` (value: `17`)

* `18` (value: `18`)

* `19` (value: `19`)

* `20` (value: `20`)

* `21` (value: `21`)





## Enum: IndTipologiaEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)




