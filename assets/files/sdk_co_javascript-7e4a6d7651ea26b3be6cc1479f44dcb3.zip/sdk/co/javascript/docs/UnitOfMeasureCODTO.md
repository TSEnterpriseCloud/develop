# TseCloudCo.UnitOfMeasureCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descr** | **String** | CG0C_DESCR - Descrizione | [optional] 
**dittaCg18** | **Number** | CG0C_DITTA_CG18 - Ditta | 
**fattconv** | **Number** | CG0C_FATTCONV - Fattore di conversione | [optional] [default to 1]
**indOperatore** | **Number** | CG0C_INDOPERATORE - Operatore di conversione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Moltiplicazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Divisione&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndOperatoreEnum.0]
**umsigla** | **String** | CG0C_UMSIGLA - Sigla da visualizzare | 
**sigla** | [**UMCodeCODTO**](UMCodeCODTO.md) |  | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndOperatoreEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)




