# TseCloudCo.CSInfoCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**area** | **String** | MG19_AREA - Codice Area | [optional] 
**areanielsenMg0e** | **String** | MG19_AREANIELSEN_MG0E - Area Nielsen | [optional] 
**bacsaccountno** | **Number** | MG19_BACSACCOUNTNO - Codice BACS | [optional] 
**categ** | **String** | MG19_CATEG - Codice Categoria | [optional] 
**cliforCg44** | **Number** | MG19_CLIFOR_CG44 - Codice cliente | 
**codIclfatt** | **Number** | MG19_CODICLFATT - Cliente fatturazione | [optional] 
**codLivbloc** | **String** | MG19_CODLIVBLOC - Codice Blocco | [optional] 
**codRifalf** | **String** | MG19_CODRIFALF - Codice di riferimento alfanumerico | [optional] 
**codRifnum** | **Number** | MG19_CODRIFNUM - Codice di riferimento numerico | [optional] 
**codRischioMg2a** | **String** | MG19_CODRISCHIO_MG2A - Codice rischio | [optional] 
**datablocco** | **Date** | MG19_DATABLOCCO - Data blocco | [optional] 
**datacreaz** | **Date** | MG19_DATACREAZ - Data creazione | 
**datadismis** | **Date** | MG19_DATADISMIS - Data dismissione | [optional] 
**datarischio** | **Date** | MG19_DATARISCHIO - Data dell&#39;attivazione controllo rischio | [optional] 
**dataultvar** | **Date** | MG19_DATAULTVAR - Data ultima variazione | 
**dittaCg18** | **Number** | MG19_DITTA_CG18 - Ditta | 
**fidoaziendale** | **Number** | MG19_FIDOAZIENDALE - Fido aziendale | [optional] 
**fidofactoring** | **Number** | MG19_FIDOFACTORING - Importo fido assicurazione credito | [optional] 
**fidolivello1** | **Number** | MG19_FIDOLIVELLO1 - Fido liv. 1 | [optional] 
**fidolivello2** | **Number** | MG19_FIDOLIVELLO2 - Fido liv.2 | [optional] 
**finchargerterms** | **String** | MG19_FINCHARGERTERMS - Termini di addebito | [optional] 
**flgEstrpayline** | **Number** | MG19_FLGESTRPAYLINE - Estrazione Payline | 
**flgSpbol** | **Number** | MG19_FLGSPBOL - Spese bolli | 
**flgSpeinc** | **Number** | MG19_FLGSPEINC - Spese incasso | 
**flgTaxliable** | **Number** | MG19_FLGTAXLIABLE - Tax Liable | 
**idmediaCg99** | **Number** | MG19_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**indClibloc** | **Number** | MG19_INDCLIBLOC - Tipo blocco&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - senza possibilità di sblocco&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - con possibilità di sblocco&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indGesfido** | **Number** | MG19_INDGESFIDO - Indicatore gestione fido | [optional] 
**indrottcig** | **Number** | MG19_INDROTTCIG - Indrottcig&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndrottcigEnum.0]
**indSpesecum** | **Number** | MG19_INDSPESECUM - Cumulo sp.bolli/incasso | 
**irs1099** | **String** | MG19_IRS1099 - IRSS1099 Code | [optional] 
**lastchange** | **Date** | MG19_LASTCHANGE - Data ultima variazione | [optional] 
**linguaMg52** | **String** | MG19_LINGUA_MG52 - Codice lingua | [optional] 
**macroarea** | **String** | MG19_MACROAREA - Codice Macroarea | [optional] 
**macrocat** | **String** | MG19_MACROCAT - Codice Macrocategoria | [optional] 
**notebloc** | **String** | MG19_NOTEBLOC - Note blocco | [optional] 
**raggcrf3** | **String** | MG19_RAGGCRF3 - Codice raggrupamento Clienti/Fornitori 3 | [optional] 
**raggrcf1** | **String** | MG19_RAGGRCF1 - Codice raggruppamento Clienti/Fornitori 1 | [optional] 
**raggrcf2** | **String** | MG19_RAGGRCF2 - Codice raggruppamento Clienti/Fornitori 2 | [optional] 
**regimeiva** | **String** | MG19_REGIMEIVA - Regime IVA | [optional] 
**reminderterms** | **String** | MG19_REMINDERTERMS - Termini di sollecito | [optional] 
**scaglspbanc** | **Number** | MG19_SCAGLSPBANC - Codice della tabella bolli e spese incasso | [optional] 
**sottocat** | **String** | MG19_SOTTOCAT - Codice Sottocategoria | [optional] 
**taxareaNv01** | **String** | MG19_TAXAREA_NV01 - Tax area | [optional] 
**taxexemptionno** | **String** | MG19_TAXEXEMPTIONNO - USA-numero esenzione sales tax | [optional] 
**tipocfCg44** | **Number** | MG19_TIPOCF_CG44 - Tipo Cliente/ Fornitore | 
**typeofsupply** | **String** | MG19_TYPEOFSUPPLY - Tipo di fornitura | [optional] 
**zona** | **String** | MG19_ZONA - Codice Zona | [optional] 
**areaCO** | [**AreaCODTO**](AreaCODTO.md) |  | [optional] 
**categoryCO** | [**CategoryCODTO**](CategoryCODTO.md) |  | [optional] 
**grouping1CO** | [**Grouping1CODTO**](Grouping1CODTO.md) |  | [optional] 
**grouping2CO** | [**Grouping2CODTO**](Grouping2CODTO.md) |  | [optional] 
**grouping3CO** | [**Grouping3CODTO**](Grouping3CODTO.md) |  | [optional] 
**macroAreaCO** | [**MacroAreaCODTO**](MacroAreaCODTO.md) |  | [optional] 
**macroCategoryCO** | [**MacroCategoryCODTO**](MacroCategoryCODTO.md) |  | [optional] 
**subCategoryCO** | [**SubCategoryCODTO**](SubCategoryCODTO.md) |  | [optional] 
**zoneCO** | [**ZoneCODTO**](ZoneCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndCliblocEnum


* `0` (value: `0`)

* `2` (value: `2`)

* `1` (value: `1`)





## Enum: IndrottcigEnum


* `0` (value: `0`)

* `1` (value: `1`)




