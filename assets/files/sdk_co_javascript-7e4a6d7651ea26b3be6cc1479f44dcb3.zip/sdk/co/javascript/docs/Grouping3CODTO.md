# TseCloudCo.Grouping3CODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codRaggrcf3** | **String** | MG33_CODRAGGRCF3 - Raggruppamento 3 | 
**descraggrcf3** | **String** | MG33_DESCRAGGRCF3 - Descrizione | [optional] 
**dittaCg18** | **Number** | MG33_DITTA_CG18 - Ditta | [optional] [default to 0]
**idmediaCg99** | **Number** | MG33_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**idprov** | **Number** | MG33_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**tipocf** | **Number** | MG33_TIPOCF - Tipo Cli/For&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] [default to TipocfEnum.0]
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: TipocfEnum


* `0` (value: `0`)

* `1` (value: `1`)




