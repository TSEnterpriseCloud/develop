# TseCloudCo.ContactLinksCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codiceCg16** | **Number** | CO03_CODICE_CG16 - Codice anagrafica | 
**flgPref** | **Number** | CO03_FLGPREF - Preferenziale | [optional] [default to 0]
**id** | **Number** | CO03_ID - ID (Required only in PUT/PATCH) | [optional] 
**idCo02** | **Number** | CO03_ID_CO02 - Codice contatto | 
**rowversion** | **Blob** | CO03_ROWVERSION - RowVersion | [optional] 
**tipoCo01** | **String** | CO03_TIPO_CO01 - Tipo Cont./Rif. Azienda | 
**contactSubject** | [**ContactSubjectCODTO**](ContactSubjectCODTO.md) |  | 
**contactType** | [**ContactTypeCODTO**](ContactTypeCODTO.md) |  | 
**generalMasterData** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


