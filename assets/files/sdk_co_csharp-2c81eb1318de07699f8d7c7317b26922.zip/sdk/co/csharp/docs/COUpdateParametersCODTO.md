# It.TSEnterprise.Sdk.Model.COUpdateParametersCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Mg28IdsToUpdate** | **List&lt;int&gt;** |  | [optional] 
**IdIntermediario** | **double?** |  | [optional] 
**TipoPlafond** | **double** |  | [optional] 
**FlgDichivapres** | **int** |  | [optional] 
**FlgEsport** | **int** |  | [optional] 
**FlgCessintra** | **int** |  | [optional] 
**FlgCessanmarino** | **int** |  | [optional] 
**FlgOperassim** | **int** |  | [optional] 
**FlgOperstraord** | **int** |  | [optional] 
**ImpeData** | **DateTime?** |  | [optional] 
**MgflId** | **int?** |  | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

