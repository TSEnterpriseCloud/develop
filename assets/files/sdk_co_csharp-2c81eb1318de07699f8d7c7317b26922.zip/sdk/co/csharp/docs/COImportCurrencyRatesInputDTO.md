# It.TSEnterprise.Sdk.Model.COImportCurrencyRatesInputDTO
Parametri per l'importazione dei cambi valuta

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ReferenceDate** | **DateTime** |  | [optional] 
**NumberOfPreviousDays** | **int?** |  | [optional] 
**Overwrite** | **bool?** |  | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

