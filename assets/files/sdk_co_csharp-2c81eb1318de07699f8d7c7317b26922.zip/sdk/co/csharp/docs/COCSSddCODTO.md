# It.TSEnterprise.Sdk.Model.COCSSddCODTO
MG29_CLIFORRID - CSSddCO<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Bancaallineam** | **double?** | MG29_BANCAALLINEAM - Codice ABI Banca Allineamento | [optional] 
**Causrich** | **double?** | MG29_CAUSRICH - Causale richiesta Azienda | [optional] 
**Causrisp** | **double?** | MG29_CAUSRISP - Causale Banca Allineamento | [optional] 
**Cfiscsottoscr** | **string** | MG29_CFISCSOTTOSCR - Codice fiscale sottoscrittore | [optional] 
**CliforCg44** | **double** | MG29_CLIFOR_CG44 - Codice Cliente / Fornitore | 
**CodAutoriz** | **string** | MG29_CODAUTORIZ - Codice autorizzazione (Acquisizione PagoBancomat) | [optional] 
**CodBicswift** | **string** | MG29_CODBICSWIFT - Codice BIC SWIFT | [optional] 
**CodClideb** | **string** | MG29_CODCLIDEB - Codice debitore | [optional] 
**CodClidebprec** | **string** | MG29_CODCLIDEBPREC - Codice debitore precedente | [optional] 
**CodIndiv** | **double?** | MG29_CODINDIV - Codice individuale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Utenza&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Matricola&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Codice fiscale&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Codice cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Codice fornitore&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Portafoglio commerciale&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Altro&lt;/li&gt;&lt;/ul&gt; | [optional] 
**CodIndivprec** | **double?** | MG29_CODINDIVPREC - Codice individuale precedente | [optional] 
**CodRif** | **string** | MG29_CODRIF - Codice riferimento | [optional] 
**Contocorr** | **string** | MG29_CONTOCORR - Conto corrente | [optional] 
**Contocorrprec** | **string** | MG29_CONTOCORRPREC - Conto corrente precedente | [optional] 
**Datamandato** | **DateTime?** | MG29_DATAMANDATO - Data mandato RID | [optional] 
**Dataprimascad** | **DateTime?** | MG29_DATAPRIMASCAD - Data prima scadenza | [optional] 
**Datarich** | **DateTime?** | MG29_DATARICH - Data richiesta | [optional] 
**Datarisp** | **DateTime?** | MG29_DATARISP - Data causale Banca Allineamento | [optional] 
**Dataultimascad** | **DateTime?** | MG29_DATAULTIMASCAD - Data ultima scadenza | [optional] 
**Descrizione** | **string** | MG29_DESCRIZIONE - Descrizione | [optional] 
**Diniego** | **int?** | MG29_DINIEGO - Diniego | [optional] 
**DittaCg18** | **double** | MG29_DITTA_CG18 - Ditta | 
**FlgAllineam** | **double?** | MG29_FLGALLINEAM - FlgAllineam | [optional] 
**FlgDisattivato** | **int?** | MG29_FLGDISATTIVATO - Dati disattivati | [optional] 
**FlgVariato** | **double** | MG29_FLGVARIATO - Variato | 
**Id** | **int?** | MG29_ID - ID (Required only in PUT/PATCH) | [optional] 
**IdmediaCg99** | **double?** | MG29_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**Impmaxrata** | **double?** | MG29_IMPMAXRATA - Importo massimo/prefissato | [optional] 
**IndIrsottoscr** | **string** | MG29_INDIRSOTTOSCR - Indirizzo sottoscrittore | [optional] 
**IndStorno** | **double?** | MG29_INDSTORNO - Facoltà di storno&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Facoltà di storno dopo la scadenza (D+5)&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Facoltà di storno alla scadenza&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Nessuna facoltà di storno per contestazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Nessuna facoltà di storno per la banca domiciliataria&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Esiste diritto al rimborso (D+8 settimane)&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Nessuna facoltà di storno per le caratteristiche del mandato&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndStornoprec** | **double?** | MG29_INDSTORNOPREC - Facoltà di storno precedente | [optional] 
**IndTipoinc** | **int?** | MG29_INDTIPOINC - Sequenza&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - First&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Recurrent&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Final&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - One-Off&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTiposdd** | **double?** | MG29_INDTIPOSDD - Tipo SDD&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Core&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - B2B&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Locsottoscr** | **string** | MG29_LOCSOTTOSCR - Località sottoscrittore | [optional] 
**Nrrate** | **double?** | MG29_NRRATE - Numero rate | [optional] 
**Nuovabanca** | **double?** | MG29_NUOVABANCA - Nuovabanca | [optional] 
**ProgR** | **int** | MG29_PROGR - Progr. | 
**Ragsosottoscr** | **string** | MG29_RAGSOSOTTOSCR - Ragione sociale sottoscrittore | [optional] 
**Ridabi** | **double?** | MG29_RIDABI - Codice ABI | [optional] 
**Ridabiprec** | **double?** | MG29_RIDABIPREC - Codice ABI precedente | [optional] 
**Ridcab** | **double?** | MG29_RIDCAB - Codice CAB | [optional] 
**Ridcabprec** | **double?** | MG29_RIDCABPREC - Codice CAB precedente | [optional] 
**Ridiban** | **string** | MG29_RIDIBAN - IBAN | [optional] 
**Ridibanprec** | **string** | MG29_RIDIBANPREC - IBAN (International Bank Account Number) | [optional] 
**SoggtitibanCg16** | **int?** | MG29_SOGGTITIBAN_CG16 - Soggetto titolare IBAN | [optional] 
**TipocfCg44** | **double** | MG29_TIPOCF_CG44 - Tipo Cliente / Fornitore | 
**Tipoinclocked** | **double?** | MG29_TIPOINCLOCKED - Tipo seq. incasso bloccato | [optional] 
**Tipologia** | **double?** | MG29_TIPOLOGIA - Tipologia&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Consumatore&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Non Consumatore&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Microimpresa&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Tipologiaprec** | **double?** | MG29_TIPOLOGIAPREC - Tipologiaprec | [optional] 
**CsHistorySddCO** | [**List&lt;COCSHistorySddCODTO&gt;**](COCSHistorySddCODTO.md) |  | [optional] 
**NationCO** | [**CONationCODTO**](CONationCODTO.md) |  | [optional] 
**Soggtitiban** | [**COGeneralMasterDataCODTO**](COGeneralMasterDataCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

