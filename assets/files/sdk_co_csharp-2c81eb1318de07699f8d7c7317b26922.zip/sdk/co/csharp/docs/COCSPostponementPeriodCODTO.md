# It.TSEnterprise.Sdk.Model.COCSPostponementPeriodCODTO
MG21_CLIFORSALPAG - CSPostponementPeriodCO<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Ammgg** | **double** | MG21_AMMGG - A gg/mm | 
**CliforCg44** | **double** | MG21_CLIFOR_CG44 - Codice Cliente / Fornitore | 
**Dammgg** | **double** | MG21_DAMMGG - Da gg/mm | 
**DittaCg18** | **double** | MG21_DITTA_CG18 - DittaCg18 | 
**Ggmmfixslit** | **double?** | MG21_GGMMFIXSLIT - gg/mm scad. | [optional] 
**Ggslsucc** | **double?** | MG21_GGSLSUCC - gg slittamento scad. successiva | [optional] 
**Id** | **long?** | MG21_ID - Id (Required only in PUT/PATCH) | [optional] 
**IdmediaCg99** | **double?** | MG21_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**IndAppggfix** | **int?** | MG21_INDAPPGGFIX - IndAppggfix | [optional] 
**IndTiposlit** | **double?** | MG21_INDTIPOSLIT - Tipo slittamento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - 1° giorno dopo limite superiore&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - 1° giorno mese successivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Stesso giorno scadenza al mese successivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Giorno fisso&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Somma alla rata del mese successivo&lt;/li&gt;&lt;/ul&gt; | [optional] 
**TipocfCg44** | **double** | MG21_TIPOCF_CG44 - Tipo Cliente / Fornitore | 
**Tipoeff** | **double?** | MG21_TIPOEFF - Tipo effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Contrassegno&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Leasing&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Lettera di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - MAV&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Ricevuta bancaria&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - SDD&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Rimessa diretta&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Tratta&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Tratta accettata&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Bancomat&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Bonifico Bancario&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Cambiale&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Carta di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - C/C postale&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Cessione&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Contanti&lt;/li&gt;&lt;/ul&gt; | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

