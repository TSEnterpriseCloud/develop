# It.TSEnterprise.Sdk.Model.ExchangeRateCODTO
CG09_TABCAMBI - ExchangeRateCO<br>Proprietà chiave:<ul><li><b>Anno</b></li><li><b>CodiceCg08</b></li><li><b>CodicerifCg08</b></li><li><b>Giorno</b></li><li><b>Mese</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Adegcambio** | **double?** | CG09_ADEGCAMBIO -  Cambio UIC Annuale | [optional] 
**Anno** | **double** | CG09_ANNO - Anno | 
**Cambio** | **double?** | CG09_CAMBIO - Cambio | [optional] 
**CodiceCg08** | **string** | CG09_CODICE_CG08 - Codice valuta | 
**CodicerifCg08** | **string** | CG09_CODICERIF_CG08 - CodicerifCg08 | 
**Giorno** | **double** | CG09_GIORNO - Giorno | 
**IdmediaCg99** | **double?** | CG09_IDMEDIA_CG99 - Hypermedia | [optional] 
**IndCertoincerto** | **int** | CG09_INDCERTOINCERTO - Cambio incerto per certo | 
**Mese** | **double** | CG09_MESE - Mese | 
**Rowversion** | **byte[]** | CG09_ROWVERSION - RowVersion | [optional] 
**CurrencyCO** | [**CurrencyCODTO**](CurrencyCODTO.md) |  | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

