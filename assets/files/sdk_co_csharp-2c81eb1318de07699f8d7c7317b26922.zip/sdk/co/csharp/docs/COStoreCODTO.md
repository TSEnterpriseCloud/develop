# It.TSEnterprise.Sdk.Model.COStoreCODTO
CG7A_PUNTIVENDITA - StoreCO<br>Proprietà chiave:<ul><li><b>DittaCg18</b></li><li><b>Puntoven</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Descrizione** | **string** | CG7A_DESCRIZIONE - Descrizione | [optional] 
**DittaCg18** | **double** | CG7A_DITTA_CG18 - Ditta | 
**Puntoven** | **double** | CG7A_PUNTOVEN - Puntoven | 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

