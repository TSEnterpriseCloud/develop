# It.TSEnterprise.Sdk.Model.COCustomerSupplierCODTO
CG44_CLIFOR - Cliente fornitore<br>Proprietà chiave:<ul><li><b>Idclifor</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**GmdUpdateAdditionalParams** | [**COGMDUpdateAdditionalParametersDTO**](COGMDUpdateAdditionalParametersDTO.md) |  | [optional] 
**Clifor** | **double** | CG44_CLIFOR - Codice cli/for | 
**CodAbiCg12** | **double?** | CG44_CODABI_CG12 - Codice banca | [optional] 
**CodCabCg13** | **double?** | CG44_CODCAB_CG13 - Codice agenzia | [optional] 
**CodiceCg28** | **string** | CG44_CODICE_CG28 - Codice aliquota IVA | [optional] 
**ContoCg24** | **string** | CG44_CONTO_CG24 - Conto merci | [optional] 
**ContorCg24** | **string** | CG44_CONTOR_CG24 - Conto merci reso | [optional] 
**Contratto** | **string** | CG44_CONTRATTO - Codice contratto | [optional] 
**Datavaliva** | **DateTime?** | CG44_DATAVALIVA - Fine validità codice IVA | [optional] 
**DittaCg18** | **double** | CG44_DITTA_CG18 - Ditta | 
**FlgArt62** | **int?** | CG44_FLGART62 - Flag Art. 62 | [optional] 
**FlgAttivo** | **double?** | CG44_FLGATTIVO - Attivo | [optional] 
**FlgCointestati** | **double?** | CG44_FLGCOINTESTATI - Cointestati | [optional] 
**FlgIntercompany** | **double?** | CG44_FLGINTERCOMPANY - Gest. Intercompany | [optional] 
**Ggscadfix** | **double?** | CG44_GGSCADFIX - GG scad. fix | [optional] 
**GruppoCg10** | **double?** | CG44_GRUPPO_CG10 - Codice Pdc | [optional] 
**Guid** | **Guid?** | CG44_GUID - GUID | [optional] 
**Idclifor** | **int?** | CG44_IDCLIFOR - ID cliente (Required only in PUT/PATCH) | [optional] 
**IdmediaCg99** | **double?** | CG44_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**IndElenchimov3000** | **int?** | CG44_INDELENCHIMOV3000 - Ind. gestione elenchi mov. 3.000€&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;99&lt;/i&gt; - Come da anag. generale&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Contratto &gt;&#x3D; 3.000€&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Contratto corrisp. periodici&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IntermedioCg40** | **double?** | CG44_INTERMEDIO_CG40 - Codice intermedio | [optional] 
**Lastchange** | **DateTime?** | CG44_LASTCHANGE - Data ultima variazione | [optional] 
**ProgREf08** | **double?** | CG44_PROGR_EF08 - Codice banca aziendale | [optional] 
**Tipocf** | **double?** | CG44_TIPOCF - Tipo Cliente / Fornitore&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IdExtendedAttributeEntity** | **int** |  | [optional] 
**IdExtendedAttributeSubEntity** | **int** |  | [optional] 
**AgentCO** | [**COAgentCODTO**](COAgentCODTO.md) |  | [optional] 
**BlackListGeneralMasterData** | [**COGeneralMasterDataCODTO**](COGeneralMasterDataCODTO.md) |  | [optional] 
**CsAccountingIndexCO** | [**COCSAccountingIndexCODTO**](COCSAccountingIndexCODTO.md) |  | [optional] 
**CsBankCO** | [**List&lt;COCSBankCODTO&gt;**](COCSBankCODTO.md) |  | [optional] 
**CsCompanyBankCO** | [**List&lt;COCSCompanyBankCODTO&gt;**](COCSCompanyBankCODTO.md) |  | [optional] 
**CsInfoCO** | [**COCSInfoCODTO**](COCSInfoCODTO.md) |  | [optional] 
**CsJointlyHeldCO** | [**List&lt;COCSJointlyHeldCODTO&gt;**](COCSJointlyHeldCODTO.md) |  | [optional] 
**CsPaymentRangeCO** | [**List&lt;COCSPaymentRangeCODTO&gt;**](COCSPaymentRangeCODTO.md) |  | [optional] 
**CsPostponementPeriodCO** | [**List&lt;COCSPostponementPeriodCODTO&gt;**](COCSPostponementPeriodCODTO.md) |  | [optional] 
**CsSddCO** | [**List&lt;COCSSddCODTO&gt;**](COCSSddCODTO.md) |  | [optional] 
**CurrencyCO** | [**COCurrencyCODTO**](COCurrencyCODTO.md) |  | [optional] 
**CustomerSupplierCIGCUPCO** | [**List&lt;COCustomerSupplierCIGCUPCODTO&gt;**](COCustomerSupplierCIGCUPCODTO.md) |  | [optional] 
**CustSupplDataInvoicePACO** | [**COCustSupplDataInvoicePACODTO**](COCustSupplDataInvoicePACODTO.md) |  | [optional] 
**DmsPublishedEntityFW** | [**CODMSPublishedEntityFWDTO**](CODMSPublishedEntityFWDTO.md) |  | 
**GeneralMasterDataCO** | [**COGeneralMasterDataCODTO**](COGeneralMasterDataCODTO.md) |  | 
**OfficeCO** | [**COOfficeCODTO**](COOfficeCODTO.md) |  | [optional] 
**OfficePACO** | [**List&lt;COOfficePACODTO&gt;**](COOfficePACODTO.md) |  | [optional] 
**PaymentTermCO** | [**COPaymentTermCODTO**](COPaymentTermCODTO.md) |  | [optional] 
**VatCodeCO** | [**COVatCodeCODTO**](COVatCodeCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

