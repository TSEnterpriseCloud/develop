# It.TSEnterprise.Sdk.Model.COPaymentTermDetailCODTO
CG63_CONDPAGDET - PaymentTermDetailCO<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Aggfix1** | **double?** | CG63_AGGFIX1 - Aggfix1 | [optional] 
**Aggfix2** | **double?** | CG63_AGGFIX2 - Aggfix2 | [optional] 
**CodPagCg62** | **string** | CG63_CODPAG_CG62 - CodPagCg62 | 
**Daggfix1** | **double?** | CG63_DAGGFIX1 - Daggfix1 | [optional] 
**Daggfix2** | **double?** | CG63_DAGGFIX2 - Daggfix2 | [optional] 
**El1frimp** | **double?** | CG63_EL1FRIMP -  Num. | [optional] 
**El1friva** | **double?** | CG63_EL1FRIVA -  Num. | [optional] 
**El2frimp** | **double?** | CG63_EL2FRIMP - Den. | [optional] 
**El2friva** | **double?** | CG63_EL2FRIVA - Den. | [optional] 
**FlgFrpercimp** | **double?** | CG63_FLGFRPERCIMP - Fr./% imp.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Percentuale&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Frazione&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgFrperciva** | **double?** | CG63_FLGFRPERCIVA - Fr./% iva.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Percentuale&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Frazione&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Ggdecor** | **double?** | CG63_GGDECOR - gg dec. | [optional] 
**Ggmmfix** | **double?** | CG63_GGMMFIX - Ggmmfix | [optional] 
**Ggscadfix1** | **double?** | CG63_GGSCADFIX1 - Ggscadfix1 | [optional] 
**Ggscadfix2** | **double?** | CG63_GGSCADFIX2 - Ggscadfix2 | [optional] 
**Id** | **long?** | CG63_ID - Id (Required only in PUT/PATCH) | [optional] 
**IdCg62** | **long** | CG63_ID_CG62 - IdCg62 | 
**IdCg64** | **long?** | CG63_ID_CG64 - IdCg64 | [optional] 
**Imporfix** | **double?** | CG63_IMPORFIX - Imporfix | [optional] 
**IndDatarif** | **double?** | CG63_INDDATARIF - Rif. decorrenza&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Data fattura&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Data Bolla&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Data consegna&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Data ordine&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Data a richiesta&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Data fattura (+GG |-&gt; fine mese)&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Data fattura (|-&gt; fine mese + GG)&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndImpfix** | **double?** | CG63_INDIMPFIX - IndImpfix&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Non gestito&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Da condizione di pagamento&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Rich . nel doc. d&#39;origine&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTipocalend** | **int?** | CG63_INDTIPOCALEND - IndTipocalend&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Commerciale&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Civile&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTipodecor** | **double?** | CG63_INDTIPODECOR - Tipo decorrenza&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Mese commerciale / civile&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Giorno fisso&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Data fissa&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Giorno fisso per int. di gg&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Percimp** | **double?** | CG63_PERCIMP - % Imp. | [optional] 
**Perciva** | **double?** | CG63_PERCIVA - % IVA | [optional] 
**Prog** | **double** | CG63_PROG - Rata | 
**Rowversion** | **byte[]** | CG63_ROWVERSION - RowVersion | [optional] 
**Tipoeff** | **double?** | CG63_TIPOEFF - Tipo effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Contrassegno&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Leasing&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Lettera di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - MAV&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Ricevuta bancaria&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - SDD&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Rimessa diretta&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Tratta&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Tratta accettata&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Bancomat&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Bonifico Bancario&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Cambiale&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Carta di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - C/C postale&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Cessione&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Contanti&lt;/li&gt;&lt;/ul&gt; | [optional] 
**SubTypeCO** | [**COSubTypeCODTO**](COSubTypeCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

