# It.TSEnterprise.Sdk.Model.COCustSupplDataInvoicePACODTO
CG1O_DATIGESTANAG - CustSupplDataInvoicePACO<br>Proprietà chiave:<ul><li><b>CodiceCg16</b></li><li><b>TipocfCg44</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodiceCg16** | **int** | CG1O_CODICE_CG16 - CodiceCg16 | 
**Emailcortesia** | **string** | CG1O_EMAILCORTESIA - Emailcortesia | [optional] 
**FlgAsw** | **int** | CG1O_FLGASW - FlgAsw | 
**IndTypeb2b** | **int** | CG1O_INDTYPEB2B - IndTypeb2b | 
**TipocfCg44** | **double** | CG1O_TIPOCF_CG44 - TipocfCg44 | 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

