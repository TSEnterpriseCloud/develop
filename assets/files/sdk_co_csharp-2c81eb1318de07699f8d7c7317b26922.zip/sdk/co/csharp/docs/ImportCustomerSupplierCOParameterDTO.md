# It.TSEnterprise.Sdk.Model.ImportCustomerSupplierCOParameterDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AddParameters** | [**ImportCustomerSupplierCOAddParameterDTO**](ImportCustomerSupplierCOAddParameterDTO.md) |  | [optional] 
**IsAsyncMode** | **bool** | Asynchronous processing | [optional] [default to false]
**CodLayout** | **string** | Code Layout | 
**StreamFileImport** | **string** | Stream File Import | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

