# It.TSEnterprise.Sdk.Model.ExportCustomerSupplierCOParameterDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AddParameters** | [**ExportCustomerSupplierCOAddParameterDTO**](ExportCustomerSupplierCOAddParameterDTO.md) |  | [optional] 
**IsAsyncMode** | **bool** | Asynchronous processing | [optional] [default to false]
**CodLayout** | **string** | Code Layout | 
**SearchFilter** | [**SearchDTO**](SearchDTO.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

