# It.TSEnterprise.Sdk.Model.COPaymentTermDuplicationParametersCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SourcePaymentTermId** | **long** |  | [optional] 
**TargetPaymentTermCode** | **string** |  | [optional] 
**TargetPaymentTermCodeDescription** | **string** |  | [optional] 
**IsDuplLangDescriptions** | **bool** |  | [optional] 
**IsDuplExtendedAttribute** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

