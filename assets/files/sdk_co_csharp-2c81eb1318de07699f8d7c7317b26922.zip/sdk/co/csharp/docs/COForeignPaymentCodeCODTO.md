# It.TSEnterprise.Sdk.Model.COForeignPaymentCodeCODTO
CG6D_CODPAGEXPMAN - ForeignPaymentCodeCO<br>Proprietà chiave:<ul><li><b>Codice</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codice** | **string** | CG6D_CODICE - Codice | 
**CodIso** | **string** | CG6D_CODISO - Codice ISO | [optional] 
**Descrpag** | **string** | CG6D_DESCRPAG - Descrizione | [optional] 
**FlgIbanobbl** | **int?** | CG6D_FLGIBANOBBL - IBAN | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

