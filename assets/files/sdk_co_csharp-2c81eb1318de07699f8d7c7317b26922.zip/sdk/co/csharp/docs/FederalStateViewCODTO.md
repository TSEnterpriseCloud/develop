# It.TSEnterprise.Sdk.Model.FederalStateViewCODTO
VCG1S_STATIFED - FederalStateViewCO<br>Proprietà chiave:<ul><li><b>CodiceCg07</b></li><li><b>Statofed</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**A2iso3166Cg07** | **string** | VCG1S_A2ISO3166_CG07 - A2iso3166Cg07 | 
**CodiceCg07** | **double** | VCG1S_CODICE_CG07 - Codice Stato | 
**Descr** | **string** | VCG1S_DESCR - Descrizione | [optional] 
**Iso3166statofed** | **string** | VCG1S_ISO3166STATOFED - Country ISO 3166 | [optional] 
**Statofed** | **string** | VCG1S_STATOFED - Stato federato | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

