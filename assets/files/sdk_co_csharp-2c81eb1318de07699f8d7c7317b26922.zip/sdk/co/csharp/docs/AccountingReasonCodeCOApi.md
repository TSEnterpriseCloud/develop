# It.TSEnterprise.Sdk.Api.AccountingReasonCodeCOApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**ApiV1EnvironmentCOAccountingReasonCodeCOGet**](AccountingReasonCodeCOApi.md#apiv1environmentcoaccountingreasoncodecoget) | **GET** /api/v1/{environment}/CO/AccountingReasonCodeCO | Get new |
| [**ApiV1EnvironmentCOAccountingReasonCodeCOIdGet**](AccountingReasonCodeCOApi.md#apiv1environmentcoaccountingreasoncodecoidget) | **GET** /api/v1/{environment}/CO/AccountingReasonCodeCO/{id} | Get by ID |
| [**ApiV1EnvironmentCOAccountingReasonCodeCOReadPost**](AccountingReasonCodeCOApi.md#apiv1environmentcoaccountingreasoncodecoreadpost) | **POST** /api/v1/{environment}/CO/AccountingReasonCodeCO/read | Read |
| [**ApiV1EnvironmentCOAccountingReasonCodeCOSearchPost**](AccountingReasonCodeCOApi.md#apiv1environmentcoaccountingreasoncodecosearchpost) | **POST** /api/v1/{environment}/CO/AccountingReasonCodeCO/search | Search |
| [**ApiV1EnvironmentCOAccountingReasonCodeCOValidatePost**](AccountingReasonCodeCOApi.md#apiv1environmentcoaccountingreasoncodecovalidatepost) | **POST** /api/v1/{environment}/CO/AccountingReasonCodeCO/validate | Validate |
| [**ApiV1EnvironmentCOAccountingReasonCodeCOValidatePropertiesPost**](AccountingReasonCodeCOApi.md#apiv1environmentcoaccountingreasoncodecovalidatepropertiespost) | **POST** /api/v1/{environment}/CO/AccountingReasonCodeCO/validateProperties | Validation of one on more properties of Type |

<a id="apiv1environmentcoaccountingreasoncodecoget"></a>
# **ApiV1EnvironmentCOAccountingReasonCodeCOGet**
> AccountingReasonCodeCODTO ApiV1EnvironmentCOAccountingReasonCodeCOGet (string op, string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null)

Get new

Get an empty object of type corresponding

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOAccountingReasonCodeCOGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new AccountingReasonCodeCOApi(config);
            var op = "op_example";  // string | The value must be 'new'
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get new
                AccountingReasonCodeCODTO result = apiInstance.ApiV1EnvironmentCOAccountingReasonCodeCOGet(op, environment, authorizationScope, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling AccountingReasonCodeCOApi.ApiV1EnvironmentCOAccountingReasonCodeCOGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOAccountingReasonCodeCOGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get new
    ApiResponse<AccountingReasonCodeCODTO> response = apiInstance.ApiV1EnvironmentCOAccountingReasonCodeCOGetWithHttpInfo(op, environment, authorizationScope, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling AccountingReasonCodeCOApi.ApiV1EnvironmentCOAccountingReasonCodeCOGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **op** | **string** | The value must be &#39;new&#39; |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**AccountingReasonCodeCODTO**](AccountingReasonCodeCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The empty object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentcoaccountingreasoncodecoidget"></a>
# **ApiV1EnvironmentCOAccountingReasonCodeCOIdGet**
> AccountingReasonCodeCODTO ApiV1EnvironmentCOAccountingReasonCodeCOIdGet (string id, string environment, string authorizationScope, string? dlevel = null, string? dlevelkey = null, string? company = null, string? user = null, string? acceptLanguage = null)

Get by ID

Get an object of type corresponding the requested id

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOAccountingReasonCodeCOIdGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new AccountingReasonCodeCOApi(config);
            var id = "id_example";  // string | Id to get the object
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var dlevel = "dlevel_example";  // string? | Serialization level (optional) 
            var dlevelkey = "dlevelkey_example";  // string? | Serialization level key (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get by ID
                AccountingReasonCodeCODTO result = apiInstance.ApiV1EnvironmentCOAccountingReasonCodeCOIdGet(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling AccountingReasonCodeCOApi.ApiV1EnvironmentCOAccountingReasonCodeCOIdGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOAccountingReasonCodeCOIdGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get by ID
    ApiResponse<AccountingReasonCodeCODTO> response = apiInstance.ApiV1EnvironmentCOAccountingReasonCodeCOIdGetWithHttpInfo(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling AccountingReasonCodeCOApi.ApiV1EnvironmentCOAccountingReasonCodeCOIdGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** | Id to get the object |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **dlevel** | **string?** | Serialization level | [optional]  |
| **dlevelkey** | **string?** | Serialization level key | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**AccountingReasonCodeCODTO**](AccountingReasonCodeCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentcoaccountingreasoncodecoreadpost"></a>
# **ApiV1EnvironmentCOAccountingReasonCodeCOReadPost**
> AccountingReasonCodeCODTO ApiV1EnvironmentCOAccountingReasonCodeCOReadPost (string environment, string authorizationScope, List<SearchElementDTO> searchElementDTO, string? dlevel = null, string? dlevelkey = null, string? company = null, string? user = null, string? acceptLanguage = null)

Read

Read among object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOAccountingReasonCodeCOReadPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new AccountingReasonCodeCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var searchElementDTO = new List<SearchElementDTO>(); // List<SearchElementDTO> | Search criteria to apply
            var dlevel = "dlevel_example";  // string? | Serialization level (optional) 
            var dlevelkey = "dlevelkey_example";  // string? | Serialization level key (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Read
                AccountingReasonCodeCODTO result = apiInstance.ApiV1EnvironmentCOAccountingReasonCodeCOReadPost(environment, authorizationScope, searchElementDTO, dlevel, dlevelkey, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling AccountingReasonCodeCOApi.ApiV1EnvironmentCOAccountingReasonCodeCOReadPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOAccountingReasonCodeCOReadPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Read
    ApiResponse<AccountingReasonCodeCODTO> response = apiInstance.ApiV1EnvironmentCOAccountingReasonCodeCOReadPostWithHttpInfo(environment, authorizationScope, searchElementDTO, dlevel, dlevelkey, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling AccountingReasonCodeCOApi.ApiV1EnvironmentCOAccountingReasonCodeCOReadPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **searchElementDTO** | [**List&lt;SearchElementDTO&gt;**](SearchElementDTO.md) | Search criteria to apply |  |
| **dlevel** | **string?** | Serialization level | [optional]  |
| **dlevelkey** | **string?** | Serialization level key | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**AccountingReasonCodeCODTO**](AccountingReasonCodeCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentcoaccountingreasoncodecosearchpost"></a>
# **ApiV1EnvironmentCOAccountingReasonCodeCOSearchPost**
> AccountingReasonCodeCODTO ApiV1EnvironmentCOAccountingReasonCodeCOSearchPost (string environment, string authorizationScope, SearchDTO searchDTO, string? loadEntireDomain = null, string? gettotalcount = null, string? company = null, string? user = null, string? acceptLanguage = null)

Search

Search among object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOAccountingReasonCodeCOSearchPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new AccountingReasonCodeCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var searchDTO = new SearchDTO(); // SearchDTO | Search criteria to apply
            var loadEntireDomain = "loadEntireDomain_example";  // string? | Specify 'loadEntireDomain=true' if you want all the aggregate (optional) 
            var gettotalcount = "gettotalcount_example";  // string? | Specify 'gettotalcount=true' if you want the total number of elements (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Search
                AccountingReasonCodeCODTO result = apiInstance.ApiV1EnvironmentCOAccountingReasonCodeCOSearchPost(environment, authorizationScope, searchDTO, loadEntireDomain, gettotalcount, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling AccountingReasonCodeCOApi.ApiV1EnvironmentCOAccountingReasonCodeCOSearchPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOAccountingReasonCodeCOSearchPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Search
    ApiResponse<AccountingReasonCodeCODTO> response = apiInstance.ApiV1EnvironmentCOAccountingReasonCodeCOSearchPostWithHttpInfo(environment, authorizationScope, searchDTO, loadEntireDomain, gettotalcount, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling AccountingReasonCodeCOApi.ApiV1EnvironmentCOAccountingReasonCodeCOSearchPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **searchDTO** | [**SearchDTO**](SearchDTO.md) | Search criteria to apply |  |
| **loadEntireDomain** | **string?** | Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate | [optional]  |
| **gettotalcount** | **string?** | Specify &#39;gettotalcount&#x3D;true&#39; if you want the total number of elements | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**AccountingReasonCodeCODTO**](AccountingReasonCodeCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The list of object of type as result of search |  -  |
| **400** | If the search criteria is not supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentcoaccountingreasoncodecovalidatepost"></a>
# **ApiV1EnvironmentCOAccountingReasonCodeCOValidatePost**
> void ApiV1EnvironmentCOAccountingReasonCodeCOValidatePost (string environment, string authorizationScope, AccountingReasonCodeCODTO accountingReasonCodeCODTO, string? company = null, string? user = null, string? acceptLanguage = null)

Validate

Validation of object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOAccountingReasonCodeCOValidatePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new AccountingReasonCodeCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var accountingReasonCodeCODTO = new AccountingReasonCodeCODTO(); // AccountingReasonCodeCODTO | Object of type to validate
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Validate
                apiInstance.ApiV1EnvironmentCOAccountingReasonCodeCOValidatePost(environment, authorizationScope, accountingReasonCodeCODTO, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling AccountingReasonCodeCOApi.ApiV1EnvironmentCOAccountingReasonCodeCOValidatePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOAccountingReasonCodeCOValidatePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Validate
    apiInstance.ApiV1EnvironmentCOAccountingReasonCodeCOValidatePostWithHttpInfo(environment, authorizationScope, accountingReasonCodeCODTO, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling AccountingReasonCodeCOApi.ApiV1EnvironmentCOAccountingReasonCodeCOValidatePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **accountingReasonCodeCODTO** | [**AccountingReasonCodeCODTO**](AccountingReasonCodeCODTO.md) | Object of type to validate |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object is VALID: the content response does NOT contain validation messages |  -  |
| **400** | If no object to validate was supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object is NOT VALID: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentcoaccountingreasoncodecovalidatepropertiespost"></a>
# **ApiV1EnvironmentCOAccountingReasonCodeCOValidatePropertiesPost**
> ValidateDTO ApiV1EnvironmentCOAccountingReasonCodeCOValidatePropertiesPost (string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null, string? body = null)

Validation of one on more properties of Type

Validation of object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOAccountingReasonCodeCOValidatePropertiesPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new AccountingReasonCodeCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)
            var body = null;  // string? |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br> (optional) 

            try
            {
                // Validation of one on more properties of Type
                ValidateDTO result = apiInstance.ApiV1EnvironmentCOAccountingReasonCodeCOValidatePropertiesPost(environment, authorizationScope, company, user, acceptLanguage, body);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling AccountingReasonCodeCOApi.ApiV1EnvironmentCOAccountingReasonCodeCOValidatePropertiesPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOAccountingReasonCodeCOValidatePropertiesPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Validation of one on more properties of Type
    ApiResponse<ValidateDTO> response = apiInstance.ApiV1EnvironmentCOAccountingReasonCodeCOValidatePropertiesPostWithHttpInfo(environment, authorizationScope, company, user, acceptLanguage, body);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling AccountingReasonCodeCOApi.ApiV1EnvironmentCOAccountingReasonCodeCOValidatePropertiesPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |
| **body** | **string?** |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED&lt;br&gt; - The id of an existing object to validate properties, or &#39;&#39; if the object does not exist yet &lt;br&gt; | [optional]  |

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object is VALID: the content response does NOT contain validation messages |  -  |
| **400** | If no object to validate was supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object is NOT VALID: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

