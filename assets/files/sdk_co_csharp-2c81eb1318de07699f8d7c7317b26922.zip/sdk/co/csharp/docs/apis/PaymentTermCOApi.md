# It.TSEnterprise.Sdk.Api.PaymentTermCOApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**ApiV1EnvironmentCOPaymentTermCOCalculateSumPost**](PaymentTermCOApi.md#apiv1environmentcopaymenttermcocalculatesumpost) | **POST** /api/v1/{environment}/CO/PaymentTermCO/calculate_sum | Calculate the sum of the percentages |
| [**ApiV1EnvironmentCOPaymentTermCOGet**](PaymentTermCOApi.md#apiv1environmentcopaymenttermcoget) | **GET** /api/v1/{environment}/CO/PaymentTermCO | Get new |
| [**ApiV1EnvironmentCOPaymentTermCOGetFromCodePost**](PaymentTermCOApi.md#apiv1environmentcopaymenttermcogetfromcodepost) | **POST** /api/v1/{environment}/CO/PaymentTermCO/get_from_code | Retrieve the payment term from code |
| [**ApiV1EnvironmentCOPaymentTermCOIdDelete**](PaymentTermCOApi.md#apiv1environmentcopaymenttermcoiddelete) | **DELETE** /api/v1/{environment}/CO/PaymentTermCO/{id} | Delete |
| [**ApiV1EnvironmentCOPaymentTermCOIdGet**](PaymentTermCOApi.md#apiv1environmentcopaymenttermcoidget) | **GET** /api/v1/{environment}/CO/PaymentTermCO/{id} | Get by ID |
| [**ApiV1EnvironmentCOPaymentTermCOIdPatch**](PaymentTermCOApi.md#apiv1environmentcopaymenttermcoidpatch) | **PATCH** /api/v1/{environment}/CO/PaymentTermCO/{id} | Update partial |
| [**ApiV1EnvironmentCOPaymentTermCOIdPut**](PaymentTermCOApi.md#apiv1environmentcopaymenttermcoidput) | **PUT** /api/v1/{environment}/CO/PaymentTermCO/{id} | Update |
| [**ApiV1EnvironmentCOPaymentTermCOPaymentTermDuplicationPost**](PaymentTermCOApi.md#apiv1environmentcopaymenttermcopaymenttermduplicationpost) | **POST** /api/v1/{environment}/CO/PaymentTermCO/PaymentTermDuplication | Duplication of Payment Term |
| [**ApiV1EnvironmentCOPaymentTermCOPost**](PaymentTermCOApi.md#apiv1environmentcopaymenttermcopost) | **POST** /api/v1/{environment}/CO/PaymentTermCO | Create |
| [**ApiV1EnvironmentCOPaymentTermCOReadPost**](PaymentTermCOApi.md#apiv1environmentcopaymenttermcoreadpost) | **POST** /api/v1/{environment}/CO/PaymentTermCO/read | Read |
| [**ApiV1EnvironmentCOPaymentTermCOSearchPost**](PaymentTermCOApi.md#apiv1environmentcopaymenttermcosearchpost) | **POST** /api/v1/{environment}/CO/PaymentTermCO/search | Search |
| [**ApiV1EnvironmentCOPaymentTermCOValidatePost**](PaymentTermCOApi.md#apiv1environmentcopaymenttermcovalidatepost) | **POST** /api/v1/{environment}/CO/PaymentTermCO/validate | Validate |
| [**ApiV1EnvironmentCOPaymentTermCOValidatePropertiesPost**](PaymentTermCOApi.md#apiv1environmentcopaymenttermcovalidatepropertiespost) | **POST** /api/v1/{environment}/CO/PaymentTermCO/validateProperties | Validation of one on more properties of Type |

<a id="apiv1environmentcopaymenttermcocalculatesumpost"></a>
# **ApiV1EnvironmentCOPaymentTermCOCalculateSumPost**
> PaymentTermDetailCalculationResultCODTO ApiV1EnvironmentCOPaymentTermCOCalculateSumPost (string environment, string authorizationScope, PaymentTermDetailCOParametersDTO paymentTermDetailCOParametersDTO, string company = null, string user = null, string acceptLanguage = null)

Calculate the sum of the percentages

Calculate the sum of the percentages

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOPaymentTermCOCalculateSumPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new PaymentTermCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var paymentTermDetailCOParametersDTO = new PaymentTermDetailCOParametersDTO(); // PaymentTermDetailCOParametersDTO | Parameters of the request
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Calculate the sum of the percentages
                PaymentTermDetailCalculationResultCODTO result = apiInstance.ApiV1EnvironmentCOPaymentTermCOCalculateSumPost(environment, authorizationScope, paymentTermDetailCOParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOCalculateSumPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOPaymentTermCOCalculateSumPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Calculate the sum of the percentages
    ApiResponse<PaymentTermDetailCalculationResultCODTO> response = apiInstance.ApiV1EnvironmentCOPaymentTermCOCalculateSumPostWithHttpInfo(environment, authorizationScope, paymentTermDetailCOParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOCalculateSumPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **paymentTermDetailCOParametersDTO** | [**PaymentTermDetailCOParametersDTO**](PaymentTermDetailCOParametersDTO.md) | Parameters of the request |  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**PaymentTermDetailCalculationResultCODTO**](PaymentTermDetailCalculationResultCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If operation was made |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentcopaymenttermcoget"></a>
# **ApiV1EnvironmentCOPaymentTermCOGet**
> PaymentTermCODTO ApiV1EnvironmentCOPaymentTermCOGet (string op, string environment, string authorizationScope, string company = null, string user = null, string acceptLanguage = null)

Get new

Get an empty object of type corresponding

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOPaymentTermCOGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new PaymentTermCOApi(config);
            var op = "op_example";  // string | The value must be 'new'
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get new
                PaymentTermCODTO result = apiInstance.ApiV1EnvironmentCOPaymentTermCOGet(op, environment, authorizationScope, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOPaymentTermCOGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get new
    ApiResponse<PaymentTermCODTO> response = apiInstance.ApiV1EnvironmentCOPaymentTermCOGetWithHttpInfo(op, environment, authorizationScope, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **op** | **string** | The value must be &#39;new&#39; |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**PaymentTermCODTO**](PaymentTermCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The empty object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentcopaymenttermcogetfromcodepost"></a>
# **ApiV1EnvironmentCOPaymentTermCOGetFromCodePost**
> PaymentTermCODTO ApiV1EnvironmentCOPaymentTermCOGetFromCodePost (string environment, string authorizationScope, CodePaymentTermCOParametersDTO codePaymentTermCOParametersDTO, string company = null, string user = null, string acceptLanguage = null)

Retrieve the payment term from code

Retrieve the payment term from code

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOPaymentTermCOGetFromCodePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new PaymentTermCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var codePaymentTermCOParametersDTO = new CodePaymentTermCOParametersDTO(); // CodePaymentTermCOParametersDTO | Input parameters
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Retrieve the payment term from code
                PaymentTermCODTO result = apiInstance.ApiV1EnvironmentCOPaymentTermCOGetFromCodePost(environment, authorizationScope, codePaymentTermCOParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOGetFromCodePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOPaymentTermCOGetFromCodePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Retrieve the payment term from code
    ApiResponse<PaymentTermCODTO> response = apiInstance.ApiV1EnvironmentCOPaymentTermCOGetFromCodePostWithHttpInfo(environment, authorizationScope, codePaymentTermCOParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOGetFromCodePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **codePaymentTermCOParametersDTO** | [**CodePaymentTermCOParametersDTO**](CodePaymentTermCOParametersDTO.md) | Input parameters |  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**PaymentTermCODTO**](PaymentTermCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If operation was made |  -  |
| **400** | In case of incorrect parameters in the request |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentcopaymenttermcoiddelete"></a>
# **ApiV1EnvironmentCOPaymentTermCOIdDelete**
> void ApiV1EnvironmentCOPaymentTermCOIdDelete (string id, string environment, string authorizationScope, string company = null, string user = null, string acceptLanguage = null)

Delete

Deleting object of type 

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOPaymentTermCOIdDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new PaymentTermCOApi(config);
            var id = "id_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Delete
                apiInstance.ApiV1EnvironmentCOPaymentTermCOIdDelete(id, environment, authorizationScope, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOIdDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOPaymentTermCOIdDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete
    apiInstance.ApiV1EnvironmentCOPaymentTermCOIdDeleteWithHttpInfo(id, environment, authorizationScope, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOIdDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object has been deleted |  -  |
| **400** | if object has not been deleted: the content response contains the validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |
| **409** | If object has not been deleted due to business rules violation: the content response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentcopaymenttermcoidget"></a>
# **ApiV1EnvironmentCOPaymentTermCOIdGet**
> PaymentTermCODTO ApiV1EnvironmentCOPaymentTermCOIdGet (string id, string environment, string authorizationScope, string dlevel = null, string dlevelkey = null, string company = null, string user = null, string acceptLanguage = null)

Get by ID

Get an object of type corresponding the requested id

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOPaymentTermCOIdGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new PaymentTermCOApi(config);
            var id = "id_example";  // string | Id to get the object
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var dlevel = "dlevel_example";  // string | Serialization level (optional) 
            var dlevelkey = "dlevelkey_example";  // string | Serialization level key (optional) 
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get by ID
                PaymentTermCODTO result = apiInstance.ApiV1EnvironmentCOPaymentTermCOIdGet(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOIdGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOPaymentTermCOIdGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get by ID
    ApiResponse<PaymentTermCODTO> response = apiInstance.ApiV1EnvironmentCOPaymentTermCOIdGetWithHttpInfo(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOIdGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** | Id to get the object |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **dlevel** | **string** | Serialization level | [optional]  |
| **dlevelkey** | **string** | Serialization level key | [optional]  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**PaymentTermCODTO**](PaymentTermCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentcopaymenttermcoidpatch"></a>
# **ApiV1EnvironmentCOPaymentTermCOIdPatch**
> void ApiV1EnvironmentCOPaymentTermCOIdPatch (string id, string environment, string authorizationScope, Object body, string force = null, string op = null, string company = null, string user = null, string acceptLanguage = null)

Update partial

Patching an object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOPaymentTermCOIdPatchExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new PaymentTermCOApi(config);
            var id = "id_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var body = null;  // Object | Object of type to patch
            var force = "force_example";  // string | The warning/s code to bypass (separated by ‘,’) during the execution (optional) 
            var op = "op_example";  // string | Set 'reload', if you want the DTO updated in the response request (optional) 
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Update partial
                apiInstance.ApiV1EnvironmentCOPaymentTermCOIdPatch(id, environment, authorizationScope, body, force, op, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOIdPatch: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOPaymentTermCOIdPatchWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update partial
    apiInstance.ApiV1EnvironmentCOPaymentTermCOIdPatchWithHttpInfo(id, environment, authorizationScope, body, force, op, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOIdPatchWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **body** | **Object** | Object of type to patch |  |
| **force** | **string** | The warning/s code to bypass (separated by ‘,’) during the execution | [optional]  |
| **op** | **string** | Set &#39;reload&#39;, if you want the DTO updated in the response request | [optional]  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object has been updated |  -  |
| **400** | If the object has not been patched: the content response contains the validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |
| **409** | If object has not been patched due to business rules violation: the content response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentcopaymenttermcoidput"></a>
# **ApiV1EnvironmentCOPaymentTermCOIdPut**
> PaymentTermCODTO ApiV1EnvironmentCOPaymentTermCOIdPut (string id, string environment, string authorizationScope, PaymentTermCODTO paymentTermCODTO, string force = null, string op = null, string company = null, string user = null, string acceptLanguage = null)

Update

Updating an object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOPaymentTermCOIdPutExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new PaymentTermCOApi(config);
            var id = "id_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var paymentTermCODTO = new PaymentTermCODTO(); // PaymentTermCODTO | Object of type to update
            var force = "force_example";  // string | The warning/s code to bypass (separated by ‘,’) during the execution (optional) 
            var op = "op_example";  // string | Set 'reload', if you want the DTO updated in the response request, otherwise will be returned null value (optional) 
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Update
                PaymentTermCODTO result = apiInstance.ApiV1EnvironmentCOPaymentTermCOIdPut(id, environment, authorizationScope, paymentTermCODTO, force, op, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOIdPut: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOPaymentTermCOIdPutWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update
    ApiResponse<PaymentTermCODTO> response = apiInstance.ApiV1EnvironmentCOPaymentTermCOIdPutWithHttpInfo(id, environment, authorizationScope, paymentTermCODTO, force, op, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOIdPutWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **paymentTermCODTO** | [**PaymentTermCODTO**](PaymentTermCODTO.md) | Object of type to update |  |
| **force** | **string** | The warning/s code to bypass (separated by ‘,’) during the execution | [optional]  |
| **op** | **string** | Set &#39;reload&#39;, if you want the DTO updated in the response request, otherwise will be returned null value | [optional]  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**PaymentTermCODTO**](PaymentTermCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object has been updated |  -  |
| **400** | If the object has not been updated: the content response contains the validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |
| **409** | If object has not been updated due to business rules violation: the content response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentcopaymenttermcopaymenttermduplicationpost"></a>
# **ApiV1EnvironmentCOPaymentTermCOPaymentTermDuplicationPost**
> void ApiV1EnvironmentCOPaymentTermCOPaymentTermDuplicationPost (string environment, string authorizationScope, PaymentTermDuplicationParametersCODTO paymentTermDuplicationParametersCODTO, string company = null, string user = null, string acceptLanguage = null)

Duplication of Payment Term

Duplication of Payment Term

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOPaymentTermCOPaymentTermDuplicationPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new PaymentTermCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var paymentTermDuplicationParametersCODTO = new PaymentTermDuplicationParametersCODTO(); // PaymentTermDuplicationParametersCODTO | Parameters for duplication
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Duplication of Payment Term
                apiInstance.ApiV1EnvironmentCOPaymentTermCOPaymentTermDuplicationPost(environment, authorizationScope, paymentTermDuplicationParametersCODTO, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOPaymentTermDuplicationPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOPaymentTermCOPaymentTermDuplicationPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Duplication of Payment Term
    apiInstance.ApiV1EnvironmentCOPaymentTermCOPaymentTermDuplicationPostWithHttpInfo(environment, authorizationScope, paymentTermDuplicationParametersCODTO, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOPaymentTermDuplicationPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **paymentTermDuplicationParametersCODTO** | [**PaymentTermDuplicationParametersCODTO**](PaymentTermDuplicationParametersCODTO.md) | Parameters for duplication |  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In caso di errori nelle logiche di business: il contenuto della risposta contiene i messaggi di validazione prodotti |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentcopaymenttermcopost"></a>
# **ApiV1EnvironmentCOPaymentTermCOPost**
> PaymentTermCODTO ApiV1EnvironmentCOPaymentTermCOPost (string environment, string authorizationScope, PaymentTermCODTO paymentTermCODTO, string company = null, string user = null, string acceptLanguage = null)

Create

Creating new object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOPaymentTermCOPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new PaymentTermCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var paymentTermCODTO = new PaymentTermCODTO(); // PaymentTermCODTO | Object of type to create
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Create
                PaymentTermCODTO result = apiInstance.ApiV1EnvironmentCOPaymentTermCOPost(environment, authorizationScope, paymentTermCODTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOPaymentTermCOPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Create
    ApiResponse<PaymentTermCODTO> response = apiInstance.ApiV1EnvironmentCOPaymentTermCOPostWithHttpInfo(environment, authorizationScope, paymentTermCODTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **paymentTermCODTO** | [**PaymentTermCODTO**](PaymentTermCODTO.md) | Object of type to create |  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**PaymentTermCODTO**](PaymentTermCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | If object has been created |  -  |
| **400** | If the object has not been created: the content response contains validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object has not been created due to business rules violation: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentcopaymenttermcoreadpost"></a>
# **ApiV1EnvironmentCOPaymentTermCOReadPost**
> PaymentTermCODTO ApiV1EnvironmentCOPaymentTermCOReadPost (string environment, string authorizationScope, List<SearchElementDTO> searchElementDTO, string dlevel = null, string dlevelkey = null, string company = null, string user = null, string acceptLanguage = null)

Read

Read among object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOPaymentTermCOReadPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new PaymentTermCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var searchElementDTO = new List<SearchElementDTO>(); // List<SearchElementDTO> | Search criteria to apply
            var dlevel = "dlevel_example";  // string | Serialization level (optional) 
            var dlevelkey = "dlevelkey_example";  // string | Serialization level key (optional) 
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Read
                PaymentTermCODTO result = apiInstance.ApiV1EnvironmentCOPaymentTermCOReadPost(environment, authorizationScope, searchElementDTO, dlevel, dlevelkey, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOReadPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOPaymentTermCOReadPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Read
    ApiResponse<PaymentTermCODTO> response = apiInstance.ApiV1EnvironmentCOPaymentTermCOReadPostWithHttpInfo(environment, authorizationScope, searchElementDTO, dlevel, dlevelkey, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOReadPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **searchElementDTO** | [**List&lt;SearchElementDTO&gt;**](SearchElementDTO.md) | Search criteria to apply |  |
| **dlevel** | **string** | Serialization level | [optional]  |
| **dlevelkey** | **string** | Serialization level key | [optional]  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**PaymentTermCODTO**](PaymentTermCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentcopaymenttermcosearchpost"></a>
# **ApiV1EnvironmentCOPaymentTermCOSearchPost**
> PaymentTermCODTO ApiV1EnvironmentCOPaymentTermCOSearchPost (string environment, string authorizationScope, SearchDTO searchDTO, string loadEntireDomain = null, string gettotalcount = null, string company = null, string user = null, string acceptLanguage = null)

Search

Search among object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOPaymentTermCOSearchPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new PaymentTermCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var searchDTO = new SearchDTO(); // SearchDTO | Search criteria to apply
            var loadEntireDomain = "loadEntireDomain_example";  // string | Specify 'loadEntireDomain=true' if you want all the aggregate (optional) 
            var gettotalcount = "gettotalcount_example";  // string | Specify 'gettotalcount=true' if you want the total number of elements (optional) 
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Search
                PaymentTermCODTO result = apiInstance.ApiV1EnvironmentCOPaymentTermCOSearchPost(environment, authorizationScope, searchDTO, loadEntireDomain, gettotalcount, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOSearchPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOPaymentTermCOSearchPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Search
    ApiResponse<PaymentTermCODTO> response = apiInstance.ApiV1EnvironmentCOPaymentTermCOSearchPostWithHttpInfo(environment, authorizationScope, searchDTO, loadEntireDomain, gettotalcount, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOSearchPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **searchDTO** | [**SearchDTO**](SearchDTO.md) | Search criteria to apply |  |
| **loadEntireDomain** | **string** | Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate | [optional]  |
| **gettotalcount** | **string** | Specify &#39;gettotalcount&#x3D;true&#39; if you want the total number of elements | [optional]  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**PaymentTermCODTO**](PaymentTermCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The list of object of type as result of search |  -  |
| **400** | If the search criteria is not supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentcopaymenttermcovalidatepost"></a>
# **ApiV1EnvironmentCOPaymentTermCOValidatePost**
> void ApiV1EnvironmentCOPaymentTermCOValidatePost (string environment, string authorizationScope, PaymentTermCODTO paymentTermCODTO, string company = null, string user = null, string acceptLanguage = null)

Validate

Validation of object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOPaymentTermCOValidatePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new PaymentTermCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var paymentTermCODTO = new PaymentTermCODTO(); // PaymentTermCODTO | Object of type to validate
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Validate
                apiInstance.ApiV1EnvironmentCOPaymentTermCOValidatePost(environment, authorizationScope, paymentTermCODTO, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOValidatePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOPaymentTermCOValidatePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Validate
    apiInstance.ApiV1EnvironmentCOPaymentTermCOValidatePostWithHttpInfo(environment, authorizationScope, paymentTermCODTO, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOValidatePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **paymentTermCODTO** | [**PaymentTermCODTO**](PaymentTermCODTO.md) | Object of type to validate |  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object is VALID: the content response does NOT contain validation messages |  -  |
| **400** | If no object to validate was supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object is NOT VALID: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentcopaymenttermcovalidatepropertiespost"></a>
# **ApiV1EnvironmentCOPaymentTermCOValidatePropertiesPost**
> ValidateDTO ApiV1EnvironmentCOPaymentTermCOValidatePropertiesPost (string environment, string authorizationScope, string company = null, string user = null, string acceptLanguage = null, string body = null)

Validation of one on more properties of Type

Validation of object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOPaymentTermCOValidatePropertiesPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new PaymentTermCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)
            var body = null;  // string |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br> (optional) 

            try
            {
                // Validation of one on more properties of Type
                ValidateDTO result = apiInstance.ApiV1EnvironmentCOPaymentTermCOValidatePropertiesPost(environment, authorizationScope, company, user, acceptLanguage, body);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOValidatePropertiesPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOPaymentTermCOValidatePropertiesPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Validation of one on more properties of Type
    ApiResponse<ValidateDTO> response = apiInstance.ApiV1EnvironmentCOPaymentTermCOValidatePropertiesPostWithHttpInfo(environment, authorizationScope, company, user, acceptLanguage, body);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling PaymentTermCOApi.ApiV1EnvironmentCOPaymentTermCOValidatePropertiesPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |
| **body** | **string** |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED&lt;br&gt; - The id of an existing object to validate properties, or &#39;&#39; if the object does not exist yet &lt;br&gt; | [optional]  |

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object is VALID: the content response does NOT contain validation messages |  -  |
| **400** | If no object to validate was supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object is NOT VALID: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

