# It.TSEnterprise.Sdk.Model.AddressTypeCODTO
CG1K_INDANAG - AddressTypeCO<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | CG1K_ID - ID (Required only in PUT/PATCH) | [optional] 
**IdCG1J** | **long** | CG1K_ID_CG1J - IdCG1J | 
**Tipo** | **int?** | CG1K_TIPO - Tipo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Sede attività&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Residenza&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Corrispondenza&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Indirizzo legale&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Residenza estera&lt;/li&gt;&lt;/ul&gt; | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

