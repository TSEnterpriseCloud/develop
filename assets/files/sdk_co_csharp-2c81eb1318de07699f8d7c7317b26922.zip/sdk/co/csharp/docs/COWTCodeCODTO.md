# It.TSEnterprise.Sdk.Model.COWTCodeCODTO
CG15_TABCAUPREST - WTCodeCO<br>Proprietà chiave:<ul><li><b>Codice</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Causdd1** | **string** | CG15_CAUSDD1 - Causale | [optional] 
**CodFiscPrev** | **string** | CG15_CODFISCPREV - Codice fiscale ente previdenziale | [optional] 
**Codice** | **string** | CG15_CODICE - Codice | 
**CodNonsog** | **double?** | CG15_CODNONSOG - Codice reddito non soggetto cu | [optional] 
**CodPrev** | **string** | CG15_CODPREV - Cod. ente previdenziale cu | [optional] 
**CodTribrp** | **string** | CG15_CODTRIBRP - Trib.RP | [optional] 
**CodTributo** | **string** | CG15_CODTRIBUTO - Trib.RA | [optional] 
**Descr** | **string** | CG15_DESCR - Descrizione | [optional] 
**FlgGlad** | **double?** | CG15_FLGGLAD - GLA/D&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgMinimi** | **int** | CG15_FLGMINIMI - FlgMinimi | 
**FlgPignTerzi** | **double?** | CG15_FLGPIGNTERZI - Pignoramento presso terzi | [optional] 
**FlgProteo360** | **double** | CG15_FLGPROTEO360 - FlgProteo360 | 
**FlgRegagevo** | **double?** | CG15_FLGREGAGEVO - R.Ag.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgRitImposta** | **double?** | CG15_FLGRITIMPOSTA - Ritenuta a titolo d&#39;imposta | [optional] 
**FlgSosprit** | **int** | CG15_FLGSOSPRIT - FlgSosprit | 
**Gcprev** | **int?** | CG15_GCPREV - g/c contributi previdenziali&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Data documento&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Data pagamento&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IdmediaCg99** | **double?** | CG15_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**Idprov** | **double?** | CG15_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**IndCodattglad** | **double?** | CG15_INDCODATTGLAD - Attività modello GLA/D&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Amministratore, revisore, liquidatore&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Amministratore di condominio&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Archiviazione, traduzioni, servizi amm. e contabili&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Assistenza tecnica macchinari, impianti&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Collaborazione giornali, riviste, enciclopedie&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Consulenze aziendali, fiscali, amministr.&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Estetica, igiene in genere&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Formazione, istruzione, addestramento&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Intermediazioni, recup. crediti, notifica atti&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Moda, arte, sport, spettacolo&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - Partecipanti a collegi e commissioni&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Salute, assistenza&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Sondaggi di opinione, marketing, pubblicita&#39;&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Trasporti e spedizioni&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - Turismo, animazione, intrattenimento&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - Vendite a domicilio&lt;/li&gt;&lt;li&gt;&lt;i&gt;17&lt;/i&gt; - Altre&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTipocassa** | **int?** | CG15_INDTIPOCASSA - Tipo cassa&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  &lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Cassa nazionale previdenza e assistenza avvocati e procuratori legali&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Cassa previdenza dottori commercialisti&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Cassa previdenza e assistenza geometri&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Cassa nazionale previdenza e assistenza ingegneri e architetti liberi professionisti&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Cassa nazionale del notariato&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Cassa nazionale previdenza e assistenza ragionieri e periti commerciali&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Ente nazionale assistenza agenti e rappresentanti di commercio (ENASARCO)&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Ente nazionale previdenza e assistenza consulenti del lavoro (ENPACL)&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Ente nazionale previdenza e assistenza medici (ENPAM)&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Ente nazionale previdenza e assistenza farmacisti (ENPAF)&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - Ente nazionale previdenza e assistenza veterinari (ENPAV)&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Ente nazionale previdenza e assistenza impiegati dell&#39;agricoltura (ENPAIA)&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Fondo previdenza impiegati imprese di spedizione e agenzie marittime&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Istituto nazionale previdenza giornalisti italiani (INPGI)&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - Opera nazionale assistenza orfani sanitari italiani (ONAOSI)&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - Cassa autonoma assistenza integrativa giornalisti italiani (CASAGIT)&lt;/li&gt;&lt;li&gt;&lt;i&gt;17&lt;/i&gt; - Ente previdenza periti industriali e periti industriali laureati (EPPI)&lt;/li&gt;&lt;li&gt;&lt;i&gt;18&lt;/i&gt; - Ente previdenza e assistenza pluricategoriale (EPAP)&lt;/li&gt;&lt;li&gt;&lt;i&gt;19&lt;/i&gt; - Ente nazionale previdenza e assistenza biologi (ENPAB)&lt;/li&gt;&lt;li&gt;&lt;i&gt;20&lt;/i&gt; - Ente nazionale previdenza e assistenza professione infermieristica (ENPAPI)&lt;/li&gt;&lt;li&gt;&lt;i&gt;21&lt;/i&gt; - Ente nazionale previdenza e assistenza psicologi (ENPAP)&lt;/li&gt;&lt;li&gt;&lt;i&gt;22&lt;/i&gt; - INPS&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Inpsivs** | **double?** | CG15_INPSIVS - % R.P. | [optional] 
**Percbaseimp** | **double?** | CG15_PERCBASEIMP - % B.imp. | [optional] 
**Percci** | **double?** | CG15_PERCCI - % C.I. | [optional] 
**Percra** | **double?** | CG15_PERCRA - % R.A. | [optional] 
**Percripaz** | **double?** | CG15_PERCRIPAZ - % Az. | [optional] 
**PercRipPerc** | **double?** | % Perc. | [optional] 
**Rowversion** | **byte[]** | CG15_ROWVERSION - Rowversion | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

