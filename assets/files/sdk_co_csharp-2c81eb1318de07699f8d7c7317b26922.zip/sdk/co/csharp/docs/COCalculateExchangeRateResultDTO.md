# It.TSEnterprise.Sdk.Model.COCalculateExchangeRateResultDTO
Risultati del calcolo cambio valute<br>- indicatoreCertoIncerto: 0 = Certo per certo, 1 = Incerto per certo<br>- tipoCambioRecuperato: 

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TipoCambioRecuperato** | **int** |  | [optional] 
**NumeroDecimali** | **int** |  | [optional] 
**Cambio** | **double** |  | [optional] 
**DataCambio** | **DateTime?** |  | [optional] 
**IndicatoreCertoIncerto** | **int** |  | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

