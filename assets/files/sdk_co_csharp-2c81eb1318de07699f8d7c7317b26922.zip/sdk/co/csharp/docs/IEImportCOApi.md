# It.TSEnterprise.Sdk.Api.IEImportCOApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**ApiV1EnvironmentCOIEImportCOCustomersupplierPost**](IEImportCOApi.md#apiv1environmentcoieimportcocustomersupplierpost) | **POST** /api/v1/{environment}/CO/IEImportCO/customersupplier | Import Customers/Suppliers based on the required parameters |

<a id="apiv1environmentcoieimportcocustomersupplierpost"></a>
# **ApiV1EnvironmentCOIEImportCOCustomersupplierPost**
> ImportExportResultDTO ApiV1EnvironmentCOIEImportCOCustomersupplierPost (string environment, string authorizationScope, ImportCustomerSupplierCOParameterDTO importCustomerSupplierCOParameterDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Import Customers/Suppliers based on the required parameters

Import Customers/Suppliers based on the required parameters

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOIEImportCOCustomersupplierPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new IEImportCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var importCustomerSupplierCOParameterDTO = new ImportCustomerSupplierCOParameterDTO(); // ImportCustomerSupplierCOParameterDTO | Import Customers/Suppliers parameters
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Import Customers/Suppliers based on the required parameters
                ImportExportResultDTO result = apiInstance.ApiV1EnvironmentCOIEImportCOCustomersupplierPost(environment, authorizationScope, importCustomerSupplierCOParameterDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling IEImportCOApi.ApiV1EnvironmentCOIEImportCOCustomersupplierPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOIEImportCOCustomersupplierPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Import Customers/Suppliers based on the required parameters
    ApiResponse<ImportExportResultDTO> response = apiInstance.ApiV1EnvironmentCOIEImportCOCustomersupplierPostWithHttpInfo(environment, authorizationScope, importCustomerSupplierCOParameterDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling IEImportCOApi.ApiV1EnvironmentCOIEImportCOCustomersupplierPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **importCustomerSupplierCOParameterDTO** | [**ImportCustomerSupplierCOParameterDTO**](ImportCustomerSupplierCOParameterDTO.md) | Import Customers/Suppliers parameters |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**ImportExportResultDTO**](ImportExportResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Import Customers/Suppliers result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages produced |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

