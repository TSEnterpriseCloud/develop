# It.TSEnterprise.Sdk.Model.COProtocolCalculationResultDTO
Results of the next protocol calculation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionResult** | **bool** |  | [optional] 
**Numdoc** | **double?** |  | [optional] 
**Tipodocrif** | **double?** |  | [optional] 
**Datadoc** | **DateTime?** |  | [optional] 
**NumDocOrigData** | [**CONumDocOrigProposalDTO**](CONumDocOrigProposalDTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

