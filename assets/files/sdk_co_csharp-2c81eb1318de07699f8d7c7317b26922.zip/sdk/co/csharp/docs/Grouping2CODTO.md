# It.TSEnterprise.Sdk.Model.Grouping2CODTO
MG32_RAGGRCF2 -  Raggruppamento 2<br>Proprietà chiave:<ul><li><b>CodRaggrcf2</b></li><li><b>DittaCg18</b></li><li><b>Tipocf</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodRaggrcf2** | **string** | MG32_CODRAGGRCF2 - Raggruppamento 2 | 
**Descraggrcf2** | **string** | MG32_DESCRAGGRCF2 - Descrizione | [optional] 
**DittaCg18** | **double?** | MG32_DITTA_CG18 - Ditta | [optional] 
**IdmediaCg99** | **double?** | MG32_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**Idprov** | **int?** | MG32_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**Tipocf** | **double?** | MG32_TIPOCF - Tipo Cli/For&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

