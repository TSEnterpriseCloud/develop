# It.TSEnterprise.Sdk.Model.COSectionalMasterDataProposalResultDTO
Results of the recovery of the requested sectional (s)

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionResult** | **bool** |  | [optional] 
**SectionalData** | [**COSectionalMasterDataProposalInfoDTO**](COSectionalMasterDataProposalInfoDTO.md) |  | [optional] 
**SelfInvoiceSectionalData** | [**COSectionalMasterDataProposalInfoDTO**](COSectionalMasterDataProposalInfoDTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

