# It.TSEnterprise.Sdk.Model.COCalculateAmountResultDTO
Importo risultante dal calcolo e il cambio usato

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Amount** | **double?** |  | [optional] 
**CurrencyExchange** | **double?** |  | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

