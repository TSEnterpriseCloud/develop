# It.TSEnterprise.Sdk.Model.COSectionalMasterDataProposalInfoDTO
Sectional requested and any associated protocol

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Causale** | **string** |  | [optional] 
**CodSez** | **string** |  | [optional] 
**DescSez** | **string** |  | [optional] 
**IndTipologia** | **double?** |  | [optional] 
**ProtocolData** | [**COProtocolCalculationResultDTO**](COProtocolCalculationResultDTO.md) |  | [optional] 
**CodAttivita** | **double?** |  | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

