# It.TSEnterprise.Sdk.Model.CONatureAssCODTO
CG2N_NATURAASSOSW - NatureAssCO<br>Proprietà chiave:<ul><li><b>Idassosw</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codice** | **string** | CG2N_CODICE - Codice | 
**Datafineval** | **DateTime?** | CG2N_DATAFINEVAL - Datafineval | [optional] 
**Datainival** | **DateTime?** | CG2N_DATAINIVAL - Datainival | [optional] 
**Descr** | **string** | CG2N_DESCR - Descrizione | 
**Idassosw** | **int** | CG2N_IDASSOSW - Idassosw | 
**IdCg2m** | **int** | CG2N_ID_CG2M - IdCg2m | 
**Rowversion** | **byte[]** | CG2N_ROWVERSION - Rowversion | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

