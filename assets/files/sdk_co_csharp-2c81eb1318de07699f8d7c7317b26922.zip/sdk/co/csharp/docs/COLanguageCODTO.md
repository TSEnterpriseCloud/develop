# It.TSEnterprise.Sdk.Model.COLanguageCODTO
MG52_LINGUE - Lingua<br>Proprietà chiave:<ul><li><b>CodLingua</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodLingua** | **string** | MG52_CODLINGUA - Codice lingua | 
**Descrlingua** | **string** | MG52_DESCRLINGUA - Descrizione lingua | [optional] 
**IdmediaCg99** | **double?** | MG52_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**Iso639** | **string** | MG52_ISO639 - Codice ISO639 | [optional] 
**Siglalingua** | **string** | MG52_SIGLALINGUA - Sigla | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

