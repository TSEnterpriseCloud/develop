# It.TSEnterprise.Sdk.Model.PaymentTermCODTO
CG62_CONDPAGDES - Condizione di pagamento<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodPag** | **string** | CG62_CODPAG - Codice | 
**DescPag** | **string** | CG62_DESCPAG - Descrizione | [optional] 
**DesPagAnal** | **string** | CG62_DESPAGANAL - Descrizione analitica | [optional] 
**FlgDesc** | **double?** | CG62_FLGDESC - Descriz. automatica  | [optional] 
**FlgDisgg** | **double?** | CG62_FLGDISGG - Non applicare giorni fissi cliente/fornitore - slittamento generale e cliente/fornitore | [optional] 
**FlgPrefatt** | **int?** | CG62_FLGPREFATT - Preferenziale ciclo attivo | [optional] 
**FlgPrefpass** | **int?** | CG62_FLGPREFPASS - Preferenziale ciclo passivo | [optional] 
**FlgStornoiva** | **double?** | CG62_FLGSTORNOIVA - Storno IVA | [optional] 
**Id** | **long?** | CG62_ID - ID (Required only in PUT/PATCH) | [optional] 
**Rowversion** | **byte[]** | CG62_ROWVERSION - RowVersion | [optional] 
**Scart26** | **double?** | CG62_SCART26 - Sconto Art.26 importo | [optional] 
**Scpercart26** | **double?** | CG62_SCPERCART26 - Sconto Art.26 % | [optional] 
**Scpercas** | **double?** | CG62_SCPERCAS - Sc. cassa | [optional] 
**Scpermer1** | **double?** | CG62_SCPERMER1 - Sc. merce 1 | [optional] 
**Scpermer2** | **double?** | CG62_SCPERMER2 - Sc. merce 2 | [optional] 
**IdExtendedAttributeEntity** | **int** |  | [optional] 
**IdExtendedAttributeSubEntity** | **int** |  | [optional] 
**PaymentTermDetailCO** | [**List&lt;PaymentTermDetailCODTO&gt;**](PaymentTermDetailCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

