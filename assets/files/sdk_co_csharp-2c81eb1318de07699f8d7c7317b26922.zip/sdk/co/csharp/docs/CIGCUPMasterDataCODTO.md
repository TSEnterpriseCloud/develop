# It.TSEnterprise.Sdk.Model.CIGCUPMasterDataCODTO
CO1H_CIGCUP - CIGCUPMasterDataCO<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Cig** | **string** | CO1H_CIG - Cig | 
**Cup** | **string** | CO1H_CUP - Cup | [optional] 
**Descrizione** | **string** | CO1H_DESCRIZIONE - Descrizione | [optional] 
**DocrifData** | **DateTime?** | CO1H_DOCRIF_DATA - DocrifData | [optional] 
**DocrifId** | **string** | CO1H_DOCRIF_ID - DocrifId | [optional] 
**FlgAttivo** | **double?** | CO1H_FLGATTIVO - FlgAttivo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Id** | **int?** | CO1H_ID - ID (Required only in PUT/PATCH) | [optional] 
**IndTipocontr** | **int?** | CO1H_INDTIPOCONTR - IndTipocontr&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Appalto&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Subappalto&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTipodocrif** | **int** | CO1H_INDTIPODOCRIF - IndTipodocrif | 
**Rowversion** | **byte[]** | CO1H_ROWVERSION - Rowversion | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

