# It.TSEnterprise.Sdk.Model.COCurrencyCODTO
CG08_TABVALUTE - Valuta<br>Proprietà chiave:<ul><li><b>Codice</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Cambiofisso** | **double?** | CG08_CAMBIOFISSO - Cambio fisso | [optional] 
**Codice** | **string** | CG08_CODICE - Codice | 
**Dataattuem** | **DateTime?** | CG08_DATAATTUEM - Data attuazione valuta UEM | [optional] 
**Descr** | **string** | CG08_DESCR - Descrizione | [optional] 
**FlgValuem** | **double?** | CG08_FLGVALUEM - Flag valuta UEM | [optional] 
**IdmediaCg99** | **double?** | CG08_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**IndCertoincerto** | **int** | CG08_INDCERTOINCERTO - Cambio incerto per certo | 
**IndSepmigl** | **double?** | CG08_INDSEPMIGL - Separatore migliaia&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - .&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - ,&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndValuem** | **double?** | CG08_INDVALUEM - Tipo valuta UEM&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No valuta UEM&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Franco belga&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Marco tedesco&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Peseta spagnola&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Franco francese&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Sterlina irlandese&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Lira italiana&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Fiorino olandese&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Scellino austriaco&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Escudo portoghese&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Marco finlandese&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - Franco lussemburghese&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Dracma greca&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Tallero sloveno&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Lira cipriota&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - Lira maltese&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - Corona slovacca&lt;/li&gt;&lt;li&gt;&lt;i&gt;17&lt;/i&gt; - Corona estone&lt;/li&gt;&lt;li&gt;&lt;i&gt;18&lt;/i&gt; - Lats lettone&lt;/li&gt;&lt;li&gt;&lt;i&gt;19&lt;/i&gt; - Litas lituano&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Numdec** | **double?** | CG08_NUMDEC - Numeri Decimali | [optional] 
**Sigla** | **string** | CG08_SIGLA - Sigla | [optional] 
**ExchangeRateCO** | [**List&lt;COExchangeRateCODTO&gt;**](COExchangeRateCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

