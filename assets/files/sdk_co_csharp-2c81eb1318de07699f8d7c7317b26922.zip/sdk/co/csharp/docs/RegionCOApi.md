# It.TSEnterprise.Sdk.Api.RegionCOApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**ApiV1EnvironmentCORegionCOIdGet**](RegionCOApi.md#apiv1environmentcoregioncoidget) | **GET** /api/v1/{environment}/CO/RegionCO/{id} | Get by ID |
| [**ApiV1EnvironmentCORegionCOReadPost**](RegionCOApi.md#apiv1environmentcoregioncoreadpost) | **POST** /api/v1/{environment}/CO/RegionCO/read | Read |
| [**ApiV1EnvironmentCORegionCOSearchPost**](RegionCOApi.md#apiv1environmentcoregioncosearchpost) | **POST** /api/v1/{environment}/CO/RegionCO/search | Search |

<a id="apiv1environmentcoregioncoidget"></a>
# **ApiV1EnvironmentCORegionCOIdGet**
> RegionCODTO ApiV1EnvironmentCORegionCOIdGet (string id, string environment, string authorizationScope, string? dlevel = null, string? dlevelkey = null, string? company = null, string? user = null, string? acceptLanguage = null)

Get by ID

Get an object of type corresponding the requested id

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCORegionCOIdGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new RegionCOApi(config);
            var id = "id_example";  // string | Id to get the object
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var dlevel = "dlevel_example";  // string? | Serialization level (optional) 
            var dlevelkey = "dlevelkey_example";  // string? | Serialization level key (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get by ID
                RegionCODTO result = apiInstance.ApiV1EnvironmentCORegionCOIdGet(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling RegionCOApi.ApiV1EnvironmentCORegionCOIdGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCORegionCOIdGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get by ID
    ApiResponse<RegionCODTO> response = apiInstance.ApiV1EnvironmentCORegionCOIdGetWithHttpInfo(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling RegionCOApi.ApiV1EnvironmentCORegionCOIdGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** | Id to get the object |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **dlevel** | **string?** | Serialization level | [optional]  |
| **dlevelkey** | **string?** | Serialization level key | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**RegionCODTO**](RegionCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentcoregioncoreadpost"></a>
# **ApiV1EnvironmentCORegionCOReadPost**
> RegionCODTO ApiV1EnvironmentCORegionCOReadPost (string environment, string authorizationScope, List<SearchElementDTO> searchElementDTO, string? dlevel = null, string? dlevelkey = null, string? company = null, string? user = null, string? acceptLanguage = null)

Read

Read among object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCORegionCOReadPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new RegionCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var searchElementDTO = new List<SearchElementDTO>(); // List<SearchElementDTO> | Search criteria to apply
            var dlevel = "dlevel_example";  // string? | Serialization level (optional) 
            var dlevelkey = "dlevelkey_example";  // string? | Serialization level key (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Read
                RegionCODTO result = apiInstance.ApiV1EnvironmentCORegionCOReadPost(environment, authorizationScope, searchElementDTO, dlevel, dlevelkey, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling RegionCOApi.ApiV1EnvironmentCORegionCOReadPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCORegionCOReadPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Read
    ApiResponse<RegionCODTO> response = apiInstance.ApiV1EnvironmentCORegionCOReadPostWithHttpInfo(environment, authorizationScope, searchElementDTO, dlevel, dlevelkey, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling RegionCOApi.ApiV1EnvironmentCORegionCOReadPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **searchElementDTO** | [**List&lt;SearchElementDTO&gt;**](SearchElementDTO.md) | Search criteria to apply |  |
| **dlevel** | **string?** | Serialization level | [optional]  |
| **dlevelkey** | **string?** | Serialization level key | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**RegionCODTO**](RegionCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentcoregioncosearchpost"></a>
# **ApiV1EnvironmentCORegionCOSearchPost**
> RegionCODTO ApiV1EnvironmentCORegionCOSearchPost (string environment, string authorizationScope, SearchDTO searchDTO, string? loadEntireDomain = null, string? gettotalcount = null, string? company = null, string? user = null, string? acceptLanguage = null)

Search

Search among object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCORegionCOSearchPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new RegionCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var searchDTO = new SearchDTO(); // SearchDTO | Search criteria to apply
            var loadEntireDomain = "loadEntireDomain_example";  // string? | Specify 'loadEntireDomain=true' if you want all the aggregate (optional) 
            var gettotalcount = "gettotalcount_example";  // string? | Specify 'gettotalcount=true' if you want the total number of elements (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Search
                RegionCODTO result = apiInstance.ApiV1EnvironmentCORegionCOSearchPost(environment, authorizationScope, searchDTO, loadEntireDomain, gettotalcount, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling RegionCOApi.ApiV1EnvironmentCORegionCOSearchPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCORegionCOSearchPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Search
    ApiResponse<RegionCODTO> response = apiInstance.ApiV1EnvironmentCORegionCOSearchPostWithHttpInfo(environment, authorizationScope, searchDTO, loadEntireDomain, gettotalcount, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling RegionCOApi.ApiV1EnvironmentCORegionCOSearchPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **searchDTO** | [**SearchDTO**](SearchDTO.md) | Search criteria to apply |  |
| **loadEntireDomain** | **string?** | Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate | [optional]  |
| **gettotalcount** | **string?** | Specify &#39;gettotalcount&#x3D;true&#39; if you want the total number of elements | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**RegionCODTO**](RegionCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The list of object of type as result of search |  -  |
| **400** | If the search criteria is not supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

