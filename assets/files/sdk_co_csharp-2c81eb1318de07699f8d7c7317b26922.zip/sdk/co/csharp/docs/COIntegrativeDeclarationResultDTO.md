# It.TSEnterprise.Sdk.Model.COIntegrativeDeclarationResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**OpResult** | [**COCSLetterOfIntentCODTO**](COCSLetterOfIntentCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

