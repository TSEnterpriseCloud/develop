# It.TSEnterprise.Sdk.Model.AgencyCODTO
CG13_AGENZIE - Agenzia<br>Proprietà chiave:<ul><li><b>CodBanca</b></li><li><b>Codice</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodBanca** | **double** | CG13_BANCA_CG12 - ABI-Banca | 
**Codice** | **double** | CG13_CODCAB - CAB agenzia | 
**Descrizione** | **string** | CG13_DESCR - Descrizione | [optional] 
**Localita** | **string** | CG13_LOCALITA - Localita | [optional] 
**Prov** | **string** | CG13_PROV - Prov | [optional] 
**BankCO** | [**BankCODTO**](BankCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

