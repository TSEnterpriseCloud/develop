# It.TSEnterprise.Sdk.Model.COContactSubjectCODTO
CO02_ANAGCONTATTO - ContactSubjectCO<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Altro1** | **string** | CO02_ALTRO1 - Altro Indirizzo 1 | [optional] 
**Altro2** | **string** | CO02_ALTRO2 - Altro Indirizzo 2 | [optional] 
**Cap** | **string** | CO02_CAP - Cap | [optional] 
**Cell1** | **string** | CO02_CELL1 - Cellulare 1 | [optional] 
**Cell2** | **string** | CO02_CELL2 - Cellulare 2 | [optional] 
**Citta** | **string** | CO02_CITTA - Città | [optional] 
**Cognomenome** | **string** | CO02_COGNOMENOME - Cognome - Nome | [optional] 
**Email1** | **string** | CO02_EMAIL1 - Email 1 | [optional] 
**Email2** | **string** | CO02_EMAIL2 - Email 2 | [optional] 
**Fax** | **string** | CO02_FAX - Fax | [optional] 
**Guid** | **Guid?** | CO02_GUID - GUID | [optional] 
**Id** | **double?** | CO02_ID - ID (Required only in PUT/PATCH) | [optional] 
**IdmediaCg99** | **double?** | CO02_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**Indirizzo** | **string** | CO02_INDIRIZZO -  Indirizzo | [optional] 
**IndPrefstdoc** | **double?** | CO02_INDPREFSTDOC - Stampa pref. doc.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Stampa&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Fax&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Mail&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - PEC&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Pdf&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Nessuna preferenza&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Lastchange** | **DateTime?** | CO02_LASTCHANGE - Data ultima variazione | [optional] 
**Note** | **string** | CO02_NOTE - Note | [optional] 
**Orariolav** | **string** | CO02_ORARIOLAV - Orario di lavoro | [optional] 
**Pec** | **string** | CO02_PEC - PEC | [optional] 
**Prov** | **string** | CO02_PROV - Prov | [optional] 
**Rowversion** | **byte[]** | CO02_ROWVERSION - RowVersion | [optional] 
**Telcasa** | **string** | CO02_TELCASA - Telefono casa | [optional] 
**Teldir1** | **string** | CO02_TELDIR1 - Telefono diretto 1 numero | [optional] 
**Teldir2** | **string** | CO02_TELDIR2 - Telefono diretto 2 numero | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

