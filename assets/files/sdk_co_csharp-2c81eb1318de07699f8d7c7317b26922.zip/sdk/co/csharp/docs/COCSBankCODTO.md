# It.TSEnterprise.Sdk.Model.COCSBankCODTO
MG35_CLIFORCC - CSBankCO<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Bban** | **string** | MG35_BBAN - BBAN | [optional] 
**Bicbancaestera** | **string** | MG35_BICBANCAESTERA - BIC | [optional] 
**Ccaddetto** | **string** | MG35_CCADDETTO - Addetto | [optional] 
**Ccdesagenz** | **string** | MG35_CCDESAGENZ - Descrizione agenzia | [optional] 
**Ccforn** | **string** | MG35_CCFORN - Conto corrente | [optional] 
**Ccfornfactor** | **double?** | MG35_CCFORNFACTOR - Fornitore per factoring | [optional] 
**CcfornfactoridCg44** | **int?** | MG35_CCFORNFACTORID_CG44 - CcfornfactoridCg44 | [optional] 
**Ccggval** | **double** | MG35_CCGGVAL - Giorni di valuta | 
**CliforCg44** | **double** | MG35_CLIFOR_CG44 - Codice Cliente / Fornitore | 
**CodiceCg07** | **double?** | MG35_CODICE_CG07 - Nazione | [optional] 
**DittaCg18** | **double** | MG35_DITTA_CG18 - Ditta | 
**FlgPref** | **double** | MG35_FLGPREF - Preferenziale pagamenti | 
**FlgPrefIncassi** | **int** | MG35_FLGPREF_INCASSI - Preferenziale incassi | 
**Iban** | **string** | MG35_IBAN - IBAN | [optional] 
**Id** | **int?** | MG35_ID - ID (Required only in PUT/PATCH) | [optional] 
**Idbancaestera** | **string** | MG35_IDBANCAESTERA - ID Banca estera | [optional] 
**Idcontratto** | **string** | MG35_IDCONTRATTO - ID Contratto/Rapporto | [optional] 
**Idsuccursale** | **double?** | MG35_IDSUCCURSALE - ID Succursale | [optional] 
**IndTipoop** | **double** | MG35_INDTIPOOP - Tipo operazione | 
**Locbancaestera** | **string** | MG35_LOCBANCAESTERA - Località Banca estera | [optional] 
**Nomebancaestera** | **string** | MG35_NOMEBANCAESTERA - Nome banca | [optional] 
**ProgR** | **int** | MG35_PROGR - Progr. | 
**Tipobanca** | **double?** | MG35_TIPOBANCA - Tipo banca&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Internazionale&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Domestico&lt;/li&gt;&lt;/ul&gt; | [optional] 
**TipocfCg44** | **double** | MG35_TIPOCF_CG44 - Tipo Cliente / Fornitore | 
**AgencyCO** | [**COAgencyCODTO**](COAgencyCODTO.md) |  | [optional] 
**CustomerSupplierCO** | [**COCustomerSupplierCODTO**](COCustomerSupplierCODTO.md) |  | [optional] 
**NationCO** | [**CONationCODTO**](CONationCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

