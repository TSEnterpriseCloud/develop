# It.TSEnterprise.Sdk.Api.CurrencyCOApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**ApiV1EnvironmentCOCurrencyCOCalculateAmountByCurrencyPost**](CurrencyCOApi.md#apiv1environmentcocurrencycocalculateamountbycurrencypost) | **POST** /api/v1/{environment}/CO/CurrencyCO/calculateAmountByCurrency | Calculation of the amount by exchange |
| [**ApiV1EnvironmentCOCurrencyCOCalculateExchangeratePost**](CurrencyCOApi.md#apiv1environmentcocurrencycocalculateexchangeratepost) | **POST** /api/v1/{environment}/CO/CurrencyCO/calculate_exchangerate | Calculation &#39;Exchange rate&#39; |
| [**ApiV1EnvironmentCOCurrencyCOGet**](CurrencyCOApi.md#apiv1environmentcocurrencycoget) | **GET** /api/v1/{environment}/CO/CurrencyCO | Get new |
| [**ApiV1EnvironmentCOCurrencyCOIdGet**](CurrencyCOApi.md#apiv1environmentcocurrencycoidget) | **GET** /api/v1/{environment}/CO/CurrencyCO/{id} | Get by ID |
| [**ApiV1EnvironmentCOCurrencyCOImportannualaverageratesPost**](CurrencyCOApi.md#apiv1environmentcocurrencycoimportannualaverageratespost) | **POST** /api/v1/{environment}/CO/CurrencyCO/importannualaveragerates | Average annual exchange rates import |
| [**ApiV1EnvironmentCOCurrencyCOImportcurrencyratesPost**](CurrencyCOApi.md#apiv1environmentcocurrencycoimportcurrencyratespost) | **POST** /api/v1/{environment}/CO/CurrencyCO/importcurrencyrates | Currency Exchange Import |
| [**ApiV1EnvironmentCOCurrencyCOImportmonthlyaverageratesPost**](CurrencyCOApi.md#apiv1environmentcocurrencycoimportmonthlyaverageratespost) | **POST** /api/v1/{environment}/CO/CurrencyCO/importmonthlyaveragerates | Import of average monthly exchange rates |
| [**ApiV1EnvironmentCOCurrencyCOImporttimeseriesratesPost**](CurrencyCOApi.md#apiv1environmentcocurrencycoimporttimeseriesratespost) | **POST** /api/v1/{environment}/CO/CurrencyCO/importtimeseriesrates | Import time series exchange rates |
| [**ApiV1EnvironmentCOCurrencyCOReadPost**](CurrencyCOApi.md#apiv1environmentcocurrencycoreadpost) | **POST** /api/v1/{environment}/CO/CurrencyCO/read | Read |
| [**ApiV1EnvironmentCOCurrencyCOSearchPost**](CurrencyCOApi.md#apiv1environmentcocurrencycosearchpost) | **POST** /api/v1/{environment}/CO/CurrencyCO/search | Search |
| [**ApiV1EnvironmentCOCurrencyCOValidatePost**](CurrencyCOApi.md#apiv1environmentcocurrencycovalidatepost) | **POST** /api/v1/{environment}/CO/CurrencyCO/validate | Validate |
| [**ApiV1EnvironmentCOCurrencyCOValidatePropertiesPost**](CurrencyCOApi.md#apiv1environmentcocurrencycovalidatepropertiespost) | **POST** /api/v1/{environment}/CO/CurrencyCO/validateProperties | Validation of one on more properties of Type |

<a id="apiv1environmentcocurrencycocalculateamountbycurrencypost"></a>
# **ApiV1EnvironmentCOCurrencyCOCalculateAmountByCurrencyPost**
> CalculateAmountResultDTO ApiV1EnvironmentCOCurrencyCOCalculateAmountByCurrencyPost (string environment, string authorizationScope, CalculateAmountParametersDTO calculateAmountParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Calculation of the amount by exchange

Currency exchange calculation

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOCurrencyCOCalculateAmountByCurrencyPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new CurrencyCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var calculateAmountParametersDTO = new CalculateAmountParametersDTO(); // CalculateAmountParametersDTO | Object containing the parameters necessary for the calculation. If it is not passed the exchange will be taken by CG09_TABCAMBI
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Calculation of the amount by exchange
                CalculateAmountResultDTO result = apiInstance.ApiV1EnvironmentCOCurrencyCOCalculateAmountByCurrencyPost(environment, authorizationScope, calculateAmountParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOCalculateAmountByCurrencyPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOCurrencyCOCalculateAmountByCurrencyPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Calculation of the amount by exchange
    ApiResponse<CalculateAmountResultDTO> response = apiInstance.ApiV1EnvironmentCOCurrencyCOCalculateAmountByCurrencyPostWithHttpInfo(environment, authorizationScope, calculateAmountParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOCalculateAmountByCurrencyPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **calculateAmountParametersDTO** | [**CalculateAmountParametersDTO**](CalculateAmountParametersDTO.md) | Object containing the parameters necessary for the calculation. If it is not passed the exchange will be taken by CG09_TABCAMBI |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**CalculateAmountResultDTO**](CalculateAmountResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Amount resulting from the calculation and the exchange rate used |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentcocurrencycocalculateexchangeratepost"></a>
# **ApiV1EnvironmentCOCurrencyCOCalculateExchangeratePost**
> CalculateExchangeRateResultDTO ApiV1EnvironmentCOCurrencyCOCalculateExchangeratePost (string environment, string authorizationScope, CalculateExchangeRateParametersDTO calculateExchangeRateParametersDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Calculation 'Exchange rate'

Currency exchange calculation

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOCurrencyCOCalculateExchangeratePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new CurrencyCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var calculateExchangeRateParametersDTO = new CalculateExchangeRateParametersDTO(); // CalculateExchangeRateParametersDTO | Object that contains all the parameters that are used in the calculation
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Calculation 'Exchange rate'
                CalculateExchangeRateResultDTO result = apiInstance.ApiV1EnvironmentCOCurrencyCOCalculateExchangeratePost(environment, authorizationScope, calculateExchangeRateParametersDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOCalculateExchangeratePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOCurrencyCOCalculateExchangeratePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Calculation 'Exchange rate'
    ApiResponse<CalculateExchangeRateResultDTO> response = apiInstance.ApiV1EnvironmentCOCurrencyCOCalculateExchangeratePostWithHttpInfo(environment, authorizationScope, calculateExchangeRateParametersDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOCalculateExchangeratePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **calculateExchangeRateParametersDTO** | [**CalculateExchangeRateParametersDTO**](CalculateExchangeRateParametersDTO.md) | Object that contains all the parameters that are used in the calculation |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**CalculateExchangeRateResultDTO**](CalculateExchangeRateResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If the calculation was done correctly. |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentcocurrencycoget"></a>
# **ApiV1EnvironmentCOCurrencyCOGet**
> CurrencyCODTO ApiV1EnvironmentCOCurrencyCOGet (string op, string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null)

Get new

Get an empty object of type corresponding

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOCurrencyCOGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new CurrencyCOApi(config);
            var op = "op_example";  // string | The value must be 'new'
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get new
                CurrencyCODTO result = apiInstance.ApiV1EnvironmentCOCurrencyCOGet(op, environment, authorizationScope, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOCurrencyCOGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get new
    ApiResponse<CurrencyCODTO> response = apiInstance.ApiV1EnvironmentCOCurrencyCOGetWithHttpInfo(op, environment, authorizationScope, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **op** | **string** | The value must be &#39;new&#39; |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**CurrencyCODTO**](CurrencyCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The empty object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentcocurrencycoidget"></a>
# **ApiV1EnvironmentCOCurrencyCOIdGet**
> CurrencyCODTO ApiV1EnvironmentCOCurrencyCOIdGet (string id, string environment, string authorizationScope, string? dlevel = null, string? dlevelkey = null, string? company = null, string? user = null, string? acceptLanguage = null)

Get by ID

Get an object of type corresponding the requested id

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOCurrencyCOIdGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new CurrencyCOApi(config);
            var id = "id_example";  // string | Id to get the object
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var dlevel = "dlevel_example";  // string? | Serialization level (optional) 
            var dlevelkey = "dlevelkey_example";  // string? | Serialization level key (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get by ID
                CurrencyCODTO result = apiInstance.ApiV1EnvironmentCOCurrencyCOIdGet(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOIdGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOCurrencyCOIdGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get by ID
    ApiResponse<CurrencyCODTO> response = apiInstance.ApiV1EnvironmentCOCurrencyCOIdGetWithHttpInfo(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOIdGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** | Id to get the object |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **dlevel** | **string?** | Serialization level | [optional]  |
| **dlevelkey** | **string?** | Serialization level key | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**CurrencyCODTO**](CurrencyCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentcocurrencycoimportannualaverageratespost"></a>
# **ApiV1EnvironmentCOCurrencyCOImportannualaverageratesPost**
> ImportCurrencyRatesOutputDTO ApiV1EnvironmentCOCurrencyCOImportannualaverageratesPost (string environment, string authorizationScope, ImportAnnualAverageRatesInputDTO importAnnualAverageRatesInputDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Average annual exchange rates import

Average annual exchange rates import

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOCurrencyCOImportannualaverageratesPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new CurrencyCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var importAnnualAverageRatesInputDTO = new ImportAnnualAverageRatesInputDTO(); // ImportAnnualAverageRatesInputDTO | Input parameters
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Average annual exchange rates import
                ImportCurrencyRatesOutputDTO result = apiInstance.ApiV1EnvironmentCOCurrencyCOImportannualaverageratesPost(environment, authorizationScope, importAnnualAverageRatesInputDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOImportannualaverageratesPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOCurrencyCOImportannualaverageratesPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Average annual exchange rates import
    ApiResponse<ImportCurrencyRatesOutputDTO> response = apiInstance.ApiV1EnvironmentCOCurrencyCOImportannualaverageratesPostWithHttpInfo(environment, authorizationScope, importAnnualAverageRatesInputDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOImportannualaverageratesPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **importAnnualAverageRatesInputDTO** | [**ImportAnnualAverageRatesInputDTO**](ImportAnnualAverageRatesInputDTO.md) | Input parameters |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**ImportCurrencyRatesOutputDTO**](ImportCurrencyRatesOutputDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result of the import operation |  -  |
| **400** | In case of incorrect parameters in the request |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentcocurrencycoimportcurrencyratespost"></a>
# **ApiV1EnvironmentCOCurrencyCOImportcurrencyratesPost**
> ImportCurrencyRatesOutputDTO ApiV1EnvironmentCOCurrencyCOImportcurrencyratesPost (string environment, string authorizationScope, ImportCurrencyRatesInputDTO importCurrencyRatesInputDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Currency Exchange Import

Currency Exchange Import

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOCurrencyCOImportcurrencyratesPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new CurrencyCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var importCurrencyRatesInputDTO = new ImportCurrencyRatesInputDTO(); // ImportCurrencyRatesInputDTO | Input parameters
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Currency Exchange Import
                ImportCurrencyRatesOutputDTO result = apiInstance.ApiV1EnvironmentCOCurrencyCOImportcurrencyratesPost(environment, authorizationScope, importCurrencyRatesInputDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOImportcurrencyratesPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOCurrencyCOImportcurrencyratesPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Currency Exchange Import
    ApiResponse<ImportCurrencyRatesOutputDTO> response = apiInstance.ApiV1EnvironmentCOCurrencyCOImportcurrencyratesPostWithHttpInfo(environment, authorizationScope, importCurrencyRatesInputDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOImportcurrencyratesPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **importCurrencyRatesInputDTO** | [**ImportCurrencyRatesInputDTO**](ImportCurrencyRatesInputDTO.md) | Input parameters |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**ImportCurrencyRatesOutputDTO**](ImportCurrencyRatesOutputDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result of the import operation |  -  |
| **400** | In case of incorrect parameters in the request |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentcocurrencycoimportmonthlyaverageratespost"></a>
# **ApiV1EnvironmentCOCurrencyCOImportmonthlyaverageratesPost**
> ImportCurrencyRatesOutputDTO ApiV1EnvironmentCOCurrencyCOImportmonthlyaverageratesPost (string environment, string authorizationScope, ImportMonthlyAverageRatesInputDTO importMonthlyAverageRatesInputDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Import of average monthly exchange rates

Import of average monthly exchange rates

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOCurrencyCOImportmonthlyaverageratesPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new CurrencyCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var importMonthlyAverageRatesInputDTO = new ImportMonthlyAverageRatesInputDTO(); // ImportMonthlyAverageRatesInputDTO | Input parameters
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Import of average monthly exchange rates
                ImportCurrencyRatesOutputDTO result = apiInstance.ApiV1EnvironmentCOCurrencyCOImportmonthlyaverageratesPost(environment, authorizationScope, importMonthlyAverageRatesInputDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOImportmonthlyaverageratesPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOCurrencyCOImportmonthlyaverageratesPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Import of average monthly exchange rates
    ApiResponse<ImportCurrencyRatesOutputDTO> response = apiInstance.ApiV1EnvironmentCOCurrencyCOImportmonthlyaverageratesPostWithHttpInfo(environment, authorizationScope, importMonthlyAverageRatesInputDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOImportmonthlyaverageratesPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **importMonthlyAverageRatesInputDTO** | [**ImportMonthlyAverageRatesInputDTO**](ImportMonthlyAverageRatesInputDTO.md) | Input parameters |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**ImportCurrencyRatesOutputDTO**](ImportCurrencyRatesOutputDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result of the import operation |  -  |
| **400** | In case of incorrect parameters in the request |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentcocurrencycoimporttimeseriesratespost"></a>
# **ApiV1EnvironmentCOCurrencyCOImporttimeseriesratesPost**
> ImportCurrencyRatesOutputDTO ApiV1EnvironmentCOCurrencyCOImporttimeseriesratesPost (string environment, string authorizationScope, ImportTimeSeriesRatesInputDTO importTimeSeriesRatesInputDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Import time series exchange rates

Time Series exchange rates import

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOCurrencyCOImporttimeseriesratesPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new CurrencyCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var importTimeSeriesRatesInputDTO = new ImportTimeSeriesRatesInputDTO(); // ImportTimeSeriesRatesInputDTO | Input parameters
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Import time series exchange rates
                ImportCurrencyRatesOutputDTO result = apiInstance.ApiV1EnvironmentCOCurrencyCOImporttimeseriesratesPost(environment, authorizationScope, importTimeSeriesRatesInputDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOImporttimeseriesratesPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOCurrencyCOImporttimeseriesratesPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Import time series exchange rates
    ApiResponse<ImportCurrencyRatesOutputDTO> response = apiInstance.ApiV1EnvironmentCOCurrencyCOImporttimeseriesratesPostWithHttpInfo(environment, authorizationScope, importTimeSeriesRatesInputDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOImporttimeseriesratesPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **importTimeSeriesRatesInputDTO** | [**ImportTimeSeriesRatesInputDTO**](ImportTimeSeriesRatesInputDTO.md) | Input parameters |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**ImportCurrencyRatesOutputDTO**](ImportCurrencyRatesOutputDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Result of the import operation |  -  |
| **400** | In case of incorrect parameters in the request |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentcocurrencycoreadpost"></a>
# **ApiV1EnvironmentCOCurrencyCOReadPost**
> CurrencyCODTO ApiV1EnvironmentCOCurrencyCOReadPost (string environment, string authorizationScope, List<SearchElementDTO> searchElementDTO, string? dlevel = null, string? dlevelkey = null, string? company = null, string? user = null, string? acceptLanguage = null)

Read

Read among object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOCurrencyCOReadPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new CurrencyCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var searchElementDTO = new List<SearchElementDTO>(); // List<SearchElementDTO> | Search criteria to apply
            var dlevel = "dlevel_example";  // string? | Serialization level (optional) 
            var dlevelkey = "dlevelkey_example";  // string? | Serialization level key (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Read
                CurrencyCODTO result = apiInstance.ApiV1EnvironmentCOCurrencyCOReadPost(environment, authorizationScope, searchElementDTO, dlevel, dlevelkey, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOReadPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOCurrencyCOReadPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Read
    ApiResponse<CurrencyCODTO> response = apiInstance.ApiV1EnvironmentCOCurrencyCOReadPostWithHttpInfo(environment, authorizationScope, searchElementDTO, dlevel, dlevelkey, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOReadPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **searchElementDTO** | [**List&lt;SearchElementDTO&gt;**](SearchElementDTO.md) | Search criteria to apply |  |
| **dlevel** | **string?** | Serialization level | [optional]  |
| **dlevelkey** | **string?** | Serialization level key | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**CurrencyCODTO**](CurrencyCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentcocurrencycosearchpost"></a>
# **ApiV1EnvironmentCOCurrencyCOSearchPost**
> CurrencyCODTO ApiV1EnvironmentCOCurrencyCOSearchPost (string environment, string authorizationScope, SearchDTO searchDTO, string? loadEntireDomain = null, string? gettotalcount = null, string? company = null, string? user = null, string? acceptLanguage = null)

Search

Search among object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOCurrencyCOSearchPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new CurrencyCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var searchDTO = new SearchDTO(); // SearchDTO | Search criteria to apply
            var loadEntireDomain = "loadEntireDomain_example";  // string? | Specify 'loadEntireDomain=true' if you want all the aggregate (optional) 
            var gettotalcount = "gettotalcount_example";  // string? | Specify 'gettotalcount=true' if you want the total number of elements (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Search
                CurrencyCODTO result = apiInstance.ApiV1EnvironmentCOCurrencyCOSearchPost(environment, authorizationScope, searchDTO, loadEntireDomain, gettotalcount, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOSearchPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOCurrencyCOSearchPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Search
    ApiResponse<CurrencyCODTO> response = apiInstance.ApiV1EnvironmentCOCurrencyCOSearchPostWithHttpInfo(environment, authorizationScope, searchDTO, loadEntireDomain, gettotalcount, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOSearchPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **searchDTO** | [**SearchDTO**](SearchDTO.md) | Search criteria to apply |  |
| **loadEntireDomain** | **string?** | Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate | [optional]  |
| **gettotalcount** | **string?** | Specify &#39;gettotalcount&#x3D;true&#39; if you want the total number of elements | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**CurrencyCODTO**](CurrencyCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The list of object of type as result of search |  -  |
| **400** | If the search criteria is not supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentcocurrencycovalidatepost"></a>
# **ApiV1EnvironmentCOCurrencyCOValidatePost**
> void ApiV1EnvironmentCOCurrencyCOValidatePost (string environment, string authorizationScope, CurrencyCODTO currencyCODTO, string? company = null, string? user = null, string? acceptLanguage = null)

Validate

Validation of object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOCurrencyCOValidatePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new CurrencyCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var currencyCODTO = new CurrencyCODTO(); // CurrencyCODTO | Object of type to validate
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Validate
                apiInstance.ApiV1EnvironmentCOCurrencyCOValidatePost(environment, authorizationScope, currencyCODTO, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOValidatePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOCurrencyCOValidatePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Validate
    apiInstance.ApiV1EnvironmentCOCurrencyCOValidatePostWithHttpInfo(environment, authorizationScope, currencyCODTO, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOValidatePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **currencyCODTO** | [**CurrencyCODTO**](CurrencyCODTO.md) | Object of type to validate |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object is VALID: the content response does NOT contain validation messages |  -  |
| **400** | If no object to validate was supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object is NOT VALID: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentcocurrencycovalidatepropertiespost"></a>
# **ApiV1EnvironmentCOCurrencyCOValidatePropertiesPost**
> ValidateDTO ApiV1EnvironmentCOCurrencyCOValidatePropertiesPost (string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null, string? body = null)

Validation of one on more properties of Type

Validation of object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOCurrencyCOValidatePropertiesPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new CurrencyCOApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)
            var body = null;  // string? |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br> (optional) 

            try
            {
                // Validation of one on more properties of Type
                ValidateDTO result = apiInstance.ApiV1EnvironmentCOCurrencyCOValidatePropertiesPost(environment, authorizationScope, company, user, acceptLanguage, body);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOValidatePropertiesPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOCurrencyCOValidatePropertiesPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Validation of one on more properties of Type
    ApiResponse<ValidateDTO> response = apiInstance.ApiV1EnvironmentCOCurrencyCOValidatePropertiesPostWithHttpInfo(environment, authorizationScope, company, user, acceptLanguage, body);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CurrencyCOApi.ApiV1EnvironmentCOCurrencyCOValidatePropertiesPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |
| **body** | **string?** |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED&lt;br&gt; - The id of an existing object to validate properties, or &#39;&#39; if the object does not exist yet &lt;br&gt; | [optional]  |

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object is VALID: the content response does NOT contain validation messages |  -  |
| **400** | If no object to validate was supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object is NOT VALID: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

