# It.TSEnterprise.Sdk.Model.COCSJointlyHeldCODTO
CG4E_CFCOINTESTATI - CSJointlyHeldCO<br>Proprietà chiave:<ul><li><b>CliforCg44</b></li><li><b>CliforcoCg44</b></li><li><b>DittaCg18</b></li><li><b>TipocfCg44</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CliforCg44** | **double** | CG4E_CLIFOR_CG44 - CliforCg44 | 
**CliforcoCg44** | **double** | CG4E_CLIFORCO_CG44 - CliforcoCg44 | 
**DittaCg18** | **double** | CG4E_DITTA_CG18 - DittaCg18 | 
**IdcliforcoCg44** | **int?** | CG4E_IDCLIFORCO_CG44 - IdcliforcoCg44 | [optional] 
**Percentuale** | **double** | CG4E_PERCENTUALE - Percentuale | 
**TipocfCg44** | **double** | CG4E_TIPOCF_CG44 - TipocfCg44 | 
**CustomerSupplierCO** | [**COCustomerSupplierCODTO**](COCustomerSupplierCODTO.md) |  | 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

