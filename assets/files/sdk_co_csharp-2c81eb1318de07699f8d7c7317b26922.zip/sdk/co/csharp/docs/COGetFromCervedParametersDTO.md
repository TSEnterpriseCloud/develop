# It.TSEnterprise.Sdk.Model.COGetFromCervedParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SubjectId** | **string** | ID dell&#39;anagrafica Cerved da importare o mappare in un&#39;entità di GeneralMasterDataCODTO | [optional] 
**CreateNew** | **bool** | Se TRUE, viene effettuata la creazione dell&#39;anagrafica | [optional] 
**SubjectType** | **string** | Type of the Cerved master data to import or map in an entity of GeneralMasterDataCODTO | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

