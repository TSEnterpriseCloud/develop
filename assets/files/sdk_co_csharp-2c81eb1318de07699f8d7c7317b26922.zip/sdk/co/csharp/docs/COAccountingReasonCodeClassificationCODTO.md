# It.TSEnterprise.Sdk.Model.COAccountingReasonCodeClassificationCODTO
CGD1_TIPOCAUSALE - AccountingReasonCodeClassificationCO<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Descr** | **string** | CGD1_DESCR - Descr | [optional] 
**Id** | **double?** | CGD1_ID - Id (Required only in PUT/PATCH) | [optional] 
**IdmediaCg99** | **double?** | CGD1_IDMEDIA_CG99 - IdmediaCg99 | [optional] 
**Tipologia** | **string** | CGD1_TIPOLOGIA - Tipologia | 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

