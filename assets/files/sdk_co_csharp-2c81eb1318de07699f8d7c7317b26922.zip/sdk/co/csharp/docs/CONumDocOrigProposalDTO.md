# It.TSEnterprise.Sdk.Model.CONumDocOrigProposalDTO
NumDocOrig proposal and updatable info's

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UpdEnabled** | **bool** |  | [optional] 
**NumDocOrig** | **string** |  | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

