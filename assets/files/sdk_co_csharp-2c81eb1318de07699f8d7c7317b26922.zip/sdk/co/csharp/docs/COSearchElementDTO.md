# It.TSEnterprise.Sdk.Model.COSearchElementDTO
DTO that identifies a search criteria

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PropertyName** | **string** | Property on witch apply the filter | 
**Comparer** | **COSearchComparer** |  | 
**Value** | **Object** |  | 
**Operator** | **COSearchLogicalOperators** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

