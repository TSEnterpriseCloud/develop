# It.TSEnterprise.Sdk.Model.ExportCustomerSupplierCOAddParameterDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SelectionValidityGeneralMasterData** | **string** | Selection on validity General master data&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - 0 (All General master data)&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - 1 (Current valid General master data)&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - 2 (General master data valid on the date)&lt;/li&gt;&lt;/ul&gt; | [optional] [default to SelectionValidityGeneralMasterDataEnum._0]
**ReferenceValidDate** | **DateTime** | Reference valid date for General master data | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

