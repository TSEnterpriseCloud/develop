# It.TSEnterprise.Sdk.Model.ImportExportResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**GuidSession** | **string** | Guid Process | [optional] 
**StateProcess** | **string** | State Process | [optional] 
**IdStateProcess** | **long** | Id State Process&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Inserted&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Processing&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Terminate&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Terminate with error&lt;/li&gt;&lt;/ul&gt; | [optional] 
**HeadProcess** | [**ImportExportHeadResultDTO**](ImportExportHeadResultDTO.md) |  | [optional] 
**StreamFileExport** | **string** | Stream File Export | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

