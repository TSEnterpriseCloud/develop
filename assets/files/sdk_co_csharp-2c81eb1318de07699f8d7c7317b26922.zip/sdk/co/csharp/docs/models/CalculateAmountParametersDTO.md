# It.TSEnterprise.Sdk.Model.CalculateAmountParametersDTO
Oggetto contenente i parametri necessari per il calcolo. Se non viene passato il cambio verrà preso da CG09_TABCAMBI

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FromCurrencyCode** | **string** |  | [optional] 
**ToCurrencyCode** | **string** |  | [optional] 
**Date** | **DateTime** |  | [optional] 
**Amount** | **double** |  | [optional] 
**CurrencyExchange** | **double** |  | [optional] 
**ToCurrencyIsCompanyCurrency** | **bool** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

