# It.TSEnterprise.Sdk.Model.MacroAreaCODTO
MG07_MACROAREE - Macroarea<br>Proprietà chiave:<ul><li><b>CodiceMacroarea</b></li><li><b>DittaCg18</b></li><li><b>Tipocf</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodiceMacroarea** | **string** | MG07_MACROAREA - Macroarea | 
**Descrmacroar** | **string** | MG07_DESCRMACROAR - Descrizione | 
**DittaCg18** | **double** | MG07_DITTA_CG18 - Ditta | 
**Idprov** | **int** | MG07_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**Tipocf** | **double** | MG07_TIPOCF - Tipo Cli/For&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Areas** | [**List&lt;AreaCODTO&gt;**](AreaCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

