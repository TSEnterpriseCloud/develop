# It.TSEnterprise.Sdk.Model.CSInfoCODTO
MG19_CLIFORVA - Classificazione Cliente/Fornitore<br>Proprietà chiave:<ul><li><b>CliforCg44</b></li><li><b>DittaCg18</b></li><li><b>TipocfCg44</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CliforCg44** | **double** | MG19_CLIFOR_CG44 - Codice cliente | 
**Datacreaz** | **DateTime** | MG19_DATACREAZ - Data creazione | 
**Dataultvar** | **DateTime** | MG19_DATAULTVAR - Data ultima variazione | 
**DittaCg18** | **double** | MG19_DITTA_CG18 - Ditta | 
**FlgEstrpayline** | **double** | MG19_FLGESTRPAYLINE - Estrazione Payline | 
**FlgSpbol** | **double** | MG19_FLGSPBOL - Spese bolli | 
**FlgSpeinc** | **double** | MG19_FLGSPEINC - Spese incasso | 
**FlgTaxliable** | **int** | MG19_FLGTAXLIABLE - Tax Liable | 
**IndSpesecum** | **double** | MG19_INDSPESECUM - Cumulo sp.bolli/incasso | 
**TipocfCg44** | **double** | MG19_TIPOCF_CG44 - Tipo Cliente/ Fornitore | 
**Area** | **string** | MG19_AREA - Codice Area | [optional] 
**AreanielsenMg0e** | **string** | MG19_AREANIELSEN_MG0E - Area Nielsen | [optional] 
**Bacsaccountno** | **int** | MG19_BACSACCOUNTNO - Codice BACS | [optional] 
**Categ** | **string** | MG19_CATEG - Codice Categoria | [optional] 
**CodIclfatt** | **double** | MG19_CODICLFATT - Cliente fatturazione | [optional] 
**CodLivbloc** | **string** | MG19_CODLIVBLOC - Codice Blocco | [optional] 
**CodRifalf** | **string** | MG19_CODRIFALF - Codice di riferimento alfanumerico | [optional] 
**CodRifnum** | **double** | MG19_CODRIFNUM - Codice di riferimento numerico | [optional] 
**CodRischioMg2a** | **string** | MG19_CODRISCHIO_MG2A - Codice rischio | [optional] 
**Datablocco** | **DateTime** | MG19_DATABLOCCO - Data blocco | [optional] 
**Datadismis** | **DateTime** | MG19_DATADISMIS - Data dismissione | [optional] 
**Datarischio** | **DateTime** | MG19_DATARISCHIO - Data dell&#39;attivazione controllo rischio | [optional] 
**Fidoaziendale** | **double** | MG19_FIDOAZIENDALE - Fido aziendale | [optional] 
**Fidofactoring** | **double** | MG19_FIDOFACTORING - Importo fido assicurazione credito | [optional] 
**Fidolivello1** | **double** | MG19_FIDOLIVELLO1 - Fido liv. 1 | [optional] 
**Fidolivello2** | **double** | MG19_FIDOLIVELLO2 - Fido liv.2 | [optional] 
**Finchargerterms** | **string** | MG19_FINCHARGERTERMS - Termini di addebito | [optional] 
**IdmediaCg99** | **double** | MG19_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**IndClibloc** | **double** | MG19_INDCLIBLOC - Tipo blocco&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - senza possibilità di sblocco&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - con possibilità di sblocco&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndGesfido** | **double** | MG19_INDGESFIDO - Indicatore gestione fido | [optional] 
**Indrottcig** | **double** | MG19_INDROTTCIG - Indrottcig&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Irs1099** | **string** | MG19_IRS1099 - IRSS1099 Code | [optional] 
**Lastchange** | **DateTime** | MG19_LASTCHANGE - Data ultima variazione | [optional] 
**LinguaMg52** | **string** | MG19_LINGUA_MG52 - Codice lingua | [optional] 
**Macroarea** | **string** | MG19_MACROAREA - Codice Macroarea | [optional] 
**Macrocat** | **string** | MG19_MACROCAT - Codice Macrocategoria | [optional] 
**Notebloc** | **string** | MG19_NOTEBLOC - Note blocco | [optional] 
**Raggcrf3** | **string** | MG19_RAGGCRF3 - Codice raggrupamento Clienti/Fornitori 3 | [optional] 
**Raggrcf1** | **string** | MG19_RAGGRCF1 - Codice raggruppamento Clienti/Fornitori 1 | [optional] 
**Raggrcf2** | **string** | MG19_RAGGRCF2 - Codice raggruppamento Clienti/Fornitori 2 | [optional] 
**Regimeiva** | **string** | MG19_REGIMEIVA - Regime IVA | [optional] 
**Reminderterms** | **string** | MG19_REMINDERTERMS - Termini di sollecito | [optional] 
**Scaglspbanc** | **double** | MG19_SCAGLSPBANC - Codice della tabella bolli e spese incasso | [optional] 
**Sottocat** | **string** | MG19_SOTTOCAT - Codice Sottocategoria | [optional] 
**TaxareaNv01** | **string** | MG19_TAXAREA_NV01 - Tax area | [optional] 
**Taxexemptionno** | **string** | MG19_TAXEXEMPTIONNO - USA-numero esenzione sales tax | [optional] 
**Typeofsupply** | **string** | MG19_TYPEOFSUPPLY - Tipo di fornitura | [optional] 
**Zona** | **string** | MG19_ZONA - Codice Zona | [optional] 
**AreaCO** | [**AreaCODTO**](AreaCODTO.md) |  | [optional] 
**CategoryCO** | [**CategoryCODTO**](CategoryCODTO.md) |  | [optional] 
**Grouping1CO** | [**Grouping1CODTO**](Grouping1CODTO.md) |  | [optional] 
**Grouping2CO** | [**Grouping2CODTO**](Grouping2CODTO.md) |  | [optional] 
**Grouping3CO** | [**Grouping3CODTO**](Grouping3CODTO.md) |  | [optional] 
**MacroAreaCO** | [**MacroAreaCODTO**](MacroAreaCODTO.md) |  | [optional] 
**MacroCategoryCO** | [**MacroCategoryCODTO**](MacroCategoryCODTO.md) |  | [optional] 
**SubCategoryCO** | [**SubCategoryCODTO**](SubCategoryCODTO.md) |  | [optional] 
**ZoneCO** | [**ZoneCODTO**](ZoneCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

