# It.TSEnterprise.Sdk.Model.AgentCODTO
MG17_AGENTI - Agente<br>Proprietà chiave:<ul><li><b>Idagente</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Agente** | **string** | MG17_AGENTE - Agente | 
**AnagenCg16** | **int** | MG17_ANAGEN_CG16 - Codice anagrafica generale | 
**DittaCg18** | **double** | MG17_DITTA_CG18 - Ditta | 
**DmsPublishedEntityFW** | [**DMSPublishedEntityFWDTO**](DMSPublishedEntityFWDTO.md) |  | 
**GeneralMasterDataCO** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | 
**Datafineman** | **DateTime** | MG17_DATAFINEMAN - Data fine mandato | [optional] 
**Datainman** | **DateTime** | MG17_DATAINMAN - Data inizio mandato | [optional] 
**Datainrapp** | **DateTime** | MG17_DATAINRAPP - Data inizio rapporto | [optional] 
**FlgAdegdelta** | **double** | MG17_FLGADEGDELTA - Adeguamento provvigioni in funzione del delta della riga documento | [optional] 
**FlgAdeguamscmag** | **double** | MG17_FLGADEGUAMSCMAG - Adeguamento provvigioni per sconti/maggiorazioni | [optional] 
**FlgRegimeart** | **double** | MG17_FLGREGIMEART - Reg. provv. dell&#39;articolo | [optional] 
**FlgRegimecl** | **double** | MG17_FLGREGIMECL - Reg. provv. del cliente | [optional] 
**Guid** | **Guid** | MG17_GUID - GUID | [optional] 
**Idagente** | **int** | MG17_IDAGENTE - ID (Required only in PUT/PATCH) | [optional] 
**IdcapoareaMg17** | **int** | MG17_IDCAPOAREA_MG17 - Capo area dell&#39;agente | [optional] 
**IdcapozonaMg17** | **int** | MG17_IDCAPOZONA_MG17 - Capo zona dell&#39;agente | [optional] 
**IdmediaCg99** | **double** | MG17_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**IndBaseimpmag** | **double** | MG17_INDBASEIMPMAG - Base impon. provv. mag.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Imponibile provvigione&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Imponib. provv. - Importo provv. gia&#39; calcolato&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Diff. pr. determinato per il calcolo dello sconto&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Impor. provv. calcolato prima dell&#39;adeguamento&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndBaseimpsc** | **double** | MG17_INDBASEIMPSC - Base impon. provv. sc.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Imponibile provvigione&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Imponib. provv. - Importo provv. gia&#39; calcolato&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Diff. pr. determinato per il calcolo dello sconto&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Impor. provv. calcolato prima dell&#39;adeguamento&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndCalcscmag** | **double** | MG17_INDCALCSCMAG - Calcolo sconto/magg.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Pr. ven./acq. calcolato da priorita&#39; prezzi-Pr. doc.&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Pr. di list. anag. art. indicato sul cli./for-Pr. doc.&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Sconti o magg. effettivi indicati sul documento&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndPrefstdoc** | **double** | MG17_INDPREFSTDOC - Stampa pref. documento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Stampa&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Fax&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Mail&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - PEC&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Pdf&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Nessuna preferenza&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndStdistenas** | **double** | MG17_INDSTDISTENAS - Flag stampata distinta enasarco&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Si stampa distinta&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - No stampa distinta&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTipoage** | **double** | MG17_INDTIPOAGE - Tipo agente&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Agente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Capo zona&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Capo area&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTipoliq** | **double** | MG17_INDTIPOLIQ - Tipo liquidazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuna scelta&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Per importo&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Per scaduto&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Per pagato&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Perprov** | **double** | MG17_PERPROV - % Provvigioni | [optional] 
**Regimeprov** | **double** | MG17_REGIMEPROV - Regime&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No calcolo provvigioni&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - % dall&#39;agente&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - % dal cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - % dall&#39;anagrafica articolo&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - % dall&#39;anagrafica articolo/agente&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - % da listino fisso&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - % da listino anag. su cli./for.&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - % da listino fisso e scagl. sc./magg.&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - % da listino utilizzato&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - % da listino utilizzato: solo gest. scagl. di sc./magg.&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - % da listino utilizzato: provv. list. + scagl. di sc./magg.&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - % da tabella composta a due livelli&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - % da tabella composta a tre livelli&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - % da scaglioni di fatturato&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - % da condizioni multiple&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - % da listini parametrici&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Tipomand** | **double** | MG17_TIPOMAND - Tipo mandato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Monomandatario&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Plurimandatario&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Tiporappor** | **double** | MG17_TIPORAPPOR - Tipo rapporto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Procacciatore&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Generale&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Ispettore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Tiposoc** | **double** | MG17_TIPOSOC - Tipo di società&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Persona fisica&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Società di capitale&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Società di persona&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IdExtendedAttributeEntity** | **int** |  | [optional] 
**IdExtendedAttributeSubEntity** | **int** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

