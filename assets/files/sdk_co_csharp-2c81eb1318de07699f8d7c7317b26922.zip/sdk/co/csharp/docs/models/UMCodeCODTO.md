# It.TSEnterprise.Sdk.Model.UMCodeCODTO
CG0B_UNITAMISURASI - Unità di misura standard internazionali<br>Proprietà chiave:<ul><li><b>Umsigla</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Umsigla** | **string** | CG0B_UMSIGLA - Sigla UM | 
**Descr** | **string** | CG0B_DESCR - Descrizione | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

