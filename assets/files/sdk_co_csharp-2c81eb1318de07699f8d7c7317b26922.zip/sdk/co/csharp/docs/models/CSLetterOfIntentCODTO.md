# It.TSEnterprise.Sdk.Model.CSLetterOfIntentCODTO
MG28_CLIFORINT - CSLetterOfIntentCO<br>Proprietà chiave:<ul><li><b>ID</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AlqIvaCg28** | **string** | MG28_ALQIVA_CG28 - Aliquota IVA | 
**Anno** | **double** | MG28_ANNO - Anno | 
**CliForCg44** | **double** | MG28_CLIFOR_CG44 - Codice Cliente / Fornitore | 
**DataFineVal** | **DateTime** | MG28_DATAFINEVAL - Data fine validità | 
**DataInVal** | **DateTime** | MG28_DATAINVAL - Data inizio validità | 
**DittaCg18** | **double** | MG28_DITTA_CG18 - Ditta | 
**FlagDisattiv** | **double** | MG28_FLGDISATTIV - Non attiva | 
**FlagStDich** | **double** | MG28_FLGSTDICH - Stampa dichiarazioni di intento | 
**FlagStReg** | **double** | MG28_FLGSTREG - Reg. st. | 
**FlgScartata** | **int** | MG28_FLGSCARTATA - Scartata | 
**TipoCFCg44** | **double** | MG28_TIPOCF_CG44 - Tipo cliente fornitore | 
**VatCodeCO** | [**VatCodeCODTO**](VatCodeCODTO.md) |  | 
**DataNsReg** | **DateTime** | MG28_DATANSREG - Data emissione | [optional] 
**DataProtocollo** | **DateTime** | MG28_DATAPROTOCOLLO - Data protocollo | [optional] 
**Datarevoca** | **DateTime** | MG28_DATAREVOCA - Data revoca | [optional] 
**DataRicez** | **DateTime** | MG28_DATARICEZ - Data ricezione | [optional] 
**Dogana** | **string** | MG28_DOGANA - Dogana | [optional] 
**FinoAEuro** | **double** | MG28_FINOAEURO - Fino a Euro | [optional] 
**Id** | **int** | MG28_ID - ID tabella MG28 (lettera di intento) (Required only in PUT/PATCH) | [optional] 
**IndTipoDich** | **double** | MG28_INDTIPODICH - Tipo Dichiarazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - La sola operazione specificata&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Le operazioni effettuate nell&#39;anno...fino a concorrenza di EURO&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Le operazioni effettuate nell&#39;anno .... per il&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Note** | **string** | MG28_NOTE - Note | [optional] 
**NumLetDich** | **string** | MG28_NUMLETDICH - Numero lettera dichiarante | [optional] 
**NumNsProt** | **double** | MG28_NUMNSPROT - Num ns Prot. | [optional] 
**NumProtocollo** | **double** | MG28_NUMPROTOCOLLO - Numero protocollo | [optional] 
**ProgRinvio** | **double** | MG28_PROGRINVIO - Progressivo invio | [optional] 
**Rowversion** | **byte[]** | MG28_ROWVERSION - Rowversion | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

