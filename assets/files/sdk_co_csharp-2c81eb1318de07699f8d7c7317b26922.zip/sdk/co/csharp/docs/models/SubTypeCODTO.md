# It.TSEnterprise.Sdk.Model.SubTypeCODTO
CG64_SOTTOTIPO - SubTypeCO<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodStipoeff** | **double** | CG64_CODSTIPOEFF - Sottotipo effetto | 
**FlgAssegno** | **int** | CG64_FLGASSEGNO - Assegno | 
**CodiceCg07** | **double** | CG64_CODICE_CG07 - Nazione di incasso | [optional] 
**CodPaguc** | **string** | CG64_CODPAGUC - Codice pagamento estero | [optional] 
**Descstipo** | **string** | CG64_DESCSTIPO - Descrizione sottotipo effetto | [optional] 
**Ggoffset** | **double** | CG64_GGOFFSET - Giorni spostamento scadenza | [optional] 
**Id** | **long** | CG64_ID - ID (Required only in PUT/PATCH) | [optional] 
**IndModfatturapa** | **int** | CG64_INDMODFATTURAPA - Modalità fattura elettronica&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuna&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Contanti&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Assegno&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Assegno circolare&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Contanti presso tesoreria&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Vaglia cambiario&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Bollettino bancario&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Quietanza erario&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Giroconto su conti di contabilità speciale&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Domiciliazione bancaria&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Domiciliazione postale&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - Trattenuta su somme già riscosse&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - PagoPa&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Rowversion** | **byte[]** | CG64_ROWVERSION - RowVersion | [optional] 
**Tipoeff** | **double** | CG64_TIPOEFF - Tipo scadenza&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Tutti&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Contanti&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Ricevuta bancaria&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Tratta&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Tratta accettata&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Cessione&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Cambiale&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Carta di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Bancomat&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Contrassegno&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Lettera di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - RID&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Leasing&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Rimessa diretta&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Bonifico&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - C/C postale&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - MAV&lt;/li&gt;&lt;/ul&gt; | [optional] 
**ForeignPaymentCodeCO** | [**ForeignPaymentCodeCODTO**](ForeignPaymentCodeCODTO.md) |  | [optional] 
**NationCO** | [**NationCODTO**](NationCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

