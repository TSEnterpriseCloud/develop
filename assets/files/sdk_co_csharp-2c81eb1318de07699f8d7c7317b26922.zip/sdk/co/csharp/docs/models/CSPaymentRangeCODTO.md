# It.TSEnterprise.Sdk.Model.CSPaymentRangeCODTO
MG20_CLIFORSCPAG - CSPaymentRangeCO<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CliforCg44** | **double** | MG20_CLIFOR_CG44 - Codice Cliente / Fornitore | 
**CodScagl** | **double** | MG20_CODSCAGL - Scaglione | 
**DittaCg18** | **double** | MG20_DITTA_CG18 - DittaCg18 | 
**TipocfCg44** | **double** | MG20_TIPOCF_CG44 - Tipo Cliente / Fornitore | 
**ValutaCg08** | **string** | MG20_VALUTA_CG08 - Valuta | 
**CurrencyCO** | [**CurrencyCODTO**](CurrencyCODTO.md) |  | 
**Aimpdoc** | **double** | MG20_AIMPDOC - Limite superiore | [optional] 
**CodPagCg62** | **string** | MG20_CODPAG_CG62 - Condizione pagamento | [optional] 
**Id** | **long** | MG20_ID - Id (Required only in PUT/PATCH) | [optional] 
**IdCg62** | **long** | MG20_ID_CG62 - IdCg62 | [optional] 
**IdmediaCg99** | **double** | MG20_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**IndPagpart** | **double** | MG20_INDPAGPART - Applica condizione di pagamento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - del documento&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - dello scaglione&lt;/li&gt;&lt;/ul&gt; | [optional] 
**PaymentTermCO** | [**PaymentTermCODTO**](PaymentTermCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

