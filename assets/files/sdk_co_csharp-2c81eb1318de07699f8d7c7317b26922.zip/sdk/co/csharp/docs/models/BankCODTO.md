# It.TSEnterprise.Sdk.Model.BankCODTO
CG12_BANCHE - Banca<br>Proprietà chiave:<ul><li><b>CodiceBanca</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodiceBanca** | **double** | CG12_BANCA - ABI-Banca | 
**CodBicswift** | **string** | CG12_CODBICSWIFT - Codice BIC SWIFT | [optional] 
**Descrizione** | **string** | CG12_DESCR - Descrizione | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

