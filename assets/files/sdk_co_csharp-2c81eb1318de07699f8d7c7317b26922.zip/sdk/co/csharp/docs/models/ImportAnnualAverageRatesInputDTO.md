# It.TSEnterprise.Sdk.Model.ImportAnnualAverageRatesInputDTO
Parametri per l'importazione dei cambi medi annuali

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BaseCurrencyIsoCode** | **List&lt;string&gt;** |  | [optional] 
**ReferenceYear** | **int** |  | [optional] 
**Overwrite** | **bool** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

