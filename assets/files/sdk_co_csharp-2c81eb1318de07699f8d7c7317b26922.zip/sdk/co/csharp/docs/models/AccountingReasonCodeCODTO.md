# It.TSEnterprise.Sdk.Model.AccountingReasonCodeCODTO
CG33_TABCAU - Causale contabile<br>Proprietà chiave:<ul><li><b>Codice</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Caualias** | **string** | CG33_CAUALIAS - Alias per ricerca causale contabile | 
**Codice** | **string** | CG33_CODICE - Codice causale | 
**Causalecoll** | **string** | CG33_CAUSALECOLL - Causale collegata | [optional] 
**Causalecolltype** | **double** | CG33_CAUSALECOLLTYPE - Causalecolltype&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Iva&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Contabile&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Scadenze&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Causaleiva** | **string** | CG33_CAUSALEIVA - Causale IVA | [optional] 
**Descr** | **string** | CG33_DESCR - Descrizione | [optional] 
**FlgAcconto** | **double** | CG33_FLGACCONTO - Causale acconto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgAgviag** | **double** | CG33_FLGAGVIAG - Agenzie viaggio&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgAutofatt** | **double** | CG33_FLGAUTOFATT - Autofattura&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgCaufissa** | **double** | CG33_FLGCAUFISSA - Causale fissa&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgComp** | **double** | CG33_FLGCOMP - Competenza esercizio precedente&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgDatiassegno** | **double** | CG33_FLGDATIASSEGNO - Richiesta riferimenti assegno&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgEconto** | **double** | CG33_FLGECONTO - Gest. E/Conto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgFattdiff** | **double** | CG33_FLGFATTDIFF - Rich. data comp. IVA | [optional] 
**FlgGestsez** | **double** | CG33_FLGGESTSEZ - Protocolla movimento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgInsoluti** | **double** | CG33_FLGINSOLUTI - Insoluti&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgIvaedit** | **double** | CG33_FLGIVAEDIT - IVA editoria&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgPortaf** | **double** | CG33_FLGPORTAF - Gest. portafoglio&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgProtsemp** | **double** | CG33_FLGPROTSEMP - Nr. docum. semplificata | [optional] 
**FlgSubforni** | **double** | CG33_FLGSUBFORNI - Subfornitura&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IdCg0z** | **long** | CG33_ID_CG0Z - IdCg0z | [optional] 
**IdCgd1** | **double** | CG33_ID_CGD1 - Classificazione causale | [optional] 
**IdmediaCg99** | **double** | CG33_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**Idprov** | **double** | CG33_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**IndCaubenius** | **double** | CG33_INDCAUBENIUS - Regime del margine&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Analitico&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Globale&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Forfetario&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Normale&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndDaav** | **int** | CG33_INDDAAV - Segno&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Dare&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Avere&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndGestec** | **double** | CG33_INDGESTEC - Gest. E/Conto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Apertura&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Chiusura&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Apertura/chiusura&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndGestfattproforma** | **int** | CG33_INDGESTFATTPROFORMA - Gestione fatture proforma | [optional] 
**IndMonofasersm** | **double** | CG33_INDMONOFASERSM - Operazioni monofase RSM | [optional] 
**IndProteo360** | **double** | CG33_INDPROTEO360 - Aggancio alla procedura Proteo 360 | [optional] 
**IndScadfattproforma** | **int** | CG33_INDSCADFATTPROFORMA - Scadenze in fatture proforma | [optional] 
**IndTipomov** | **int** | CG33_INDTIPOMOV - Tipo operazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - criterio Gestionale      &lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - criterio di Cassa        &lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Gestionale/Cassa         &lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Gestionale/Cassa sospeso &lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Gestionale/Cassa speciale&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Gestionale/Cassa esteso  &lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTipooper** | **double** | CG33_INDTIPOOPER - IndTipooper | [optional] 
**IndTiporeg** | **int** | CG33_INDTIPOREG - Tipo registro&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Acquisti&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Vendite&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Corrispettivi&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Rowversion** | **byte[]** | CG33_ROWVERSION - RowVersion | [optional] 
**Tipoeff** | **int** | CG33_TIPOEFF - Tipo effetti&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Tutti&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Contanti&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Ricevuta bancaria&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Tratta&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Tratta accettata&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Cessione&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Cambiale&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Carta di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Bancomat&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Contrassegno&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Lettera di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - RID&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Leasing&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Rimessa diretta&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Bonifico&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - C/C postale&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - MAV&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Classification** | [**AccountingReasonCodeClassificationCODTO**](AccountingReasonCodeClassificationCODTO.md) |  | [optional] 
**VatCodeReason** | [**AccountingReasonCodeCODTO**](AccountingReasonCodeCODTO.md) |  | [optional] 
**VatCodeReasonConnect** | [**AccountingReasonCodeCODTO**](AccountingReasonCodeCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

