# It.TSEnterprise.Sdk.Model.CalculateExchangeRateParametersDTO
Calcola il cambio valute in base ai parametri forniti

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ValutaRiferimento** | **string** |  | [optional] 
**Valuta** | **string** |  | [optional] 
**Data** | **DateTime** |  | [optional] 
**TipoCambioRichiesto** | **int** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

