# It.TSEnterprise.Sdk.Model.NationCODTO
CG07_TABSTATIEST - Stati esteri<br>Proprietà chiave:<ul><li><b>Codice</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codice** | **double** | CG07_CODICE - Codice | 
**A2iso3166** | **string** | CG07_A2ISO3166 - Alpha-2 ISO 3166 | [optional] 
**A3iso3166** | **string** | CG07_A3ISO3166 - Alpha-3 ISO 3166 | [optional] 
**CodiceCg08** | **string** | CG07_CODICE_CG08 - Divisa | [optional] 
**CodIso** | **string** | CG07_CODISO - Codice ISO | [optional] 
**CodSian** | **double** | CG07_CODSIAN - Codice SIAN | [optional] 
**Crtpiva** | **string** | CG07_CRTPIVA - Caratteri lunghezza partita IVA (separati da /) | [optional] 
**Datacee** | **DateTime** | CG07_DATACEE - Data ingresso CEE | [optional] 
**Datafinblacklist** | **DateTime** | CG07_DATAFINBLACKLIST - Data uscita Black List | [optional] 
**Datainiblacklist** | **DateTime** | CG07_DATAINIBLACKLIST - Data ingresso Black List | [optional] 
**Descr** | **string** | CG07_DESCR - Descrizione | [optional] 
**Desiso3166** | **string** | CG07_DESISO3166 - Descrizione Stato ISO 3166 | [optional] 
**FlgIban** | **int** | CG07_FLGIBAN - Utilizzo IBAN&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgSepa** | **int** | CG07_FLGSEPA - Utilizzo standard SEPA&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IdmediaCg99** | **double** | CG07_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**IndTipostato** | **double** | CG07_INDTIPOSTATO - Tipo Nazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Extracomunitario&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Intracomunitario&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Rep. San Marino&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Leniban** | **int** | CG07_LENIBAN - Lunghezza IBAN | [optional] 
**Numiso3166** | **string** | CG07_NUMISO3166 - Number ISO 3166 | [optional] 
**CurrencyCO** | [**CurrencyCODTO**](CurrencyCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

