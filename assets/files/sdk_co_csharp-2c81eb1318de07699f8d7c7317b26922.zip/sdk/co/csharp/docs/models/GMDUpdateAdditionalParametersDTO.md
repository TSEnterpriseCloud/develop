# It.TSEnterprise.Sdk.Model.GMDUpdateAdditionalParametersDTO
Parametri per scrittura dati General Master Data

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codice** | **int** |  | [optional] 
**RagSoAnag** | **string** |  | [optional] 
**Indirizzo** | **string** |  | [optional] 
**NumCiv** | **string** |  | [optional] 
**Cap** | **string** |  | [optional] 
**Citta** | **string** |  | [optional] 
**Prov** | **string** |  | [optional] 
**CodiceCg07** | **double** |  | [optional] 
**Partiva** | **string** |  | [optional] 
**CodFiscale** | **string** |  | [optional] 
**Tel1Num** | **string** |  | [optional] 
**Fax** | **string** |  | [optional] 
**Tipologia** | **string** |  | [optional] 
**CodLegCg01** | **string** |  | [optional] 
**DescrCg07** | **string** |  | [optional] 
**NationIso** | **string** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

