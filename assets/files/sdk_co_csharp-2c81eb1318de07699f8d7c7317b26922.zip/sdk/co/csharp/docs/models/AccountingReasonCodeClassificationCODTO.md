# It.TSEnterprise.Sdk.Model.AccountingReasonCodeClassificationCODTO
CGD1_TIPOCAUSALE - Classificazione causale<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Tipologia** | **string** | CGD1_TIPOLOGIA - Codice classificazione | 
**Descr** | **string** | CGD1_DESCR - Descrizione classificazione | [optional] 
**Id** | **double** | CGD1_ID - Id classificazione (Required only in PUT/PATCH) | [optional] 
**IdmediaCg99** | **double** | CGD1_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

