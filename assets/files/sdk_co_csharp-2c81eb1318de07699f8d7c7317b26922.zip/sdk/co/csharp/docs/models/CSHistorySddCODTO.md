# It.TSEnterprise.Sdk.Model.CSHistorySddCODTO
MG2E_STORICORID - CSHistorySddCO<br>Proprietà chiave:<ul><li><b>Datavar</b></li><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Datavar** | **DateTime** | MG2E_DATAVAR - Data | 
**Id** | **int** | MG2E_ID - Id | 
**CodBicswift** | **string** | MG2E_CODBICSWIFT - BICSWIFT | [optional] 
**CodClideb** | **string** | MG2E_CODCLIDEB - Codice debitore | [optional] 
**CodIndiv** | **double** | MG2E_CODINDIV - Codice individuale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Utenza&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Matricola&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Codice fiscale&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Codice cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Codice fornitore&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Portafoglio commerciale&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Altro&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndStorno** | **double** | MG2E_INDSTORNO - Facoltà di storno&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Facoltà di storno dopo la scadenza (D+5)&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Facoltà di storno alla scadenza&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Nessuna facoltà di storno per contestazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Nessuna facoltà di storno per la banca domiciliataria&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Esiste diritto al rimborso (D+8 settimane)&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Nessuna facoltà di storno per le caratteristiche del mandato&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTipoinc** | **int** | MG2E_INDTIPOINC - Tipo seq. incasso&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - First&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Recurrent&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Final&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - One-Off&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTiposdd** | **double** | MG2E_INDTIPOSDD - Tipo SDD&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Core&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - B2B&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Ridiban** | **string** | MG2E_RIDIBAN - IBAN | [optional] 
**SoggtitibanCg16** | **int** | MG2E_SOGGTITIBAN_CG16 - Sogg. titolare IBAN | [optional] 
**Tipologia** | **double** | MG2E_TIPOLOGIA - Tipologia&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Consumatore&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Non Consumatore&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Microimpresa&lt;/li&gt;&lt;/ul&gt; | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

