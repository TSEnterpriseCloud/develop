# It.TSEnterprise.Sdk.Model.IntegrativeDeclarationParametersCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Mg28Id** | **int** |  | [optional] 
**DataIniVal** | **DateTime** |  | [optional] 
**DataFineVal** | **DateTime** |  | [optional] 
**IndTipoDich** | **double** |  | [optional] 
**Ammontare** | **double** |  | [optional] 
**IdIntermediario** | **double** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

