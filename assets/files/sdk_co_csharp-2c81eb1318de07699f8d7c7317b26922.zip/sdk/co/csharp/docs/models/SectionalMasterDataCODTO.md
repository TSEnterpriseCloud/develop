# It.TSEnterprise.Sdk.Model.SectionalMasterDataCODTO
CG68_NUMERDESC - Sezionale<br>Proprietà chiave:<ul><li><b>DittaCg18</b></li><li><b>Sezionale</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DittaCg18** | **double** | CG68_DITTA_CG18 - Ditta | 
**Sezionale** | **string** | CG68_SEZIONALE - Sezionale | 
**Caustcoll** | **string** | CG68_CAUSTCOLL - Causale trasporto collegata | [optional] 
**Descsez** | **string** | CG68_DESCSEZ - Descrizione Sezionale | [optional] 
**FlgNoLiqIva** | **int** | CG68_FLGNOLIQIVA - Escludi elaborazioni IVA&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Idagentecoll** | **int** | CG68_IDAGENTECOLL - Agente collegato | [optional] 
**Idprov** | **double** | CG68_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**IndIntra1213** | **double** | CG68_INDINTRA1213 - Modelli INTRA 12 e INTRA 13&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - INTRA 12&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - INTRA 13&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndRegione** | **double** | CG68_INDREGIONE - Regione attività&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - non specificata&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Abruzzo&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Basilicata&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Bolzano&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Calabria&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Campania&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Emilia Romagna&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Friuli Venezia Giulia&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Lazio&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Liguria&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Lombardia&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - Marche&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Molise&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Piemonte&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Puglia&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - Sardegna&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - Sicilia&lt;/li&gt;&lt;li&gt;&lt;i&gt;17&lt;/i&gt; - Toscana&lt;/li&gt;&lt;li&gt;&lt;i&gt;18&lt;/i&gt; - Trento&lt;/li&gt;&lt;li&gt;&lt;i&gt;19&lt;/i&gt; - Umbria&lt;/li&gt;&lt;li&gt;&lt;i&gt;20&lt;/i&gt; - Valle D&#39;Aosta&lt;/li&gt;&lt;li&gt;&lt;i&gt;21&lt;/i&gt; - Veneto&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTipologia** | **double** | CG68_INDTIPOLOGIA - Tipologia&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Iva&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Gestionale area amministrativa&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Gestionale area commerciale&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Gestionale area amministrativa/commerciale&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Registro IVA riepilogativo&lt;/li&gt;&lt;/ul&gt; | [optional] 
**PuntovenCg7a** | **double** | CG68_PUNTOVEN_CG7A - Punto vendita | [optional] 
**StoreCO** | [**StoreCODTO**](StoreCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

