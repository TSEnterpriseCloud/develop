# It.TSEnterprise.Sdk.Model.ImportExportRowResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TypeResult** | **int** | Type Result | [optional] 
**TypeResultDescription** | **string** | Type Result Description | [optional] 
**Description** | **string** | Description | [optional] 
**IsDone** | **bool** | Is Done | [optional] 
**IsImportance** | **bool** | Is Importance | [optional] 
**IsError** | **bool** | Is Error | [optional] 
**IsWarning** | **bool** | Is Warning | [optional] 
**IsInformation** | **bool** | Is Information | [optional] 
**IsCreate** | **bool** | Is Create | [optional] 
**IsUpdate** | **bool** | Is Update | [optional] 
**IsDelete** | **bool** | Is Delete | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

