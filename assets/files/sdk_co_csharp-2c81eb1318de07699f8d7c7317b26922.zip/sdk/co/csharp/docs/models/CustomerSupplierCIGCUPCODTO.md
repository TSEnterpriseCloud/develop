# It.TSEnterprise.Sdk.Model.CustomerSupplierCIGCUPCODTO
CO1I_CFCIGCUP - CustomerSupplierCIGCUPCO<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CliforCg44** | **double** | CO1I_CLIFOR_CG44 - CliforCg44 | 
**DittaCg18** | **double** | CO1I_DITTA_CG18 - Ditta | 
**IdcigcupCo1h** | **int** | CO1I_IDCIGCUP_CO1H - IdcigcupCo1h | 
**TipocfCg44** | **double** | CO1I_TIPOCF_CG44 - TipocfCg44 | 
**CigcuPcode** | [**CIGCUPMasterDataCODTO**](CIGCUPMasterDataCODTO.md) |  | 
**Id** | **int** | CO1I_ID - ID (Required only in PUT/PATCH) | [optional] 
**ProgREf08** | **double** | CO1I_PROGR_EF08 - ProgREf08 | [optional] 
**ProgRMg35** | **int** | CO1I_PROGR_MG35 - ProgRMg35 | [optional] 
**Rowversion** | **byte[]** | CO1I_ROWVERSION - Rowversion | [optional] 
**CompanyBank** | [**CompanyBankCODTO**](CompanyBankCODTO.md) |  | [optional] 
**CsBankCO** | [**CSBankCODTO**](CSBankCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

