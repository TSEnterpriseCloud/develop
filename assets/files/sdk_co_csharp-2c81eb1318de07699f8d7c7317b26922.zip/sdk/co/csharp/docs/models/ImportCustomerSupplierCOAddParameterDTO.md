# It.TSEnterprise.Sdk.Model.ImportCustomerSupplierCOAddParameterDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TypeImportModeCustomerSupplier** | **string** | Type import mode Customer/Supplier&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Search by general master data&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Search by code and verify general master data&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Search by code (with overwriting of non-corresponding data)&lt;/li&gt;&lt;/ul&gt; | [optional] [default to TypeImportModeCustomerSupplierEnum._0]
**InsertCustomerSupplier** | **bool** | Inserting a new Customer/Supplier | [optional] [default to true]
**UpdateExistingCustomerSupplier** | **bool** | Update existing Customer/Supplier | [optional] [default to false]

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

