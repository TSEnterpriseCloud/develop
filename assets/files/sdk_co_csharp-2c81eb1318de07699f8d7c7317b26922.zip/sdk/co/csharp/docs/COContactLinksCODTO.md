# It.TSEnterprise.Sdk.Model.COContactLinksCODTO
CO03_LEGCONTATTO - ContactLinksCO<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodiceCg16** | **int** | CO03_CODICE_CG16 - Codice anagrafica | 
**FlgPref** | **double?** | CO03_FLGPREF - Preferenziale | [optional] 
**Id** | **double?** | CO03_ID - ID (Required only in PUT/PATCH) | [optional] 
**IdCo02** | **double** | CO03_ID_CO02 - Codice contatto | 
**Rowversion** | **byte[]** | CO03_ROWVERSION - RowVersion | [optional] 
**TipoCo01** | **string** | CO03_TIPO_CO01 - Tipo Cont./Rif. Azienda | 
**ContactSubject** | [**COContactSubjectCODTO**](COContactSubjectCODTO.md) |  | 
**ContactType** | [**COContactTypeCODTO**](COContactTypeCODTO.md) |  | 
**GeneralMasterData** | [**COGeneralMasterDataCODTO**](COGeneralMasterDataCODTO.md) |  | 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

