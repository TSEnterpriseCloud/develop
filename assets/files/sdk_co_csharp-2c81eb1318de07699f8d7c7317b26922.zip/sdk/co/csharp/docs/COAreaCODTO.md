# It.TSEnterprise.Sdk.Model.COAreaCODTO
MG08_AREE - AreaCO<br>Proprietà chiave:<ul><li><b>CodiceAreaMG</b></li><li><b>DittaCg18</b></li><li><b>MacroareaMg07</b></li><li><b>TipocfMg07</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodiceAreaMG** | **string** | MG08_AREA - Area | 
**Descrarea** | **string** | MG08_DESCRAREA - Descrizione | [optional] 
**DittaCg18** | **double** | MG08_DITTA_CG18 - Ditta | 
**Idprov** | **int?** | MG08_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**MacroareaMg07** | **string** | MG08_MACROAREA_MG07 - Macroarea | 
**TipocfMg07** | **double?** | MG08_TIPOCF_MG07 - Tipo Cliente / Fornitore&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Zone** | [**List&lt;COZoneCODTO&gt;**](COZoneCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

