# It.TSEnterprise.Sdk.Model.IELayoutCODTO
IE25_TRACCIATI - IELayoutCO<br>Proprietà chiave:<ul><li><b>CodLayout</b></li><li><b>CodStructureType</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BytesToExclude** | **double?** | IE25_BYTEDAESCL - Bytes da escludere | [optional] 
**CodLayout** | **string** | IE25_TRACCIATO - Tracciato | 
**CodStructureSubType** | **double** | IE25_SOTTOTIPO_IE37 - Sottotipo struttura | 
**CodStructureType** | **int** | IE25_STRUTTURA_IE21 - Struttura | 
**Description** | **string** | IE25_DESCRIZIONE - Descrizione tracciato | 
**FilePath** | **string** | IE25_NOMEFILE - Percorso e nome file | [optional] 
**HeaderWithFieldNames** | **double?** | IE25_FLGINTESTAZIONE - Intestazione con nomi campi&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Note** | **string** | IE25_NOTE - Note | [optional] 
**RowLength** | **double?** | IE25_LENREC - Lunghezza riga | [optional] 
**TableFile** | **string** | IE25_TABELLAFILE - Tabella file | [optional] 
**TableSingle** | **string** | IE25_TABELLA - Tabella | [optional] 
**TypeCharset** | **int?** | IE25_INDCHARSET - Codifica&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Ansi&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Utf-8&lt;/li&gt;&lt;/ul&gt; | [optional] 
**TypeEndRow** | **double?** | IE25_INDFINERIGA - Indicatore fine riga&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - CR+LF&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - CR&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - LF&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;/ul&gt; | [optional] 
**TypeFile** | **double?** | IE25_INDTIPOFILE - Tipo file&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Testo&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Testo delimitato&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Binario&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Excel(Xls)&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - XML&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Tabella&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Excel(Xlsx)&lt;/li&gt;&lt;/ul&gt; | [optional] 
**TypeImpExp** | **double?** | IE25_INDIMPEXP - Modalità Import/Export&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Import/Export&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Import&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Export&lt;/li&gt;&lt;/ul&gt; | [optional] 
**TypeRecord** | **double?** | IE25_INDGESTTIPIREC - Gestione tipi record&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**TypeSeparation** | **double?** | IE25_INDSEPARATORE - Separatore&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - ,&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Punto (.)&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Barra (/)&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Tab&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - !&lt;/li&gt;&lt;/ul&gt; | [optional] 
**TypeTextQualification** | **int?** | IE25_INDQUALIFICATESTO - Qualificatore di testo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Virgolette (\&quot;)&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Apice (&#39;)&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Virgolette (\&quot;) e raddoppio virgolette presenti&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Apice (&#39;) e raddoppio apici presenti&lt;/li&gt;&lt;/ul&gt; | [optional] 
**StructureSubType** | [**IEStructureSubTypeCODTO**](IEStructureSubTypeCODTO.md) |  | 
**StructureType** | [**IEStructureTypeCODTO**](IEStructureTypeCODTO.md) |  | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

