# It.TSEnterprise.Sdk.Model.COImportExportHeadResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**GuidResult** | **string** | Guid Result | [optional] 
**TotRowImpExp** | **int** | total rows processed | [optional] 
**ImpExpWithErrors** | **bool** | Import/Export with Error | [optional] 
**RowElab** | [**List&lt;COImportExportRowResultDTO&gt;**](COImportExportRowResultDTO.md) | Information/Error rows | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

