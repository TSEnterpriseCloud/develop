# It.TSEnterprise.Sdk.Model.COMacroCategoryCODTO
MG10_MACROCAT - MacroCategoryCO<br>Proprietà chiave:<ul><li><b>DittaCg18</b></li><li><b>Macrocat</b></li><li><b>Tipocf</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Descrmacrocat** | **string** | MG10_DESCRMACROCAT - Descrizione | [optional] 
**DittaCg18** | **double** | MG10_DITTA_CG18 - Ditta | 
**Macrocat** | **string** | MG10_MACROCAT - Macrocategoria | 
**Tipocf** | **double?** | MG10_TIPOCF - Tipo Cli/For&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Categorie** | [**List&lt;COCategoryCODTO&gt;**](COCategoryCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

