# It.TSEnterprise.Sdk.Model.IEStructureSubTypeCODTO
IE37_SOTTOTIPI - IEStructureSubTypeCO<br>Proprietà chiave:<ul><li><b>CodStructureSubType</b></li><li><b>CodStructureType</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodStructureSubType** | **double** | IE37_SOTTOTIPO - Sottotipo struttura | 
**CodStructureType** | **int** | IE37_STRUTTURA_IE21 - Struttura | 
**Description** | **string** | IE37_DESCRIZIONE - Descrizione Sottotipo | 
**StructureType** | [**IEStructureTypeCODTO**](IEStructureTypeCODTO.md) |  | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

