# It.TSEnterprise.Sdk.Model.SearchGroupDTO
DTO that identifies a group of search criteria

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Items** | [**List&lt;OneOfSearchNodeDTOSearchElementDTOSearchGroupDTO&gt;**](OneOfSearchNodeDTOSearchElementDTOSearchGroupDTO.md) | Items list to apply: any element can be a &#39;SearchGroupDTO&#39; or a &#39;SearchElementDTO&#39; | [optional] 
**Operator** | **SearchLogicalOperators** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

