# It.TSEnterprise.Sdk.Model.COUnitOfMeasureCODTO
CG0C_UNITAMISURA - UnitOfMeasureCO<br>Proprietà chiave:<ul><li><b>DittaCg18</b></li><li><b>Umsigla</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Descr** | **string** | CG0C_DESCR - Descrizione | [optional] 
**DittaCg18** | **double** | CG0C_DITTA_CG18 - Ditta | 
**Fattconv** | **double?** | CG0C_FATTCONV - Fattore di conversione | [optional] 
**IndOperatore** | **double?** | CG0C_INDOPERATORE - Operatore di conversione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Moltiplicazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Divisione&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Umsigla** | **string** | CG0C_UMSIGLA - Sigla da visualizzare | 
**UmsiglaCg0b** | **string** | CG0C_UMSIGLA_CG0B - UM del SI corrispondente | 
**Sigla** | [**COUMCodeCODTO**](COUMCodeCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

