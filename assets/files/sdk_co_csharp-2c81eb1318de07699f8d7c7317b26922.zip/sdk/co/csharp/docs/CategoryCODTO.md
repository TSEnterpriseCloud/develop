# It.TSEnterprise.Sdk.Model.CategoryCODTO
MG11_CATEG - Categoria<br>Proprietà chiave:<ul><li><b>Categ</b></li><li><b>DittaCg18</b></li><li><b>MacrocatMg10</b></li><li><b>TipocfMg10</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Categ** | **string** | MG11_CATEG - Categoria | 
**Descrcat** | **string** | MG11_DESCRCAT - Descrizione | [optional] 
**DittaCg18** | **double?** | MG11_DITTA_CG18 - Ditta | [optional] 
**MacrocatMg10** | **string** | MG11_MACROCAT_MG10 - Macrocategoria | 
**TipocfMg10** | **double?** | MG11_TIPOCF_MG10 - Tipo Cli/For&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

