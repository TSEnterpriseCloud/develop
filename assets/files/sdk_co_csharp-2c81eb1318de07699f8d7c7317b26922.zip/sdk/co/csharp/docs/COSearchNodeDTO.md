# It.TSEnterprise.Sdk.Model.COSearchNodeDTO
DTO that identifies a search criteria node (abstract)

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Operator** | **COSearchLogicalOperators** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

