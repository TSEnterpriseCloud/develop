# It.TSEnterprise.Sdk.Model.VatCodeCODTO
CG28_TABCODIVA - Codice IVA<br>Proprietà chiave:<ul><li><b>Codice</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Aliqivavent** | **double?** | CG28_ALIQIVAVENT - % acquisti in ventilazione | [optional] 
**Annotazioni** | **string** | CG28_ANNOTAZIONI - Annotazioni su fatture di vendita e sui registri IVA art.21 comma 6 DPR 633/72 | [optional] 
**Codice** | **string** | CG28_CODICE - Codice aliquota | 
**Codiceagr** | **string** | CG28_CODICEAGR - Codice IVA per compensazione agricoltura | [optional] 
**CodiceOss** | **string** | CG28_OSSCOD_CG28 - Codice IVA correlato | [optional] 
**CodPlafond** | **double?** | CG28_CODPLAFOND - Plafond&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No plafond&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Esportazioni art.8 1°c. a/b, 9 1°c.-Cessioni art.8 1°c. c,2°c.&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Acquisti interni art.8 2°c., 8 bis 2°c., 9 2°c.&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Importazioni art.8 2°c., 68 l.a, 8 bis, 9 2°c.&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Acquisti intracomunitari art. 42 1°c.&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Cessioni intracomunitarie art. 41 2°c.&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Cessioni art.8 bis, 1°c. (no lettera intento)&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Descrizione** | **string** | CG28_DESCR - Descrizione | 
**FlgAgri** | **double?** | CG28_FLGAGRI - Indicare se codice IVA utilizzato per agricoltura&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgAllclifor** | **double?** | CG28_FLGALLCLIFOR - Progressivi aliquota IVA inclusi negli allegati clienti fornitori&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgAssport398** | **double?** | CG28_FLGASSPORT398 - Soc. sportiva dilettantistica (L.398/91)&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgAutoue** | **double?** | CG28_FLGAUTOUE - Vendita auto UE L. 286&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgCorrVent** | **double?** | CG28_FLGCORRVENT - Aliquota IVA utilizzata per la registrazione dei corrispettivi da ventilare&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgEscludiblacklist** | **double?** | CG28_FLGESCLUDIBLACKLIST - Escludi da black list&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgImpostadibollo** | **int?** | CG28_FLGIMPOSTADIBOLLO - Imposta di bollo applicabile&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgIndet** | **double?** | CG28_FLGINDET - IVA indetraibile&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgIvaedit** | **double?** | CG28_FLGIVAEDIT - Indicare se codice IVA utilizzato per editoria&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Non movimentato&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Movimentato&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgMonofasersm** | **double?** | CG28_FLGMONOFASERSM - Monofase Repubblica di San Marino | [optional] 
**FlgMossgest** | **int?** | CG28_FLGMOSSGEST - One Stop Shop (OSS)&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgMossrid** | **int?** | CG28_FLGMOSSRID - Aliquota ridotta&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgNotvar** | **double?** | CG28_FLGNOTVAR - Indicare se codice IVA utilizzato per note variazioni IVA&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgSospimp** | **double?** | CG28_FLGSOSPIMP - IVA esigibilità differita&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Immediata&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Differita Enti Pubblici&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Differita altre società&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Enti pubblici Art.17-ter (Split Payment)&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Idprov** | **double?** | CG28_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**Impostamonofasersm** | **double?** | CG28_IMPOSTAMONOFASERSM - Importo imposta fissa | [optional] 
**IndNatassoswCg2n** | **int?** | CG28_INDNATASSOSW_CG2N - Natura Assosoftware | [optional] 
**IndNatura** | **int?** | CG28_INDNATURA - Natura | [optional] 
**IndStaper** | **double?** | CG28_INDSTAPER - Standard/Pers.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Standard&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Personalizzato&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Indtipopart** | **double?** | CG28_INDTIPOPART - Indtipopart&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - NessunValore&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Operazioni con IVA non esposta in fattura&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Operazioni imponibili (es.: reverse charge)&lt;/li&gt;&lt;/ul&gt; | [optional] 
**MosscodCg07** | **double?** | CG28_MOSSCOD_CG07 - Codice Stato | [optional] 
**Mossperc** | **double?** | CG28_MOSSPERC - VAT rate (%) | [optional] 
**Note** | **string** | CG28_NOTE - Note | [optional] 
**Percforf** | **double?** | CG28_PERCFORF - % forfetizzazione editoria/agricoltura | [optional] 
**Percindet** | **double?** | CG28_PERCINDET - % assoggettamento ad indetraibilità | [optional] 
**Perciva** | **double?** | CG28_PERCIVA - % assoggettamento aliquota | [optional] 
**Percmonofasersm** | **double?** | CG28_PERCMONOFASERSM - % Monofase | [optional] 
**RowVersion** | **byte[]** | CG28_ROWVERSION - RowVersion | [optional] 
**StdcodivarifCg28** | **string** | CG28_STDCODIVARIF_CG28 - StdcodivarifCg28 | [optional] 
**Tipologia** | **double?** | CG28_TIPOLOGIA - Tipologia&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Imponibile&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Non imponibile&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Esente&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Escluso&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Fuori campo IVA&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Verslynfa** | **string** | CG28_VERSLYNFA - Verslynfa | [optional] 
**IdExtendedAttributeEntity** | **int** |  | [optional] 
**IdExtendedAttributeSubEntity** | **int** |  | [optional] 
**NationCO** | [**NationCODTO**](NationCODTO.md) |  | [optional] 
**NatureAssCO** | [**NatureAssCODTO**](NatureAssCODTO.md) |  | [optional] 
**NatureEsCO** | [**NatureEsCODTO**](NatureEsCODTO.md) |  | [optional] 
**VatCodeCOAgr** | [**VatCodeCODTO**](VatCodeCODTO.md) |  | [optional] 
**VatCodeCOAIRif** | [**VatCodeCODTO**](VatCodeCODTO.md) |  | [optional] 
**VatCodeCOOss** | [**VatCodeCODTO**](VatCodeCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

