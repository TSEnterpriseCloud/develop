# It.TSEnterprise.Sdk.Api.IEServiceCOApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**ApiV1EnvironmentCOIEServiceCOGuidProcessGet**](IEServiceCOApi.md#apiv1environmentcoieservicecoguidprocessget) | **GET** /api/v1/{environment}/CO/IEServiceCO/{GuidProcess} | Get by Guid Session result of import/export |

<a id="apiv1environmentcoieservicecoguidprocessget"></a>
# **ApiV1EnvironmentCOIEServiceCOGuidProcessGet**
> ImportExportResultDTO ApiV1EnvironmentCOIEServiceCOGuidProcessGet (string guidProcess, string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null)

Get by Guid Session result of import/export

Get by Guid Session result of import/export

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentCOIEServiceCOGuidProcessGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new IEServiceCOApi(config);
            var guidProcess = "guidProcess_example";  // string | Guid to get the process import/export
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get by Guid Session result of import/export
                ImportExportResultDTO result = apiInstance.ApiV1EnvironmentCOIEServiceCOGuidProcessGet(guidProcess, environment, authorizationScope, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling IEServiceCOApi.ApiV1EnvironmentCOIEServiceCOGuidProcessGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentCOIEServiceCOGuidProcessGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get by Guid Session result of import/export
    ApiResponse<ImportExportResultDTO> response = apiInstance.ApiV1EnvironmentCOIEServiceCOGuidProcessGetWithHttpInfo(guidProcess, environment, authorizationScope, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling IEServiceCOApi.ApiV1EnvironmentCOIEServiceCOGuidProcessGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **guidProcess** | **string** | Guid to get the process import/export |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**ImportExportResultDTO**](ImportExportResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Import/Export result |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | In case of errors in the business logic: the content of the response contains the validation messages produced |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

