# It.TSEnterprise.Sdk.Model.COGrouping3CODTO
MG33_RAGGRCF3 - Grouping3CO<br>Proprietà chiave:<ul><li><b>CodRaggrcf3</b></li><li><b>DittaCg18</b></li><li><b>Tipocf</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodRaggrcf3** | **string** | MG33_CODRAGGRCF3 - Raggruppamento 3 | 
**Descraggrcf3** | **string** | MG33_DESCRAGGRCF3 - Descrizione | [optional] 
**DittaCg18** | **double** | MG33_DITTA_CG18 - Ditta | 
**IdmediaCg99** | **double?** | MG33_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**Idprov** | **int?** | MG33_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**Tipocf** | **double?** | MG33_TIPOCF - Tipo Cli/For&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

