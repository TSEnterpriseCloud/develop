# It.TSEnterprise.Sdk.Model.COImportExportResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**GuidSession** | **string** | Guid Process | [optional] 
**StateProcess** | **string** | State Process | [optional] 
**IdStateProcess** | **long** | Id State Process | [optional] 
**HeadProcess** | [**COImportExportHeadResultDTO**](COImportExportHeadResultDTO.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

