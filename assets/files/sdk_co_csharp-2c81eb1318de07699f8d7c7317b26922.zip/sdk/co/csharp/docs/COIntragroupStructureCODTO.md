# It.TSEnterprise.Sdk.Model.COIntragroupStructureCODTO
IntragroupStructureCO<br>Proprietà chiave:<ul><li><b>Codice</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodAnagGen** | **int?** | Codice anagrafica | [optional] 
**Codice** | **double** | CGC0_CODICE - Codice | 
**CodIntercompany** | **int?** | Codice intercompany | [optional] 
**Descr** | **string** | CGC0_DESCR - Descrizione | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

