# It.TSEnterprise.Sdk.Model.ProvinceCODTO
CP02_PROVINCIA -  Provincia <br>Proprietà chiave:<ul><li><b>IdProvince</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Acronym** | **string** | CP02_SIGLA - Sigla provincia | 
**IdProvince** | **long** | CP02_ID - Cod. Provincia | 
**IdRegion** | **int** | CP02_IDREGIONE_CP01 - Cod. Regione | 
**IstatCapitalCityCode** | **string** | CP02_CODISTATCAPOLUOGO - Codice ISTAT capoluogo | 
**IstatCode** | **string** | CP02_CODISTAT - Codici Istat | 
**Name** | **string** | CP02_DENOMINAZIONE -  Provincia  | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

