# It.TSEnterprise.Sdk.Model.CSWithEffectivePaymentConditionParametersDTO
Parametri per lettura cli/for con condizione di pagamento in base agli scaglioni

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdCliFor** | **int** |  | [optional] 
**Valuta** | **string** |  | [optional] 
**ImpTotale** | **double?** |  | [optional] 
**ImpTotaleVal** | **double?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

