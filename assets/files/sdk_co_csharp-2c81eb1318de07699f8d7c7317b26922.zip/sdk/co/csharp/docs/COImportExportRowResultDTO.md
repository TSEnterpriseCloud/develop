# It.TSEnterprise.Sdk.Model.COImportExportRowResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TypeResult** | **int** | Type Result | [optional] 
**TypeResultDescription** | **string** | Type Result Description | [optional] 
**Description** | **string** | Description | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

