# It.TSEnterprise.Sdk.Model.COBankCODTO
CG12_BANCHE - Banca<br>Proprietà chiave:<ul><li><b>CodiceBanca</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodBicswift** | **string** | CG12_CODBICSWIFT - Codice BIC SWIFT | [optional] 
**CodiceBanca** | **double** | CG12_BANCA - ABI-Banca | 
**Descrizione** | **string** | CG12_DESCR - Descrizione | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

