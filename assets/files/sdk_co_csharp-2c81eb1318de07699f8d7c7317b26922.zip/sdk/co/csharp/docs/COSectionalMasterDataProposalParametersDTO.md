# It.TSEnterprise.Sdk.Model.COSectionalMasterDataProposalParametersDTO
It proposes the sectional/s and any protocols based on the parameters provided

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Anno** | **double** |  | [optional] 
**Causale** | **string** |  | [optional] 
**CodAttivita** | **double?** |  | [optional] 
**CalcolaProtocollo** | **bool** |  | [optional] 
**TipoMovimento** | **double** |  | [optional] 
**IgnoraCodAttivita** | **bool** |  | [optional] 
**IgnoraProtocollazioneMovimenti** | **bool** |  | [optional] 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

