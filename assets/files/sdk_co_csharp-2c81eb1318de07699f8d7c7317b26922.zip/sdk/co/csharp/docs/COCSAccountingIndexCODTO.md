# It.TSEnterprise.Sdk.Model.COCSAccountingIndexCODTO
MGA3_CATCPARCF - Indice contabile<br>Proprietà chiave:<ul><li><b>CodCat</b></li><li><b>DittaCg18</b></li><li><b>TipocfCg44</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodCat** | **string** | MGA3_CODCAT -  Codice | 
**Descr** | **string** | MGA3_DESCR - Descrizione | [optional] 
**DittaCg18** | **double** | MGA3_DITTA_CG18 - Ditta | 
**TipocfCg44** | **double** | MGA3_TIPOCF_CG44 - Tipo cliente fornitore | 
**ExtensionData** | [**List&lt;COStringObjectKeyValuePair&gt;**](COStringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

