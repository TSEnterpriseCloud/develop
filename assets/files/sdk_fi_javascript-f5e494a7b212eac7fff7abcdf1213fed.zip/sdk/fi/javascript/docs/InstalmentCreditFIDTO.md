# TseCloudFi.InstalmentCreditFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**debitore** | **String** | EF03_DEBITORE - Debitore | [optional] 
**dittaCg18** | **Number** | EF03_DITTA_CG18 - Codice ditta | 
**dittagirEf01** | **Number** | EF03_DITTAGIR_EF01 - DittagirEf01 | [optional] 
**dittaricEf01** | **Number** | EF03_DITTARIC_EF01 - DittaricEf01 | [optional] 
**id** | **Number** | EF03_ID - Id (Required only in PUT/PATCH) | [optional] 
**idEf01** | **Number** | EF03_ID_EF01 - IdEf01 | 
**idgirEf01** | **Number** | EF03_IDGIR_EF01 - IdgirEf01 | [optional] 
**idricEf01** | **Number** | EF03_IDRIC_EF01 - IdricEf01 | [optional] 
**numregCo99** | **String** | EF03_NUMREG_CO99 - NumregCo99 | 
**numreggirEf01** | **String** | EF03_NUMREGGIR_EF01 - NumreggirEf01 | [optional] 
**numregricEf01** | **String** | EF03_NUMREGRIC_EF01 - NumregricEf01 | [optional] 
**piazza** | **String** | EF03_PIAZZA - Piazza | [optional] 
**progEffEf01** | **Number** | EF03_PROGEFF_EF01 - ProgEffEf01 | 
**progEffgirEf01** | **Number** | EF03_PROGEFFGIR_EF01 - ProgEffgirEf01 | [optional] 
**progEffricEf01** | **Number** | EF03_PROGEFFRIC_EF01 - ProgEffricEf01 | [optional] 
**rigacontEf01** | **Number** | EF03_RIGACONT_EF01 - RigacontEf01 | 
**rigacontgirEf01** | **Number** | EF03_RIGACONTGIR_EF01 - RigacontgirEf01 | [optional] 
**rigacontricEf01** | **Number** | EF03_RIGACONTRIC_EF01 - RigacontricEf01 | [optional] 
**rowversion** | **Blob** | EF03_ROWVERSION - Rowversion | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


