# TseCloudFi.StagePaymentInstalmentAndHistoryParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instalmentId** | **Number** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**manualOperation** | **Boolean** |  | [optional] 
**createStage** | **Boolean** |  | [optional] 
**sendingRecipientAddress** | **Boolean** |  | [optional] 
**transferType** | [**ETransferType**](ETransferType.md) |  | [optional] 
**indPresentation** | [**EPresentationBank**](EPresentationBank.md) |  | [optional] 
**presentationBankId** | **Number** |  | [optional] 
**presentationBankProgr** | **Number** |  | [optional] 
**indBankFilter** | [**EFilterBank**](EFilterBank.md) |  | [optional] 
**transferModeType** | [**ETransferModeType**](ETransferModeType.md) |  | [optional] 
**recipientType** | [**ERecipientType**](ERecipientType.md) |  | [optional] 
**recoverNegativeInstalment** | [**ERecoverNegativeInstalment**](ERecoverNegativeInstalment.md) |  | [optional] 
**groupingInstalment** | [**EGroupingInstalmentPayment**](EGroupingInstalmentPayment.md) |  | [optional] 
**instalmentType** | **String** |  | [optional] 
**movementType** | **String** |  | [optional] 
**currency** | **String** |  | [optional] 
**creationDate** | **Date** |  | [optional] 
**registrationDate** | **Date** |  | [optional] 
**indSuspended** | [**ESuspended**](ESuspended.md) |  | [optional] 
**indOrderingPayment** | [**EOrderingPayment**](EOrderingPayment.md) |  | [optional] 
**partialPayment** | **Boolean** |  | [optional] 
**reasonForPayment** | **String** |  | [optional] 
**reasonForSepaPayment** | **String** |  | [optional] 
**bankId** | **Number** |  | [optional] 
**paymentAmount** | **Number** |  | [optional] 
**indPaymentGroupingMode** | [**EPaymentGroupingMode**](EPaymentGroupingMode.md) |  | [optional] 
**amountToSelect** | **Number** |  | [optional] 
**externalSearchGroup** | [**[StageInstalmentAndHistoryParametersDTOExternalSearchGroupInner]**](StageInstalmentAndHistoryParametersDTOExternalSearchGroupInner.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


