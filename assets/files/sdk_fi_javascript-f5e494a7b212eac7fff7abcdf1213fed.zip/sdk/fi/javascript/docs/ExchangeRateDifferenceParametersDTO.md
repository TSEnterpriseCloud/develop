# TseCloudFi.ExchangeRateDifferenceParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amountInCurrencyReg** | **Number** |  | [optional] 
**amountInReg** | **Number** |  | [optional] 
**currencyReg** | **String** |  | [optional] 
**exchangeDifferenceMode** | **Number** |  | [optional] 
**exchangeReg** | **Number** |  | [optional] 
**id** | **Number** |  | [optional] 
**accountingReasonCode** | **String** |  | [optional] 
**registrationDate** | **Date** |  | [optional] 
**typeReg** | **Number** |  | [optional] 


