# TseCloudFi.GLEntryNumregResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numregResult** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


