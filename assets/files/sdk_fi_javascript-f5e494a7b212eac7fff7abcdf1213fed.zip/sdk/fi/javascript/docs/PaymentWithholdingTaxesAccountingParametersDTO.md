# TseCloudFi.PaymentWithholdingTaxesAccountingParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ids** | **[Number]** |  | [optional] 
**accountingReasonCode** | **String** |  | [optional] 
**additionalDescription** | **String** |  | [optional] 
**registrationDate** | **Date** |  | [optional] 
**documentDate** | **Date** |  | [optional] 
**paymentYearRA** | **Number** |  | [optional] 
**paymentMonthRA** | **Number** |  | [optional] 
**paymentDayRA** | **Number** |  | [optional] 
**abiCodeRA** | **Number** |  | [optional] 
**cabCodeRA** | **Number** |  | [optional] 
**paymentYearRP** | **Number** |  | [optional] 
**paymentMonthRP** | **Number** |  | [optional] 
**paymentDayRP** | **Number** |  | [optional] 
**abiCodeRP** | **Number** |  | [optional] 
**cabCodeRP** | **Number** |  | [optional] 
**treasuryAccountId** | **Number** |  | [optional] 
**socialSecurityAccountId** | **Number** |  | [optional] 
**bankAccountId** | **Number** |  | [optional] 
**wtTotalRA** | **Number** |  | [optional] 
**wtTotalRP** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


