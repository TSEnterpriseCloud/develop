# TseCloudFi.SavePaymentDispositionResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**executionResult** | **Boolean** |  | [optional] 
**collectionBnkId** | **Number** |  | [optional] 
**numordpbonif** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


