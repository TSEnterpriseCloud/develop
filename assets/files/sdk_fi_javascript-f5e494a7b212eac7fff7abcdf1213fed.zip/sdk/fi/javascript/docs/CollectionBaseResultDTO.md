# TseCloudFi.CollectionBaseResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | [**[BaseEntity]**](BaseEntity.md) |  | [optional] 


