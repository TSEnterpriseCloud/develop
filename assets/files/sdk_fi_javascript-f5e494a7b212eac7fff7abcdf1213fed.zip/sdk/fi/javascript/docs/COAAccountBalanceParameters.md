# TseCloudFi.COAAccountBalanceParameters

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountId** | **Number** |  | [optional] 
**custSupplId** | **Number** |  | [optional] 
**startDate** | **Date** |  | [optional] 
**endDate** | **Date** |  | [optional] 
**year** | **Number** |  | [optional] 
**progrYear** | **Number** |  | [optional] 
**currencies** | **[String]** |  | [optional] 
**sites** | **[String]** |  | [optional] 
**holdings** | **[String]** |  | [optional] 
**movementTypes** | **[Number]** |  | [optional] 
**indTipoData** | **Number** |  | [optional] 
**sqlFilter** | **String** |  | [optional] 
**paramFilter** | [**QuerySqlParamsValues**](QuerySqlParamsValues.md) |  | [optional] 
**sqlMovementType** | **String** |  | [optional] 
**parentHolding** | **Number** |  | [optional] 
**indTipoSaldo** | **Number** |  | [optional] 
**listHolding** | **[Number]** |  | [optional] 


