# TseCloudFi.TSPaaSShowInvoicePDFParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idXmlInvoice** | **String** |  | [optional] 
**idSDI** | **String** |  | [optional] 
**hubid** | **String** |  | [optional] 
**mode** | **String** |  | [optional] 
**outputType** | **String** |  | [optional] 


