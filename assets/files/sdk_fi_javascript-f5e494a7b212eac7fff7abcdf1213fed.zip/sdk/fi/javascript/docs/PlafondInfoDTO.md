# TseCloudFi.PlafondInfoDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dataDoc** | **Date** |  | [optional] 
**dataReg** | **Date** |  | [optional] 
**dataRegIva** | **Date** |  | [optional] 
**codAttivita** | **Number** |  | [optional] 


