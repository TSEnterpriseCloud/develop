# TseCloudFi.ApplicationVersionResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**major** | **Number** |  | [optional] 
**minor** | **Number** |  | [optional] 
**patch** | **Number** |  | [optional] 
**build** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


