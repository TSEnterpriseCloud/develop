# TseCloudFi.InstalmentsPairingBlockedParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numReg** | **String** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


