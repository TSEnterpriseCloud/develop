# TseCloudFi.InstalmentsPairingParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tipoAssociazioneScadenze** | **Number** |  | [optional] 
**modalitaAssociazioneScadenze** | **Number** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**selectedID** | **[String]** |  | [optional] 
**cambioData** | **Date** |  | [optional] 
**cambioValore** | **Number** |  | [optional] 
**causaleContabile** | **String** |  | [optional] 
**modalitaDifferenzaCambi** | **Number** |  | [optional] 
**diffCambiID** | **[String]** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


