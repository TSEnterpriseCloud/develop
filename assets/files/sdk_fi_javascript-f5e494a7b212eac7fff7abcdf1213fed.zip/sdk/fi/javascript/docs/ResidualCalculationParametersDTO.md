# TseCloudFi.ResidualCalculationParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rowIdStage** | **Number** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**currency** | **String** |  | [optional] 
**dataCambio** | **Date** |  | [optional] 
**cambio** | **Number** |  | [optional] 


