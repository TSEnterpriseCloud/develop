# TseCloudFi.GetDocumentAccountResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**executionResult** | **Boolean** |  | [optional] 
**idaccountCg24** | **Number** |  | [optional] 
**suddconti** | **Number** |  | [optional] 
**idreverse** | **Number** |  | [optional] 
**conto** | **String** |  | [optional] 
**codeFormatted** | **String** |  | [optional] 
**contoDescr** | **String** |  | [optional] 
**vatTypeCode** | **Number** |  | [optional] 
**vatTypeDescr** | **String** |  | [optional] 
**reversTypeCode** | **Number** |  | [optional] 
**reversTypeDescr** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


