# TseCloudFi.ResidualCalculationResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**residualAmount** | **Number** |  | [optional] 
**debitCreditIndicator** | **Number** |  | [optional] 
**residualAmountCC** | **Number** |  | [optional] 
**dataCambio** | **Date** |  | [optional] 
**cambio** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


