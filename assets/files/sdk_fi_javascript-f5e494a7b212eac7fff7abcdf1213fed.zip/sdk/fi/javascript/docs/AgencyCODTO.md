# TseCloudFi.AgencyCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codBanca** | **Number** | CG13_BANCA_CG12 - ABI-Banca | 
**codice** | **Number** | CG13_CODCAB - CAB agenzia | 
**descrizione** | **String** | CG13_DESCR - Descrizione | [optional] 
**localita** | **String** | CG13_LOCALITA - Localita | [optional] 
**prov** | **String** | CG13_PROV - Prov | [optional] 
**bankCO** | [**BankCODTO**](BankCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


