# TseCloudFi.CreateMultiGLEntryJobParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**GLEntryFIMultipleCreateParametersDTO**](GLEntryFIMultipleCreateParametersDTO.md) |  | [optional] 
**idWorkflowProcess** | **String** |  | [optional] 
**environment** | **String** |  | [optional] 
**module** | **String** |  | [optional] 
**job** | **String** |  | [optional] 
**priority** | **Number** |  | [optional] 
**runSync** | **Boolean** |  | [optional] 
**detailLifeHours** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


