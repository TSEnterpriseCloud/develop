# TseCloudFi.InstalmentSuspensionCommissionLiquidationResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**executionResult** | **Boolean** |  | [optional] 
**changedInstalmentIds** | **[Number]** |  | [optional] 
**errorInstalmentIds** | [**[Int64StringValueTuple]**](Int64StringValueTuple.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


