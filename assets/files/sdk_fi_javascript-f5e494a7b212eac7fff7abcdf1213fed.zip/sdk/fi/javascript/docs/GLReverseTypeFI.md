# TseCloudFi.GLReverseTypeFI

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idEntityWithDescriptions** | **Number** |  | [optional] 
**reverseTypeCode** | **Number** |  | [optional] 
**reverseTypeDescription** | **String** |  | [optional] 
**languageDescriptionFI** | [**[LanguageDescriptionFI]**](LanguageDescriptionFI.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


