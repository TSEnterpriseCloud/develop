# TseCloudFi.CompanyBankFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bancaCg12** | **Number** | EF08_BANCA_CG12 - Abi | [optional] 
**conanticipiCg24** | **String** | EF08_CONANTICIPI_CG24 - ConanticipiCg24 | [optional] 
**conccbancaCg24** | **String** | EF08_CONCCBANCA_CG24 - ConccbancaCg24 | [optional] 
**conspcommCg24** | **String** | EF08_CONSPCOMM_CG24 - ConspcommCg24 | [optional] 
**descr** | **String** | EF08_DESCR - Banca | [optional] 
**dittaCg18** | **Number** | EF08_DITTA_CG18 - Ditta | 
**flgPref** | **Number** | EF08_FLGPREF - Banca preferenziale | 
**gruanticipiCg24** | **Number** | EF08_GRUANTICIPI_CG24 - GruanticipiCg24 | [optional] 
**gruccbancaCg24** | **Number** | EF08_GRUCCBANCA_CG24 - GruccbancaCg24 | [optional] 
**gruspcommCg24** | **Number** | EF08_GRUSPCOMM_CG24 - GruspcommCg24 | [optional] 
**id** | **Number** | EF08_ID - ID (Required only in PUT/PATCH) | [optional] 
**idanticipiCg24** | **Number** | EF08_IDANTICIPI_CG24 - IdanticipiCg24 | [optional] 
**idccbancaCg24** | **Number** | EF08_IDCCBANCA_CG24 - IdccbancaCg24 | [optional] 
**idspcommCg24** | **Number** | EF08_IDSPCOMM_CG24 - IdspcommCg24 | [optional] 
**progR** | **Number** | EF08_PROGR -  Progressivo | 
**rowversion** | **Blob** | EF08_ROWVERSION - Rowversion | [optional] 
**advancedPaymentAccount** | [**COAAccountDescrFIDTO**](COAAccountDescrFIDTO.md) |  | [optional] 
**bankAccount** | [**COAAccountDescrFIDTO**](COAAccountDescrFIDTO.md) |  | [optional] 
**commissionFeesAccount** | [**COAAccountDescrFIDTO**](COAAccountDescrFIDTO.md) |  | [optional] 
**companyBankMiscellaneousAccountFI** | [**[CompanyBankMiscellaneousAccountFIDTO]**](CompanyBankMiscellaneousAccountFIDTO.md) |  | [optional] 
**companyBankPresentationAccountFI** | [**[CompanyBankPresentationAccountFIDTO]**](CompanyBankPresentationAccountFIDTO.md) |  | [optional] 
**companyBankSupplierCreditCardAccountFI** | [**[CompanyBankSupplierCreditCardAccountFIDTO]**](CompanyBankSupplierCreditCardAccountFIDTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


