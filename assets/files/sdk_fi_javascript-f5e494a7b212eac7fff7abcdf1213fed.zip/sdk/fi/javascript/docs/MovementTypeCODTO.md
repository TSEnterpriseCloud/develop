# TseCloudFi.MovementTypeCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codice** | **Number** | CGT0_CODICE - Codice | 
**descr** | **String** | CGT0_DESCR - Descr | [optional] 
**descrbreve** | **String** | CGT0_DESCRBREVE - Descr.breve | [optional] 
**descrmedia** | **String** | CGT0_DESCRMEDIA - Descrmedia | [optional] 
**flgBilanci** | **Number** | CGT0_FLGBILANCI - Bilanci | 
**flgBilancicons** | **Number** | CGT0_FLGBILANCICONS - FlgBilancicons | 
**flgCanrevoke** | **Number** | CGT0_FLGCANREVOKE - Revoke | 
**flgCoan** | **Number** | CGT0_FLGCOAN - Movimenti CoAn | 
**flgContrsaldi** | **Number** | CGT0_FLGCONTRSALDI - FlgContrsaldi | 
**flgDoc** | **Number** | CGT0_FLGDOC - FlgDoc | 
**flgEc** | **Number** | CGT0_FLGEC - FlgEc | 
**flgElabiva** | **Number** | CGT0_FLGELABIVA - FlgElabiva | 
**flgHyperion** | **Number** | CGT0_FLGHYPERION - Hyperion | 
**flgMovcont** | **Number** | CGT0_FLGMOVCONT - Mov.cont. | 
**flgMoviva** | **Number** | CGT0_FLGMOVIVA - Movimenti IVA | 
**flgPartitari** | **Number** | CGT0_FLGPARTITARI - Partitari | 
**flgPf** | **Number** | CGT0_FLGPF - FlgPf | 
**flgQuerypn** | **Number** | CGT0_FLGQUERYPN - FlgQuerypn | 
**indAcconti** | **Number** | CGT0_INDACCONTI - Acconti | 
**indCambiali** | **Number** | CGT0_INDCAMBIALI - Cambiali | 
**indChiuseff** | **Number** | CGT0_INDCHIUSEFF - Chiusura effetti | 
**indConsolidamento** | **Number** | CGT0_INDCONSOLIDAMENTO - Consolidamento | 
**indDatabilanci** | **Number** | CGT0_INDDATABILANCI - IndDatabilanci | 
**indEcportaper** | **Number** | CGT0_INDECPORTAPER - IndEcportaper | 
**indEcportchius** | **Number** | CGT0_INDECPORTCHIUS - IndEcportchius | 
**indIncassobf** | **Number** | CGT0_INDINCASSOBF - Incasso b.f. | 
**indInsoluti** | **Number** | CGT0_INDINSOLUTI - IndInsoluti | 
**indProforma** | **Number** | CGT0_INDPROFORMA - Proforma | 
**indRaggr** | **Number** | CGT0_INDRAGGR - IndRaggr | 
**indRatrisc** | **Number** | CGT0_INDRATRISC - IndRatrisc | 
**indRettifica** | **Number** | CGT0_INDRETTIFICA - Rettifica | 
**indSimulbilanci** | **Number** | CGT0_INDSIMULBILANCI - Simulazione bilanci | 
**indTipoifrs** | **Number** | CGT0_INDTIPOIFRS - IndTipoifrs | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


