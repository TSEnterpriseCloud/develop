# TseCloudFi.ExchangeRateCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**adegcambio** | **Number** |  | [optional] 
**anno** | **Number** |  | [optional] 
**cambio** | **Number** |  | [optional] 
**codiceCg08** | **String** |  | [optional] 
**codicerifCg08** | **String** |  | [optional] 
**giorno** | **Number** |  | [optional] 
**idmediaCg99** | **Number** |  | [optional] 
**indCertoincerto** | **Number** |  | [optional] 
**mese** | **Number** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**parent** | [**CurrencyCO**](CurrencyCO.md) |  | [optional] 
**currencyCO** | [**CurrencyCO**](CurrencyCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


