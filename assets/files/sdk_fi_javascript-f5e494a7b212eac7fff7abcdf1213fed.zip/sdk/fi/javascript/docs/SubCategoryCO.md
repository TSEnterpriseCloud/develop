# TseCloudFi.SubCategoryCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categMg11** | **String** |  | [optional] 
**descrsottocat** | **String** |  | [optional] 
**dittaCg18** | **Number** |  | [optional] 
**idEntityWithDescriptions** | **Number** |  | [optional] 
**idmediaCg99** | **Number** |  | [optional] 
**idprov** | **Number** |  | [optional] 
**macrocatMg11** | **String** |  | [optional] 
**sottcat** | **String** |  | [optional] 
**tipocfMg11** | **Number** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


