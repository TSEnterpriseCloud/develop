# TseCloudFi.GeneralMasterDataCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alias** | **String** | CG16_ALIAS - Alias | [optional] 
**auidAu04** | **Number** | CG16_AUID_AU04 - Codice AU | [optional] 
**cap** | **String** | CG16_CAP - Cap | [optional] 
**capcor** | **String** | CG16_CAPCOR - Cap corrispondenza | [optional] 
**capfisc** | **String** | CG16_CAPFISC - CAP fiscale | [optional] 
**cellnum** | **String** | CG16_CELLNUM - Cell. | [optional] 
**citta** | **String** | CG16_CITTA - Città | [optional] 
**cittacor** | **String** | CG16_CITTACOR - Città corrispondenza | [optional] 
**cittafisc** | **String** | CG16_CITTAFISC - Città fiscale | [optional] 
**codfiscale** | **String** | CG16_CODFISCALE - Codice fiscale | [optional] 
**codice** | **Number** | CG16_CODICE - Codice | 
**codiceCg07** | **Number** | CG16_CODICE_CG07 - Stato estero | [optional] 
**codiceCg15** | **String** | CG16_CODICE_CG15 - Causale prestazione | [optional] 
**codiceCgc0** | **Number** | CG16_CODICE_CGC0 - Azienda intercompany | [optional] 
**codicecorCg07** | **Number** | CG16_CODICECOR_CG07 - Stato estero corrisp. | [optional] 
**codiceident** | **String** | CG16_CODICEIDENT - Codice aggiuntivo | [optional] 
**codicesfed** | **String** | CG16_CODICESFED - Stato federato | [optional] 
**codrichiamo** | **Number** | CG16_CODRICHIAMO - Codice anagrafica sostitutiva | [optional] 
**cognome** | **String** | CG16_COGNOME - Cognome | [optional] 
**comfisCg01** | **String** | CG16_COMFIS_CG01 - Codice comune fiscale | [optional] 
**comnascita** | **String** | CG16_COMNASCITA - Comune di nascita | [optional] 
**comnascitaCg01** | **String** | CG16_COMNASCITA_CG01 - Codice comune nascita | [optional] 
**datanascita** | **Date** | CG16_DATANASCITA - Data di nascita | [optional] 
**datavalid** | **Date** | CG16_DATAVALID - Data validità | [optional] 
**dtfinepec** | **Date** | CG16_DTFINEPEC - Data fine procedure esecutive o concorsuali | [optional] 
**dtiniziopec** | **Date** | CG16_DTINIZIOPEC - Data inizio procedure esecutive o concorsuali | [optional] 
**faxnum** | **String** | CG16_FAXNUM - Fax | [optional] 
**flgAnagval** | **Number** | CG16_FLGANAGVAL - Anag. valida&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Anagrafica valida&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Anagrafica non valida&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgFattpa** | **Number** | CG16_FLGFATTPA - Attivazione modulo fatturazione elettronica verso la Pubblica Amministrazione | [optional] 
**flgNoblacklist** | **Number** | CG16_FLGNOBLACKLIST - Escludi anagrafica da elenco Black List | [optional] 
**flgOmonimo** | **Number** | CG16_FLGOMONIMO - Anagr. principale per fusione omonimi | [optional] 
**flgPrsfis** | **Number** | CG16_FLGPRSFIS - Persona fisica&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**idmediaCg99** | **Number** | CG16_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**indemail** | **String** | CG16_INDEMAIL - E-mail | [optional] 
**indFiscale** | **String** | CG16_INDFISCALE - Indirizzo fiscale | [optional] 
**indFiscaleEX** | **String** | CG16_INDFISCALEEX - Indirizzo fiscale est | [optional] 
**indirCor** | **String** | CG16_INDIRCOR - Indirizzo corrispondenza | [optional] 
**indirCorEX** | **String** | CG16_INDIRCOREX - Indirizzo corrispondenza esteso | [optional] 
**indirizzo** | **String** | CG16_INDIRIZZO - Indirizzo | [optional] 
**indirizzoEX** | **String** | CG16_INDIRIZZOEX - Indirizzo esteso | [optional] 
**indsoggrit** | **Number** | CG16_INDSOGGRIT - Soggetto ritenuta acconto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Non soggetto&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Professionista&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Rappresentante&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indweb** | **String** | CG16_INDWEB - Indirizzo web | [optional] 
**lastchange** | **Date** | CG16_LASTCHANGE - Data ultima variazione | [optional] 
**nome** | **String** | CG16_NOME - Nome | [optional] 
**partitaIVA** | **String** | Partita IVA | [optional] 
**partiva** | **String** | CG16_PARTIVA - Partita IVA | [optional] 
**partivaEst** | **String** | CG16_PARTIVA_EST - Partita IVA estera | [optional] 
**prov** | **String** | CG16_PROV - Prov | [optional] 
**provcor** | **String** | CG16_PROVCOR - Provincia corrispondenza | [optional] 
**provfisc** | **String** | CG16_PROVFISC - Provincia fiscale | [optional] 
**provnascita** | **String** | CG16_PROVNASCITA - Provincia di nascita | [optional] 
**ragSoAnag** | **String** | CG16_RAGSOANAG - Ragione sociale | [optional] 
**ragsoanagex** | **String** | CG16_RAGSOANAGEX - Ragione sociale estesa | [optional] 
**ragsocor** | **String** | CG16_RAGSOCOR - Ragione sociale corrispondenza | [optional] 
**ragsocorex** | **String** | CG16_RAGSOCOREX - Ragione sociale corrispondenza estesa | [optional] 
**ragsofisc** | **String** | CG16_RAGSOFISC - Ragione sociale fiscale | [optional] 
**ragsofiscex** | **String** | CG16_RAGSOFISCEX - Ragione sociale fiscale estesa | [optional] 
**rapazestCg16** | **Number** | CG16_RAPAZEST_CG16 - Codice anagrafico rappresentante legale | [optional] 
**sesso** | **Number** | CG16_SESSO - Sesso&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Maschio&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Femmina&lt;/li&gt;&lt;/ul&gt; | [optional] 
**statofed** | **String** | CG16_STATOFED - Stato federato | [optional] 
**statofedfisc** | **String** | CG16_STATOFEDFISC - Stato federato fisc. | [optional] 
**statofiscCg07** | **Number** | CG16_STATOFISC_CG07 - Codice stato fiscale | [optional] 
**statonascitaCg07** | **Number** | CG16_STATONASCITA_CG07 - Codice stato nascita | [optional] 
**tel1num** | **String** | CG16_TEL1NUM - Telefono 1 | [optional] 
**tel2num** | **String** | CG16_TEL2NUM - Telefono 2 | [optional] 
**idExtendedAttributeEntity** | **Number** |  | [optional] 
**idExtendedAttributeSubEntity** | **Number** |  | [optional] 
**addresses** | [**[AddressCODTO]**](AddressCODTO.md) |  | [optional] 
**fiscalRepresentative** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | [optional] 
**intragroupStructureCO** | [**IntragroupStructureCODTO**](IntragroupStructureCODTO.md) |  | [optional] 
**nationCOBirth** | [**NationCODTO**](NationCODTO.md) |  | [optional] 
**substitutiveMasterdata** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | [optional] 
**wtCodeCO** | [**WTCodeCODTO**](WTCodeCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgAnagvalEnum


* `1` (value: `1`)

* `0` (value: `0`)





## Enum: FlgPrsfisEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndsoggritEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: SessoEnum


* `0` (value: `0`)

* `1` (value: `1`)




