# TseCloudFi.AreaCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codiceAreaMG** | **String** |  | [optional] 
**descrarea** | **String** |  | [optional] 
**dittaCg18** | **Number** |  | [optional] 
**idEntityWithDescriptions** | **Number** |  | [optional] 
**idmediaCg99** | **Number** |  | [optional] 
**idprov** | **Number** |  | [optional] 
**macroareaMg07** | **String** |  | [optional] 
**tipocfMg07** | **Number** |  | [optional] 
**descrizioniLingua** | [**[LanguageDescriptionMGCO]**](LanguageDescriptionMGCO.md) |  | [optional] 
**zone** | [**[ZoneCO]**](ZoneCO.md) |  | [optional] 
**macroAreaCOParent** | [**MacroAreaCO**](MacroAreaCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


