# TseCloudFi.VATTotals

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codiceIVA** | **String** |  | [optional] 
**totaleImponibile** | **Number** |  | [optional] 
**totaleImposta** | **Number** |  | [optional] 
**totaleImpostaNonDet** | **Number** |  | [optional] 
**totaleImponibileVal** | **Number** |  | [optional] 
**totaleImpostaVal** | **Number** |  | [optional] 
**totaleImpostaNonDetVal** | **Number** |  | [optional] 


