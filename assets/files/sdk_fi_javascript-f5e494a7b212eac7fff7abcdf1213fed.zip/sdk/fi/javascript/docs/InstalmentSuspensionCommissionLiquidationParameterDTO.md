# TseCloudFi.InstalmentSuspensionCommissionLiquidationParameterDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instalmentIds** | **[Number]** |  | [optional] 
**enableSuspension** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


