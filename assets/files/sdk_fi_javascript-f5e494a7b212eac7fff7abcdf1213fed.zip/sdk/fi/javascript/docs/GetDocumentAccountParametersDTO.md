# TseCloudFi.GetDocumentAccountParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**itemIdAccountCg24** | **Number** |  | [optional] 
**idcliforCg44** | **Number** |  | [optional] 
**documentAccountType** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


