# TseCloudFi.AccountingReasonCodeClassificationCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descr** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**idmediaCg99** | **Number** |  | [optional] 
**tipologia** | **String** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


