# TseCloudFi.CheckInstalmentStageDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stageGuid** | **String** |  | [optional] 
**taxable** | **Number** |  | [optional] 
**vat** | **Number** |  | [optional] 
**withholdingTax** | **Number** |  | [optional] 
**taxableCurrency** | **Number** |  | [optional] 
**vatCurrency** | **Number** |  | [optional] 
**withholdingTaxCurrency** | **Number** |  | [optional] 


