# TseCloudFi.EPresentationBank

## Enum


* `0` (value: `0`)


