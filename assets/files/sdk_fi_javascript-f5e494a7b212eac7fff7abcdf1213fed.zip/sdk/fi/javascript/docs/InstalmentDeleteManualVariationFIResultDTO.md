# TseCloudFi.InstalmentDeleteManualVariationFIResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**deleted** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


