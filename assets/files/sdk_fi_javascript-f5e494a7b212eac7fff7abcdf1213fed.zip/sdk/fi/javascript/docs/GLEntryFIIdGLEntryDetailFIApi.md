# TseCloudFi.GLEntryFIIdGLEntryDetailFIApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIGet**](GLEntryFIIdGLEntryDetailFIApi.md#apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIGet) | **GET** /api/v1/{environment}/FI/GLEntryFI/{id}/GLEntryDetailFI | Get new
[**apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdDelete**](GLEntryFIIdGLEntryDetailFIApi.md#apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdDelete) | **DELETE** /api/v1/{environment}/FI/GLEntryFI/{id}/GLEntryDetailFI/{internalId} | Delete
[**apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdGet**](GLEntryFIIdGLEntryDetailFIApi.md#apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdGet) | **GET** /api/v1/{environment}/FI/GLEntryFI/{id}/GLEntryDetailFI/{internalId} | Get by ID
[**apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPatch**](GLEntryFIIdGLEntryDetailFIApi.md#apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPatch) | **PATCH** /api/v1/{environment}/FI/GLEntryFI/{id}/GLEntryDetailFI/{internalId} | Update partial
[**apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPut**](GLEntryFIIdGLEntryDetailFIApi.md#apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPut) | **PUT** /api/v1/{environment}/FI/GLEntryFI/{id}/GLEntryDetailFI/{internalId} | Update
[**apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdValidatePost**](GLEntryFIIdGLEntryDetailFIApi.md#apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdValidatePost) | **POST** /api/v1/{environment}/FI/GLEntryFI/{id}/GLEntryDetailFI/{internalId}/validate | Validate
[**apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIPost**](GLEntryFIIdGLEntryDetailFIApi.md#apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/{id}/GLEntryDetailFI | Create



## apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIGet

> GLEntryDetailFIDTO apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIGet(id, op, environment, authorizationScope, opts)

Get new

Get an empty object of type corresponding

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIIdGLEntryDetailFIApi();
let id = "id_example"; // String | 
let op = "op_example"; // String | The value must be 'new'
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIGet(id, op, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **op** | **String**| The value must be &#39;new&#39; | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**GLEntryDetailFIDTO**](GLEntryDetailFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdDelete

> apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdDelete(id, internalId, environment, authorizationScope, opts)

Delete

Deleting object of type 

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIIdGLEntryDetailFIApi();
let id = "id_example"; // String | 
let internalId = "internalId_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdDelete(id, internalId, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **internalId** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdGet

> GLEntryDetailFIDTO apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdGet(id, internalId, environment, authorizationScope, opts)

Get by ID

Get an object of type corresponding the requested id

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIIdGLEntryDetailFIApi();
let id = "id_example"; // String | 
let internalId = "internalId_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdGet(id, internalId, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **internalId** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**GLEntryDetailFIDTO**](GLEntryDetailFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPatch

> apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPatch(id, internalId, environment, authorizationScope, body, opts)

Update partial

Patching an object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIIdGLEntryDetailFIApi();
let id = "id_example"; // String | 
let internalId = "internalId_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let body = null; // Object | Object of type to patch
let opts = {
  'force': "force_example", // String | The warning/s code to bypass (separated by ‘,’) during the execution
  'op': "op_example", // String | Set 'reload', if you want the DTO updated in the response request
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPatch(id, internalId, environment, authorizationScope, body, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **internalId** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **body** | **Object**| Object of type to patch | 
 **force** | **String**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **String**| Set &#39;reload&#39;, if you want the DTO updated in the response request | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPut

> apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPut(id, internalId, environment, authorizationScope, gLEntryDetailFIDTO, opts)

Update

Updating an object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIIdGLEntryDetailFIApi();
let id = "id_example"; // String | 
let internalId = "internalId_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let gLEntryDetailFIDTO = new TseCloudFi.GLEntryDetailFIDTO(); // GLEntryDetailFIDTO | Object of type to update
let opts = {
  'force': "force_example", // String | The warning/s code to bypass (separated by ‘,’) during the execution
  'op': "op_example", // String | Set 'reload', if you want the DTO updated in the response request
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdPut(id, internalId, environment, authorizationScope, gLEntryDetailFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **internalId** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **gLEntryDetailFIDTO** | [**GLEntryDetailFIDTO**](GLEntryDetailFIDTO.md)| Object of type to update | 
 **force** | **String**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **String**| Set &#39;reload&#39;, if you want the DTO updated in the response request | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdValidatePost

> apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdValidatePost(id, internalId, environment, authorizationScope, gLEntryDetailFIDTO, opts)

Validate

Validation of object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIIdGLEntryDetailFIApi();
let id = "id_example"; // String | 
let internalId = "internalId_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let gLEntryDetailFIDTO = new TseCloudFi.GLEntryDetailFIDTO(); // GLEntryDetailFIDTO | Object of type to validate
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIInternalIdValidatePost(id, internalId, environment, authorizationScope, gLEntryDetailFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **internalId** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **gLEntryDetailFIDTO** | [**GLEntryDetailFIDTO**](GLEntryDetailFIDTO.md)| Object of type to validate | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIPost

> apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIPost(id, environment, authorizationScope, gLEntryDetailFIDTO, opts)

Create

Creating new object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIIdGLEntryDetailFIApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let gLEntryDetailFIDTO = new TseCloudFi.GLEntryDetailFIDTO(); // GLEntryDetailFIDTO | Object of type to create
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIIdGLEntryDetailFIPost(id, environment, authorizationScope, gLEntryDetailFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **gLEntryDetailFIDTO** | [**GLEntryDetailFIDTO**](GLEntryDetailFIDTO.md)| Object of type to create | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml

