# TseCloudFi.InstalmentHistoryFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agenzpreS** | **Number** | EF06_AGENZPRE_S - Agenzia di presentazione | [optional] 
**annoEf09** | **Number** | EF06_ANNO_EF09 - Anno presentazione distinta | [optional] 
**annoEf10** | **Number** | EF06_ANNO_EF10 - Anno ordine di pagamento/bonifico | [optional] 
**bancapreS** | **Number** | EF06_BANCAPRE_S - Banca di presentazione | [optional] 
**cambio** | **Number** | EF06_CAMBIO - Valore del cambio | [optional] 
**cambioadconto** | **Number** | EF06_CAMBIOADCONTO - Valore cambio su movimento adeguamento conto | [optional] 
**cambioadcontoS** | **Number** | EF06_CAMBIOADCONTO_S - Valore cambio su movimento adeguamento conto | [optional] 
**causvalutaria** | **String** | EF06_CAUSVALUTARIA - Causale valutaria | [optional] 
**datacambio** | **Date** | EF06_DATACAMBIO - Data cambio | [optional] 
**datacambioadconto** | **Date** | EF06_DATACAMBIOADCONTO - Incremento data cambio dell&#39;adeguamento | [optional] 
**datacambioadcontoS** | **Date** | EF06_DATACAMBIOADCONTO_S - Data cambio dell&#39;adeguamento | [optional] 
**dataprestazione** | **Date** | EF06_DATAPRESTAZIONE - Data prestazione | [optional] 
**datareg** | **Date** | EF06_DATAREG - Data registrazione | 
**datavalutaben** | **Date** | EF06_DATAVALUTABEN - Data valuta beneficiario | [optional] 
**datavalutadeb** | **Date** | EF06_DATAVALUTADEB - Data valuta debitore | [optional] 
**diffcambio** | **Number** | EF06_DIFFCAMBIO - Differenza cambio | [optional] 
**diffcambioconto** | **Number** | EF06_DIFFCAMBIOCONTO - Differenza cambio | [optional] 
**dittaCg18** | **Number** | EF06_DITTA_CG18 - Codice azienda | 
**dittaEf09** | **Number** | EF06_DITTA_EF09 - Codice azienda | [optional] 
**dittaEf10** | **Number** | EF06_DITTA_EF10 - Codice azienda | [optional] 
**etichraggravv** | **String** | EF06_ETICHRAGGRAVV - Etichetta raggruppamento avvisi | [optional] 
**flgGiratoS** | **Number** | EF06_FLGGIRATO_S - Effetto girato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgIncassobfS** | **Number** | EF06_FLGINCASSOBF_S - Incasso buon fine&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgProformadef** | **Number** | EF06_FLGPROFORMADEF - Flag generata fattura definitiva da proforma&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgRicevutoS** | **Number** | EF06_FLGRICEVUTO_S - Effetto ricevuto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgSteffS** | **Number** | EF06_FLGSTEFF_S - Stampato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgStornoritins** | **Number** | EF06_FLGSTORNORITINS - Storno rit. attive insoluti&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgVariatoMg29** | **Number** | EF06_FLGVARIATO_MG29 - Flag variato RID&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**id** | **Number** | EF06_ID - ID storico (Required only in PUT/PATCH) | [optional] 
**idassEf01** | **Number** | EF06_IDASS_EF01 - IdassEf01 | [optional] 
**idcontratto** | **String** | EF06_IDCONTRATTO - Id Contratto | [optional] 
**idEf01** | **Number** | EF06_ID_EF01 - Id Scadenza | 
**idEf09** | **Number** | EF06_ID_EF09 - IdEf09 | [optional] 
**idEf10** | **Number** | EF06_ID_EF10 - IdEf10 | [optional] 
**idesitopag** | **Number** | EF06_IDESITOPAG - ID esito pagamento | [optional] 
**idmediaCg99** | **Number** | EF06_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**idMg35** | **Number** | EF06_ID_MG35 - ID CC | [optional] 
**idpreEf08S** | **Number** | EF06_IDPRE_EF08_S - ID Banca di presentazione | [optional] 
**impadegcambio** | **Number** | EF06_IMPADEGCAMBIO - Incremento adeguamento cambio | [optional] 
**impadegcambioS** | **Number** | EF06_IMPADEGCAMBIO_S - Valore adeguamento cambio | [optional] 
**impeffnetprevS** | **Number** | EF06_IMPEFFNETPREV_S - Importo effetto al netto dei mov. previsionali in EURO | 
**impeffnetprevvalS** | **Number** | EF06_IMPEFFNETPREVVAL_S - Importo effetto al netto dei mov. previsionali in valuta | [optional] 
**impeffS** | **Number** | EF06_IMPEFF_S - Importo effetto in EURO | 
**impeffvalS** | **Number** | EF06_IMPEFFVAL_S - Importo in valuta | [optional] 
**impmovabb** | **Number** | EF06_IMPMOVABB - Importo abbuono in Euro | [optional] 
**impmovabbval** | **Number** | EF06_IMPMOVABBVAL - Importo abbuono in valuta | [optional] 
**impmovacc** | **Number** | EF06_IMPMOVACC - Importo acconto in EURO | [optional] 
**impmovaccval** | **Number** | EF06_IMPMOVACCVAL - Importo acconto in valuta | [optional] 
**impmovomanoriv** | **Number** | EF06_IMPMOVOMANORIV - Importo omaggio senza rivalsa in EURO | [optional] 
**impmovomanorivval** | **Number** | EF06_IMPMOVOMANORIVVAL - Importo omaggio senza rivalsa in valuta | [optional] 
**impmovpag** | **Number** | EF06_IMPMOVPAG - Importo pagato in Euro | 
**impmovpagrit** | **Number** | EF06_IMPMOVPAGRIT - Importo delle ritenute pagate in Euro | [optional] 
**impmovpagritval** | **Number** | EF06_IMPMOVPAGRITVAL - Importo delle ritenute pagate in valuta | [optional] 
**impmovpagval** | **Number** | EF06_IMPMOVPAGVAL - Importo pagato in valuta | [optional] 
**impmovrit** | **Number** | EF06_IMPMOVRIT - Importo ritenuta di acconto in EURO | [optional] 
**impmovritval** | **Number** | EF06_IMPMOVRITVAL - Importo ritenuta di acconto | [optional] 
**impmovscind** | **Number** | EF06_IMPMOVSCIND - Importo sconto incondizionato in EURO | [optional] 
**impmovscindval** | **Number** | EF06_IMPMOVSCINDVAL - Importo sconto incondizionato in valuta | [optional] 
**impscarvalut** | **Number** | EF06_IMPSCARVALUT - Importo scarico valutario | [optional] 
**indAssoc** | **Number** | EF06_INDASSOC - Modalità associazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Non associata&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Associata con metodo progressivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Associata con metodo proporzionale&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indEsecuzione** | **Number** | EF06_INDESECUZIONE - Tipo esecuzione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Conto anticipi&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Contratto&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indGenstatoS** | **Number** | EF06_INDGENSTATO_S - Specifica generazione stato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Creazione iniziale&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Pagamento/Riscossione&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Chiusura effetti&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  Insoluto&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; -  Raggruppato&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; -  Riemissione&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; -  Richiamato&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indOrdpbonifEf10** | **Number** | EF06_INDORDPBONIF_EF10 - Tipo documento ordine di pagamento/bonifico&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Ordine di pagamento&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Bonifico bancario&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Bonifico Estero (no SEPA)&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indPresS** | **Number** | EF06_INDPRES_S - Presentazione dell&#39;effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Non soggetto&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  In portafoglio&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  S.b.f. ordinario&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  S.b.f. a maturazione valuta&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; -  S.b.f. anticipato&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; -  Dopo incasso&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; -  Allo sconto&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; -  Altre presentazioni&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; -  Sconto fatture&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; -  Cessione a factoring&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indSperitS** | **Number** | EF06_INDSPERIT_S - Modalità di registrazione delle spese di ritorno&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Nessun addebito&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Solo annotate sull&#39;effetto&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Sommate all&#39;importo dell&#39;effetto&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  Creazione di un nuovo effetto&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indStatoS** | **Number** | EF06_INDSTATO_S - Stato dell&#39;effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Aperto&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Chiuso&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTipodistEf09** | **Number** | EF06_INDTIPODIST_EF09 - Tipo distinta&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Riba&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  RID&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  MAV &lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  Sconto fatture&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; -  Cessione a factoring&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; -  Distinta multipla&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; -  LCR (Generico)&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; -  IEF (Generico)&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; -  Lastschrift (Generico)&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; -  Unicredit (Export Manager)&lt;/li&gt;&lt;li&gt;&lt;i&gt;21&lt;/i&gt; - Distinta francese LCR-BOR&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTipoincMg29** | **Number** | EF06_INDTIPOINC_MG29 - Tipo sequenza RID&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - First&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Recurrent&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Final&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - OneOff&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTipoper** | **Number** | EF06_INDTIPOPER - Tipo operazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Variazione manuale&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Pagamento/Riscossione&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Chiusura effetti&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  Presentazione effetti&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; -  Insoluto&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; -  Raggruppamento&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; -  Riemissione&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; -  Girata&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; -  Storno chiusura eff.&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; -  Adeguamento valutario&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; -  Richiamato&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; -  Incasso buon fine&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; -  Frazionamento scadenza&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; -  Rilevazione assegno&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; -  Perdite su crediti&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; -  Spese esiti&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; -  Pag./Risc. split payment&lt;/li&gt;&lt;li&gt;&lt;i&gt;17&lt;/i&gt; - Compensazione nota di credito&lt;/li&gt;&lt;/ul&gt; | [optional] 
**livellorischio** | **Number** | EF06_LIVELLORISCHIO - Livello di rischio | 
**numassegno** | **String** | EF06_NUMASSEGNO - Numero di assegno | [optional] 
**numccassegn** | **String** | EF06_NUMCCASSEGN - Conto corrente assegno | [optional] 
**numdistEf09** | **Number** | EF06_NUMDIST_EF09 - Numero distinta | [optional] 
**numordpbonifEf10** | **Number** | EF06_NUMORDPBONIF_EF10 - Numero ordine di pagamento/bonifico | [optional] 
**numregdcCo99** | **String** | EF06_NUMREGDC_CO99 - Numero della registrazione di differenza cambio associata | [optional] 
**numregmovCo99** | **String** | EF06_NUMREGMOV_CO99 - Numero di registrazione | [optional] 
**numregstornoivaCo99** | **String** | EF06_NUMREGSTORNOIVA_CO99 - Numero di registrazione storno IVA | [optional] 
**numriemisS** | **Number** | EF06_NUMRIEMIS_S - Numero di riemissione | [optional] 
**numsteffS** | **Number** | EF06_NUMSTEFF_S - Numero stampa effetti | [optional] 
**ordbonabiCg13** | **Number** | EF06_ORDBONABI_CG13 - Banca di presentazione ordine di pagamento/bonifico | [optional] 
**ordbonbban** | **String** | EF06_ORDBONBBAN - Codice BBAN del fornitore a cui è destinato il bonifico | [optional] 
**ordboncabCg13** | **Number** | EF06_ORDBONCAB_CG13 - Agenzia di presentazione ordine di pagamento/bonifico | [optional] 
**ordboncaupag** | **String** | EF06_ORDBONCAUPAG - Causale SEPA per bonifico/Esito Rid SDD | [optional] 
**ordbonccforn** | **String** | EF06_ORDBONCCFORN - Conto corrente del fornitore | [optional] 
**ordbonflgconf** | **Number** | EF06_ORDBONFLGCONF - Ordine di pagamento/bonifico confermato | [optional] 
**ordboniban** | **String** | EF06_ORDBONIBAN - Codice IBAN del fornitore a cui è destinato il bonifico | [optional] 
**ordbonmotivo** | **String** | EF06_ORDBONMOTIVO - Motivo ordine di pagamento/bonifico | [optional] 
**progEcmovEc01** | **Number** | EF06_PROGECMOV_EC01 - Progressivo estratto conto | [optional] 
**progEffspe** | **Number** | EF06_PROGEFFSPE - Progressivo nuovo effetto creato | [optional] 
**progSto** | **Number** | EF06_PROGSTO - Progressivo storico | 
**rigacontmovAlRitCg42** | **Number** | EF06_RIGACONTMOVALRIT_CG42 - Riga contabile altre ritenute | [optional] 
**rigacontmovAlRitCpCg42** | **Number** | EF06_RIGACONTMOVALRITCP_CG42 - Riga contabile altre ritenute - contropartita | [optional] 
**rigacontmovCg42** | **Number** | EF06_RIGACONTMOV_CG42 - Riga contabile | [optional] 
**rigacontmovCpCg42** | **Number** | EF06_RIGACONTMOVCP_CG42 - Riga contabile - contropartita | [optional] 
**rigacontmovRitCg42** | **Number** | EF06_RIGACONTMOVRIT_CG42 - Riga contabile ritenuta acconto | [optional] 
**rigacontmovRitCpCg42** | **Number** | EF06_RIGACONTMOVRITCP_CG42 - Riga contabile ritenuta acconto - contropartita | [optional] 
**rowversion** | **Blob** | EF06_ROWVERSION - RowVersion | [optional] 
**scadeS** | **Date** | EF06_SCADE_S - Data scadenza | 
**speseritbanS** | **Number** | EF06_SPESERITBAN_S - Spese di ritorno addebitate dalla banca | [optional] 
**speseritS** | **Number** | EF06_SPESERIT_S - Spese di ritorno addebitate al cliente | [optional] 
**tariffadoganale** | **Number** | EF06_TARIFFADOGANALE - Tariffa doganale | [optional] 
**tipocvs** | **Number** | EF06_TIPOCVS - Tipo CVS | 
**tipovalutaben** | **Number** | EF06_TIPOVALUTABEN - Tipo valuta beneficiario | 
**tipovalutadeb** | **Number** | EF06_TIPOVALUTADEB - Tipo valuta debitore | 
**companyBankFI** | [**CompanyBankFIDTO**](CompanyBankFIDTO.md) |  | [optional] 
**sepaReasonCodesFI** | [**SepaReasonCodesFIDTO**](SepaReasonCodesFIDTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgGiratoSEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgIncassobfSEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgProformadefEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgRicevutoSEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgSteffSEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgStornoritinsEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgVariatoMg29Enum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndAssocEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndEsecuzioneEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndGenstatoSEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)





## Enum: IndOrdpbonifEf10Enum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndPresSEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)





## Enum: IndSperitSEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: IndStatoSEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndTipodistEf09Enum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)

* `21` (value: `21`)





## Enum: IndTipoincMg29Enum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: IndTipoperEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)

* `10` (value: `10`)

* `11` (value: `11`)

* `12` (value: `12`)

* `13` (value: `13`)

* `14` (value: `14`)

* `15` (value: `15`)

* `16` (value: `16`)

* `17` (value: `17`)




