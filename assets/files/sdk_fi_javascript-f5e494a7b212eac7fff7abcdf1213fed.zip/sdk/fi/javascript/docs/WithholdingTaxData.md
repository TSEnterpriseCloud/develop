# TseCloudFi.WithholdingTaxData

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**importoAltreRitenute** | **Number** |  | [optional] 
**importoEnasarcoAzienda** | **Number** |  | [optional] 


