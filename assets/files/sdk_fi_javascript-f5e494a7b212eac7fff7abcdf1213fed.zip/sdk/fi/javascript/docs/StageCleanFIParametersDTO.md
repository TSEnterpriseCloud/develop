# TseCloudFi.StageCleanFIParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lastExecHours** | **Number** |  | [optional] 
**lastUpdHours** | **Number** |  | [optional] 
**validationRequired** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


