# TseCloudFi.COAAccountCustomizationFI

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**contoCg24** | **String** |  | [optional] 
**descr** | **String** |  | [optional] 
**dittaCg18** | **Number** |  | [optional] 
**gruppoCg10** | **Number** |  | [optional] 
**idCg24** | **Number** |  | [optional] 
**iddespcon** | **Number** |  | [optional] 
**idEntityWithDescriptions** | **Number** |  | [optional] 
**idmediaCg99** | **Number** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**languageDescriptionFI** | [**[LanguageDescriptionFI]**](LanguageDescriptionFI.md) |  | [optional] 
**parent** | [**COAAccountFI**](COAAccountFI.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


