# TseCloudFi.InstalmentsAdditionalInfoParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**inStage** | **Boolean** |  | [optional] 
**numReg** | **String** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**rigaContCG42** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


