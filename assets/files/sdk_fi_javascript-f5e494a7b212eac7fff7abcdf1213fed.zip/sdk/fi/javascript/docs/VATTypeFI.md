# TseCloudFi.VATTypeFI

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agviaggio** | **Number** |  | [optional] 
**codice** | **Number** |  | [optional] 
**codiceCg0d** | **Number** |  | [optional] 
**descr** | **String** |  | [optional] 
**idEntityWithDescriptions** | **Number** |  | [optional] 
**indAutofattura** | **Number** |  | [optional] 
**indTipo** | **Number** |  | [optional] 
**localizzazione** | **Number** |  | [optional] 
**languageDescriptionFI** | [**[LanguageDescriptionFI]**](LanguageDescriptionFI.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


