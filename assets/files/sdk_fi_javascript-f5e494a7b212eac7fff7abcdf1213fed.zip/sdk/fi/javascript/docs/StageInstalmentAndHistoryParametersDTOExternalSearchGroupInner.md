# TseCloudFi.StageInstalmentAndHistoryParametersDTOExternalSearchGroupInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**operator** | [**SearchLogicalOperators**](SearchLogicalOperators.md) |  | [optional] 
**propertyName** | **String** | Property on witch apply the filter | 
**comparer** | [**SearchComparer**](SearchComparer.md) |  | 
**value** | **Object** |  | 
**items** | [**[OneOfSearchNodeDTOSearchElementDTOSearchGroupDTO]**](OneOfSearchNodeDTOSearchElementDTOSearchGroupDTO.md) | Items list to apply: any element can be a &#39;SearchGroupDTO&#39; or a &#39;SearchElementDTO&#39; | [optional] 


