# TseCloudFi.CSJointlyHeldCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cliforCg44** | **Number** | CG4E_CLIFOR_CG44 - CliforCg44 | 
**cliforcoCg44** | **Number** | CG4E_CLIFORCO_CG44 - CliforcoCg44 | 
**dittaCg18** | **Number** | CG4E_DITTA_CG18 - DittaCg18 | 
**idcliforcoCg44** | **Number** | CG4E_IDCLIFORCO_CG44 - IdcliforcoCg44 | [optional] 
**percentuale** | **Number** | CG4E_PERCENTUALE - Percentuale | 
**tipocfCg44** | **Number** | CG4E_TIPOCF_CG44 - TipocfCg44 | 
**customerSupplierCO** | [**CustomerSupplierCODTO**](CustomerSupplierCODTO.md) |  | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


