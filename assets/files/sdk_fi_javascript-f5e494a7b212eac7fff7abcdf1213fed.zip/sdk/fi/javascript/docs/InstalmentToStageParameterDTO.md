# TseCloudFi.InstalmentToStageParameterDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numreg** | **String** |  | [optional] 
**rigacontCg42** | **Number** |  | [optional] 
**guid** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


