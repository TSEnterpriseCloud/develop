# TseCloudFi.Int64ListGLEntryGenericResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | **[Number]** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


