# TseCloudFi.DigitalSendersCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cap** | **String** |  | [optional] 
**capleg** | **String** |  | [optional] 
**citta** | **String** |  | [optional] 
**cittaleg** | **String** |  | [optional] 
**codFiscale** | **String** |  | [optional] 
**codice** | **Number** |  | [optional] 
**codiceCg16** | **Number** |  | [optional] 
**dirtecnico** | **String** |  | [optional] 
**flgSededec** | **Number** |  | [optional] 
**id** | **Number** |  | [optional] 
**indInviotel** | **Number** |  | [optional] 
**indirizzo** | **String** |  | [optional] 
**indIrleg** | **String** |  | [optional] 
**niscrcaf** | **String** |  | [optional] 
**prov** | **String** |  | [optional] 
**provleg** | **String** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**sedeivaann** | **Number** |  | [optional] 
**sedeivaper** | **Number** |  | [optional] 
**ultprotivaann** | **Number** |  | [optional] 
**ultprotivaper** | **Number** |  | [optional] 
**generalMasterDataCO** | [**GeneralMasterDataCO**](GeneralMasterDataCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


