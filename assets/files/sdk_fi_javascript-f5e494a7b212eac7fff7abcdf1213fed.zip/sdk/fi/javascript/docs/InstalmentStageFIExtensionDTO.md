# TseCloudFi.InstalmentStageFIExtensionDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numRata** | **Number** |  | [optional] 
**importoPagato** | **Number** |  | [optional] 
**abbuono** | **Number** |  | [optional] 
**flagNote** | **Number** |  | [optional] 
**scontoIncond** | **Number** |  | [optional] 
**omaggioSenzaRiv** | **Number** |  | [optional] 
**scontoIncondEURO** | **Number** |  | [optional] 
**omaggioSenzaRivEURO** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


