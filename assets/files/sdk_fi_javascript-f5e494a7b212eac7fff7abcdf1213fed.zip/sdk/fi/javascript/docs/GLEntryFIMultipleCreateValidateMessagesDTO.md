# TseCloudFi.GLEntryFIMultipleCreateValidateMessagesDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idEntry** | **Number** |  | [optional] 
**messages** | [**[GLEntryFIMultipleCreateValidateMessageDTO]**](GLEntryFIMultipleCreateValidateMessageDTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


