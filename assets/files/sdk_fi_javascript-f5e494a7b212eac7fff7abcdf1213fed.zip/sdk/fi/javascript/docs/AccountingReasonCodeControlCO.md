# TseCloudFi.AccountingReasonCodeControlCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codiceCg33** | **String** |  | [optional] 
**contomaxCg24** | **String** |  | [optional] 
**contominCg24** | **String** |  | [optional] 
**gruppoCg10** | **Number** |  | [optional] 
**idmediaCg99** | **Number** |  | [optional] 
**indDaav** | **Number** |  | [optional] 
**progR** | **Number** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**parent** | [**AccountingReasonCodeCO**](AccountingReasonCodeCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


