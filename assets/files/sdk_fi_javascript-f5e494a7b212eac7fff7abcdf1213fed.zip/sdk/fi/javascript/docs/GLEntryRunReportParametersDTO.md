# TseCloudFi.GLEntryRunReportParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idProcessingDetails** | **Number** |  | [optional] 
**parameters** | **{String: Object}** |  | [optional] 
**reportParameters** | [**[GLEntryReportParam]**](GLEntryReportParam.md) |  | [optional] 
**filterGlentriesParams** | [**FilterGLEntriesParamsDTO**](FilterGLEntriesParamsDTO.md) |  | [optional] 
**filterOnly** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


