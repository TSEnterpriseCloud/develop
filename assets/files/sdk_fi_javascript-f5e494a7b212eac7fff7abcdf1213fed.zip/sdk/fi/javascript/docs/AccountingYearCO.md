# TseCloudFi.AccountingYearCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**anno** | **Number** |  | [optional] 
**dataape** | **Date** |  | [optional] 
**datachiu** | **Date** |  | [optional] 
**dittaCg18** | **Number** |  | [optional] 
**flgAdecbatt** | **Number** |  | [optional] 
**flgAdecbcli** | **Number** |  | [optional] 
**flgAdecbfor** | **Number** |  | [optional] 
**flgAdecbpas** | **Number** |  | [optional] 
**flgEserchiuso** | **Number** |  | [optional] 
**flgEsercor** | **Number** |  | [optional] 
**flgGencesp** | **Number** |  | [optional] 
**flgGenratei** | **Number** |  | [optional] 
**flgGenrisc** | **Number** |  | [optional] 
**id** | **Number** |  | [optional] 
**idmediaCg99** | **Number** |  | [optional] 
**progEser** | **Number** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


