# TseCloudFi.BusinessTypeDataDefaultResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codAttivita** | **Number** |  | [optional] 
**descrattivita** | **String** |  | [optional] 
**indPlafond** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


