# TseCloudFi.CompanyBankPresentationAccountFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bancaCg12** | **Number** | EF12_BANCA_CG12 - Abi | [optional] 
**conpreseffCg24** | **String** | EF12_CONPRESEFF_CG24 - Conto presentazione effetti | [optional] 
**conpresspeCg24** | **String** | EF12_CONPRESSPE_CG24 - Conto per spese di presentazione | [optional] 
**dittaCg18** | **Number** | EF12_DITTA_CG18 - DittaCg18 | 
**grupreseffCg24** | **Number** | EF12_GRUPRESEFF_CG24 - GrupreseffCg24 | [optional] 
**grupresspeCg24** | **Number** | EF12_GRUPRESSPE_CG24 - GrupresspeCg24 | [optional] 
**id** | **Number** | EF12_ID - ID (Required only in PUT/PATCH) | [optional] 
**idEf08** | **Number** | EF12_ID_EF08 - IdEf08 | [optional] 
**idpreseffCg24** | **Number** | EF12_IDPRESEFF_CG24 - IdpreseffCg24 | [optional] 
**idpresspeCg24** | **Number** | EF12_IDPRESSPE_CG24 - IdpresspeCg24 | [optional] 
**indEffclifor** | **Number** | EF12_INDEFFCLIFOR - Cliente / Fornitore&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Clienti&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Fornitori&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indPres** | **Number** | EF12_INDPRES - Tipo presentazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Sbf a maturazione valuta&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Sbf ordinario&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Sbf anticipato&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - All&#39;incasso&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Allo sconto&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTipoeff** | **Number** | EF12_INDTIPOEFF - Tipo effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Ri.Ba.&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Tratte, Tratte acc.&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Cessioni, Cambiali&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - RID&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - MAV&lt;/li&gt;&lt;/ul&gt; | [optional] 
**rowversion** | **Blob** | EF12_ROWVERSION - Rowversion | [optional] 
**bankCO** | [**BankCODTO**](BankCODTO.md) |  | [optional] 
**presentationBill** | [**COAAccountDescrFIDTO**](COAAccountDescrFIDTO.md) |  | [optional] 
**presentationFee** | [**COAAccountDescrFIDTO**](COAAccountDescrFIDTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndEffcliforEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndPresEnum


* `1` (value: `1`)

* `0` (value: `0`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)





## Enum: IndTipoeffEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)




