# TseCloudFi.TSPaaSShowInvoicePDFResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**streamInvoice** | **Blob** |  | [optional] 
**fileName** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


