# TseCloudFi.BusinessTypeDataCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**annoliq** | **Number** | CG96_ANNOLIQ - Anno ultima stampa liquidazione annuale | [optional] 
**codAttivita** | **Number** | CG96_CODATTIVITA - Codice Attività | 
**codiceCg06** | **String** | CG96_CODICE_CG06 - CodiceCg06 | [optional] 
**codiceCg6a** | **String** | CG96_CODICE_CG6A - Codice attività ATECO 2007 | [optional] 
**datastpliqiva** | **Date** | CG96_DATASTPLIQIVA - Data ultima stampa registro liquidazione IVA | [optional] 
**datastpplafon** | **Date** | CG96_DATASTPPLAFON - Data ultima stampa plafond su registro liquidazione IVA | [optional] 
**datastpregacq** | **Date** | CG96_DATASTPREGACQ - Data ultima stampa registro acquisti | [optional] 
**datastpregacqglob** | **Date** | CG96_DATASTPREGACQGLOB - Data ultima stampa registro acquisti regime del margine globale | [optional] 
**datastpregcor** | **Date** | CG96_DATASTPREGCOR - Data ultima stampa registro corrispettivi | [optional] 
**datastpregrie** | **Date** | CG96_DATASTPREGRIE - Data ultima stampa registro riepilogativo | [optional] 
**datastpregunicanal** | **Date** | CG96_DATASTPREGUNICANAL - Data ultima stampa registro unico regime del margine analitico | [optional] 
**datastpregven** | **Date** | CG96_DATASTPREGVEN - Data ultima stampa registro vendite  | [optional] 
**datastpregvenglob** | **Date** | CG96_DATASTPREGVENGLOB - Data ultima stampa registro vendite regime del margine globale | [optional] 
**descrattivita** | **String** | CG96_DESCRATTIVITA - Descrizione | [optional] 
**dittaCg18** | **Number** | CG96_DITTA_CG18 - Ditta | 
**flgIvaedit** | **Number** | CG96_FLGIVAEDIT - IVA per editoria | 
**indAgric** | **Number** | CG96_INDAGRIC - Tipo impresa agricola&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Azienda agricola&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Cooperativa&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Assoc. categoria agricoltori&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Agriturismo&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Cessione bovini e suini&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Attività connesse agricoltura&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indCatpart** | **Number** | CG96_INDCATPART - Regimi speciali&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Autotrasportatori di merci per conto terzi&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Esercenti impianti distribuzione carburanti&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Società sportive dilettantistiche (L.398/91)&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Agricoltura&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Editoria&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Agenzie di viaggio&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indRegimefiscale** | **Number** | CG96_INDREGIMEFISCALE - Regime fiscale (per Fatture PA)&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - RF01 - Ordinario&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - RF02 - Contribuenti minimi (art.1, c.96-117, L. 244/07)&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - RF03 - Nuove iniziative produttive (art.13, L. 388/00)&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - RF04 - Agricoltura e attività connesse e pesca (artt.34 e 34-bis, DPR 633/72)&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - RF05 - Vendita sali e tabacchi (art.74, c.1, DPR. 633/72)&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - RF06 - Commercio fiammiferi (art.74, c.1, DPR 633/72)&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - RF07 - Editoria (art.74, c.1, DPR 633/72)&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - RF08 - Gestione servizi telefonia pubblica (art.74, c.1, DPR 633/72)&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - RF09 - Rivendita documenti di trasporto pubblico e di sosta (art.74, c.1, DPR 633/72)&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - RF10 - Intrattenimenti, giochi e altre attività di cui alla tariffa allegata al DPR 640/72 (art.74, c.6, DPR 633/72)&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - RF11 - Agenzie viaggi e turismo (art.74-ter, DPR 633/72)&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - RF12 - Agriturismo (art.5, c.2, L. 413/91)&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - RF13 - Vendite a domicilio (art.25-bis, c.6, DPR 600/73)&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - RF14 - Rivendita beni usati, oggetti d’arte, d’antiquariato o da collezione (art.36, DL 41/95)&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - RF15 - Agenzie di vendite all’asta di oggetti d’arte, antiquariato o da collezione (art.40-bis, DL 41/95)&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - RF16 - IVA per cassa P.A. (art.6, c.5, DPR 633/72)&lt;/li&gt;&lt;li&gt;&lt;i&gt;17&lt;/i&gt; - RF17 - IVA per cassa soggetti con vol. d’affari inferiore ad euro 200.000 (art.7, DL 185/2008)&lt;/li&gt;&lt;li&gt;&lt;i&gt;18&lt;/i&gt; - RF18 - Altro&lt;/li&gt;&lt;li&gt;&lt;i&gt;19&lt;/i&gt; - RF19 - Regime forfettario&lt;/li&gt;&lt;/ul&gt; | [optional] 
**rowversion** | **Blob** | CG96_ROWVERSION - Rowversion | [optional] 
**codAteco** | [**AtecoCodeCODTO**](AtecoCodeCODTO.md) |  | [optional] 
**istatActivityCO** | [**ISTATActivityCODTO**](ISTATActivityCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndAgricEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)





## Enum: IndCatpartEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `4` (value: `4`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)





## Enum: IndRegimefiscaleEnum


* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)

* `10` (value: `10`)

* `11` (value: `11`)

* `12` (value: `12`)

* `13` (value: `13`)

* `14` (value: `14`)

* `15` (value: `15`)

* `16` (value: `16`)

* `17` (value: `17`)

* `18` (value: `18`)

* `19` (value: `19`)




