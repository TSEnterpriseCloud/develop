# TseCloudFi.InstalmentDataDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instalmentId** | **Number** |  | [optional] 
**impEffS** | **Number** |  | [optional] 
**impEffSVal** | **Number** |  | [optional] 
**amountToPay** | **Number** |  | [optional] 
**cliFor** | **Number** |  | [optional] 
**scadeS** | **Date** |  | [optional] 
**cig** | **String** |  | [optional] 
**cup** | **String** |  | [optional] 
**iban** | **String** |  | [optional] 
**numDoc** | **Number** |  | [optional] 


