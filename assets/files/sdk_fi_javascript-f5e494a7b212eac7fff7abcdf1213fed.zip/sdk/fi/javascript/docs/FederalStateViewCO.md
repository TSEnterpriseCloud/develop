# TseCloudFi.FederalStateViewCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**a2iso3166Cg07** | **String** |  | [optional] 
**codiceCg07** | **Number** |  | [optional] 
**descr** | **String** |  | [optional] 
**iso3166statofed** | **String** |  | [optional] 
**statofed** | **String** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


