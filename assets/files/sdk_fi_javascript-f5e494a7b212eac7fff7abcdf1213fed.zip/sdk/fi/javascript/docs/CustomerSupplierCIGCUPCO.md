# TseCloudFi.CustomerSupplierCIGCUPCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cliforCg44** | **Number** |  | [optional] 
**dittaCg18** | **Number** |  | [optional] 
**id** | **Number** |  | [optional] 
**idcigcupCo1h** | **Number** |  | [optional] 
**progREf08** | **Number** |  | [optional] 
**progRMg35** | **Number** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**tipocfCg44** | **Number** |  | [optional] 
**parent** | [**CustomerSupplierCO**](CustomerSupplierCO.md) |  | [optional] 
**cigcuPcode** | [**CIGCUPMasterDataCO**](CIGCUPMasterDataCO.md) |  | [optional] 
**companyBank** | [**CompanyBankCO**](CompanyBankCO.md) |  | [optional] 
**csBankCO** | [**CSBankCO**](CSBankCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


