# TseCloudFi.B2BResultsCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descriptionId** | **Number** | IE89_DESCRIPTIONID - DescriptionId | [optional] 
**gravita** | **Number** | IE89_GRAVITA - Gravita&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Non elaborato&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - OK&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Warning&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Errore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**id** | **Number** | IE89_ID - Id (Required only in PUT/PATCH) | [optional] 
**idIe83** | **Number** | IE89_ID_IE83 - IdIe83 | 
**numLineaL** | **String** | IE89_NUMLINEA_L - Riga | [optional] 
**testoMsg** | **String** | IE89_TESTOMSG - TestoMsg | [optional] 
**tipoEsito** | **Number** | IE89_TIPO_ESITO - TipoEsito | 
**tipologia** | **Number** | IE89_TIPOLOGIA - Tipologia | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: GravitaEnum


* `0` (value: `0`)

* `3` (value: `3`)

* `1` (value: `1`)

* `2` (value: `2`)




