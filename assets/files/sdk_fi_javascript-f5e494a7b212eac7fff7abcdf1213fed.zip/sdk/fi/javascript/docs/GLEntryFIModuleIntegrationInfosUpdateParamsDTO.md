# TseCloudFi.GLEntryFIModuleIntegrationInfosUpdateParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**glEntryId** | **Number** |  | [optional] 
**operationType** | **Number** |  | [optional] 
**operationState** | **Number** |  | [optional] 
**externalRif** | **Number** |  | [optional] 
**isDeleteOp** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


