# TseCloudFi.GLEntryFIPublishStageJobDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**externalRif** | **String** |  | [optional] 
**validateDTO** | [**ValidateDTO**](ValidateDTO.md) |  | [optional] 
**entries** | **[Number]** |  | [optional] 
**entriesAdditionalInfo** | [**[GLEntryAdditionalInfoDTO]**](GLEntryAdditionalInfoDTO.md) |  | [optional] 
**validateMessages** | [**[GLEntryFIMultipleCreateValidateMessagesDTO]**](GLEntryFIMultipleCreateValidateMessagesDTO.md) |  | [optional] 
**errorMessages** | [**[GLEntryFIMultipleCreateErrorMessagesDTO]**](GLEntryFIMultipleCreateErrorMessagesDTO.md) |  | [optional] 
**instalments** | **[Number]** |  | [optional] 
**purchases** | **[Number]** |  | [optional] 
**info** | **[String]** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


