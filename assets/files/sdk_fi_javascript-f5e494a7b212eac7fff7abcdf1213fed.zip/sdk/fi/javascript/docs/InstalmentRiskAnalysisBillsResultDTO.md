# TseCloudFi.InstalmentRiskAnalysisBillsResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**consolidBill** | **Number** |  | [optional] 
**toConsolidBill** | **Number** |  | [optional] 
**estimatedBill** | **Number** |  | [optional] 
**overdueNotUnpaid** | **Number** |  | [optional] 
**overdueUnpaid** | **Number** |  | [optional] 
**dueNotUnpaid** | **Number** |  | [optional] 
**dueUnpaid** | **Number** |  | [optional] 
**collectedDue** | **Number** |  | [optional] 
**sentToBankNumber** | **Number** |  | [optional] 
**sentToBankAmount** | **Number** |  | [optional] 
**unpaidNumber** | **Number** |  | [optional] 
**unpaidAmount** | **Number** |  | [optional] 
**openDueNumber** | **Number** |  | [optional] 
**delayDays** | **Number** |  | [optional] 
**delayDaysOpen** | **Number** |  | [optional] 
**delayDaysClose** | **Number** |  | [optional] 
**actualDelayDays** | **Number** |  | [optional] 
**actualDelayDaysOpen** | **Number** |  | [optional] 
**actualDelayDaysClose** | **Number** |  | [optional] 
**paymentLateDays** | **Number** |  | [optional] 
**paymentLateDaysOpen** | **Number** |  | [optional] 
**paymentLateDaysClose** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


