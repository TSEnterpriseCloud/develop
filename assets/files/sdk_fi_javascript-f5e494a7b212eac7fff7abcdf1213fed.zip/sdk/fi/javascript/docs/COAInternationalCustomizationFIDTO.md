# TseCloudFi.COAInternationalCustomizationFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categoria** | **Number** | CG2D_CATEGORIA - Categoria conto | [optional] 
**contoCg24** | **String** | CG2D_CONTO_CG24 - Codice conto | 
**esModulo347** | **Number** | CG2D_ES_MODULO347 - Escludi mod.347 | [optional] 
**gbDeferralcode** | **String** | CG2D_GB_DEFERRALCODE - Deferral code | [optional] 
**gruppoCg10** | **Number** | CG2D_GRUPPO_CG10 - Piano dei conti | 
**id** | **Number** | CG2D_ID - ID (Required only in PUT/PATCH) | [optional] 
**idCg24** | **Number** | CG2D_ID_CG24 - ID Conto | 
**iso3166A2** | **String** | CG2D_ISO3166_A2 - Localizzazione | 
**rowversion** | **Blob** | CG2D_ROWVERSION - RowVersion | [optional] 
**subcategoria** | **Number** | CG2D_SUBCATEGORIA - Sottocategoria | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


