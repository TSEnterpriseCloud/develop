# TseCloudFi.GLEntryFIOffSetSummaryResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stageGuid** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**debitAmount** | **Number** |  | [optional] 
**debitValAmount** | **Number** |  | [optional] 
**creditAmount** | **Number** |  | [optional] 
**creditValAmount** | **Number** |  | [optional] 
**debitOffset** | **Number** |  | [optional] 
**debitValOffset** | **Number** |  | [optional] 
**creditOffset** | **Number** |  | [optional] 
**creditValOffset** | **Number** |  | [optional] 
**forceCompanyCurrency** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


