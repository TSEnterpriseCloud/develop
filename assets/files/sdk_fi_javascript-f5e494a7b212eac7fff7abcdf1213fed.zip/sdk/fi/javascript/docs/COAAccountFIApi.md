# TseCloudFi.COAAccountFIApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiV1EnvironmentFICOAAccountFICalculatebalancePost**](COAAccountFIApi.md#apiV1EnvironmentFICOAAccountFICalculatebalancePost) | **POST** /api/v1/{environment}/FI/COAAccountFI/calculatebalance | Calculate balance for account
[**apiV1EnvironmentFICOAAccountFIDuplicateAccountPost**](COAAccountFIApi.md#apiV1EnvironmentFICOAAccountFIDuplicateAccountPost) | **POST** /api/v1/{environment}/FI/COAAccountFI/duplicate_account | Duplicate account
[**apiV1EnvironmentFICOAAccountFIGet**](COAAccountFIApi.md#apiV1EnvironmentFICOAAccountFIGet) | **GET** /api/v1/{environment}/FI/COAAccountFI | Get new
[**apiV1EnvironmentFICOAAccountFIGetDocumentAccountPost**](COAAccountFIApi.md#apiV1EnvironmentFICOAAccountFIGetDocumentAccountPost) | **POST** /api/v1/{environment}/FI/COAAccountFI/GetDocumentAccount | Retrieve the account associated with the item, customer/supplier or account proposal
[**apiV1EnvironmentFICOAAccountFIGetFormatCodePost**](COAAccountFIApi.md#apiV1EnvironmentFICOAAccountFIGetFormatCodePost) | **POST** /api/v1/{environment}/FI/COAAccountFI/get_format_code | Formatted account
[**apiV1EnvironmentFICOAAccountFIIdDelete**](COAAccountFIApi.md#apiV1EnvironmentFICOAAccountFIIdDelete) | **DELETE** /api/v1/{environment}/FI/COAAccountFI/{id} | Delete
[**apiV1EnvironmentFICOAAccountFIIdGet**](COAAccountFIApi.md#apiV1EnvironmentFICOAAccountFIIdGet) | **GET** /api/v1/{environment}/FI/COAAccountFI/{id} | Get by ID
[**apiV1EnvironmentFICOAAccountFIIdIsDisabledPost**](COAAccountFIApi.md#apiV1EnvironmentFICOAAccountFIIdIsDisabledPost) | **POST** /api/v1/{environment}/FI/COAAccountFI/{id}/is_disabled | Verify if it&#39;s disabled
[**apiV1EnvironmentFICOAAccountFIIdPatch**](COAAccountFIApi.md#apiV1EnvironmentFICOAAccountFIIdPatch) | **PATCH** /api/v1/{environment}/FI/COAAccountFI/{id} | Update partial
[**apiV1EnvironmentFICOAAccountFIIdPut**](COAAccountFIApi.md#apiV1EnvironmentFICOAAccountFIIdPut) | **PUT** /api/v1/{environment}/FI/COAAccountFI/{id} | Update
[**apiV1EnvironmentFICOAAccountFIPost**](COAAccountFIApi.md#apiV1EnvironmentFICOAAccountFIPost) | **POST** /api/v1/{environment}/FI/COAAccountFI | Create
[**apiV1EnvironmentFICOAAccountFIReadPost**](COAAccountFIApi.md#apiV1EnvironmentFICOAAccountFIReadPost) | **POST** /api/v1/{environment}/FI/COAAccountFI/read | Read
[**apiV1EnvironmentFICOAAccountFIReferenceAccountfaPost**](COAAccountFIApi.md#apiV1EnvironmentFICOAAccountFIReferenceAccountfaPost) | **POST** /api/v1/{environment}/FI/COAAccountFI/reference_accountfa | Verify if fixed asset group code is referenced by gl account
[**apiV1EnvironmentFICOAAccountFISearchPost**](COAAccountFIApi.md#apiV1EnvironmentFICOAAccountFISearchPost) | **POST** /api/v1/{environment}/FI/COAAccountFI/search | Search
[**apiV1EnvironmentFICOAAccountFISwitchDownPost**](COAAccountFIApi.md#apiV1EnvironmentFICOAAccountFISwitchDownPost) | **POST** /api/v1/{environment}/FI/COAAccountFI/switch_down | Switch Down
[**apiV1EnvironmentFICOAAccountFISwitchUpPost**](COAAccountFIApi.md#apiV1EnvironmentFICOAAccountFISwitchUpPost) | **POST** /api/v1/{environment}/FI/COAAccountFI/switch_up | Switch Up
[**apiV1EnvironmentFICOAAccountFIUpdateCustomLanguageDescriptionsPost**](COAAccountFIApi.md#apiV1EnvironmentFICOAAccountFIUpdateCustomLanguageDescriptionsPost) | **POST** /api/v1/{environment}/FI/COAAccountFI/update_custom_language_descriptions | Update custom and language descriptions
[**apiV1EnvironmentFICOAAccountFIValidatePost**](COAAccountFIApi.md#apiV1EnvironmentFICOAAccountFIValidatePost) | **POST** /api/v1/{environment}/FI/COAAccountFI/validate | Validate
[**apiV1EnvironmentFICOAAccountFIValidatePropertiesPost**](COAAccountFIApi.md#apiV1EnvironmentFICOAAccountFIValidatePropertiesPost) | **POST** /api/v1/{environment}/FI/COAAccountFI/validateProperties | Validation of one on more properties of Type



## apiV1EnvironmentFICOAAccountFICalculatebalancePost

> AccountBalanceResultDTO apiV1EnvironmentFICOAAccountFICalculatebalancePost(environment, authorizationScope, cOAAccountBalanceParameters, opts)

Calculate balance for account

Calculate balance for account

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.COAAccountFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let cOAAccountBalanceParameters = new TseCloudFi.COAAccountBalanceParameters(); // COAAccountBalanceParameters | Account balance parameters
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFICOAAccountFICalculatebalancePost(environment, authorizationScope, cOAAccountBalanceParameters, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **cOAAccountBalanceParameters** | [**COAAccountBalanceParameters**](COAAccountBalanceParameters.md)| Account balance parameters | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**AccountBalanceResultDTO**](AccountBalanceResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFICOAAccountFIDuplicateAccountPost

> COAAccountFIDTO apiV1EnvironmentFICOAAccountFIDuplicateAccountPost(environment, authorizationScope, duplicateAccountParametersDTO, opts)

Duplicate account

Duplicate account

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.COAAccountFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let duplicateAccountParametersDTO = new TseCloudFi.DuplicateAccountParametersDTO(); // DuplicateAccountParametersDTO | Parameters for duplication
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFICOAAccountFIDuplicateAccountPost(environment, authorizationScope, duplicateAccountParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **duplicateAccountParametersDTO** | [**DuplicateAccountParametersDTO**](DuplicateAccountParametersDTO.md)| Parameters for duplication | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**COAAccountFIDTO**](COAAccountFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFICOAAccountFIGet

> COAAccountFIDTO apiV1EnvironmentFICOAAccountFIGet(op, environment, authorizationScope, opts)

Get new

Get an empty object of type corresponding

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.COAAccountFIApi();
let op = "op_example"; // String | The value must be 'new'
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFICOAAccountFIGet(op, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **op** | **String**| The value must be &#39;new&#39; | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**COAAccountFIDTO**](COAAccountFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFICOAAccountFIGetDocumentAccountPost

> GetDocumentAccountResultDTO apiV1EnvironmentFICOAAccountFIGetDocumentAccountPost(environment, authorizationScope, getDocumentAccountParametersDTO, opts)

Retrieve the account associated with the item, customer/supplier or account proposal

 It retrieve the account informations associated with the following priority:     1. From the item&#39;s account     2. From the customer/supplier accounts     3. From the account proposals

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.COAAccountFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let getDocumentAccountParametersDTO = new TseCloudFi.GetDocumentAccountParametersDTO(); // GetDocumentAccountParametersDTO | Parameter validation for processing
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFICOAAccountFIGetDocumentAccountPost(environment, authorizationScope, getDocumentAccountParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **getDocumentAccountParametersDTO** | [**GetDocumentAccountParametersDTO**](GetDocumentAccountParametersDTO.md)| Parameter validation for processing | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**GetDocumentAccountResultDTO**](GetDocumentAccountResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFICOAAccountFIGetFormatCodePost

> COAAccountMaskResultDTO apiV1EnvironmentFICOAAccountFIGetFormatCodePost(environment, authorizationScope, cOAAccountMaskParametersDTO, opts)

Formatted account

Formatted account

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.COAAccountFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let cOAAccountMaskParametersDTO = new TseCloudFi.COAAccountMaskParametersDTO(); // COAAccountMaskParametersDTO | Parameters
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFICOAAccountFIGetFormatCodePost(environment, authorizationScope, cOAAccountMaskParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **cOAAccountMaskParametersDTO** | [**COAAccountMaskParametersDTO**](COAAccountMaskParametersDTO.md)| Parameters | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**COAAccountMaskResultDTO**](COAAccountMaskResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFICOAAccountFIIdDelete

> apiV1EnvironmentFICOAAccountFIIdDelete(id, environment, authorizationScope, opts)

Delete

Deleting object of type 

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.COAAccountFIApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFICOAAccountFIIdDelete(id, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFICOAAccountFIIdGet

> COAAccountFIDTO apiV1EnvironmentFICOAAccountFIIdGet(id, environment, authorizationScope, opts)

Get by ID

Get an object of type corresponding the requested id

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.COAAccountFIApi();
let id = "id_example"; // String | Id to get the object
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'dlevel': "dlevel_example", // String | Serialization level
  'dlevelkey': "dlevelkey_example", // String | Serialization level key
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFICOAAccountFIIdGet(id, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Id to get the object | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **dlevel** | **String**| Serialization level | [optional] 
 **dlevelkey** | **String**| Serialization level key | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**COAAccountFIDTO**](COAAccountFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFICOAAccountFIIdIsDisabledPost

> IsAccountDisabledResultDTO apiV1EnvironmentFICOAAccountFIIdIsDisabledPost(id, environment, authorizationScope, opts)

Verify if it&#39;s disabled

Verify if it&#39;s disabled

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.COAAccountFIApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'deactivationdate': new Date("2013-10-20T19:20:30+01:00"), // Date | 
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'", // String | Example for multilanguage
  'body': null // Object | 
};
apiInstance.apiV1EnvironmentFICOAAccountFIIdIsDisabledPost(id, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **deactivationdate** | **Date**|  | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]
 **body** | **Object**|  | [optional] 

### Return type

[**IsAccountDisabledResultDTO**](IsAccountDisabledResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFICOAAccountFIIdPatch

> apiV1EnvironmentFICOAAccountFIIdPatch(id, environment, authorizationScope, body, opts)

Update partial

Patching an object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.COAAccountFIApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let body = null; // Object | Object of type to patch
let opts = {
  'force': "force_example", // String | The warning/s code to bypass (separated by ‘,’) during the execution
  'op': "op_example", // String | Set 'reload', if you want the DTO updated in the response request
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFICOAAccountFIIdPatch(id, environment, authorizationScope, body, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **body** | **Object**| Object of type to patch | 
 **force** | **String**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **String**| Set &#39;reload&#39;, if you want the DTO updated in the response request | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFICOAAccountFIIdPut

> COAAccountFIDTO apiV1EnvironmentFICOAAccountFIIdPut(id, environment, authorizationScope, cOAAccountFIDTO, opts)

Update

Updating an object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.COAAccountFIApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let cOAAccountFIDTO = new TseCloudFi.COAAccountFIDTO(); // COAAccountFIDTO | Object of type to update
let opts = {
  'force': "force_example", // String | The warning/s code to bypass (separated by ‘,’) during the execution
  'op': "op_example", // String | Set 'reload', if you want the DTO updated in the response request, otherwise will be returned null value
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFICOAAccountFIIdPut(id, environment, authorizationScope, cOAAccountFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **cOAAccountFIDTO** | [**COAAccountFIDTO**](COAAccountFIDTO.md)| Object of type to update | 
 **force** | **String**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **String**| Set &#39;reload&#39;, if you want the DTO updated in the response request, otherwise will be returned null value | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**COAAccountFIDTO**](COAAccountFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFICOAAccountFIPost

> COAAccountFIDTO apiV1EnvironmentFICOAAccountFIPost(environment, authorizationScope, cOAAccountFIDTO, opts)

Create

Creating new object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.COAAccountFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let cOAAccountFIDTO = new TseCloudFi.COAAccountFIDTO(); // COAAccountFIDTO | Object of type to create
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFICOAAccountFIPost(environment, authorizationScope, cOAAccountFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **cOAAccountFIDTO** | [**COAAccountFIDTO**](COAAccountFIDTO.md)| Object of type to create | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**COAAccountFIDTO**](COAAccountFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFICOAAccountFIReadPost

> COAAccountFIDTO apiV1EnvironmentFICOAAccountFIReadPost(environment, authorizationScope, searchElementDTO, opts)

Read

Read among object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.COAAccountFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let searchElementDTO = [new TseCloudFi.SearchElementDTO()]; // [SearchElementDTO] | Search criteria to apply
let opts = {
  'dlevel': "dlevel_example", // String | Serialization level
  'dlevelkey': "dlevelkey_example", // String | Serialization level key
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFICOAAccountFIReadPost(environment, authorizationScope, searchElementDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **searchElementDTO** | [**[SearchElementDTO]**](SearchElementDTO.md)| Search criteria to apply | 
 **dlevel** | **String**| Serialization level | [optional] 
 **dlevelkey** | **String**| Serialization level key | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**COAAccountFIDTO**](COAAccountFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFICOAAccountFIReferenceAccountfaPost

> Number apiV1EnvironmentFICOAAccountFIReferenceAccountfaPost(accountfacode, group, environment, authorizationScope, opts)

Verify if fixed asset group code is referenced by gl account

Verify if fixed asset group code is referenced by gl account

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.COAAccountFIApi();
let accountfacode = "accountfacode_example"; // String | FA group code
let group = "group_example"; // String | Group
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFICOAAccountFIReferenceAccountfaPost(accountfacode, group, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accountfacode** | **String**| FA group code | 
 **group** | **String**| Group | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

**Number**

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFICOAAccountFISearchPost

> COAAccountFIDTO apiV1EnvironmentFICOAAccountFISearchPost(environment, authorizationScope, searchDTO, opts)

Search

Search among object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.COAAccountFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let searchDTO = new TseCloudFi.SearchDTO(); // SearchDTO | Search criteria to apply
let opts = {
  'loadEntireDomain': "loadEntireDomain_example", // String | Specify 'loadEntireDomain=true' if you want all the aggregate
  'getTotalCount': "getTotalCount_example", // String | Specify 'getTotalCount=true' if you want the total number of elements
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFICOAAccountFISearchPost(environment, authorizationScope, searchDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **searchDTO** | [**SearchDTO**](SearchDTO.md)| Search criteria to apply | 
 **loadEntireDomain** | **String**| Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate | [optional] 
 **getTotalCount** | **String**| Specify &#39;getTotalCount&#x3D;true&#39; if you want the total number of elements | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**COAAccountFIDTO**](COAAccountFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFICOAAccountFISwitchDownPost

> COAAccountFIDTO apiV1EnvironmentFICOAAccountFISwitchDownPost(environment, authorizationScope, switchCOAAccountParametersDTO, opts)

Switch Down

Switch Down

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.COAAccountFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let switchCOAAccountParametersDTO = new TseCloudFi.SwitchCOAAccountParametersDTO(); // SwitchCOAAccountParametersDTO | Parameters
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFICOAAccountFISwitchDownPost(environment, authorizationScope, switchCOAAccountParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **switchCOAAccountParametersDTO** | [**SwitchCOAAccountParametersDTO**](SwitchCOAAccountParametersDTO.md)| Parameters | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**COAAccountFIDTO**](COAAccountFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFICOAAccountFISwitchUpPost

> COAAccountFIDTO apiV1EnvironmentFICOAAccountFISwitchUpPost(environment, authorizationScope, switchCOAAccountParametersDTO, opts)

Switch Up

Switch Up

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.COAAccountFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let switchCOAAccountParametersDTO = new TseCloudFi.SwitchCOAAccountParametersDTO(); // SwitchCOAAccountParametersDTO | Parameters
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFICOAAccountFISwitchUpPost(environment, authorizationScope, switchCOAAccountParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **switchCOAAccountParametersDTO** | [**SwitchCOAAccountParametersDTO**](SwitchCOAAccountParametersDTO.md)| Parameters | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**COAAccountFIDTO**](COAAccountFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFICOAAccountFIUpdateCustomLanguageDescriptionsPost

> UpdateCustomAndLanguageDescriptionsResultDTO apiV1EnvironmentFICOAAccountFIUpdateCustomLanguageDescriptionsPost(environment, authorizationScope, updateCustomAndLanguageDescriptionsParamsDTO, opts)

Update custom and language descriptions

Update custom and language descriptions

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.COAAccountFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let updateCustomAndLanguageDescriptionsParamsDTO = new TseCloudFi.UpdateCustomAndLanguageDescriptionsParamsDTO(); // UpdateCustomAndLanguageDescriptionsParamsDTO | Parameters for updates
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFICOAAccountFIUpdateCustomLanguageDescriptionsPost(environment, authorizationScope, updateCustomAndLanguageDescriptionsParamsDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **updateCustomAndLanguageDescriptionsParamsDTO** | [**UpdateCustomAndLanguageDescriptionsParamsDTO**](UpdateCustomAndLanguageDescriptionsParamsDTO.md)| Parameters for updates | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**UpdateCustomAndLanguageDescriptionsResultDTO**](UpdateCustomAndLanguageDescriptionsResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFICOAAccountFIValidatePost

> apiV1EnvironmentFICOAAccountFIValidatePost(environment, authorizationScope, cOAAccountFIDTO, opts)

Validate

Validation of object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.COAAccountFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let cOAAccountFIDTO = new TseCloudFi.COAAccountFIDTO(); // COAAccountFIDTO | Object of type to validate
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFICOAAccountFIValidatePost(environment, authorizationScope, cOAAccountFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **cOAAccountFIDTO** | [**COAAccountFIDTO**](COAAccountFIDTO.md)| Object of type to validate | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFICOAAccountFIValidatePropertiesPost

> ValidateDTO apiV1EnvironmentFICOAAccountFIValidatePropertiesPost(environment, authorizationScope, opts)

Validation of one on more properties of Type

Validation of object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.COAAccountFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'", // String | Example for multilanguage
  'body': null // String |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br>
};
apiInstance.apiV1EnvironmentFICOAAccountFIValidatePropertiesPost(environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]
 **body** | **String**|  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED&lt;br&gt; - The id of an existing object to validate properties, or &#39;&#39; if the object does not exist yet &lt;br&gt; | [optional] 

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json, application/xml

