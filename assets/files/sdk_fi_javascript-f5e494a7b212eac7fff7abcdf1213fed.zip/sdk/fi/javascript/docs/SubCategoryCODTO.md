# TseCloudFi.SubCategoryCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categMg11** | **String** | MG12_CATEG_MG11 - Categoria | 
**descrsottocat** | **String** | MG12_DESCRSOTTOCAT - Descrizione | [optional] 
**dittaCg18** | **Number** | MG12_DITTA_CG18 - Ditta | [optional] 
**macrocatMg11** | **String** | MG12_MACROCAT_MG11 - Macrocategoria | 
**sottcat** | **String** | MG12_SOTTCAT - Sottocategoria | 
**tipocfMg11** | **Number** | MG12_TIPOCF_MG11 - Tipo Cli/For&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: TipocfMg11Enum


* `0` (value: `0`)

* `1` (value: `1`)




