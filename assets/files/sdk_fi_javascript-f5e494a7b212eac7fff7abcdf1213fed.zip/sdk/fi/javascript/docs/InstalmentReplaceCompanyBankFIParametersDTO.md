# TseCloudFi.InstalmentReplaceCompanyBankFIParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instalmentIds** | **[Number]** |  | [optional] 
**newCompanyBankFI** | **Number** |  | [optional] 
**oldCompanyBankFI** | **Number** |  | [optional] 
**isUpdate** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


