# TseCloudFi.GLEntryFIGetXSLTParameters

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**idSdi** | **String** |  | [optional] 
**hubid** | **String** |  | [optional] 
**isAssoSoftware** | **Boolean** |  | [optional] 


