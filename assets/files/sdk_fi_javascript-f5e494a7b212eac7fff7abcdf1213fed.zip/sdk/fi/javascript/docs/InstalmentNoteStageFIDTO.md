# TseCloudFi.InstalmentNoteStageFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**changed** | **Boolean** | Changed - Changed | [optional] 
**id** | **Number** | EF04_ID - Id | 
**idEf01** | **Number** | EF04_ID_EF01 - IdEf01 | 
**idEf01Stage** | **Number** | EF04_ID_EF01_STAGE - IdEf01Stage | 
**idStage** | **Number** | EF04_ID_STAGE - IdStage (Required only in PUT/PATCH) | [optional] 
**noteammin** | **String** | EF04_NOTEAMMIN - Noteammin | [optional] 
**noteraggr** | **String** | EF04_NOTERAGGR - Noteraggr | [optional] 
**recordtype** | **Number** | RecordType - Recordtype | [optional] 
**rowversion** | **Blob** | EF04_ROWVERSION - Rowversion | [optional] 
**stageguid** | **String** | StageGuid - Stageguid | [optional] 
**stagestate** | **Number** | Stagestate - Stagestate | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


