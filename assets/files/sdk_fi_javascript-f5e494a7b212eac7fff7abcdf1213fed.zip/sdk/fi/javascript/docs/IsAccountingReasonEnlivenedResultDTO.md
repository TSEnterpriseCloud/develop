# TseCloudFi.IsAccountingReasonEnlivenedResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enlivened** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


