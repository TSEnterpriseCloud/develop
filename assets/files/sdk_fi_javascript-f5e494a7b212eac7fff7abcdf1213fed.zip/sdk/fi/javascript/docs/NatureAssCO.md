# TseCloudFi.NatureAssCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codice** | **String** |  | [optional] 
**datafineval** | **Date** |  | [optional] 
**datainival** | **Date** |  | [optional] 
**descr** | **String** |  | [optional] 
**idassosw** | **Number** |  | [optional] 
**idCg2m** | **Number** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**parent** | [**NatureEsCO**](NatureEsCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


