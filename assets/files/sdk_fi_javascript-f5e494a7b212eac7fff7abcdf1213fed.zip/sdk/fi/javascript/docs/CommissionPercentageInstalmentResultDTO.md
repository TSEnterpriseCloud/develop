# TseCloudFi.CommissionPercentageInstalmentResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**percentage** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


