# TseCloudFi.GLEntryRowChangeAllowedDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numReg** | **String** |  | [optional] 
**rowNumber** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


