# TseCloudFi.InstalmentManualVariationFIResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**saved** | **Boolean** |  | [optional] 
**addedToHistory** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


