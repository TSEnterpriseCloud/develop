# TseCloudFi.IdsListFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ids** | **[Number]** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


