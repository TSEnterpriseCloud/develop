# TseCloudFi.BankDispositionFIParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**indPresentationBank** | **Number** |  | [optional] 
**presentationBank** | **Number** |  | [optional] 
**creationDate** | **String** |  | [optional] 
**office** | **Number** |  | [optional] 
**indPresentation** | **Number** |  | [optional] 
**indTipoEff** | **Number** |  | [optional] 
**gruppoCg10** | **Number** |  | [optional] 
**isDiscount** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


