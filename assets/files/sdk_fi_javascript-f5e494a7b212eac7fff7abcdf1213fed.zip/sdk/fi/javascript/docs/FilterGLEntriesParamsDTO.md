# TseCloudFi.FilterGLEntriesParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customFilter** | [**SearchDTO**](SearchDTO.md) |  | [optional] 
**idProcessingDetails** | **Number** |  | [optional] 
**idEntities** | **[String]** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


