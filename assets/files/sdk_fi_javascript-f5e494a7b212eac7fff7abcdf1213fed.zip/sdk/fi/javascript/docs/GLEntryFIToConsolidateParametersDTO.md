# TseCloudFi.GLEntryFIToConsolidateParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 


