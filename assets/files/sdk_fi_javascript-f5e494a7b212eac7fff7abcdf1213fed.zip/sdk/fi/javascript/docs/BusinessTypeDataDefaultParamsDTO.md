# TseCloudFi.BusinessTypeDataDefaultParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**datareg** | **Date** |  | [optional] 
**sez** | **String** |  | [optional] 


