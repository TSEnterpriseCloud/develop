# TseCloudFi.InstalmentReminderFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**adatacalc** | **Date** | EF05_ADATACALC - A data | [optional] 
**codBlocMg25** | **String** | EF05_CODBLOC_MG25 - Codice Blocco | [optional] 
**dadatacalc** | **Date** | EF05_DADATACALC - Da data | [optional] 
**dataavviso** | **Date** | EF05_DATAAVVISO - Data avviso | 
**datadoc** | **Date** | EF05_DATADOC - Data documento | [optional] 
**datarifelab** | **Date** | EF05_DATARIFELAB - Data riferimento elaborazione | 
**dittaCg18** | **Number** | EF05_DITTA_CG18 - Codice ditta | 
**documMg36** | **String** | EF05_DOCUM_MG36 - Tipo documento | [optional] 
**flgAzlegal** | **Number** | EF05_FLGAZLEGAL - Azione legale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgCalcint** | **Number** | EF05_FLGCALCINT - Calcolo interessi&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgDocbis** | **Number** | EF05_FLGDOCBIS - Documento bis | 
**flgEmisdoc** | **Number** | EF05_FLGEMISDOC - Emissione documento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgInvioage** | **Number** | EF05_FLGINVIOAGE - Invio agente&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgPers1** | **Number** | EF05_FLGPERS1 - Personalizzabile 1 | 
**flgPers2** | **Number** | EF05_FLGPERS2 - Personalizzabile 2 | 
**id** | **Number** | EF05_ID - Id (Required only in PUT/PATCH) | [optional] 
**idEf01** | **Number** | EF05_ID_EF01 - IdEf01 | 
**impadetr** | **Number** | EF05_IMPADETR - Impadetr | 
**impinteres** | **Number** | EF05_IMPINTERES - Importo interessi | [optional] 
**indBloc** | **Number** | EF05_INDBLOC - Indicatore blocco&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Blocco fisso&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Blocco mobile&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Non applicato&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indImpadetr** | **Number** | EF05_INDIMPADETR - IndImpadetr | 
**numdist** | **Number** | EF05_NUMDIST - Numero distinta | 
**numdoc** | **Number** | EF05_NUMDOC - Numero documento | [optional] 
**numregCo99** | **String** | EF05_NUMREG_CO99 - NumregCo99 | 
**numregDo11** | **String** | EF05_NUMREG_DO11 - NumregDo11 | [optional] 
**progAvvisi** | **Number** | EF05_PROGAVVISI - Progressivo avviso | 
**progEffEf01** | **Number** | EF05_PROGEFF_EF01 - ProgEffEf01 | 
**progREf08** | **Number** | EF05_PROGR_EF08 - ProgREf08 | [optional] 
**progRigaSpeseint** | **Number** | EF05_PROGRIGA_SPESEINT - ProgRigaSpeseint | [optional] 
**progRigaSpeseprot** | **Number** | EF05_PROGRIGA_SPESEPROT - ProgRigaSpeseprot | [optional] 
**riffiglia** | **Number** | EF05_RIFFIGLIA - Riffiglia | 
**rifpadre** | **Number** | EF05_RIFPADRE - Rifpadre | 
**rigacontEf01** | **Number** | EF05_RIGACONT_EF01 - RigacontEf01 | 
**rowversion** | **Blob** | EF05_ROWVERSION - Rowversion | [optional] 
**sezdoc** | **String** | EF05_SEZDOC - Sezionale documento | [optional] 
**siglalettera** | **String** | EF05_SIGLALETTERA - Sigla lettera | [optional] 
**spbollo** | **Number** | EF05_SPBOLLO - Spese bollo | [optional] 
**speserit** | **Number** | EF05_SPESERIT - Spese di ritorno | [optional] 
**sppost** | **Number** | EF05_SPPOST - Spese postali | [optional] 
**spvarie** | **Number** | EF05_SPVARIE - Spese varie | [optional] 
**tassoint** | **Number** | EF05_TASSOINT - Tasso d&#39;interesse | [optional] 
**testopers** | **String** | EF05_TESTOPERS - Nota | [optional] 
**companyBank** | [**CompanyBankFIDTO**](CompanyBankFIDTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgAzlegalEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgCalcintEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgEmisdocEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgInvioageEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndBlocEnum


* `2` (value: `2`)

* `1` (value: `1`)

* `0` (value: `0`)




