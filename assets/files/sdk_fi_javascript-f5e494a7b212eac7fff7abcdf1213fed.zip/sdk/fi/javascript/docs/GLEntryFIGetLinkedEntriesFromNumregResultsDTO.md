# TseCloudFi.GLEntryFIGetLinkedEntriesFromNumregResultsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entriesChilds** | **[{String: Object}]** |  | [optional] 
**entryParent** | **{String: Object}** |  | [optional] 
**executionResult** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


