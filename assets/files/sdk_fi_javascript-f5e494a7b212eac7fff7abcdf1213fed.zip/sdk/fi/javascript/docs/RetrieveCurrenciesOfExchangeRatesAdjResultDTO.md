# TseCloudFi.RetrieveCurrenciesOfExchangeRatesAdjResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currencies** | **[String]** |  | [optional] 
**exchanges** | **[Number]** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


