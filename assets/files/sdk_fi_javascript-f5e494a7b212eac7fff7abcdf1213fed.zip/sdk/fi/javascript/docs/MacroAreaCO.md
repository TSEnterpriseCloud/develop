# TseCloudFi.MacroAreaCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codiceMacroarea** | **String** |  | [optional] 
**descrmacroar** | **String** |  | [optional] 
**dittaCg18** | **Number** |  | [optional] 
**idEntityWithDescriptions** | **Number** |  | [optional] 
**idmediaCg99** | **Number** |  | [optional] 
**idprov** | **Number** |  | [optional] 
**tipocf** | **Number** |  | [optional] 
**areas** | [**[AreaCO]**](AreaCO.md) |  | [optional] 
**descrizioniLingua** | [**[LanguageDescriptionMGCO]**](LanguageDescriptionMGCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


