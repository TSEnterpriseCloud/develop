# TseCloudFi.ICustomerSupplierContract

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idCliFor** | **Number** |  | [optional] [readonly] 
**cliFor** | **Number** |  | [optional] [readonly] 
**tipoCf** | **Number** |  | [optional] [readonly] 
**dittaCg18** | **Number** |  | [optional] [readonly] 


