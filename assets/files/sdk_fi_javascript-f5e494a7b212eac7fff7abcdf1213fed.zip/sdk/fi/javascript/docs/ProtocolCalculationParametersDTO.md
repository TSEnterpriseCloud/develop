# TseCloudFi.ProtocolCalculationParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**anno** | **Number** |  | [optional] 
**sez** | **String** |  | [optional] 
**tipodocint** | **Number** |  | [optional] 
**causale** | **String** |  | [optional] 
**tipoMovimento** | **Number** |  | [optional] 
**tipoOperazione** | **Number** |  | [optional] 
**datareg** | **String** |  | [optional] 
**numDocDaAggiornare** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


