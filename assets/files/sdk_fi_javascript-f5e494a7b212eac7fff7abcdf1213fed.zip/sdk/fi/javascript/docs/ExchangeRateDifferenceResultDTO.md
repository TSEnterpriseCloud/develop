# TseCloudFi.ExchangeRateDifferenceResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exchangeDifferenceAmount** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


