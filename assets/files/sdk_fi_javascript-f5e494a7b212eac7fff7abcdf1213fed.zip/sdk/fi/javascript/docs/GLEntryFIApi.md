# TseCloudFi.GLEntryFIApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiV1EnvironmentFIGLEntryFIArchiveB2BFileFepaPassPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIArchiveB2BFileFepaPassPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/ArchiveB2BFileFepaPass | Archive B2B file Fepa pass
[**apiV1EnvironmentFIGLEntryFIAutoArchiveB2BFileFepaPassPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIAutoArchiveB2BFileFepaPassPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/AutoArchiveB2BFileFepaPass | Auto archive B2B file Fepa pass
[**apiV1EnvironmentFIGLEntryFICalculateNextGLEntryProtocolPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFICalculateNextGLEntryProtocolPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/CalculateNextGLEntryProtocol | Calculate the next available protocol for gl entries
[**apiV1EnvironmentFIGLEntryFICalculatecreditlinePost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFICalculatecreditlinePost) | **POST** /api/v1/{environment}/FI/GLEntryFI/calculatecreditline | Calculate credit line
[**apiV1EnvironmentFIGLEntryFICheckConfigurationExchangeDiffPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFICheckConfigurationExchangeDiffPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/CheckConfigurationExchangeDiff | Checks configuration exchange differences
[**apiV1EnvironmentFIGLEntryFICloseVatOnPaymentsPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFICloseVatOnPaymentsPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/CloseVatOnPayments | Close Vat on payments
[**apiV1EnvironmentFIGLEntryFICrossBorderDetailOperationPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFICrossBorderDetailOperationPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/CrossBorderDetailOperation | Cross-border operations (detail)
[**apiV1EnvironmentFIGLEntryFICrossBorderOperationPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFICrossBorderOperationPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/CrossBorderOperation | Cross-border operations
[**apiV1EnvironmentFIGLEntryFIDecumulateCalculationPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIDecumulateCalculationPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/DecumulateCalculation | Percentage unbundling calculation
[**apiV1EnvironmentFIGLEntryFIDeleteClosingReopeningPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIDeleteClosingReopeningPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/DeleteClosingReopening | Eliminates the records of the tables related to an accounting processing
[**apiV1EnvironmentFIGLEntryFIDeleteExchangeDifferencePost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIDeleteExchangeDifferencePost) | **POST** /api/v1/{environment}/FI/GLEntryFI/DeleteExchangeDifference | Eliminates the records of the tables related to an accounting processing
[**apiV1EnvironmentFIGLEntryFIEnabledtoprojectsPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIEnabledtoprojectsPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/enabledtoprojects | Check if the gl entry can open project entries
[**apiV1EnvironmentFIGLEntryFIFilterglentriesPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIFilterglentriesPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/filterglentries | FilterGlentries
[**apiV1EnvironmentFIGLEntryFIGLEntryPartialValidatePost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIGLEntryPartialValidatePost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GLEntryPartialValidate | GL ENtry Header validations
[**apiV1EnvironmentFIGLEntryFIGet**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIGet) | **GET** /api/v1/{environment}/FI/GLEntryFI | Get new
[**apiV1EnvironmentFIGLEntryFIGetApplicationVersionPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIGetApplicationVersionPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetApplicationVersion | Application version reading
[**apiV1EnvironmentFIGLEntryFIGetBusinessTypeDataDefaultPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIGetBusinessTypeDataDefaultPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetBusinessTypeDataDefault | Get default dbsiness type data
[**apiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankMovementsPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankMovementsPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetEligibleIdsFromBankMovements | Request the list of bank movements to account
[**apiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankReconcileMovementsPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankReconcileMovementsPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetEligibleIdsFromBankReconcileMovements | Request the list of reconcilable bank transactions
[**apiV1EnvironmentFIGLEntryFIGetEligibleIdsFromTsDigitalPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIGetEligibleIdsFromTsDigitalPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetEligibleIdsFromTsDigital | Request the list of TsDigital movements to account
[**apiV1EnvironmentFIGLEntryFIGetFileFepaPassCOPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIGetFileFepaPassCOPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetFileFepaPassCO | Read by key B2B file Fepa pass and fix it
[**apiV1EnvironmentFIGLEntryFIGetGLEntryAccountingReasonCodeDataGet**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIGetGLEntryAccountingReasonCodeDataGet) | **GET** /api/v1/{environment}/FI/GLEntryFI/GetGLEntryAccountingReasonCodeData | Data reading for accounting reason code
[**apiV1EnvironmentFIGLEntryFIGetGLEntryAdditionalDataPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIGetGLEntryAdditionalDataPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetGLEntryAdditionalData | Data reading for withholdings deadlines
[**apiV1EnvironmentFIGLEntryFIGetGLEntryOffSetPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIGetGLEntryOffSetPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetGLEntryOffSet | Get gl entry off set
[**apiV1EnvironmentFIGLEntryFIGetLinkedEntriesFromNumregPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIGetLinkedEntriesFromNumregPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetLinkedEntriesFromNumreg | Returns all gl entries starting from a registration number.
[**apiV1EnvironmentFIGLEntryFIGetNumregByDetailIdPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIGetNumregByDetailIdPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetNumregByDetailId | Get GLEntry numreg by detail id
[**apiV1EnvironmentFIGLEntryFIGetTracciatoDocumentalePost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIGetTracciatoDocumentalePost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetTracciatoDocumentale | Retrieve document track
[**apiV1EnvironmentFIGLEntryFIGetVatRegistryResultPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIGetVatRegistryResultPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/GetVatRegistryResult | Get vat registry result
[**apiV1EnvironmentFIGLEntryFIGetxsltPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIGetxsltPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/getxslt | Get XSLT
[**apiV1EnvironmentFIGLEntryFIIdDelete**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIIdDelete) | **DELETE** /api/v1/{environment}/FI/GLEntryFI/{id} | Delete
[**apiV1EnvironmentFIGLEntryFIIdGet**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIIdGet) | **GET** /api/v1/{environment}/FI/GLEntryFI/{id} | Get by ID
[**apiV1EnvironmentFIGLEntryFIIdPatch**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIIdPatch) | **PATCH** /api/v1/{environment}/FI/GLEntryFI/{id} | Update partial
[**apiV1EnvironmentFIGLEntryFIIdPut**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIIdPut) | **PUT** /api/v1/{environment}/FI/GLEntryFI/{id} | Update
[**apiV1EnvironmentFIGLEntryFIImportDocB2BFileFepaPassPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIImportDocB2BFileFepaPassPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/ImportDocB2BFileFepaPass | Import B2B file Fepa pass
[**apiV1EnvironmentFIGLEntryFIImportInvoiceFepaPassFIPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIImportInvoiceFepaPassFIPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/ImportInvoiceFepaPassFI | Import file Fepa pass
[**apiV1EnvironmentFIGLEntryFIInsertmissingexchangeratesPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIInsertmissingexchangeratesPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/insertmissingexchangerates | Insert missing exchange rate
[**apiV1EnvironmentFIGLEntryFIIsCheckListEnabledGet**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIIsCheckListEnabledGet) | **GET** /api/v1/{environment}/FI/GLEntryFI/IsCheckListEnabled | Returns if the checklist functionality on glentry landing is enabled
[**apiV1EnvironmentFIGLEntryFIModuleintegrationinfosupdatePost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIModuleintegrationinfosupdatePost) | **POST** /api/v1/{environment}/FI/GLEntryFI/moduleintegrationinfosupdate | Updates module integration infos
[**apiV1EnvironmentFIGLEntryFIMulticreatePost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIMulticreatePost) | **POST** /api/v1/{environment}/FI/GLEntryFI/multicreate | Multiple creation of gl entries
[**apiV1EnvironmentFIGLEntryFIMultiplecreatejobPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIMultiplecreatejobPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/multiplecreatejob | Job creation of multiple entry of gl entries
[**apiV1EnvironmentFIGLEntryFIPaymentwithholdingtaxesaccountingPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIPaymentwithholdingtaxesaccountingPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/paymentwithholdingtaxesaccounting | Payment withholding taxes accounting
[**apiV1EnvironmentFIGLEntryFIPlafondinfoPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIPlafondinfoPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/plafondinfo | Reading of the ceiling management indicator
[**apiV1EnvironmentFIGLEntryFIPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIPost) | **POST** /api/v1/{environment}/FI/GLEntryFI | Create
[**apiV1EnvironmentFIGLEntryFIPreviewPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIPreviewPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/preview | Preview of a gl entry
[**apiV1EnvironmentFIGLEntryFIReadPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIReadPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/read | Read
[**apiV1EnvironmentFIGLEntryFIReelaborateInvoiceFepaPassFIPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIReelaborateInvoiceFepaPassFIPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/ReelaborateInvoiceFepaPassFI | Reelaborate file Fepa pass
[**apiV1EnvironmentFIGLEntryFIResidualCalculationPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIResidualCalculationPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/ResidualCalculation | Residual accounting entry calculation
[**apiV1EnvironmentFIGLEntryFIRestoreB2BFileFepaPassPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIRestoreB2BFileFepaPassPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/RestoreB2BFileFepaPass | Restore B2B file Fepa pass
[**apiV1EnvironmentFIGLEntryFIRestoreInvoiceFepaPassFIPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIRestoreInvoiceFepaPassFIPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/RestoreInvoiceFepaPassFI | Restore file Fepa pass
[**apiV1EnvironmentFIGLEntryFIRetrieveCurrenciesOfExchangeRatesAdjPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIRetrieveCurrenciesOfExchangeRatesAdjPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/RetrieveCurrenciesOfExchangeRatesAdj | Manages the recovery of all currencies and relative exchange rates belonging to an accounting process
[**apiV1EnvironmentFIGLEntryFIRunreportrglentriesPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIRunreportrglentriesPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/runreportrglentries | RunReportGlentries
[**apiV1EnvironmentFIGLEntryFISearchPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFISearchPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/search | Search
[**apiV1EnvironmentFIGLEntryFISetGLEntryFromBankTransactionsMovPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFISetGLEntryFromBankTransactionsMovPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/SetGLEntryFromBankTransactionsMov | Import bank transactions
[**apiV1EnvironmentFIGLEntryFISetGLEntryFromTsDigitalPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFISetGLEntryFromTsDigitalPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/SetGLEntryFromTsDigital | Import TsDigital entry
[**apiV1EnvironmentFIGLEntryFISetGLEntryLinkedF24MovementsIdPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFISetGLEntryLinkedF24MovementsIdPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/SetGLEntryLinkedF24MovementsId | Set GLEntry linked F24 movements
[**apiV1EnvironmentFIGLEntryFIShowPDFInvoicePost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIShowPDFInvoicePost) | **POST** /api/v1/{environment}/FI/GLEntryFI/showPDFInvoice | View the invoice in PDF format
[**apiV1EnvironmentFIGLEntryFIStageCleanGLEntryPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIStageCleanGLEntryPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/StageCleanGLEntry | Cleaning GLEntry and related stage tables
[**apiV1EnvironmentFIGLEntryFIToConsolidatePost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIToConsolidatePost) | **POST** /api/v1/{environment}/FI/GLEntryFI/ToConsolidate | Returns all gl entries starting from a registration number.
[**apiV1EnvironmentFIGLEntryFIUpdatehubidsdiPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIUpdatehubidsdiPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/updatehubidsdi | Update CG41_HUBID and CG41_IDSDI
[**apiV1EnvironmentFIGLEntryFIValidatePost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIValidatePost) | **POST** /api/v1/{environment}/FI/GLEntryFI/validate | Validate
[**apiV1EnvironmentFIGLEntryFIValidatePropertiesPost**](GLEntryFIApi.md#apiV1EnvironmentFIGLEntryFIValidatePropertiesPost) | **POST** /api/v1/{environment}/FI/GLEntryFI/validateProperties | Validation of one on more properties of Type



## apiV1EnvironmentFIGLEntryFIArchiveB2BFileFepaPassPost

> FIGLEntriesExecutionResultDTO apiV1EnvironmentFIGLEntryFIArchiveB2BFileFepaPassPost(environment, authorizationScope, idsListFIDTO, opts)

Archive B2B file Fepa pass

Archive B2B file Fepa pass

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let idsListFIDTO = new TseCloudFi.IdsListFIDTO(); // IdsListFIDTO | Input params
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIArchiveB2BFileFepaPassPost(environment, authorizationScope, idsListFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **idsListFIDTO** | [**IdsListFIDTO**](IdsListFIDTO.md)| Input params | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIAutoArchiveB2BFileFepaPassPost

> FIGLEntriesExecutionResultDTO apiV1EnvironmentFIGLEntryFIAutoArchiveB2BFileFepaPassPost(environment, authorizationScope, opts)

Auto archive B2B file Fepa pass

Auto archive B2B file Fepa pass

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIAutoArchiveB2BFileFepaPassPost(environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFICalculateNextGLEntryProtocolPost

> ProtocolCalculationResultDTO apiV1EnvironmentFIGLEntryFICalculateNextGLEntryProtocolPost(environment, authorizationScope, protocolCalculationParametersDTO, opts)

Calculate the next available protocol for gl entries

Calculate the next available protocol for gl entries

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let protocolCalculationParametersDTO = new TseCloudFi.ProtocolCalculationParametersDTO(); // ProtocolCalculationParametersDTO | Object that contains all the parameters that are used in the calculation
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFICalculateNextGLEntryProtocolPost(environment, authorizationScope, protocolCalculationParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **protocolCalculationParametersDTO** | [**ProtocolCalculationParametersDTO**](ProtocolCalculationParametersDTO.md)| Object that contains all the parameters that are used in the calculation | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**ProtocolCalculationResultDTO**](ProtocolCalculationResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFICalculatecreditlinePost

> CalculateCreditLineResultDTO apiV1EnvironmentFIGLEntryFICalculatecreditlinePost(environment, authorizationScope, calculateCreditLineParamsDTO, opts)

Calculate credit line

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let calculateCreditLineParamsDTO = new TseCloudFi.CalculateCreditLineParamsDTO(); // CalculateCreditLineParamsDTO | Input parameters for elaboration
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFICalculatecreditlinePost(environment, authorizationScope, calculateCreditLineParamsDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **calculateCreditLineParamsDTO** | [**CalculateCreditLineParamsDTO**](CalculateCreditLineParamsDTO.md)| Input parameters for elaboration | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**CalculateCreditLineResultDTO**](CalculateCreditLineResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFICheckConfigurationExchangeDiffPost

> FIGLEntriesExecutionResultDTO apiV1EnvironmentFIGLEntryFICheckConfigurationExchangeDiffPost(environment, authorizationScope, opts)

Checks configuration exchange differences

Checks configuration exchange differences

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFICheckConfigurationExchangeDiffPost(environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFICloseVatOnPaymentsPost

> apiV1EnvironmentFIGLEntryFICloseVatOnPaymentsPost(environment, authorizationScope, vatPaymentCloseFromVATReturnParametersDTO, opts)

Close Vat on payments

Close Vat on payments

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let vatPaymentCloseFromVATReturnParametersDTO = new TseCloudFi.VatPaymentCloseFromVATReturnParametersDTO(); // VatPaymentCloseFromVATReturnParametersDTO | Input params
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFICloseVatOnPaymentsPost(environment, authorizationScope, vatPaymentCloseFromVATReturnParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **vatPaymentCloseFromVATReturnParametersDTO** | [**VatPaymentCloseFromVATReturnParametersDTO**](VatPaymentCloseFromVATReturnParametersDTO.md)| Input params | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined


## apiV1EnvironmentFIGLEntryFICrossBorderDetailOperationPost

> ValidateDTO apiV1EnvironmentFIGLEntryFICrossBorderDetailOperationPost(environment, authorizationScope, crossBorderDetailOperationParamsDTO, opts)

Cross-border operations (detail)

Change IndNatura, FlgDeducibile and PercDetr of the GLVATDetailFI table

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let crossBorderDetailOperationParamsDTO = new TseCloudFi.CrossBorderDetailOperationParamsDTO(); // CrossBorderDetailOperationParamsDTO | Parameters for operations
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFICrossBorderDetailOperationPost(environment, authorizationScope, crossBorderDetailOperationParamsDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **crossBorderDetailOperationParamsDTO** | [**CrossBorderDetailOperationParamsDTO**](CrossBorderDetailOperationParamsDTO.md)| Parameters for operations | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFICrossBorderOperationPost

> ValidateDTO apiV1EnvironmentFIGLEntryFICrossBorderOperationPost(environment, authorizationScope, crossBorderOperationParamsDTO, opts)

Cross-border operations

Cross-border operations

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let crossBorderOperationParamsDTO = new TseCloudFi.CrossBorderOperationParamsDTO(); // CrossBorderOperationParamsDTO | Parameters for operations 
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFICrossBorderOperationPost(environment, authorizationScope, crossBorderOperationParamsDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **crossBorderOperationParamsDTO** | [**CrossBorderOperationParamsDTO**](CrossBorderOperationParamsDTO.md)| Parameters for operations  | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIDecumulateCalculationPost

> DecumulateCalculationResultDTO apiV1EnvironmentFIGLEntryFIDecumulateCalculationPost(environment, authorizationScope, decumulateCalculationParametersDTO, opts)

Percentage unbundling calculation

Calculate the value resulting from the separation of the percentage requested on the initial amount indicated

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let decumulateCalculationParametersDTO = new TseCloudFi.DecumulateCalculationParametersDTO(); // DecumulateCalculationParametersDTO | Input parameters for calculation
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIDecumulateCalculationPost(environment, authorizationScope, decumulateCalculationParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **decumulateCalculationParametersDTO** | [**DecumulateCalculationParametersDTO**](DecumulateCalculationParametersDTO.md)| Input parameters for calculation | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**DecumulateCalculationResultDTO**](DecumulateCalculationResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIDeleteClosingReopeningPost

> DeleteClosingReopeningResultDTO apiV1EnvironmentFIGLEntryFIDeleteClosingReopeningPost(environment, authorizationScope, deleteClosingReopeningParamsDTO, opts)

Eliminates the records of the tables related to an accounting processing

Eliminates the records of the tables related to an accounting processing

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let deleteClosingReopeningParamsDTO = new TseCloudFi.DeleteClosingReopeningParamsDTO(); // DeleteClosingReopeningParamsDTO | An object that contains all the parameters that are used in the processing
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIDeleteClosingReopeningPost(environment, authorizationScope, deleteClosingReopeningParamsDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **deleteClosingReopeningParamsDTO** | [**DeleteClosingReopeningParamsDTO**](DeleteClosingReopeningParamsDTO.md)| An object that contains all the parameters that are used in the processing | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**DeleteClosingReopeningResultDTO**](DeleteClosingReopeningResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIDeleteExchangeDifferencePost

> DeleteExchangeDifferenceResultDTO apiV1EnvironmentFIGLEntryFIDeleteExchangeDifferencePost(environment, authorizationScope, deleteExchangeDifferenceParamsDTO, opts)

Eliminates the records of the tables related to an accounting processing

Eliminates the records of the tables related to an accounting processing

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let deleteExchangeDifferenceParamsDTO = new TseCloudFi.DeleteExchangeDifferenceParamsDTO(); // DeleteExchangeDifferenceParamsDTO | An object that contains all the parameters that are used in the processing
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIDeleteExchangeDifferencePost(environment, authorizationScope, deleteExchangeDifferenceParamsDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **deleteExchangeDifferenceParamsDTO** | [**DeleteExchangeDifferenceParamsDTO**](DeleteExchangeDifferenceParamsDTO.md)| An object that contains all the parameters that are used in the processing | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**DeleteExchangeDifferenceResultDTO**](DeleteExchangeDifferenceResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIEnabledtoprojectsPost

> FIGLEntriesExecutionResultDTO apiV1EnvironmentFIGLEntryFIEnabledtoprojectsPost(environment, authorizationScope, gLEntryFIParametersDTO, opts)

Check if the gl entry can open project entries

Check if the gl entry can open project entries

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let gLEntryFIParametersDTO = new TseCloudFi.GLEntryFIParametersDTO(); // GLEntryFIParametersDTO | Registration number to check
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIEnabledtoprojectsPost(environment, authorizationScope, gLEntryFIParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **gLEntryFIParametersDTO** | [**GLEntryFIParametersDTO**](GLEntryFIParametersDTO.md)| Registration number to check | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIFilterglentriesPost

> FilterGlentriesResultDTO apiV1EnvironmentFIGLEntryFIFilterglentriesPost(environment, authorizationScope, filterGLEntriesParamsDTO, opts)

FilterGlentries

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let filterGLEntriesParamsDTO = new TseCloudFi.FilterGLEntriesParamsDTO(); // FilterGLEntriesParamsDTO | Input parameters for elaboration
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIFilterglentriesPost(environment, authorizationScope, filterGLEntriesParamsDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **filterGLEntriesParamsDTO** | [**FilterGLEntriesParamsDTO**](FilterGLEntriesParamsDTO.md)| Input parameters for elaboration | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**FilterGlentriesResultDTO**](FilterGlentriesResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIGLEntryPartialValidatePost

> GLEntryFIDTO apiV1EnvironmentFIGLEntryFIGLEntryPartialValidatePost(force, environment, authorizationScope, gLEntryFIDTO, opts)

GL ENtry Header validations

Verify that the header informations of a GLEntryFI element are correct

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let force = "force_example"; // String | force
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let gLEntryFIDTO = new TseCloudFi.GLEntryFIDTO(); // GLEntryFIDTO | The gl entry to validate
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIGLEntryPartialValidatePost(force, environment, authorizationScope, gLEntryFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **force** | **String**| force | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **gLEntryFIDTO** | [**GLEntryFIDTO**](GLEntryFIDTO.md)| The gl entry to validate | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**GLEntryFIDTO**](GLEntryFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIGet

> GLEntryFIDTO apiV1EnvironmentFIGLEntryFIGet(op, environment, authorizationScope, opts)

Get new

Get an empty object of type corresponding

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let op = "op_example"; // String | The value must be 'new'
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIGet(op, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **op** | **String**| The value must be &#39;new&#39; | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**GLEntryFIDTO**](GLEntryFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIGetApplicationVersionPost

> ValidateDTO apiV1EnvironmentFIGLEntryFIGetApplicationVersionPost(environment, authorizationScope, opts)

Application version reading

Get the application version identifiers

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'", // String | Example for multilanguage
  'applicationVersionResultDTO': new TseCloudFi.ApplicationVersionResultDTO() // ApplicationVersionResultDTO | Input parameters for caculation
};
apiInstance.apiV1EnvironmentFIGLEntryFIGetApplicationVersionPost(environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]
 **applicationVersionResultDTO** | [**ApplicationVersionResultDTO**](ApplicationVersionResultDTO.md)| Input parameters for caculation | [optional] 

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIGetBusinessTypeDataDefaultPost

> BusinessTypeDataDefaultResultDTO apiV1EnvironmentFIGLEntryFIGetBusinessTypeDataDefaultPost(environment, authorizationScope, businessTypeDataDefaultParamsDTO, opts)

Get default dbsiness type data

Get default dbsiness type data

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let businessTypeDataDefaultParamsDTO = new TseCloudFi.BusinessTypeDataDefaultParamsDTO(); // BusinessTypeDataDefaultParamsDTO | Input params
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIGetBusinessTypeDataDefaultPost(environment, authorizationScope, businessTypeDataDefaultParamsDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **businessTypeDataDefaultParamsDTO** | [**BusinessTypeDataDefaultParamsDTO**](BusinessTypeDataDefaultParamsDTO.md)| Input params | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**BusinessTypeDataDefaultResultDTO**](BusinessTypeDataDefaultResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankMovementsPost

> IdsListFIDTO apiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankMovementsPost(environment, authorizationScope, gLEntryFICreateFromBankMovementsParameters, opts)

Request the list of bank movements to account

Request the list of bank movements to be accounted

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let gLEntryFICreateFromBankMovementsParameters = new TseCloudFi.GLEntryFICreateFromBankMovementsParameters(); // GLEntryFICreateFromBankMovementsParameters | Input params
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankMovementsPost(environment, authorizationScope, gLEntryFICreateFromBankMovementsParameters, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **gLEntryFICreateFromBankMovementsParameters** | [**GLEntryFICreateFromBankMovementsParameters**](GLEntryFICreateFromBankMovementsParameters.md)| Input params | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**IdsListFIDTO**](IdsListFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankReconcileMovementsPost

> IdsListFIDTO apiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankReconcileMovementsPost(environment, authorizationScope, idFIDTO, opts)

Request the list of reconcilable bank transactions

Request the list of reconcilable bank transactions

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let idFIDTO = new TseCloudFi.IdFIDTO(); // IdFIDTO | Input params
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIGetEligibleIdsFromBankReconcileMovementsPost(environment, authorizationScope, idFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **idFIDTO** | [**IdFIDTO**](IdFIDTO.md)| Input params | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**IdsListFIDTO**](IdsListFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIGetEligibleIdsFromTsDigitalPost

> IdsListFIDTO apiV1EnvironmentFIGLEntryFIGetEligibleIdsFromTsDigitalPost(environment, authorizationScope, idFIDTO, opts)

Request the list of TsDigital movements to account

Request the list of TsDigital movements to be accounted

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let idFIDTO = new TseCloudFi.IdFIDTO(); // IdFIDTO | Input params
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIGetEligibleIdsFromTsDigitalPost(environment, authorizationScope, idFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **idFIDTO** | [**IdFIDTO**](IdFIDTO.md)| Input params | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**IdsListFIDTO**](IdsListFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIGetFileFepaPassCOPost

> FilesFepaPassCODTO apiV1EnvironmentFIGLEntryFIGetFileFepaPassCOPost(environment, authorizationScope, opts)

Read by key B2B file Fepa pass and fix it

Read by key B2B file Fepa pass and fix it

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'", // String | Example for multilanguage
  'idFIDTO': new TseCloudFi.IdFIDTO() // IdFIDTO | Input parameters for caculation
};
apiInstance.apiV1EnvironmentFIGLEntryFIGetFileFepaPassCOPost(environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]
 **idFIDTO** | [**IdFIDTO**](IdFIDTO.md)| Input parameters for caculation | [optional] 

### Return type

[**FilesFepaPassCODTO**](FilesFepaPassCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIGetGLEntryAccountingReasonCodeDataGet

> GLEntryFIAdditionalDataResultDTO apiV1EnvironmentFIGLEntryFIGetGLEntryAccountingReasonCodeDataGet(numreg, environment, authorizationScope, opts)

Data reading for accounting reason code

Returns the minimum data of the accounting reason relating to the numreg supplied as a parameter

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let numreg = "numreg_example"; // String | numreg
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIGetGLEntryAccountingReasonCodeDataGet(numreg, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **numreg** | **String**| numreg | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**GLEntryFIAdditionalDataResultDTO**](GLEntryFIAdditionalDataResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIGetGLEntryAdditionalDataPost

> GLEntryFIAdditionalDataResultDTO apiV1EnvironmentFIGLEntryFIGetGLEntryAdditionalDataPost(environment, authorizationScope, gLEntryFIAdditionalDataParametersDTO, opts)

Data reading for withholdings deadlines

Calculates the values ​​necessary to determine the withholding taxes / deadlines for the required registration

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let gLEntryFIAdditionalDataParametersDTO = new TseCloudFi.GLEntryFIAdditionalDataParametersDTO(); // GLEntryFIAdditionalDataParametersDTO | Id/StageGuid entry
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIGetGLEntryAdditionalDataPost(environment, authorizationScope, gLEntryFIAdditionalDataParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **gLEntryFIAdditionalDataParametersDTO** | [**GLEntryFIAdditionalDataParametersDTO**](GLEntryFIAdditionalDataParametersDTO.md)| Id/StageGuid entry | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**GLEntryFIAdditionalDataResultDTO**](GLEntryFIAdditionalDataResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIGetGLEntryOffSetPost

> GLEntryFIOffSetSummaryResultDTO apiV1EnvironmentFIGLEntryFIGetGLEntryOffSetPost(environment, authorizationScope, gLEntryFIKeyDTO, opts)

Get gl entry off set

Get gl entry off set

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let gLEntryFIKeyDTO = new TseCloudFi.GLEntryFIKeyDTO(); // GLEntryFIKeyDTO | Input params
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIGetGLEntryOffSetPost(environment, authorizationScope, gLEntryFIKeyDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **gLEntryFIKeyDTO** | [**GLEntryFIKeyDTO**](GLEntryFIKeyDTO.md)| Input params | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**GLEntryFIOffSetSummaryResultDTO**](GLEntryFIOffSetSummaryResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIGetLinkedEntriesFromNumregPost

> GLEntryFIGetLinkedEntriesFromNumregResultsDTO apiV1EnvironmentFIGLEntryFIGetLinkedEntriesFromNumregPost(environment, authorizationScope, gLEntryFIGetLinkedEntriesFromNumregParametersDTO, opts)

Returns all gl entries starting from a registration number.

Search for the parent registration and all related registrations of which the entered registration number is a part

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let gLEntryFIGetLinkedEntriesFromNumregParametersDTO = new TseCloudFi.GLEntryFIGetLinkedEntriesFromNumregParametersDTO(); // GLEntryFIGetLinkedEntriesFromNumregParametersDTO | Id or registration number to find
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIGetLinkedEntriesFromNumregPost(environment, authorizationScope, gLEntryFIGetLinkedEntriesFromNumregParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **gLEntryFIGetLinkedEntriesFromNumregParametersDTO** | [**GLEntryFIGetLinkedEntriesFromNumregParametersDTO**](GLEntryFIGetLinkedEntriesFromNumregParametersDTO.md)| Id or registration number to find | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**GLEntryFIGetLinkedEntriesFromNumregResultsDTO**](GLEntryFIGetLinkedEntriesFromNumregResultsDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIGetNumregByDetailIdPost

> GLEntryNumregResultDTO apiV1EnvironmentFIGLEntryFIGetNumregByDetailIdPost(environment, authorizationScope, idFIDTO, opts)

Get GLEntry numreg by detail id

Get GLEntry numreg starting from a detail id

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let idFIDTO = new TseCloudFi.IdFIDTO(); // IdFIDTO | An object that contains all the parameters that are used in the processing
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIGetNumregByDetailIdPost(environment, authorizationScope, idFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **idFIDTO** | [**IdFIDTO**](IdFIDTO.md)| An object that contains all the parameters that are used in the processing | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**GLEntryNumregResultDTO**](GLEntryNumregResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIGetTracciatoDocumentalePost

> FIGLEntriesExecutionResultDTO apiV1EnvironmentFIGLEntryFIGetTracciatoDocumentalePost(environment, authorizationScope, opts)

Retrieve document track

Retrieve document track

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIGetTracciatoDocumentalePost(environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIGetVatRegistryResultPost

> VatRegisterSerializedResultDTO apiV1EnvironmentFIGLEntryFIGetVatRegistryResultPost(environment, authorizationScope, vatRegistryResultParametersDTO, opts)

Get vat registry result

Get vat registry result

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let vatRegistryResultParametersDTO = new TseCloudFi.VatRegistryResultParametersDTO(); // VatRegistryResultParametersDTO | Input params
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIGetVatRegistryResultPost(environment, authorizationScope, vatRegistryResultParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **vatRegistryResultParametersDTO** | [**VatRegistryResultParametersDTO**](VatRegistryResultParametersDTO.md)| Input params | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**VatRegisterSerializedResultDTO**](VatRegisterSerializedResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIGetxsltPost

> XSLTResultDTO apiV1EnvironmentFIGLEntryFIGetxsltPost(environment, authorizationScope, gLEntryFIGetXSLTParameters, opts)

Get XSLT

Get XSLT

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let gLEntryFIGetXSLTParameters = new TseCloudFi.GLEntryFIGetXSLTParameters(); // GLEntryFIGetXSLTParameters | Input params
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIGetxsltPost(environment, authorizationScope, gLEntryFIGetXSLTParameters, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **gLEntryFIGetXSLTParameters** | [**GLEntryFIGetXSLTParameters**](GLEntryFIGetXSLTParameters.md)| Input params | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**XSLTResultDTO**](XSLTResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIIdDelete

> apiV1EnvironmentFIGLEntryFIIdDelete(id, environment, authorizationScope, opts)

Delete

Deleting object of type 

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIIdDelete(id, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIIdGet

> GLEntryFIDTO apiV1EnvironmentFIGLEntryFIIdGet(id, environment, authorizationScope, opts)

Get by ID

Get an object of type corresponding the requested id

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let id = "id_example"; // String | Id to get the object
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'dlevel': "dlevel_example", // String | Serialization level
  'dlevelkey': "dlevelkey_example", // String | Serialization level key
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIIdGet(id, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Id to get the object | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **dlevel** | **String**| Serialization level | [optional] 
 **dlevelkey** | **String**| Serialization level key | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**GLEntryFIDTO**](GLEntryFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIIdPatch

> apiV1EnvironmentFIGLEntryFIIdPatch(id, environment, authorizationScope, body, opts)

Update partial

Patching an object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let body = null; // Object | Object of type to patch
let opts = {
  'force': "force_example", // String | The warning/s code to bypass (separated by ‘,’) during the execution
  'op': "op_example", // String | Set 'reload', if you want the DTO updated in the response request
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIIdPatch(id, environment, authorizationScope, body, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **body** | **Object**| Object of type to patch | 
 **force** | **String**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **String**| Set &#39;reload&#39;, if you want the DTO updated in the response request | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIIdPut

> GLEntryFIDTO apiV1EnvironmentFIGLEntryFIIdPut(id, environment, authorizationScope, gLEntryFIDTO, opts)

Update

Updating an object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let gLEntryFIDTO = new TseCloudFi.GLEntryFIDTO(); // GLEntryFIDTO | Object of type to update
let opts = {
  'force': "force_example", // String | The warning/s code to bypass (separated by ‘,’) during the execution
  'op': "op_example", // String | Set 'reload', if you want the DTO updated in the response request, otherwise will be returned null value
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIIdPut(id, environment, authorizationScope, gLEntryFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **gLEntryFIDTO** | [**GLEntryFIDTO**](GLEntryFIDTO.md)| Object of type to update | 
 **force** | **String**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **String**| Set &#39;reload&#39;, if you want the DTO updated in the response request, otherwise will be returned null value | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**GLEntryFIDTO**](GLEntryFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIImportDocB2BFileFepaPassPost

> FIGLEntriesExecutionResultDTO apiV1EnvironmentFIGLEntryFIImportDocB2BFileFepaPassPost(environment, authorizationScope, tsDigitalImportDocParametersDTO, opts)

Import B2B file Fepa pass

Import B2B file Fepa pass

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let tsDigitalImportDocParametersDTO = new TseCloudFi.TsDigitalImportDocParametersDTO(); // TsDigitalImportDocParametersDTO | Input Params
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIImportDocB2BFileFepaPassPost(environment, authorizationScope, tsDigitalImportDocParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **tsDigitalImportDocParametersDTO** | [**TsDigitalImportDocParametersDTO**](TsDigitalImportDocParametersDTO.md)| Input Params | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIImportInvoiceFepaPassFIPost

> ImportInvoiceFepaPassResultDTO apiV1EnvironmentFIGLEntryFIImportInvoiceFepaPassFIPost(environment, authorizationScope, importInvoiceFepaPassParamsDTO, opts)

Import file Fepa pass

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let importInvoiceFepaPassParamsDTO = new TseCloudFi.ImportInvoiceFepaPassParamsDTO(); // ImportInvoiceFepaPassParamsDTO | Input parameters for reelaborate
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIImportInvoiceFepaPassFIPost(environment, authorizationScope, importInvoiceFepaPassParamsDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **importInvoiceFepaPassParamsDTO** | [**ImportInvoiceFepaPassParamsDTO**](ImportInvoiceFepaPassParamsDTO.md)| Input parameters for reelaborate | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**ImportInvoiceFepaPassResultDTO**](ImportInvoiceFepaPassResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIInsertmissingexchangeratesPost

> InsertMissingExchangeRatesResultDTO apiV1EnvironmentFIGLEntryFIInsertmissingexchangeratesPost(environment, authorizationScope, insertMissingExchangeRatesParamsDTO, opts)

Insert missing exchange rate

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let insertMissingExchangeRatesParamsDTO = new TseCloudFi.InsertMissingExchangeRatesParamsDTO(); // InsertMissingExchangeRatesParamsDTO | Input parameters for elaboration
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIInsertmissingexchangeratesPost(environment, authorizationScope, insertMissingExchangeRatesParamsDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **insertMissingExchangeRatesParamsDTO** | [**InsertMissingExchangeRatesParamsDTO**](InsertMissingExchangeRatesParamsDTO.md)| Input parameters for elaboration | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InsertMissingExchangeRatesResultDTO**](InsertMissingExchangeRatesResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIIsCheckListEnabledGet

> Boolean apiV1EnvironmentFIGLEntryFIIsCheckListEnabledGet(environment, authorizationScope, opts)

Returns if the checklist functionality on glentry landing is enabled

Returns if the checklist functionality on glentry landing is enabled

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIIsCheckListEnabledGet(environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

**Boolean**

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIModuleintegrationinfosupdatePost

> GLEntryFIModuleIntegrationInfosUpdateResultDTO apiV1EnvironmentFIGLEntryFIModuleintegrationinfosupdatePost(environment, authorizationScope, gLEntryFIModuleIntegrationInfosUpdateParamsDTO, opts)

Updates module integration infos

Updates module integration infos related to a glentry

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let gLEntryFIModuleIntegrationInfosUpdateParamsDTO = new TseCloudFi.GLEntryFIModuleIntegrationInfosUpdateParamsDTO(); // GLEntryFIModuleIntegrationInfosUpdateParamsDTO | An object that contains all the parameters that are used in the processing
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIModuleintegrationinfosupdatePost(environment, authorizationScope, gLEntryFIModuleIntegrationInfosUpdateParamsDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **gLEntryFIModuleIntegrationInfosUpdateParamsDTO** | [**GLEntryFIModuleIntegrationInfosUpdateParamsDTO**](GLEntryFIModuleIntegrationInfosUpdateParamsDTO.md)| An object that contains all the parameters that are used in the processing | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**GLEntryFIModuleIntegrationInfosUpdateResultDTO**](GLEntryFIModuleIntegrationInfosUpdateResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIMulticreatePost

> CollectionBaseResultDTO apiV1EnvironmentFIGLEntryFIMulticreatePost(environment, authorizationScope, gLEntryFIMultipleDTOCollectionBaseDTO, opts)

Multiple creation of gl entries

Multiple creation of gl entries

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let gLEntryFIMultipleDTOCollectionBaseDTO = new TseCloudFi.GLEntryFIMultipleDTOCollectionBaseDTO(); // GLEntryFIMultipleDTOCollectionBaseDTO | List of accounting entries to be entered
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIMulticreatePost(environment, authorizationScope, gLEntryFIMultipleDTOCollectionBaseDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **gLEntryFIMultipleDTOCollectionBaseDTO** | [**GLEntryFIMultipleDTOCollectionBaseDTO**](GLEntryFIMultipleDTOCollectionBaseDTO.md)| List of accounting entries to be entered | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**CollectionBaseResultDTO**](CollectionBaseResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIMultiplecreatejobPost

> CreateMultiGLEntryJobResultDTO apiV1EnvironmentFIGLEntryFIMultiplecreatejobPost(environment, authorizationScope, createMultiGLEntryJobParamsDTO, opts)

Job creation of multiple entry of gl entries

Job creation of multiple entry of gl entries

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let createMultiGLEntryJobParamsDTO = {"data":{"vatReverseIncoporated":true,"items":[{"externalRif":"string","autoVatRow":true,"externalInfo":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"},"entry":{"stageGuid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","canUpdate":true,"cambio":0,"causcollnumreg":"string","codiceCg33":"string","datacambio":"2024-11-15T13:29:44.505Z","datacomp":"2024-11-15T13:29:44.505Z","datacons":"2024-11-15T13:29:44.505Z","datadoc":"2024-11-15T13:29:44.505Z","datadocrifnotevar":"2024-11-15T13:29:44.505Z","dataprecons":"2024-11-15T13:29:44.505Z","datarateo":"2024-11-15T13:29:44.505Z","datarateop":"2024-11-15T13:29:44.505Z","datareg":"2024-11-15T13:29:44.505Z","dataregiva":"2024-11-15T13:29:44.505Z","descausale":"string","descragg":"string","dittaCg18":0,"flgDelete":0,"flgDocbis":0,"flgDocriep":0,"flgDocsemplif":0,"flgIntra":0,"flgMentry":0,"flgSegnoiva":0,"flgStpgior":0,"flgStpiva":0,"flgStptotiva":0,"flgTurismo":0,"hubid":"string","id":0,"idCo1a":0,"idMg28":"string","idsdi":"string","imparrot":0,"imparrotval":0,"imparrotval2":0,"imptotale":0,"imptotaleval":0,"imptotaleval2":0,"indElenchimov3000":0,"indExp":0,"indModdiffcambio":0,"indModpn":0,"indMovgruppo":0,"indNollis":0,"indProvreg":0,"indTipodoc":0,"indTipoifrs":0,"indTipomov":0,"indTiporeg":0,"lastchange":"2024-11-15T13:29:44.505Z","numdoc":0,"numdocorig":"string","numpart":0,"numreg":"string","parentCodiceCgc0":0,"progEserCg19":0,"selfInvoiceProtocol":0,"selfInvoiceSectional":"string","sezionale":"string","tipodoc":0,"tipodocfe":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"accountingYearCO":{"anno":0,"dataape":"2024-11-15T13:29:44.505Z","datachiu":"2024-11-15T13:29:44.505Z","dittaCg18":0,"flgAdecbatt":0,"flgAdecbcli":0,"flgAdecbfor":0,"flgAdecbpas":0,"flgEserchiuso":0,"flgEsercor":0,"flgGencesp":0,"flgGenratei":0,"flgGenrisc":0,"id":0,"progEser":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.505Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"customerSupplierCO":{"gmdUpdateAdditionalParams":{"codice":0,"ragSoAnag":"string","indirizzo":"string","numCiv":"string","cap":"string","citta":"string","prov":"string","codiceCg07":0,"partiva":"string","codFiscale":"string","tel1Num":"string","fax":"string","tipologia":"string","codLegCg01":"string","descrCg07":"string","nationIso":"string"},"clifor":0,"codAbiCg12":0,"codCabCg13":0,"codiceCg28":"string","contoCg24":"string","contorCg24":"string","contratto":"string","datavaliva":"2024-11-15T13:29:44.505Z","dittaCg18":0,"flgArt62":0,"flgAttivo":1,"flgCointestati":0,"flgIntercompany":0,"ggscadfix":0,"gruppoCg10":0,"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","idclifor":0,"idmediaCg99":0,"indElenchimov3000":99,"intermedioCg40":0,"lastchange":"2024-11-15T13:29:44.505Z","progREf08":0,"tipocf":0,"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"agentCO":{"agente":"string","anagenCg16":0,"datafineman":"2024-11-15T13:29:44.505Z","datainman":"2024-11-15T13:29:44.505Z","datainrapp":"2024-11-15T13:29:44.505Z","dittaCg18":0,"flgAdegdelta":0,"flgAdeguamscmag":0,"flgRegimeart":0,"flgRegimecl":0,"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","idagente":0,"idcapoareaMg17":0,"idcapozonaMg17":0,"idmediaCg99":0,"indBaseimpmag":0,"indBaseimpsc":0,"indCalcscmag":0,"indPrefstdoc":0,"indStdistenas":0,"indTipoage":0,"indTipoliq":0,"perprov":0,"regimeprov":0,"tipomand":0,"tiporappor":1,"tiposoc":0,"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"dmsPublishedEntityFW":{"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","tipoarchHm30":0,"idknos":0,"dittaCg18":0,"protocollo":"string","flgInvalid":0,"percorso":"string","nome":"string","datapub":"2024-11-15T13:29:44.505Z","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"generalMasterDataCO":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:29:44.505Z","datavalid":"2024-11-15T13:29:44.505Z","dtfinepec":"2024-11-15T13:29:44.505Z","dtiniziopec":"2024-11-15T13:29:44.505Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:29:44.505Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:29:44.505Z","datamod":"2024-11-15T13:29:44.505Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.505Z","datafinblacklist":"2024-11-15T13:29:44.505Z","datainiblacklist":"2024-11-15T13:29:44.505Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.505Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.505Z","datafinblacklist":"2024-11-15T13:29:44.505Z","datainiblacklist":"2024-11-15T13:29:44.505Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.505Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"blackListGeneralMasterData":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:29:44.505Z","datavalid":"2024-11-15T13:29:44.505Z","dtfinepec":"2024-11-15T13:29:44.505Z","dtiniziopec":"2024-11-15T13:29:44.505Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:29:44.505Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:29:44.509Z","datamod":"2024-11-15T13:29:44.509Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.509Z","datafinblacklist":"2024-11-15T13:29:44.509Z","datainiblacklist":"2024-11-15T13:29:44.509Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.509Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.509Z","datafinblacklist":"2024-11-15T13:29:44.509Z","datainiblacklist":"2024-11-15T13:29:44.509Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.509Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"csAccountingIndexCO":{"codCat":"string","descr":"string","dittaCg18":0,"tipocfCg44":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"csBankCO":[{"bban":"string","bicbancaestera":"string","ccaddetto":"string","ccdesagenz":"string","ccforn":"string","ccfornfactor":0,"ccfornfactoridCg44":0,"ccggval":0,"cliforCg44":0,"codiceCg07":0,"dittaCg18":0,"flgPref":0,"flgPrefIncassi":0,"iban":"string","id":0,"idbancaestera":"string","idcontratto":"string","idsuccursale":0,"indTipoop":0,"locbancaestera":"string","nomebancaestera":"string","progR":0,"tipobanca":0,"tipocfCg44":0,"agencyCO":{"codBanca":0,"codice":0,"descrizione":"string","localita":"string","prov":"string","bankCO":{"codBicswift":"string","codiceBanca":0,"descrizione":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"customerSupplierCO":"string","nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.509Z","datafinblacklist":"2024-11-15T13:29:44.509Z","datainiblacklist":"2024-11-15T13:29:44.509Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.509Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"csCompanyBankCO":[{"cliforCg44":0,"dittaCg18":0,"flgPref":0,"id":0,"progR":0,"progREf08":0,"rowversion":"string","tipocfCg44":0,"companyBankCO":{"aprogressmav":0,"bancaCg12":0,"bbananticipi":"string","bbanconto":"string","bbaneffpresef":"string","bbanordpbonif":"string","bicbanca":"string","cabbonifCg13":0,"cabcontoCg13":0,"cabmavCg13":0,"cabribaCg13":0,"cabridCg13":0,"ccanticipi":"string","ccconto":"string","cceffpresef":"string","ccordpbonif":"string","codAzienda":"string","codiceCg07":0,"codicecuc":"string","codRappopor":"string","codSia":"string","creditidentifier":"string","daprogressmav":0,"descr":"string","dittaCg18":0,"flgAutattribnrmav":0,"flgCambiali":0,"flgCessioni":0,"flgMav":0,"flgPref":0,"flgRiba":0,"flgRibacamb":0,"flgRibacess":0,"flgRibaricba":0,"flgRibatratac":0,"flgRibatratte":0,"flgRidsdd":0,"flgRidsddraggr":0,"flgScfatt":0,"flgTratte":0,"ggvalcambalt":0,"ggvalcambfil":0,"ggvalmavincalt":0,"ggvalmavincfil":0,"ggvalmavincpos":0,"ggvalmavsbf":0,"ggvalribaalt":0,"ggvalribafil":0,"ggvalridalt":0,"ggvalridfil":0,"ggvalscfattalt":0,"ggvalscfattfil":0,"ggvaltratalt":0,"ggvaltratfil":0,"ibananticipi":"string","ibanconto":"string","ibaneffpresef":"string","ibanordpbonif":"string","id":0,"idbancaestera":"string","idcontratto":"string","idmediaCg99":0,"idsuccursale":0,"impcastel":0,"impfido":0,"indCheckpivacf":0,"indCompind":0,"indContpmtinf":0,"indPresmav":1,"indPresriba":1,"indPresrid":1,"indTipolib":1,"indTipopres":0,"locbancaestera":"string","maxgginsoluti":0,"prefissoattribmav":0,"progR":0,"rowversion":"string","scfindbasecalc":1,"scfnsdocrif":"string","scfpercpres":0,"scfperctasso":0,"scfvsdocrif":"string","spcommbonalt":0,"spcommbonfil":0,"spcommordpalt":0,"spcommordpfil":0,"spinccambalt":0,"spinccambfil":0,"spinccoralt":0,"spinccorfil":0,"spincesitopag":0,"spincmavincalt":0,"spincmavincfil":0,"spincmavincpos":0,"spincmavsbf":0,"spincribaalt":0,"spincribafil":0,"spincridalt":0,"spincridfil":0,"spinctraalt":0,"spinctrafil":0,"sppresdistinta":0,"spritcamb":0,"spritcambcl":0,"spritmavincas":0,"spritmavincascl":0,"spritmavsbf":0,"spritmavsbfcl":0,"spritriba":0,"spritribacl":0,"spritrid":0,"spritridcl":0,"sprittratte":0,"sprittrattecl":0,"tipobanca":0,"ultprogressmav":0,"bankCO":{"codBicswift":"string","codiceBanca":0,"descrizione":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.509Z","datafinblacklist":"2024-11-15T13:29:44.509Z","datainiblacklist":"2024-11-15T13:29:44.509Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.509Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"csInfoCO":{"area":"string","areanielsenMg0e":"string","bacsaccountno":0,"categ":"string","cliforCg44":0,"codIclfatt":0,"codLivbloc":"string","codRifalf":"string","codRifnum":0,"codRischioMg2a":"string","datablocco":"2024-11-15T13:29:44.509Z","datacreaz":"2024-11-15T13:29:44.509Z","datadismis":"2024-11-15T13:29:44.509Z","datarischio":"2024-11-15T13:29:44.509Z","dataultvar":"2024-11-15T13:29:44.509Z","dittaCg18":0,"fidoaziendale":0,"fidofactoring":0,"fidolivello1":0,"fidolivello2":0,"finchargerterms":"string","flgEstrpayline":0,"flgSpbol":0,"flgSpeinc":0,"flgTaxliable":0,"idmediaCg99":0,"indClibloc":0,"indGesfido":0,"indrottcig":0,"indSpesecum":0,"irs1099":"string","lastchange":"2024-11-15T13:29:44.509Z","linguaMg52":"string","macroarea":"string","macrocat":"string","notebloc":"string","raggcrf3":"string","raggrcf1":"string","raggrcf2":"string","regimeiva":"string","reminderterms":"string","scaglspbanc":0,"sottocat":"string","taxareaNv01":"string","taxexemptionno":"string","tipocfCg44":0,"typeofsupply":"string","zona":"string","areaCO":{"codiceAreaMG":"string","descrarea":"string","dittaCg18":0,"idprov":0,"macroareaMg07":"string","tipocfMg07":0,"zone":[{"areaMg08":"string","codiceZona":"string","descrzona":"string","dittaCg18":0,"idprov":0,"macroareaMg08":"string","tipocfMg08":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"categoryCO":{"categ":"string","descrcat":"string","dittaCg18":0,"macrocatMg10":"string","tipocfMg10":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"grouping1CO":{"codRaggrcf1":"string","descraggrcf1":"string","dittaCg18":0,"idmediaCg99":0,"idprov":0,"tipocf":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"grouping2CO":{"codRaggrcf2":"string","descraggrcf2":"string","dittaCg18":0,"idmediaCg99":0,"idprov":0,"tipocf":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"grouping3CO":{"codRaggrcf3":"string","descraggrcf3":"string","dittaCg18":0,"idmediaCg99":0,"idprov":0,"tipocf":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"macroAreaCO":{"codiceMacroarea":"string","descrmacroar":"string","dittaCg18":0,"idprov":0,"tipocf":0,"areas":[{"codiceAreaMG":"string","descrarea":"string","dittaCg18":0,"idprov":0,"macroareaMg07":"string","tipocfMg07":0,"zone":[{"areaMg08":"string","codiceZona":"string","descrzona":"string","dittaCg18":0,"idprov":0,"macroareaMg08":"string","tipocfMg08":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"macroCategoryCO":{"descrmacrocat":"string","dittaCg18":0,"macrocat":"string","tipocf":0,"categorie":[{"categ":"string","descrcat":"string","dittaCg18":0,"macrocatMg10":"string","tipocfMg10":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"subCategoryCO":{"categMg11":"string","descrsottocat":"string","dittaCg18":0,"macrocatMg11":"string","sottcat":"string","tipocfMg11":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"zoneCO":{"areaMg08":"string","codiceZona":"string","descrzona":"string","dittaCg18":0,"idprov":0,"macroareaMg08":"string","tipocfMg08":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"csJointlyHeldCO":[{"cliforCg44":0,"cliforcoCg44":0,"dittaCg18":0,"idcliforcoCg44":0,"percentuale":0,"tipocfCg44":0,"customerSupplierCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"csPaymentRangeCO":[{"aimpdoc":0,"cliforCg44":0,"codPagCg62":"string","codScagl":0,"dittaCg18":0,"id":0,"idCg62":0,"idmediaCg99":0,"indPagpart":0,"tipocfCg44":0,"valutaCg08":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.510Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"paymentTermCO":{"codPag":"string","descPag":"string","desPagAnal":"string","flgDesc":0,"flgDisgg":0,"flgPrefatt":0,"flgPrefpass":0,"flgStornoiva":0,"id":0,"rowversion":"string","scart26":0,"scpercart26":0,"scpercas":0,"scpermer1":0,"scpermer2":0,"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"paymentTermDetailCO":[{"aggfix1":0,"aggfix2":0,"codPagCg62":"string","daggfix1":0,"daggfix2":0,"el1frimp":0,"el1friva":0,"el2frimp":0,"el2friva":0,"flgFrpercimp":1,"flgFrperciva":1,"ggdecor":0,"ggmmfix":0,"ggscadfix1":0,"ggscadfix2":0,"id":0,"idCg62":0,"idCg64":0,"imporfix":0,"indDatarif":0,"indImpfix":0,"indTipocalend":0,"indTipodecor":1,"percimp":0,"perciva":0,"prog":0,"rowversion":"string","tipoeff":9,"subTypeCO":{"codiceCg07":0,"codPaguc":"string","codStipoeff":0,"descstipo":"string","flgAssegno":0,"ggoffset":0,"id":0,"indModfatturapa":0,"rowversion":"string","tipoeff":0,"foreignPaymentCodeCO":{"codice":"string","codIso":"string","descrpag":"string","flgIbanobbl":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.510Z","datafinblacklist":"2024-11-15T13:29:44.510Z","datainiblacklist":"2024-11-15T13:29:44.510Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.510Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"csPostponementPeriodCO":[{"ammgg":0,"cliforCg44":0,"dammgg":0,"dittaCg18":0,"ggmmfixslit":0,"ggslsucc":0,"id":0,"idmediaCg99":0,"indAppggfix":0,"indTiposlit":1,"tipocfCg44":0,"tipoeff":9,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"csSddCO":[{"bancaallineam":0,"causrich":0,"causrisp":0,"cfiscsottoscr":"string","cliforCg44":0,"codAutoriz":"string","codBicswift":"string","codClideb":"string","codClidebprec":"string","codIndiv":0,"codIndivprec":0,"codRif":"string","contocorr":"string","contocorrprec":"string","datamandato":"2024-11-15T13:29:44.510Z","dataprimascad":"2024-11-15T13:29:44.510Z","datarich":"2024-11-15T13:29:44.510Z","datarisp":"2024-11-15T13:29:44.510Z","dataultimascad":"2024-11-15T13:29:44.510Z","descrizione":"string","diniego":0,"dittaCg18":0,"flgAllineam":0,"flgDisattivato":0,"flgVariato":0,"id":0,"idmediaCg99":0,"impmaxrata":0,"indIrsottoscr":"string","indStorno":0,"indStornoprec":0,"indTipoinc":0,"indTiposdd":0,"locsottoscr":"string","nrrate":0,"nuovabanca":0,"progR":0,"ragsosottoscr":"string","ridabi":0,"ridabiprec":0,"ridcab":0,"ridcabprec":0,"ridiban":"string","ridibanprec":"string","soggtitibanCg16":0,"tipocfCg44":0,"tipoinclocked":0,"tipologia":1,"tipologiaprec":0,"csHistorySddCO":[{"codBicswift":"string","codClideb":"string","codIndiv":0,"datavar":"2024-11-15T13:29:44.510Z","id":0,"indStorno":0,"indTipoinc":0,"indTiposdd":0,"ridiban":"string","soggtitibanCg16":0,"tipologia":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.510Z","datafinblacklist":"2024-11-15T13:29:44.510Z","datainiblacklist":"2024-11-15T13:29:44.510Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.510Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"soggtitiban":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:29:44.510Z","datavalid":"2024-11-15T13:29:44.510Z","dtfinepec":"2024-11-15T13:29:44.510Z","dtiniziopec":"2024-11-15T13:29:44.510Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:29:44.510Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:29:44.510Z","datamod":"2024-11-15T13:29:44.510Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.510Z","datafinblacklist":"2024-11-15T13:29:44.510Z","datainiblacklist":"2024-11-15T13:29:44.510Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.510Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.510Z","datafinblacklist":"2024-11-15T13:29:44.510Z","datainiblacklist":"2024-11-15T13:29:44.510Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.510Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.510Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"customerSupplierCIGCUPCO":[{"cliforCg44":0,"dittaCg18":0,"id":0,"idcigcupCo1h":0,"progREf08":0,"progRMg35":0,"rowversion":"string","tipocfCg44":0,"cigcuPcode":{"cig":"string","cup":"string","descrizione":"string","docrifData":"2024-11-15T13:29:44.510Z","docrifId":"string","flgAttivo":0,"id":0,"indTipocontr":0,"indTipodocrif":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"companyBank":{"aprogressmav":0,"bancaCg12":0,"bbananticipi":"string","bbanconto":"string","bbaneffpresef":"string","bbanordpbonif":"string","bicbanca":"string","cabbonifCg13":0,"cabcontoCg13":0,"cabmavCg13":0,"cabribaCg13":0,"cabridCg13":0,"ccanticipi":"string","ccconto":"string","cceffpresef":"string","ccordpbonif":"string","codAzienda":"string","codiceCg07":0,"codicecuc":"string","codRappopor":"string","codSia":"string","creditidentifier":"string","daprogressmav":0,"descr":"string","dittaCg18":0,"flgAutattribnrmav":0,"flgCambiali":0,"flgCessioni":0,"flgMav":0,"flgPref":0,"flgRiba":0,"flgRibacamb":0,"flgRibacess":0,"flgRibaricba":0,"flgRibatratac":0,"flgRibatratte":0,"flgRidsdd":0,"flgRidsddraggr":0,"flgScfatt":0,"flgTratte":0,"ggvalcambalt":0,"ggvalcambfil":0,"ggvalmavincalt":0,"ggvalmavincfil":0,"ggvalmavincpos":0,"ggvalmavsbf":0,"ggvalribaalt":0,"ggvalribafil":0,"ggvalridalt":0,"ggvalridfil":0,"ggvalscfattalt":0,"ggvalscfattfil":0,"ggvaltratalt":0,"ggvaltratfil":0,"ibananticipi":"string","ibanconto":"string","ibaneffpresef":"string","ibanordpbonif":"string","id":0,"idbancaestera":"string","idcontratto":"string","idmediaCg99":0,"idsuccursale":0,"impcastel":0,"impfido":0,"indCheckpivacf":0,"indCompind":0,"indContpmtinf":0,"indPresmav":1,"indPresriba":1,"indPresrid":1,"indTipolib":1,"indTipopres":0,"locbancaestera":"string","maxgginsoluti":0,"prefissoattribmav":0,"progR":0,"rowversion":"string","scfindbasecalc":1,"scfnsdocrif":"string","scfpercpres":0,"scfperctasso":0,"scfvsdocrif":"string","spcommbonalt":0,"spcommbonfil":0,"spcommordpalt":0,"spcommordpfil":0,"spinccambalt":0,"spinccambfil":0,"spinccoralt":0,"spinccorfil":0,"spincesitopag":0,"spincmavincalt":0,"spincmavincfil":0,"spincmavincpos":0,"spincmavsbf":0,"spincribaalt":0,"spincribafil":0,"spincridalt":0,"spincridfil":0,"spinctraalt":0,"spinctrafil":0,"sppresdistinta":0,"spritcamb":0,"spritcambcl":0,"spritmavincas":0,"spritmavincascl":0,"spritmavsbf":0,"spritmavsbfcl":0,"spritriba":0,"spritribacl":0,"spritrid":0,"spritridcl":0,"sprittratte":0,"sprittrattecl":0,"tipobanca":0,"ultprogressmav":0,"bankCO":{"codBicswift":"string","codiceBanca":0,"descrizione":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.510Z","datafinblacklist":"2024-11-15T13:29:44.510Z","datainiblacklist":"2024-11-15T13:29:44.510Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.510Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"csBankCO":{"bban":"string","bicbancaestera":"string","ccaddetto":"string","ccdesagenz":"string","ccforn":"string","ccfornfactor":0,"ccfornfactoridCg44":0,"ccggval":0,"cliforCg44":0,"codiceCg07":0,"dittaCg18":0,"flgPref":0,"flgPrefIncassi":0,"iban":"string","id":0,"idbancaestera":"string","idcontratto":"string","idsuccursale":0,"indTipoop":0,"locbancaestera":"string","nomebancaestera":"string","progR":0,"tipobanca":0,"tipocfCg44":0,"agencyCO":{"codBanca":0,"codice":0,"descrizione":"string","localita":"string","prov":"string","bankCO":{"codBicswift":"string","codiceBanca":0,"descrizione":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"customerSupplierCO":"string","nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.511Z","datafinblacklist":"2024-11-15T13:29:44.511Z","datainiblacklist":"2024-11-15T13:29:44.511Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.511Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"custSupplDataInvoicePACO":{"codiceCg16":0,"emailcortesia":"string","flgAsw":0,"indTypeb2b":0,"tipocfCg44":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"dmsPublishedEntityFW":{"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","tipoarchHm30":0,"idknos":0,"dittaCg18":0,"protocollo":"string","flgInvalid":0,"percorso":"string","nome":"string","datapub":"2024-11-15T13:29:44.511Z","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"generalMasterDataCO":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:29:44.511Z","datavalid":"2024-11-15T13:29:44.511Z","dtfinepec":"2024-11-15T13:29:44.511Z","dtiniziopec":"2024-11-15T13:29:44.511Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:29:44.511Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:29:44.511Z","datamod":"2024-11-15T13:29:44.511Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.511Z","datafinblacklist":"2024-11-15T13:29:44.511Z","datainiblacklist":"2024-11-15T13:29:44.511Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.512Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.512Z","datafinblacklist":"2024-11-15T13:29:44.512Z","datainiblacklist":"2024-11-15T13:29:44.512Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.512Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"officeCO":{"cap":"string","citta":"string","codice":0,"dittaCg18":0,"idmediaCg99":0,"indDimcentrocomm":0,"indIrizzo":"string","numerorea":"string","progRea":0,"prov":"string","rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"officePACO":[{"cap":"string","codDestin":"string","codice":"string","codiceCg16":0,"comune":"string","flgPreferenziale":0,"idprovincia":0,"idregione":0,"indIrizzo":"string","indTypeb2b":0,"lastupdateB2b":"2024-11-15T13:29:44.512Z","nome":"string","tipocfCg44":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"paymentTermCO":{"codPag":"string","descPag":"string","desPagAnal":"string","flgDesc":0,"flgDisgg":0,"flgPrefatt":0,"flgPrefpass":0,"flgStornoiva":0,"id":0,"rowversion":"string","scart26":0,"scpercart26":0,"scpercas":0,"scpermer1":0,"scpermer2":0,"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"paymentTermDetailCO":[{"aggfix1":0,"aggfix2":0,"codPagCg62":"string","daggfix1":0,"daggfix2":0,"el1frimp":0,"el1friva":0,"el2frimp":0,"el2friva":0,"flgFrpercimp":1,"flgFrperciva":1,"ggdecor":0,"ggmmfix":0,"ggscadfix1":0,"ggscadfix2":0,"id":0,"idCg62":0,"idCg64":0,"imporfix":0,"indDatarif":0,"indImpfix":0,"indTipocalend":0,"indTipodecor":1,"percimp":0,"perciva":0,"prog":0,"rowversion":"string","tipoeff":9,"subTypeCO":{"codiceCg07":0,"codPaguc":"string","codStipoeff":0,"descstipo":"string","flgAssegno":0,"ggoffset":0,"id":0,"indModfatturapa":0,"rowversion":"string","tipoeff":0,"foreignPaymentCodeCO":{"codice":"string","codIso":"string","descrpag":"string","flgIbanobbl":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.512Z","datafinblacklist":"2024-11-15T13:29:44.512Z","datainiblacklist":"2024-11-15T13:29:44.512Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.512Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCO":{"aliqivavent":0,"annotazioni":"string","codice":"string","codiceagr":"string","codiceOss":"string","codPlafond":0,"descrizione":"string","flgAgri":0,"flgAllclifor":0,"flgAssport398":0,"flgAutoue":0,"flgCorrVent":0,"flgEscludiblacklist":0,"flgImpostadibollo":0,"flgIndet":0,"flgIvaedit":0,"flgMonofasersm":0,"flgMossgest":0,"flgMossrid":0,"flgNotvar":0,"flgSospimp":0,"idprov":0,"impostamonofasersm":0,"indNatassoswCg2n":0,"indNatura":0,"indStaper":0,"indtipopart":0,"mosscodCg07":0,"mossperc":0,"note":"string","percforf":0,"percindet":0,"perciva":0,"percmonofasersm":0,"rowVersion":"string","tipologia":1,"verslynfa":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.513Z","datafinblacklist":"2024-11-15T13:29:44.513Z","datainiblacklist":"2024-11-15T13:29:44.513Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.513Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureAssCO":{"codice":"string","datafineval":"2024-11-15T13:29:44.513Z","datainival":"2024-11-15T13:29:44.513Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureEsCO":{"codice":"string","datafineval":"2024-11-15T13:29:44.513Z","datainival":"2024-11-15T13:29:44.513Z","descr":"string","id":0,"rowversion":"string","natureAssCO":[{"codice":"string","datafineval":"2024-11-15T13:29:44.513Z","datainival":"2024-11-15T13:29:44.513Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCOAgr":"string","vatCodeCOOss":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"dmsPublishedEntityFW":{"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","tipoarchHm30":0,"idknos":0,"dittaCg18":0,"protocollo":"string","flgInvalid":0,"percorso":"string","nome":"string","datapub":"2024-11-15T13:29:44.513Z","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"estabilshedOrganization":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:29:44.513Z","datavalid":"2024-11-15T13:29:44.513Z","dtfinepec":"2024-11-15T13:29:44.513Z","dtiniziopec":"2024-11-15T13:29:44.513Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:29:44.513Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:29:44.513Z","datamod":"2024-11-15T13:29:44.513Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.513Z","datafinblacklist":"2024-11-15T13:29:44.513Z","datainiblacklist":"2024-11-15T13:29:44.513Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.513Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.514Z","datafinblacklist":"2024-11-15T13:29:44.514Z","datainiblacklist":"2024-11-15T13:29:44.514Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.514Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"fiscalRepresentative":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:29:44.514Z","datavalid":"2024-11-15T13:29:44.514Z","dtfinepec":"2024-11-15T13:29:44.514Z","dtiniziopec":"2024-11-15T13:29:44.514Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:29:44.514Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:29:44.514Z","datamod":"2024-11-15T13:29:44.514Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.514Z","datafinblacklist":"2024-11-15T13:29:44.514Z","datainiblacklist":"2024-11-15T13:29:44.514Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.514Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.514Z","datafinblacklist":"2024-11-15T13:29:44.514Z","datainiblacklist":"2024-11-15T13:29:44.514Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.514Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"generalMasterDataCOBlackList":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:29:44.515Z","datavalid":"2024-11-15T13:29:44.515Z","dtfinepec":"2024-11-15T13:29:44.515Z","dtiniziopec":"2024-11-15T13:29:44.515Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:29:44.515Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:29:44.515Z","datamod":"2024-11-15T13:29:44.515Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.515Z","datafinblacklist":"2024-11-15T13:29:44.515Z","datainiblacklist":"2024-11-15T13:29:44.515Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.515Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.515Z","datafinblacklist":"2024-11-15T13:29:44.515Z","datainiblacklist":"2024-11-15T13:29:44.515Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.515Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"generalMasterDataCODirectID":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:29:44.515Z","datavalid":"2024-11-15T13:29:44.515Z","dtfinepec":"2024-11-15T13:29:44.515Z","dtiniziopec":"2024-11-15T13:29:44.515Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:29:44.516Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:29:44.516Z","datamod":"2024-11-15T13:29:44.516Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.516Z","datafinblacklist":"2024-11-15T13:29:44.516Z","datainiblacklist":"2024-11-15T13:29:44.516Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.516Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.516Z","datafinblacklist":"2024-11-15T13:29:44.516Z","datainiblacklist":"2024-11-15T13:29:44.516Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.516Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"glEntryDetailFI":[{"debitAmount":0,"creditAmount":0,"glvatDetailFI":{"causaleiva":0,"dittaCg18":0,"flgDeducibile":0,"flgTsescluso":0,"flgTsinviato":0,"id":0,"idCg41":0,"idcontoCg24":0,"imponibile":0,"imponibileval":0,"imposta":0,"impostand":0,"impostandval":0,"impostaval":0,"indDetriva":0,"indIvaacqagric":0,"indNatura":0,"indProrata":0,"indTipo":0,"indTstipoop":0,"indTstiposp":0,"indTsvocesp":0,"numrigaiva":0,"percdetr":0,"percforf":0,"tsdatadocori":"2024-11-15T13:29:44.516Z","tsdocorigine":"string","coaAccountFI":{"accountType":0,"alias":"string","codeformatted":"string","codiceCg22":0,"codiceCgc0":0,"cogeprogeAbil":0,"cogeprogeAttivita":0,"cogeprogeMateriali":0,"cogeprogeNodo":0,"cogeprogeSpese":0,"conto":"string","contoape":"string","contochiu":"string","contocrsosp":"string","contoratatt":"string","contoratpass":"string","contorisatt":"string","contorispass":"string","descr":"string","flgAggfatt":0,"flgAnalit":0,"flgBilconsattpassdist":0,"flgContoimm":0,"flgGesec":0,"flgGespor":0,"flgIntercompany":0,"flgOpnonfin":0,"flgRaganal":0,"flgRarp":0,"flgSaldog":0,"flgValutaest":0,"gruppoCg10":0,"idconto":0,"idcontoapeCg24":0,"idcontochiuCg24":0,"idcontoratattCg24":0,"idcontoratpassCg24":0,"idcontorisattCg24":0,"idcontorispassCg24":0,"idparent":0,"idreverse":0,"idRifPdC80":0,"indAttpasspor":0,"indContoricav":0,"indCosvend":0,"indDaav":0,"indDaavec":0,"indLivchius":0,"indMastroCliFor":99,"indTipoconto":0,"percindeduc":0,"percindetra":0,"suddconti":0,"coaAccountCustomizationFI":[{"contoCg24":"string","descr":"string","dittaCg18":0,"gruppoCg10":0,"idCg24":0,"iddespcon":0,"idmediaCg99":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"coaAccountFIApe":"string","coaAccountFIChiu":"string","coaAccountFIParent":"string","coaAccountFIRatatt":"string","coaAccountFIRatpass":"string","coaAccountFIRisatt":"string","coaAccountFIRispass":"string","coaAccountStateFI":[{"consosCg24":"string","dittaCg18":0,"dtconsos":"2024-11-15T13:29:44.517Z","dtdisatt":"2024-11-15T13:29:44.517Z","flgDisatt":0,"grusosCg10":0,"idCg24":0,"idstatipdc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"coaGroupCodeFI":{"descr":"string","flgPdclib":0,"gruppo":0,"maskedit":"string","numlivcons":0,"numlivelli":0,"rowversion":"string","accountProposals":[{"codice":0,"contoCg24":"string","gruppoCg10":0,"id":0,"idCg24":0,"rowversion":"string","coaAccountFI":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"coaInternationalCustomizationFI":[{"categoria":0,"contoCg24":"string","esModulo347":0,"gbDeferralcode":"string","gruppoCg10":0,"id":0,"idCg24":0,"iso3166A2":"string","rowversion":"string","subcategoria":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"reverseTypeFI":{"reverseTypeCode":0,"reverseTypeDescription":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatTypeFI":{"agviaggio":0,"codice":0,"codiceCg0d":0,"descr":"string","indAutofattura":0,"indTipo":0,"localizzazione":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"reverseTypeFI":{"reverseTypeCode":0,"reverseTypeDescription":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCO":{"aliqivavent":0,"annotazioni":"string","codice":"string","codiceagr":"string","codiceOss":"string","codPlafond":0,"descrizione":"string","flgAgri":0,"flgAllclifor":0,"flgAssport398":0,"flgAutoue":0,"flgCorrVent":0,"flgEscludiblacklist":0,"flgImpostadibollo":0,"flgIndet":0,"flgIvaedit":0,"flgMonofasersm":0,"flgMossgest":0,"flgMossrid":0,"flgNotvar":0,"flgSospimp":0,"idprov":0,"impostamonofasersm":0,"indNatassoswCg2n":0,"indNatura":0,"indStaper":0,"indtipopart":0,"mosscodCg07":0,"mossperc":0,"note":"string","percforf":0,"percindet":0,"perciva":0,"percmonofasersm":0,"rowVersion":"string","tipologia":1,"verslynfa":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.517Z","datafinblacklist":"2024-11-15T13:29:44.517Z","datainiblacklist":"2024-11-15T13:29:44.517Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.517Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureAssCO":{"codice":"string","datafineval":"2024-11-15T13:29:44.517Z","datainival":"2024-11-15T13:29:44.517Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureEsCO":{"codice":"string","datafineval":"2024-11-15T13:29:44.517Z","datainival":"2024-11-15T13:29:44.517Z","descr":"string","id":0,"rowversion":"string","natureAssCO":[{"codice":"string","datafineval":"2024-11-15T13:29:44.517Z","datainival":"2024-11-15T13:29:44.517Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCOAgr":"string","vatCodeCOOss":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCompensationCO":{"aliqivavent":0,"annotazioni":"string","codice":"string","codiceagr":"string","codiceOss":"string","codPlafond":0,"descrizione":"string","flgAgri":0,"flgAllclifor":0,"flgAssport398":0,"flgAutoue":0,"flgCorrVent":0,"flgEscludiblacklist":0,"flgImpostadibollo":0,"flgIndet":0,"flgIvaedit":0,"flgMonofasersm":0,"flgMossgest":0,"flgMossrid":0,"flgNotvar":0,"flgSospimp":0,"idprov":0,"impostamonofasersm":0,"indNatassoswCg2n":0,"indNatura":0,"indStaper":0,"indtipopart":0,"mosscodCg07":0,"mossperc":0,"note":"string","percforf":0,"percindet":0,"perciva":0,"percmonofasersm":0,"rowVersion":"string","tipologia":1,"verslynfa":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.517Z","datafinblacklist":"2024-11-15T13:29:44.517Z","datainiblacklist":"2024-11-15T13:29:44.517Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.517Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureAssCO":{"codice":"string","datafineval":"2024-11-15T13:29:44.518Z","datainival":"2024-11-15T13:29:44.518Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureEsCO":{"codice":"string","datafineval":"2024-11-15T13:29:44.518Z","datainival":"2024-11-15T13:29:44.518Z","descr":"string","id":0,"rowversion":"string","natureAssCO":[{"codice":"string","datafineval":"2024-11-15T13:29:44.518Z","datainival":"2024-11-15T13:29:44.518Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCOAgr":"string","vatCodeCOOss":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatTypeFI":{"agviaggio":0,"codice":0,"codiceCg0d":0,"descr":"string","indAutofattura":0,"indTipo":0,"localizzazione":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"taxableAmount":0,"cambio":0,"codAttivitaCg96":0,"datacambio":"2024-11-15T13:29:44.518Z","datafincomp":"2024-11-15T13:29:44.518Z","datainicomp":"2024-11-15T13:29:44.518Z","dataoperazione":"2024-11-15T13:29:44.518Z","datareg":"2024-11-15T13:29:44.518Z","datavaluta":"2024-11-15T13:29:44.518Z","descausale":"string","descragg":"string","flgComp":0,"flgDescrstd":0,"flgMentry":0,"flgStpgior":0,"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"imptotale":0,"imptotaleval":0,"imptotaleval2":0,"indDaav":1,"indGiroliq":0,"indRatris":0,"indTipooper":1,"nrmovgruppo":0,"numrigacont":0,"progEserCg19":0,"progIvaCg43":0,"rifrigagior":0,"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"businessTypeDataCO":{"annoliq":0,"codAttivita":0,"codiceCg06":"string","codiceCg6a":"string","datastpliqiva":"2024-11-15T13:29:44.518Z","datastpplafon":"2024-11-15T13:29:44.518Z","datastpregacq":"2024-11-15T13:29:44.518Z","datastpregacqglob":"2024-11-15T13:29:44.518Z","datastpregcor":"2024-11-15T13:29:44.518Z","datastpregrie":"2024-11-15T13:29:44.518Z","datastpregunicanal":"2024-11-15T13:29:44.518Z","datastpregven":"2024-11-15T13:29:44.518Z","datastpregvenglob":"2024-11-15T13:29:44.518Z","descrattivita":"string","dittaCg18":0,"flgIvaedit":0,"indAgric":0,"indCatpart":0,"indRegimefiscale":1,"rowversion":"string","codAteco":{"codice":"string","descriz":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"istatActivityCO":{"codice":"string","descr":"string","idmediaCg99":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"coaAccountFI":{"accountType":0,"alias":"string","codeformatted":"string","codiceCg22":0,"codiceCgc0":0,"cogeprogeAbil":0,"cogeprogeAttivita":0,"cogeprogeMateriali":0,"cogeprogeNodo":0,"cogeprogeSpese":0,"conto":"string","contoape":"string","contochiu":"string","contocrsosp":"string","contoratatt":"string","contoratpass":"string","contorisatt":"string","contorispass":"string","descr":"string","flgAggfatt":0,"flgAnalit":0,"flgBilconsattpassdist":0,"flgContoimm":0,"flgGesec":0,"flgGespor":0,"flgIntercompany":0,"flgOpnonfin":0,"flgRaganal":0,"flgRarp":0,"flgSaldog":0,"flgValutaest":0,"gruppoCg10":0,"idconto":0,"idcontoapeCg24":0,"idcontochiuCg24":0,"idcontoratattCg24":0,"idcontoratpassCg24":0,"idcontorisattCg24":0,"idcontorispassCg24":0,"idparent":0,"idreverse":0,"idRifPdC80":0,"indAttpasspor":0,"indContoricav":0,"indCosvend":0,"indDaav":0,"indDaavec":0,"indLivchius":0,"indMastroCliFor":99,"indTipoconto":0,"percindeduc":0,"percindetra":0,"suddconti":0,"coaAccountCustomizationFI":[{"contoCg24":"string","descr":"string","dittaCg18":0,"gruppoCg10":0,"idCg24":0,"iddespcon":0,"idmediaCg99":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"coaAccountFIApe":"string","coaAccountFIChiu":"string","coaAccountFIParent":"string","coaAccountFIRatatt":"string","coaAccountFIRatpass":"string","coaAccountFIRisatt":"string","coaAccountFIRispass":"string","coaAccountStateFI":[{"consosCg24":"string","dittaCg18":0,"dtconsos":"2024-11-15T13:29:44.518Z","dtdisatt":"2024-11-15T13:29:44.518Z","flgDisatt":0,"grusosCg10":0,"idCg24":0,"idstatipdc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"coaGroupCodeFI":{"descr":"string","flgPdclib":0,"gruppo":0,"maskedit":"string","numlivcons":0,"numlivelli":0,"rowversion":"string","accountProposals":[{"codice":0,"contoCg24":"string","gruppoCg10":0,"id":0,"idCg24":0,"rowversion":"string","coaAccountFI":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"coaInternationalCustomizationFI":[{"categoria":0,"contoCg24":"string","esModulo347":0,"gbDeferralcode":"string","gruppoCg10":0,"id":0,"idCg24":0,"iso3166A2":"string","rowversion":"string","subcategoria":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"reverseTypeFI":{"reverseTypeCode":0,"reverseTypeDescription":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatTypeFI":{"agviaggio":0,"codice":0,"codiceCg0d":0,"descr":"string","indAutofattura":0,"indTipo":0,"localizzazione":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.518Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"customerSupplierCO":{"gmdUpdateAdditionalParams":{"codice":0,"ragSoAnag":"string","indirizzo":"string","numCiv":"string","cap":"string","citta":"string","prov":"string","codiceCg07":0,"partiva":"string","codFiscale":"string","tel1Num":"string","fax":"string","tipologia":"string","codLegCg01":"string","descrCg07":"string","nationIso":"string"},"clifor":0,"codAbiCg12":0,"codCabCg13":0,"codiceCg28":"string","contoCg24":"string","contorCg24":"string","contratto":"string","datavaliva":"2024-11-15T13:29:44.519Z","dittaCg18":0,"flgArt62":0,"flgAttivo":1,"flgCointestati":0,"flgIntercompany":0,"ggscadfix":0,"gruppoCg10":0,"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","idclifor":0,"idmediaCg99":0,"indElenchimov3000":99,"intermedioCg40":0,"lastchange":"2024-11-15T13:29:44.519Z","progREf08":0,"tipocf":0,"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"agentCO":{"agente":"string","anagenCg16":0,"datafineman":"2024-11-15T13:29:44.519Z","datainman":"2024-11-15T13:29:44.519Z","datainrapp":"2024-11-15T13:29:44.519Z","dittaCg18":0,"flgAdegdelta":0,"flgAdeguamscmag":0,"flgRegimeart":0,"flgRegimecl":0,"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","idagente":0,"idcapoareaMg17":0,"idcapozonaMg17":0,"idmediaCg99":0,"indBaseimpmag":0,"indBaseimpsc":0,"indCalcscmag":0,"indPrefstdoc":0,"indStdistenas":0,"indTipoage":0,"indTipoliq":0,"perprov":0,"regimeprov":0,"tipomand":0,"tiporappor":1,"tiposoc":0,"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"dmsPublishedEntityFW":{"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","tipoarchHm30":0,"idknos":0,"dittaCg18":0,"protocollo":"string","flgInvalid":0,"percorso":"string","nome":"string","datapub":"2024-11-15T13:29:44.519Z","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"generalMasterDataCO":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:29:44.519Z","datavalid":"2024-11-15T13:29:44.519Z","dtfinepec":"2024-11-15T13:29:44.519Z","dtiniziopec":"2024-11-15T13:29:44.519Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:29:44.519Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:29:44.519Z","datamod":"2024-11-15T13:29:44.519Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.519Z","datafinblacklist":"2024-11-15T13:29:44.519Z","datainiblacklist":"2024-11-15T13:29:44.519Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.519Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.519Z","datafinblacklist":"2024-11-15T13:29:44.519Z","datainiblacklist":"2024-11-15T13:29:44.519Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.519Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"blackListGeneralMasterData":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:29:44.519Z","datavalid":"2024-11-15T13:29:44.519Z","dtfinepec":"2024-11-15T13:29:44.519Z","dtiniziopec":"2024-11-15T13:29:44.519Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:29:44.519Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:29:44.519Z","datamod":"2024-11-15T13:29:44.519Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.519Z","datafinblacklist":"2024-11-15T13:29:44.519Z","datainiblacklist":"2024-11-15T13:29:44.519Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.519Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.519Z","datafinblacklist":"2024-11-15T13:29:44.519Z","datainiblacklist":"2024-11-15T13:29:44.519Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.519Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"csAccountingIndexCO":{"codCat":"string","descr":"string","dittaCg18":0,"tipocfCg44":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"csBankCO":[{"bban":"string","bicbancaestera":"string","ccaddetto":"string","ccdesagenz":"string","ccforn":"string","ccfornfactor":0,"ccfornfactoridCg44":0,"ccggval":0,"cliforCg44":0,"codiceCg07":0,"dittaCg18":0,"flgPref":0,"flgPrefIncassi":0,"iban":"string","id":0,"idbancaestera":"string","idcontratto":"string","idsuccursale":0,"indTipoop":0,"locbancaestera":"string","nomebancaestera":"string","progR":0,"tipobanca":0,"tipocfCg44":0,"agencyCO":{"codBanca":0,"codice":0,"descrizione":"string","localita":"string","prov":"string","bankCO":{"codBicswift":"string","codiceBanca":0,"descrizione":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"customerSupplierCO":"string","nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.520Z","datafinblacklist":"2024-11-15T13:29:44.520Z","datainiblacklist":"2024-11-15T13:29:44.520Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.520Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"csCompanyBankCO":[{"cliforCg44":0,"dittaCg18":0,"flgPref":0,"id":0,"progR":0,"progREf08":0,"rowversion":"string","tipocfCg44":0,"companyBankCO":{"aprogressmav":0,"bancaCg12":0,"bbananticipi":"string","bbanconto":"string","bbaneffpresef":"string","bbanordpbonif":"string","bicbanca":"string","cabbonifCg13":0,"cabcontoCg13":0,"cabmavCg13":0,"cabribaCg13":0,"cabridCg13":0,"ccanticipi":"string","ccconto":"string","cceffpresef":"string","ccordpbonif":"string","codAzienda":"string","codiceCg07":0,"codicecuc":"string","codRappopor":"string","codSia":"string","creditidentifier":"string","daprogressmav":0,"descr":"string","dittaCg18":0,"flgAutattribnrmav":0,"flgCambiali":0,"flgCessioni":0,"flgMav":0,"flgPref":0,"flgRiba":0,"flgRibacamb":0,"flgRibacess":0,"flgRibaricba":0,"flgRibatratac":0,"flgRibatratte":0,"flgRidsdd":0,"flgRidsddraggr":0,"flgScfatt":0,"flgTratte":0,"ggvalcambalt":0,"ggvalcambfil":0,"ggvalmavincalt":0,"ggvalmavincfil":0,"ggvalmavincpos":0,"ggvalmavsbf":0,"ggvalribaalt":0,"ggvalribafil":0,"ggvalridalt":0,"ggvalridfil":0,"ggvalscfattalt":0,"ggvalscfattfil":0,"ggvaltratalt":0,"ggvaltratfil":0,"ibananticipi":"string","ibanconto":"string","ibaneffpresef":"string","ibanordpbonif":"string","id":0,"idbancaestera":"string","idcontratto":"string","idmediaCg99":0,"idsuccursale":0,"impcastel":0,"impfido":0,"indCheckpivacf":0,"indCompind":0,"indContpmtinf":0,"indPresmav":1,"indPresriba":1,"indPresrid":1,"indTipolib":1,"indTipopres":0,"locbancaestera":"string","maxgginsoluti":0,"prefissoattribmav":0,"progR":0,"rowversion":"string","scfindbasecalc":1,"scfnsdocrif":"string","scfpercpres":0,"scfperctasso":0,"scfvsdocrif":"string","spcommbonalt":0,"spcommbonfil":0,"spcommordpalt":0,"spcommordpfil":0,"spinccambalt":0,"spinccambfil":0,"spinccoralt":0,"spinccorfil":0,"spincesitopag":0,"spincmavincalt":0,"spincmavincfil":0,"spincmavincpos":0,"spincmavsbf":0,"spincribaalt":0,"spincribafil":0,"spincridalt":0,"spincridfil":0,"spinctraalt":0,"spinctrafil":0,"sppresdistinta":0,"spritcamb":0,"spritcambcl":0,"spritmavincas":0,"spritmavincascl":0,"spritmavsbf":0,"spritmavsbfcl":0,"spritriba":0,"spritribacl":0,"spritrid":0,"spritridcl":0,"sprittratte":0,"sprittrattecl":0,"tipobanca":0,"ultprogressmav":0,"bankCO":{"codBicswift":"string","codiceBanca":0,"descrizione":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.520Z","datafinblacklist":"2024-11-15T13:29:44.520Z","datainiblacklist":"2024-11-15T13:29:44.520Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.520Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"csInfoCO":{"area":"string","areanielsenMg0e":"string","bacsaccountno":0,"categ":"string","cliforCg44":0,"codIclfatt":0,"codLivbloc":"string","codRifalf":"string","codRifnum":0,"codRischioMg2a":"string","datablocco":"2024-11-15T13:29:44.520Z","datacreaz":"2024-11-15T13:29:44.520Z","datadismis":"2024-11-15T13:29:44.520Z","datarischio":"2024-11-15T13:29:44.520Z","dataultvar":"2024-11-15T13:29:44.520Z","dittaCg18":0,"fidoaziendale":0,"fidofactoring":0,"fidolivello1":0,"fidolivello2":0,"finchargerterms":"string","flgEstrpayline":0,"flgSpbol":0,"flgSpeinc":0,"flgTaxliable":0,"idmediaCg99":0,"indClibloc":0,"indGesfido":0,"indrottcig":0,"indSpesecum":0,"irs1099":"string","lastchange":"2024-11-15T13:29:44.520Z","linguaMg52":"string","macroarea":"string","macrocat":"string","notebloc":"string","raggcrf3":"string","raggrcf1":"string","raggrcf2":"string","regimeiva":"string","reminderterms":"string","scaglspbanc":0,"sottocat":"string","taxareaNv01":"string","taxexemptionno":"string","tipocfCg44":0,"typeofsupply":"string","zona":"string","areaCO":{"codiceAreaMG":"string","descrarea":"string","dittaCg18":0,"idprov":0,"macroareaMg07":"string","tipocfMg07":0,"zone":[{"areaMg08":"string","codiceZona":"string","descrzona":"string","dittaCg18":0,"idprov":0,"macroareaMg08":"string","tipocfMg08":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"categoryCO":{"categ":"string","descrcat":"string","dittaCg18":0,"macrocatMg10":"string","tipocfMg10":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"grouping1CO":{"codRaggrcf1":"string","descraggrcf1":"string","dittaCg18":0,"idmediaCg99":0,"idprov":0,"tipocf":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"grouping2CO":{"codRaggrcf2":"string","descraggrcf2":"string","dittaCg18":0,"idmediaCg99":0,"idprov":0,"tipocf":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"grouping3CO":{"codRaggrcf3":"string","descraggrcf3":"string","dittaCg18":0,"idmediaCg99":0,"idprov":0,"tipocf":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"macroAreaCO":{"codiceMacroarea":"string","descrmacroar":"string","dittaCg18":0,"idprov":0,"tipocf":0,"areas":[{"codiceAreaMG":"string","descrarea":"string","dittaCg18":0,"idprov":0,"macroareaMg07":"string","tipocfMg07":0,"zone":[{"areaMg08":"string","codiceZona":"string","descrzona":"string","dittaCg18":0,"idprov":0,"macroareaMg08":"string","tipocfMg08":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"macroCategoryCO":{"descrmacrocat":"string","dittaCg18":0,"macrocat":"string","tipocf":0,"categorie":[{"categ":"string","descrcat":"string","dittaCg18":0,"macrocatMg10":"string","tipocfMg10":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"subCategoryCO":{"categMg11":"string","descrsottocat":"string","dittaCg18":0,"macrocatMg11":"string","sottcat":"string","tipocfMg11":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"zoneCO":{"areaMg08":"string","codiceZona":"string","descrzona":"string","dittaCg18":0,"idprov":0,"macroareaMg08":"string","tipocfMg08":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"csJointlyHeldCO":[{"cliforCg44":0,"cliforcoCg44":0,"dittaCg18":0,"idcliforcoCg44":0,"percentuale":0,"tipocfCg44":0,"customerSupplierCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"csPaymentRangeCO":[{"aimpdoc":0,"cliforCg44":0,"codPagCg62":"string","codScagl":0,"dittaCg18":0,"id":0,"idCg62":0,"idmediaCg99":0,"indPagpart":0,"tipocfCg44":0,"valutaCg08":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.520Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"paymentTermCO":{"codPag":"string","descPag":"string","desPagAnal":"string","flgDesc":0,"flgDisgg":0,"flgPrefatt":0,"flgPrefpass":0,"flgStornoiva":0,"id":0,"rowversion":"string","scart26":0,"scpercart26":0,"scpercas":0,"scpermer1":0,"scpermer2":0,"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"paymentTermDetailCO":[{"aggfix1":0,"aggfix2":0,"codPagCg62":"string","daggfix1":0,"daggfix2":0,"el1frimp":0,"el1friva":0,"el2frimp":0,"el2friva":0,"flgFrpercimp":1,"flgFrperciva":1,"ggdecor":0,"ggmmfix":0,"ggscadfix1":0,"ggscadfix2":0,"id":0,"idCg62":0,"idCg64":0,"imporfix":0,"indDatarif":0,"indImpfix":0,"indTipocalend":0,"indTipodecor":1,"percimp":0,"perciva":0,"prog":0,"rowversion":"string","tipoeff":9,"subTypeCO":{"codiceCg07":0,"codPaguc":"string","codStipoeff":0,"descstipo":"string","flgAssegno":0,"ggoffset":0,"id":0,"indModfatturapa":0,"rowversion":"string","tipoeff":0,"foreignPaymentCodeCO":{"codice":"string","codIso":"string","descrpag":"string","flgIbanobbl":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.520Z","datafinblacklist":"2024-11-15T13:29:44.520Z","datainiblacklist":"2024-11-15T13:29:44.520Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.520Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"csPostponementPeriodCO":[{"ammgg":0,"cliforCg44":0,"dammgg":0,"dittaCg18":0,"ggmmfixslit":0,"ggslsucc":0,"id":0,"idmediaCg99":0,"indAppggfix":0,"indTiposlit":1,"tipocfCg44":0,"tipoeff":9,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"csSddCO":[{"bancaallineam":0,"causrich":0,"causrisp":0,"cfiscsottoscr":"string","cliforCg44":0,"codAutoriz":"string","codBicswift":"string","codClideb":"string","codClidebprec":"string","codIndiv":0,"codIndivprec":0,"codRif":"string","contocorr":"string","contocorrprec":"string","datamandato":"2024-11-15T13:29:44.521Z","dataprimascad":"2024-11-15T13:29:44.521Z","datarich":"2024-11-15T13:29:44.521Z","datarisp":"2024-11-15T13:29:44.521Z","dataultimascad":"2024-11-15T13:29:44.521Z","descrizione":"string","diniego":0,"dittaCg18":0,"flgAllineam":0,"flgDisattivato":0,"flgVariato":0,"id":0,"idmediaCg99":0,"impmaxrata":0,"indIrsottoscr":"string","indStorno":0,"indStornoprec":0,"indTipoinc":0,"indTiposdd":0,"locsottoscr":"string","nrrate":0,"nuovabanca":0,"progR":0,"ragsosottoscr":"string","ridabi":0,"ridabiprec":0,"ridcab":0,"ridcabprec":0,"ridiban":"string","ridibanprec":"string","soggtitibanCg16":0,"tipocfCg44":0,"tipoinclocked":0,"tipologia":1,"tipologiaprec":0,"csHistorySddCO":[{"codBicswift":"string","codClideb":"string","codIndiv":0,"datavar":"2024-11-15T13:29:44.521Z","id":0,"indStorno":0,"indTipoinc":0,"indTiposdd":0,"ridiban":"string","soggtitibanCg16":0,"tipologia":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.521Z","datafinblacklist":"2024-11-15T13:29:44.521Z","datainiblacklist":"2024-11-15T13:29:44.521Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.521Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"soggtitiban":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:29:44.521Z","datavalid":"2024-11-15T13:29:44.521Z","dtfinepec":"2024-11-15T13:29:44.521Z","dtiniziopec":"2024-11-15T13:29:44.521Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:29:44.521Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:29:44.521Z","datamod":"2024-11-15T13:29:44.521Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.521Z","datafinblacklist":"2024-11-15T13:29:44.521Z","datainiblacklist":"2024-11-15T13:29:44.521Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.521Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.521Z","datafinblacklist":"2024-11-15T13:29:44.521Z","datainiblacklist":"2024-11-15T13:29:44.521Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.521Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.521Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"customerSupplierCIGCUPCO":[{"cliforCg44":0,"dittaCg18":0,"id":0,"idcigcupCo1h":0,"progREf08":0,"progRMg35":0,"rowversion":"string","tipocfCg44":0,"cigcuPcode":{"cig":"string","cup":"string","descrizione":"string","docrifData":"2024-11-15T13:29:44.521Z","docrifId":"string","flgAttivo":0,"id":0,"indTipocontr":0,"indTipodocrif":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"companyBank":{"aprogressmav":0,"bancaCg12":0,"bbananticipi":"string","bbanconto":"string","bbaneffpresef":"string","bbanordpbonif":"string","bicbanca":"string","cabbonifCg13":0,"cabcontoCg13":0,"cabmavCg13":0,"cabribaCg13":0,"cabridCg13":0,"ccanticipi":"string","ccconto":"string","cceffpresef":"string","ccordpbonif":"string","codAzienda":"string","codiceCg07":0,"codicecuc":"string","codRappopor":"string","codSia":"string","creditidentifier":"string","daprogressmav":0,"descr":"string","dittaCg18":0,"flgAutattribnrmav":0,"flgCambiali":0,"flgCessioni":0,"flgMav":0,"flgPref":0,"flgRiba":0,"flgRibacamb":0,"flgRibacess":0,"flgRibaricba":0,"flgRibatratac":0,"flgRibatratte":0,"flgRidsdd":0,"flgRidsddraggr":0,"flgScfatt":0,"flgTratte":0,"ggvalcambalt":0,"ggvalcambfil":0,"ggvalmavincalt":0,"ggvalmavincfil":0,"ggvalmavincpos":0,"ggvalmavsbf":0,"ggvalribaalt":0,"ggvalribafil":0,"ggvalridalt":0,"ggvalridfil":0,"ggvalscfattalt":0,"ggvalscfattfil":0,"ggvaltratalt":0,"ggvaltratfil":0,"ibananticipi":"string","ibanconto":"string","ibaneffpresef":"string","ibanordpbonif":"string","id":0,"idbancaestera":"string","idcontratto":"string","idmediaCg99":0,"idsuccursale":0,"impcastel":0,"impfido":0,"indCheckpivacf":0,"indCompind":0,"indContpmtinf":0,"indPresmav":1,"indPresriba":1,"indPresrid":1,"indTipolib":1,"indTipopres":0,"locbancaestera":"string","maxgginsoluti":0,"prefissoattribmav":0,"progR":0,"rowversion":"string","scfindbasecalc":1,"scfnsdocrif":"string","scfpercpres":0,"scfperctasso":0,"scfvsdocrif":"string","spcommbonalt":0,"spcommbonfil":0,"spcommordpalt":0,"spcommordpfil":0,"spinccambalt":0,"spinccambfil":0,"spinccoralt":0,"spinccorfil":0,"spincesitopag":0,"spincmavincalt":0,"spincmavincfil":0,"spincmavincpos":0,"spincmavsbf":0,"spincribaalt":0,"spincribafil":0,"spincridalt":0,"spincridfil":0,"spinctraalt":0,"spinctrafil":0,"sppresdistinta":0,"spritcamb":0,"spritcambcl":0,"spritmavincas":0,"spritmavincascl":0,"spritmavsbf":0,"spritmavsbfcl":0,"spritriba":0,"spritribacl":0,"spritrid":0,"spritridcl":0,"sprittratte":0,"sprittrattecl":0,"tipobanca":0,"ultprogressmav":0,"bankCO":{"codBicswift":"string","codiceBanca":0,"descrizione":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.521Z","datafinblacklist":"2024-11-15T13:29:44.521Z","datainiblacklist":"2024-11-15T13:29:44.521Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.521Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"csBankCO":{"bban":"string","bicbancaestera":"string","ccaddetto":"string","ccdesagenz":"string","ccforn":"string","ccfornfactor":0,"ccfornfactoridCg44":0,"ccggval":0,"cliforCg44":0,"codiceCg07":0,"dittaCg18":0,"flgPref":0,"flgPrefIncassi":0,"iban":"string","id":0,"idbancaestera":"string","idcontratto":"string","idsuccursale":0,"indTipoop":0,"locbancaestera":"string","nomebancaestera":"string","progR":0,"tipobanca":0,"tipocfCg44":0,"agencyCO":{"codBanca":0,"codice":0,"descrizione":"string","localita":"string","prov":"string","bankCO":{"codBicswift":"string","codiceBanca":0,"descrizione":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"customerSupplierCO":"string","nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.522Z","datafinblacklist":"2024-11-15T13:29:44.522Z","datainiblacklist":"2024-11-15T13:29:44.522Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.522Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"custSupplDataInvoicePACO":{"codiceCg16":0,"emailcortesia":"string","flgAsw":0,"indTypeb2b":0,"tipocfCg44":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"dmsPublishedEntityFW":{"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","tipoarchHm30":0,"idknos":0,"dittaCg18":0,"protocollo":"string","flgInvalid":0,"percorso":"string","nome":"string","datapub":"2024-11-15T13:29:44.522Z","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"generalMasterDataCO":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:29:44.522Z","datavalid":"2024-11-15T13:29:44.522Z","dtfinepec":"2024-11-15T13:29:44.522Z","dtiniziopec":"2024-11-15T13:29:44.522Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:29:44.522Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:29:44.522Z","datamod":"2024-11-15T13:29:44.522Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.522Z","datafinblacklist":"2024-11-15T13:29:44.522Z","datainiblacklist":"2024-11-15T13:29:44.522Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.522Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.522Z","datafinblacklist":"2024-11-15T13:29:44.522Z","datainiblacklist":"2024-11-15T13:29:44.522Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.522Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"officeCO":{"cap":"string","citta":"string","codice":0,"dittaCg18":0,"idmediaCg99":0,"indDimcentrocomm":0,"indIrizzo":"string","numerorea":"string","progRea":0,"prov":"string","rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"officePACO":[{"cap":"string","codDestin":"string","codice":"string","codiceCg16":0,"comune":"string","flgPreferenziale":0,"idprovincia":0,"idregione":0,"indIrizzo":"string","indTypeb2b":0,"lastupdateB2b":"2024-11-15T13:29:44.522Z","nome":"string","tipocfCg44":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"paymentTermCO":{"codPag":"string","descPag":"string","desPagAnal":"string","flgDesc":0,"flgDisgg":0,"flgPrefatt":0,"flgPrefpass":0,"flgStornoiva":0,"id":0,"rowversion":"string","scart26":0,"scpercart26":0,"scpercas":0,"scpermer1":0,"scpermer2":0,"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"paymentTermDetailCO":[{"aggfix1":0,"aggfix2":0,"codPagCg62":"string","daggfix1":0,"daggfix2":0,"el1frimp":0,"el1friva":0,"el2frimp":0,"el2friva":0,"flgFrpercimp":1,"flgFrperciva":1,"ggdecor":0,"ggmmfix":0,"ggscadfix1":0,"ggscadfix2":0,"id":0,"idCg62":0,"idCg64":0,"imporfix":0,"indDatarif":0,"indImpfix":0,"indTipocalend":0,"indTipodecor":1,"percimp":0,"perciva":0,"prog":0,"rowversion":"string","tipoeff":9,"subTypeCO":{"codiceCg07":0,"codPaguc":"string","codStipoeff":0,"descstipo":"string","flgAssegno":0,"ggoffset":0,"id":0,"indModfatturapa":0,"rowversion":"string","tipoeff":0,"foreignPaymentCodeCO":{"codice":"string","codIso":"string","descrpag":"string","flgIbanobbl":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.522Z","datafinblacklist":"2024-11-15T13:29:44.522Z","datainiblacklist":"2024-11-15T13:29:44.522Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.522Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCO":{"aliqivavent":0,"annotazioni":"string","codice":"string","codiceagr":"string","codiceOss":"string","codPlafond":0,"descrizione":"string","flgAgri":0,"flgAllclifor":0,"flgAssport398":0,"flgAutoue":0,"flgCorrVent":0,"flgEscludiblacklist":0,"flgImpostadibollo":0,"flgIndet":0,"flgIvaedit":0,"flgMonofasersm":0,"flgMossgest":0,"flgMossrid":0,"flgNotvar":0,"flgSospimp":0,"idprov":0,"impostamonofasersm":0,"indNatassoswCg2n":0,"indNatura":0,"indStaper":0,"indtipopart":0,"mosscodCg07":0,"mossperc":0,"note":"string","percforf":0,"percindet":0,"perciva":0,"percmonofasersm":0,"rowVersion":"string","tipologia":1,"verslynfa":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.522Z","datafinblacklist":"2024-11-15T13:29:44.522Z","datainiblacklist":"2024-11-15T13:29:44.522Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.522Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureAssCO":{"codice":"string","datafineval":"2024-11-15T13:29:44.522Z","datainival":"2024-11-15T13:29:44.523Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureEsCO":{"codice":"string","datafineval":"2024-11-15T13:29:44.523Z","datainival":"2024-11-15T13:29:44.523Z","descr":"string","id":0,"rowversion":"string","natureAssCO":[{"codice":"string","datafineval":"2024-11-15T13:29:44.523Z","datainival":"2024-11-15T13:29:44.523Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCOAgr":"string","vatCodeCOOss":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"officeCO":{"cap":"string","citta":"string","codice":0,"dittaCg18":0,"idmediaCg99":0,"indDimcentrocomm":0,"indIrizzo":"string","numerorea":"string","progRea":0,"prov":"string","rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"glvatDetailFI":[{"causaleiva":0,"dittaCg18":0,"flgDeducibile":0,"flgTsescluso":0,"flgTsinviato":0,"id":0,"idCg41":0,"idcontoCg24":0,"imponibile":0,"imponibileval":0,"imposta":0,"impostand":0,"impostandval":0,"impostaval":0,"indDetriva":0,"indIvaacqagric":0,"indNatura":0,"indProrata":0,"indTipo":0,"indTstipoop":0,"indTstiposp":0,"indTsvocesp":0,"numrigaiva":0,"percdetr":0,"percforf":0,"tsdatadocori":"2024-11-15T13:29:44.523Z","tsdocorigine":"string","coaAccountFI":{"accountType":0,"alias":"string","codeformatted":"string","codiceCg22":0,"codiceCgc0":0,"cogeprogeAbil":0,"cogeprogeAttivita":0,"cogeprogeMateriali":0,"cogeprogeNodo":0,"cogeprogeSpese":0,"conto":"string","contoape":"string","contochiu":"string","contocrsosp":"string","contoratatt":"string","contoratpass":"string","contorisatt":"string","contorispass":"string","descr":"string","flgAggfatt":0,"flgAnalit":0,"flgBilconsattpassdist":0,"flgContoimm":0,"flgGesec":0,"flgGespor":0,"flgIntercompany":0,"flgOpnonfin":0,"flgRaganal":0,"flgRarp":0,"flgSaldog":0,"flgValutaest":0,"gruppoCg10":0,"idconto":0,"idcontoapeCg24":0,"idcontochiuCg24":0,"idcontoratattCg24":0,"idcontoratpassCg24":0,"idcontorisattCg24":0,"idcontorispassCg24":0,"idparent":0,"idreverse":0,"idRifPdC80":0,"indAttpasspor":0,"indContoricav":0,"indCosvend":0,"indDaav":0,"indDaavec":0,"indLivchius":0,"indMastroCliFor":99,"indTipoconto":0,"percindeduc":0,"percindetra":0,"suddconti":0,"coaAccountCustomizationFI":[{"contoCg24":"string","descr":"string","dittaCg18":0,"gruppoCg10":0,"idCg24":0,"iddespcon":0,"idmediaCg99":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"coaAccountFIApe":"string","coaAccountFIChiu":"string","coaAccountFIParent":"string","coaAccountFIRatatt":"string","coaAccountFIRatpass":"string","coaAccountFIRisatt":"string","coaAccountFIRispass":"string","coaAccountStateFI":[{"consosCg24":"string","dittaCg18":0,"dtconsos":"2024-11-15T13:29:44.523Z","dtdisatt":"2024-11-15T13:29:44.523Z","flgDisatt":0,"grusosCg10":0,"idCg24":0,"idstatipdc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"coaGroupCodeFI":{"descr":"string","flgPdclib":0,"gruppo":0,"maskedit":"string","numlivcons":0,"numlivelli":0,"rowversion":"string","accountProposals":[{"codice":0,"contoCg24":"string","gruppoCg10":0,"id":0,"idCg24":0,"rowversion":"string","coaAccountFI":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"coaInternationalCustomizationFI":[{"categoria":0,"contoCg24":"string","esModulo347":0,"gbDeferralcode":"string","gruppoCg10":0,"id":0,"idCg24":0,"iso3166A2":"string","rowversion":"string","subcategoria":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"reverseTypeFI":{"reverseTypeCode":0,"reverseTypeDescription":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatTypeFI":{"agviaggio":0,"codice":0,"codiceCg0d":0,"descr":"string","indAutofattura":0,"indTipo":0,"localizzazione":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"reverseTypeFI":{"reverseTypeCode":0,"reverseTypeDescription":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCO":{"aliqivavent":0,"annotazioni":"string","codice":"string","codiceagr":"string","codiceOss":"string","codPlafond":0,"descrizione":"string","flgAgri":0,"flgAllclifor":0,"flgAssport398":0,"flgAutoue":0,"flgCorrVent":0,"flgEscludiblacklist":0,"flgImpostadibollo":0,"flgIndet":0,"flgIvaedit":0,"flgMonofasersm":0,"flgMossgest":0,"flgMossrid":0,"flgNotvar":0,"flgSospimp":0,"idprov":0,"impostamonofasersm":0,"indNatassoswCg2n":0,"indNatura":0,"indStaper":0,"indtipopart":0,"mosscodCg07":0,"mossperc":0,"note":"string","percforf":0,"percindet":0,"perciva":0,"percmonofasersm":0,"rowVersion":"string","tipologia":1,"verslynfa":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.523Z","datafinblacklist":"2024-11-15T13:29:44.523Z","datainiblacklist":"2024-11-15T13:29:44.523Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.523Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureAssCO":{"codice":"string","datafineval":"2024-11-15T13:29:44.523Z","datainival":"2024-11-15T13:29:44.523Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureEsCO":{"codice":"string","datafineval":"2024-11-15T13:29:44.523Z","datainival":"2024-11-15T13:29:44.523Z","descr":"string","id":0,"rowversion":"string","natureAssCO":[{"codice":"string","datafineval":"2024-11-15T13:29:44.523Z","datainival":"2024-11-15T13:29:44.523Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCOAgr":"string","vatCodeCOOss":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCompensationCO":{"aliqivavent":0,"annotazioni":"string","codice":"string","codiceagr":"string","codiceOss":"string","codPlafond":0,"descrizione":"string","flgAgri":0,"flgAllclifor":0,"flgAssport398":0,"flgAutoue":0,"flgCorrVent":0,"flgEscludiblacklist":0,"flgImpostadibollo":0,"flgIndet":0,"flgIvaedit":0,"flgMonofasersm":0,"flgMossgest":0,"flgMossrid":0,"flgNotvar":0,"flgSospimp":0,"idprov":0,"impostamonofasersm":0,"indNatassoswCg2n":0,"indNatura":0,"indStaper":0,"indtipopart":0,"mosscodCg07":0,"mossperc":0,"note":"string","percforf":0,"percindet":0,"perciva":0,"percmonofasersm":0,"rowVersion":"string","tipologia":1,"verslynfa":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.523Z","datafinblacklist":"2024-11-15T13:29:44.523Z","datainiblacklist":"2024-11-15T13:29:44.523Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.523Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureAssCO":{"codice":"string","datafineval":"2024-11-15T13:29:44.523Z","datainival":"2024-11-15T13:29:44.523Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureEsCO":{"codice":"string","datafineval":"2024-11-15T13:29:44.523Z","datainival":"2024-11-15T13:29:44.523Z","descr":"string","id":0,"rowversion":"string","natureAssCO":[{"codice":"string","datafineval":"2024-11-15T13:29:44.523Z","datainival":"2024-11-15T13:29:44.523Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCOAgr":"string","vatCodeCOOss":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatTypeFI":{"agviaggio":0,"codice":0,"codiceCg0d":0,"descr":"string","indAutofattura":0,"indTipo":0,"localizzazione":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"movementTypeCO":{"codice":0,"descr":"string","descrbreve":"string","descrmedia":"string","flgBilanci":0,"flgBilancicons":0,"flgCanrevoke":0,"flgCoan":0,"flgContrsaldi":0,"flgDoc":0,"flgEc":0,"flgElabiva":0,"flgHyperion":0,"flgMovcont":0,"flgMoviva":0,"flgPartitari":0,"flgPf":0,"flgQuerypn":0,"indAcconti":0,"indCambiali":0,"indChiuseff":0,"indConsolidamento":0,"indDatabilanci":0,"indEcportaper":0,"indEcportchius":0,"indIncassobf":0,"indInsoluti":0,"indProforma":0,"indRaggr":0,"indRatrisc":0,"indRettifica":0,"indSimulbilanci":0,"indTipoifrs":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"officeCO":{"cap":"string","citta":"string","codice":0,"dittaCg18":0,"idmediaCg99":0,"indDimcentrocomm":0,"indIrizzo":"string","numerorea":"string","progRea":0,"prov":"string","rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"sectionalMasterDataCO":{"caustcoll":"string","descsez":"string","dittaCg18":0,"flgNoLiqIva":0,"idagentecoll":0,"idprov":0,"indIntra1213":0,"indRegione":0,"indTipologia":0,"puntovenCg7a":0,"sezionale":"string","storeCO":{"descrizione":"string","dittaCg18":0,"puntoven":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"instalments":[{"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"agenappCg13":0,"agenpreScg13":0,"annopart":0,"bancaappCg12":0,"bancapreScg12":0,"bolli":0,"bollival":0,"cambio":0,"causaleCg33":"string","causmgoMgfo":0,"changed":true,"cig":"string","codCcred":"string","codiceCg08":"string","cup":"string","datacambio":"2024-11-15T13:29:44.524Z","datadecorr":"2024-11-15T13:29:44.524Z","datadoc":"2024-11-15T13:29:44.524Z","datareg":"2024-11-15T13:29:44.524Z","descausale":"string","descragg":"string","dittaCg18":0,"flgAcconto":0,"flgDocbis":0,"flgEffvar":0,"flgEstraz":0,"flgGendarag":0,"flgGiratoS":0,"flgPartbis":0,"flgRicevutoS":0,"flgSospeso":0,"flgSteffS":0,"id":0,"idagenteMg17":0,"idCg24":0,"idCg44":0,"idCg62":0,"idContoSpeseCg24":0,"idEf08":0,"idLinkEf01":0,"idMg29":0,"idMg35":0,"idpreEf08":0,"idStage":0,"idStageLinkEf01":0,"impeffiva":0,"impeffivaVal":0,"impeffnetprevS":0,"impeffnetprevvalS":0,"impefforig":0,"impefforigval":0,"impeffS":0,"impeffvalS":0,"importoDaAssociare":0,"impritacc":0,"impritaccorig":0,"impritaccorigval":0,"impritaccval":0,"indConto":0,"indGenstatoS":0,"indLiqprov":0,"indMerceart62":0,"indPresS":0,"indSperitS":0,"indStatoS":0,"indTipomov":0,"numdoc":0,"numdocorig":"string","numeff":0,"numpart":0,"numrata":0,"numregCo99":"string","recordtype":0,"rigacontCg42":0,"rowversion":"string","scadeorig":"2024-11-15T13:29:44.524Z","scadeS":"2024-11-15T13:29:44.524Z","sezdoc":"string","sezpart":"string","speseritS":0,"spinc":0,"spincval":0,"stageguid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","stagestate":0,"stipoeff":0,"tipoeff":1,"totdoc":0,"totdocval":0,"totrate":0,"instalmentNoteStageFIDTO":[{"changed":true,"id":0,"idEf01":0,"idEf01Stage":0,"idStage":0,"noteammin":"string","noteraggr":"string","recordtype":0,"rowversion":"string","stageguid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","stagestate":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"instalmentStageHistoryFIDTO":[{"agenzpreS":0,"bancapreS":0,"cambio":0,"cambioadcontoS":0,"changed":true,"datacambio":"2024-11-15T13:29:44.524Z","datacambioadcontoS":"2024-11-15T13:29:44.524Z","datareg":"2024-11-15T13:29:44.524Z","diffcambio":0,"diffcambioconto":0,"flgGiratoS":0,"flgIncassobfS":0,"flgProformadef":0,"flgRicevutoS":0,"flgSteffS":0,"flgVariatoMg29":0,"id":0,"idassEf01":0,"idEf01":0,"idEf01Stage":0,"idpreEf08S":0,"idStage":0,"impadegcambioS":0,"impeffnetprevS":0,"impeffnetprevvalS":0,"impeffS":0,"impeffvalS":0,"impmovabb":0,"impmovabbval":0,"impmovacc":0,"impmovaccval":0,"impmovomanoriv":0,"impmovomanorivval":0,"impmovpag":0,"impmovpagrit":0,"impmovpagritval":0,"impmovpagval":0,"impmovrit":0,"impmovritval":0,"impmovscind":0,"impmovscindval":0,"indAssoc":0,"indGenstatoS":0,"indPresS":0,"indSperitS":0,"indStatoS":0,"indTipoincMg29":0,"indTipoper":0,"numassegno":"string","numccassegn":"string","numregmovCo99":"string","numriemisS":0,"numsteffS":0,"ordbonabiCg13":0,"ordboncabCg13":0,"ordboncaupag":"string","ordboniban":"string","ordbonmotivo":"string","progSto":0,"recordtype":0,"rigacontmovAlRitCg42":0,"rigacontmovAlRitCpCg42":0,"rigacontmovCg42":0,"rigacontmovCpCg42":0,"rigacontmovRitCg42":0,"rigacontmovRitCpCg42":0,"rowversion":"string","scadeS":"2024-11-15T13:29:44.524Z","speseritbanS":0,"speseritS":0,"stageguid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","stagestate":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"instalmentsExtension":[{"numRata":0,"importoPagato":0,"abbuono":0,"flagNote":0,"scontoIncond":0,"omaggioSenzaRiv":0,"scontoIncondEURO":0,"omaggioSenzaRivEURO":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"wtPurchases":[{"annocomp":0,"codiceCg15":"string","codiceCg16":0,"codTribrp":"string","codTributo":"string","contcditta":0,"contcperc":0,"contribint":0,"datadoc":"2024-11-15T13:29:44.524Z","datareg":"2024-11-15T13:29:44.524Z","dittaCg18":0,"enasazienda":0,"flgDocbis":0,"flgPagtot":0,"flgSegno":0,"flgStampra":0,"flgStandalone":0,"franchigia":0,"id":0,"idCg41":0,"impfattura":0,"impiva":0,"imponibilera":0,"imponibilerp":0,"importoalrit":0,"importora":0,"ind770":0,"indAsscontr":0,"numdoc":0,"numdocorig":"string","numregCg41":"string","perattal":"2024-11-15T13:29:44.524Z","perattdal":"2024-11-15T13:29:44.524Z","percra":0,"percripaz":0,"percrp":0,"provvnonsog":0,"rimborsi":0,"rowversion":"string","sezionale":"string","generalMasterDataCODTO":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:29:44.524Z","datavalid":"2024-11-15T13:29:44.524Z","dtfinepec":"2024-11-15T13:29:44.524Z","dtiniziopec":"2024-11-15T13:29:44.524Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:29:44.524Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:29:44.524Z","datamod":"2024-11-15T13:29:44.524Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.524Z","datafinblacklist":"2024-11-15T13:29:44.524Z","datainiblacklist":"2024-11-15T13:29:44.524Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.524Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:29:44.525Z","datafinblacklist":"2024-11-15T13:29:44.525Z","datainiblacklist":"2024-11-15T13:29:44.525Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:29:44.525Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"purchasePaymentWTDTO":[{"annocomp":0,"annovers":0,"annoversrp":0,"ccpostalera":"string","ccpostalerp":"string","codAbiraCg12":0,"codAbirpCg12":0,"codCabraCg13":0,"codCabrpCg13":0,"contcditta":0,"contcperc":0,"contribint":0,"credimposta":0,"datapag":"2024-11-15T13:29:44.525Z","dittaCg18":0,"enasazienda":0,"flgStampra":0,"flgStamprp":0,"flgStandalone":0,"franchigia":0,"id":0,"idCg54":0,"iddeleraCg3f":0,"iddelerpCg3f":0,"idEf01":0,"idtribraCg2f":0,"idtribrpCg2f":0,"imponibilera":0,"imponibilerp":0,"importoabb":0,"importoalrit":0,"importopag":0,"importora":0,"impversra":0,"impversrp":0,"indTipoversra":0,"indTipoversrp":0,"mesecomp":0,"mesevers":0,"meseversrp":0,"numf24ra":0,"numf24rp":0,"numpag":0,"numregCg41":"string","provvnonsog":0,"quietanzara":"string","quietanzarp":"string","regpnCg41":"string","regpnvCg41":"string","regpnvrpCg41":"string","rimborsi":0,"rowversion":"string","seriera":"string","serierp":"string"}],"sectionalMasterDataCODTO":{"caustcoll":"string","descsez":"string","dittaCg18":0,"flgNoLiqIva":0,"idagentecoll":0,"idprov":0,"indIntra1213":0,"indRegione":0,"indTipologia":0,"puntovenCg7a":0,"sezionale":"string","storeCO":{"descrizione":"string","dittaCg18":0,"puntoven":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"tributeCodeCO":{"codMatricolaCg0e":"string","codPeriodo1":"string","codPeriodo2":"string","codTributo":"string","descr":"string","descrext":"string","flgCodenteloc":0,"flgCodregione":0,"flgCredcompens":0,"flgDebnoncompens":0,"flgDisattivato":0,"flgIcicomuni":0,"flgMeserif":0,"flgNumrate":0,"flgRichcodatto":0,"flgRichcoduff":0,"flgStpprov":0,"impdetrazioneici":0,"indSezione":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"tributeCodeCORA":{"codMatricolaCg0e":"string","codPeriodo1":"string","codPeriodo2":"string","codTributo":"string","descr":"string","descrext":"string","flgCodenteloc":0,"flgCodregione":0,"flgCredcompens":0,"flgDebnoncompens":0,"flgDisattivato":0,"flgIcicomuni":0,"flgMeserif":0,"flgNumrate":0,"flgRichcodatto":0,"flgRichcoduff":0,"flgStpprov":0,"impdetrazioneici":0,"indSezione":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"wtCodeCODTO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"totaleRitenute":0,"contribintRIC":0,"provvnonsogRIC":0,"imponibileraRIC":0,"importoraRIC":0,"enasaziendaRIC":0,"rimborsiRIC":0,"franchigiaRIC":0,"imponibilerpRIC":0,"contcdittaRIC":0,"contcpercRIC":0,"importoalritRIC":0,"residuoDaPagare":0}],"vatTotals":[{"codiceIVA":"string","totaleImponibile":0,"totaleImposta":0,"totaleImpostaNonDet":0,"totaleImponibileVal":0,"totaleImpostaVal":0,"totaleImpostaNonDetVal":0}],"instalmentsToPay":[{"idInstalment":0,"entryReference":{"idCliFor":0,"idConto":0,"annoPart":0,"numeroPart":0,"sezionalePart":"string","bisPart":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"numRigaCont":0,"importoPagato":0,"importoAbbuono":0,"numeroAssegno":"string","riferimentiAssegno":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"manageWithholdingTax":true,"withholdingTaxData":{"importoAltreRitenute":0,"importoEnasarcoAzienda":0},"instalmentsPairing":{"pairingMode":0,"instalments":[{"numInstalment":0,"idInstalmentToPair":0,"pairedAmount":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"outTransactionNumbering":true,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"externalModule":"string","numDocAlreadyExistsAsError":true,"forceAssignedNumReg":true,"viewWarnings":true,"warningsToByPass":[0],"recoverReverseChargeIfNotDefined":true,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"idWorkflowProcess":"string","environment":"string","module":"string","job":"string","priority":0,"runSync":true,"detailLifeHours":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}; // CreateMultiGLEntryJobParamsDTO | List of entries to insert 
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIMultiplecreatejobPost(environment, authorizationScope, createMultiGLEntryJobParamsDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **createMultiGLEntryJobParamsDTO** | [**CreateMultiGLEntryJobParamsDTO**](CreateMultiGLEntryJobParamsDTO.md)| List of entries to insert  | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**CreateMultiGLEntryJobResultDTO**](CreateMultiGLEntryJobResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIPaymentwithholdingtaxesaccountingPost

> PaymentWithholdingTaxesAccountingResultDTO apiV1EnvironmentFIGLEntryFIPaymentwithholdingtaxesaccountingPost(environment, authorizationScope, paymentWithholdingTaxesAccountingParametersDTO, opts)

Payment withholding taxes accounting

Payment withholding taxes accounting

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let paymentWithholdingTaxesAccountingParametersDTO = new TseCloudFi.PaymentWithholdingTaxesAccountingParametersDTO(); // PaymentWithholdingTaxesAccountingParametersDTO | Object that contains all the parameters necessary for the payment withholding taxes accounting
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIPaymentwithholdingtaxesaccountingPost(environment, authorizationScope, paymentWithholdingTaxesAccountingParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **paymentWithholdingTaxesAccountingParametersDTO** | [**PaymentWithholdingTaxesAccountingParametersDTO**](PaymentWithholdingTaxesAccountingParametersDTO.md)| Object that contains all the parameters necessary for the payment withholding taxes accounting | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**PaymentWithholdingTaxesAccountingResultDTO**](PaymentWithholdingTaxesAccountingResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIPlafondinfoPost

> PlafondInfoResultDTO apiV1EnvironmentFIGLEntryFIPlafondinfoPost(environment, authorizationScope, plafondInfoDTO, opts)

Reading of the ceiling management indicator

Retrieves the ceiling management indicator

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let plafondInfoDTO = new TseCloudFi.PlafondInfoDTO(); // PlafondInfoDTO | Parameters relating to the selected entry
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIPlafondinfoPost(environment, authorizationScope, plafondInfoDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **plafondInfoDTO** | [**PlafondInfoDTO**](PlafondInfoDTO.md)| Parameters relating to the selected entry | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**PlafondInfoResultDTO**](PlafondInfoResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIPost

> GLEntryFIDTO apiV1EnvironmentFIGLEntryFIPost(environment, authorizationScope, gLEntryFIDTO, opts)

Create

Creating new object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let gLEntryFIDTO = {"stageGuid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","canUpdate":true,"cambio":0,"causcollnumreg":"string","codiceCg33":"string","datacambio":"2024-11-15T13:23:29.067Z","datacomp":"2024-11-15T13:23:29.067Z","datacons":"2024-11-15T13:23:29.067Z","datadoc":"2024-11-15T13:23:29.067Z","datadocrifnotevar":"2024-11-15T13:23:29.067Z","dataprecons":"2024-11-15T13:23:29.067Z","datarateo":"2024-11-15T13:23:29.067Z","datarateop":"2024-11-15T13:23:29.067Z","datareg":"2024-11-15T13:23:29.067Z","dataregiva":"2024-11-15T13:23:29.067Z","descausale":"string","descragg":"string","dittaCg18":0,"flgDelete":0,"flgDocbis":0,"flgDocriep":0,"flgDocsemplif":0,"flgIntra":0,"flgMentry":0,"flgSegnoiva":0,"flgStpgior":0,"flgStpiva":0,"flgStptotiva":0,"flgTurismo":0,"hubid":"string","id":0,"idCo1a":0,"idMg28":"string","idsdi":"string","imparrot":0,"imparrotval":0,"imparrotval2":0,"imptotale":0,"imptotaleval":0,"imptotaleval2":0,"indElenchimov3000":0,"indExp":0,"indModdiffcambio":0,"indModpn":0,"indMovgruppo":0,"indNollis":0,"indProvreg":0,"indTipodoc":0,"indTipoifrs":0,"indTipomov":0,"indTiporeg":0,"lastchange":"2024-11-15T13:23:29.067Z","numdoc":0,"numdocorig":"string","numpart":0,"numreg":"string","parentCodiceCgc0":0,"progEserCg19":0,"selfInvoiceProtocol":0,"selfInvoiceSectional":"string","sezionale":"string","tipodoc":0,"tipodocfe":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"accountingYearCO":{"anno":0,"dataape":"2024-11-15T13:23:29.067Z","datachiu":"2024-11-15T13:23:29.067Z","dittaCg18":0,"flgAdecbatt":0,"flgAdecbcli":0,"flgAdecbfor":0,"flgAdecbpas":0,"flgEserchiuso":0,"flgEsercor":0,"flgGencesp":0,"flgGenratei":0,"flgGenrisc":0,"id":0,"progEser":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.067Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"customerSupplierCO":{"gmdUpdateAdditionalParams":{"codice":0,"ragSoAnag":"string","indirizzo":"string","numCiv":"string","cap":"string","citta":"string","prov":"string","codiceCg07":0,"partiva":"string","codFiscale":"string","tel1Num":"string","fax":"string","tipologia":"string","codLegCg01":"string","descrCg07":"string","nationIso":"string"},"clifor":0,"codAbiCg12":0,"codCabCg13":0,"codiceCg28":"string","contoCg24":"string","contorCg24":"string","contratto":"string","datavaliva":"2024-11-15T13:23:29.067Z","dittaCg18":0,"flgArt62":0,"flgAttivo":1,"flgCointestati":0,"flgIntercompany":0,"ggscadfix":0,"gruppoCg10":0,"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","idclifor":0,"idmediaCg99":0,"indElenchimov3000":99,"intermedioCg40":0,"lastchange":"2024-11-15T13:23:29.067Z","progREf08":0,"tipocf":0,"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"agentCO":{"agente":"string","anagenCg16":0,"datafineman":"2024-11-15T13:23:29.067Z","datainman":"2024-11-15T13:23:29.067Z","datainrapp":"2024-11-15T13:23:29.067Z","dittaCg18":0,"flgAdegdelta":0,"flgAdeguamscmag":0,"flgRegimeart":0,"flgRegimecl":0,"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","idagente":0,"idcapoareaMg17":0,"idcapozonaMg17":0,"idmediaCg99":0,"indBaseimpmag":0,"indBaseimpsc":0,"indCalcscmag":0,"indPrefstdoc":0,"indStdistenas":0,"indTipoage":0,"indTipoliq":0,"perprov":0,"regimeprov":0,"tipomand":0,"tiporappor":1,"tiposoc":0,"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"dmsPublishedEntityFW":{"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","tipoarchHm30":0,"idknos":0,"dittaCg18":0,"protocollo":"string","flgInvalid":0,"percorso":"string","nome":"string","datapub":"2024-11-15T13:23:29.067Z","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"generalMasterDataCO":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:23:29.067Z","datavalid":"2024-11-15T13:23:29.067Z","dtfinepec":"2024-11-15T13:23:29.067Z","dtiniziopec":"2024-11-15T13:23:29.067Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:23:29.067Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:23:29.067Z","datamod":"2024-11-15T13:23:29.067Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.067Z","datafinblacklist":"2024-11-15T13:23:29.067Z","datainiblacklist":"2024-11-15T13:23:29.067Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.067Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.067Z","datafinblacklist":"2024-11-15T13:23:29.067Z","datainiblacklist":"2024-11-15T13:23:29.067Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.067Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"blackListGeneralMasterData":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:23:29.067Z","datavalid":"2024-11-15T13:23:29.067Z","dtfinepec":"2024-11-15T13:23:29.067Z","dtiniziopec":"2024-11-15T13:23:29.067Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:23:29.067Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:23:29.068Z","datamod":"2024-11-15T13:23:29.068Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.068Z","datafinblacklist":"2024-11-15T13:23:29.068Z","datainiblacklist":"2024-11-15T13:23:29.068Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.068Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.068Z","datafinblacklist":"2024-11-15T13:23:29.068Z","datainiblacklist":"2024-11-15T13:23:29.068Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.068Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"csAccountingIndexCO":{"codCat":"string","descr":"string","dittaCg18":0,"tipocfCg44":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"csBankCO":[{"bban":"string","bicbancaestera":"string","ccaddetto":"string","ccdesagenz":"string","ccforn":"string","ccfornfactor":0,"ccfornfactoridCg44":0,"ccggval":0,"cliforCg44":0,"codiceCg07":0,"dittaCg18":0,"flgPref":0,"flgPrefIncassi":0,"iban":"string","id":0,"idbancaestera":"string","idcontratto":"string","idsuccursale":0,"indTipoop":0,"locbancaestera":"string","nomebancaestera":"string","progR":0,"tipobanca":0,"tipocfCg44":0,"agencyCO":{"codBanca":0,"codice":0,"descrizione":"string","localita":"string","prov":"string","bankCO":{"codBicswift":"string","codiceBanca":0,"descrizione":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"customerSupplierCO":"string","nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.068Z","datafinblacklist":"2024-11-15T13:23:29.068Z","datainiblacklist":"2024-11-15T13:23:29.068Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.068Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"csCompanyBankCO":[{"cliforCg44":0,"dittaCg18":0,"flgPref":0,"id":0,"progR":0,"progREf08":0,"rowversion":"string","tipocfCg44":0,"companyBankCO":{"aprogressmav":0,"bancaCg12":0,"bbananticipi":"string","bbanconto":"string","bbaneffpresef":"string","bbanordpbonif":"string","bicbanca":"string","cabbonifCg13":0,"cabcontoCg13":0,"cabmavCg13":0,"cabribaCg13":0,"cabridCg13":0,"ccanticipi":"string","ccconto":"string","cceffpresef":"string","ccordpbonif":"string","codAzienda":"string","codiceCg07":0,"codicecuc":"string","codRappopor":"string","codSia":"string","creditidentifier":"string","daprogressmav":0,"descr":"string","dittaCg18":0,"flgAutattribnrmav":0,"flgCambiali":0,"flgCessioni":0,"flgMav":0,"flgPref":0,"flgRiba":0,"flgRibacamb":0,"flgRibacess":0,"flgRibaricba":0,"flgRibatratac":0,"flgRibatratte":0,"flgRidsdd":0,"flgRidsddraggr":0,"flgScfatt":0,"flgTratte":0,"ggvalcambalt":0,"ggvalcambfil":0,"ggvalmavincalt":0,"ggvalmavincfil":0,"ggvalmavincpos":0,"ggvalmavsbf":0,"ggvalribaalt":0,"ggvalribafil":0,"ggvalridalt":0,"ggvalridfil":0,"ggvalscfattalt":0,"ggvalscfattfil":0,"ggvaltratalt":0,"ggvaltratfil":0,"ibananticipi":"string","ibanconto":"string","ibaneffpresef":"string","ibanordpbonif":"string","id":0,"idbancaestera":"string","idcontratto":"string","idmediaCg99":0,"idsuccursale":0,"impcastel":0,"impfido":0,"indCheckpivacf":0,"indCompind":0,"indContpmtinf":0,"indPresmav":1,"indPresriba":1,"indPresrid":1,"indTipolib":1,"indTipopres":0,"locbancaestera":"string","maxgginsoluti":0,"prefissoattribmav":0,"progR":0,"rowversion":"string","scfindbasecalc":1,"scfnsdocrif":"string","scfpercpres":0,"scfperctasso":0,"scfvsdocrif":"string","spcommbonalt":0,"spcommbonfil":0,"spcommordpalt":0,"spcommordpfil":0,"spinccambalt":0,"spinccambfil":0,"spinccoralt":0,"spinccorfil":0,"spincesitopag":0,"spincmavincalt":0,"spincmavincfil":0,"spincmavincpos":0,"spincmavsbf":0,"spincribaalt":0,"spincribafil":0,"spincridalt":0,"spincridfil":0,"spinctraalt":0,"spinctrafil":0,"sppresdistinta":0,"spritcamb":0,"spritcambcl":0,"spritmavincas":0,"spritmavincascl":0,"spritmavsbf":0,"spritmavsbfcl":0,"spritriba":0,"spritribacl":0,"spritrid":0,"spritridcl":0,"sprittratte":0,"sprittrattecl":0,"tipobanca":0,"ultprogressmav":0,"bankCO":{"codBicswift":"string","codiceBanca":0,"descrizione":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.068Z","datafinblacklist":"2024-11-15T13:23:29.068Z","datainiblacklist":"2024-11-15T13:23:29.068Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.068Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"csInfoCO":{"area":"string","areanielsenMg0e":"string","bacsaccountno":0,"categ":"string","cliforCg44":0,"codIclfatt":0,"codLivbloc":"string","codRifalf":"string","codRifnum":0,"codRischioMg2a":"string","datablocco":"2024-11-15T13:23:29.068Z","datacreaz":"2024-11-15T13:23:29.068Z","datadismis":"2024-11-15T13:23:29.068Z","datarischio":"2024-11-15T13:23:29.068Z","dataultvar":"2024-11-15T13:23:29.068Z","dittaCg18":0,"fidoaziendale":0,"fidofactoring":0,"fidolivello1":0,"fidolivello2":0,"finchargerterms":"string","flgEstrpayline":0,"flgSpbol":0,"flgSpeinc":0,"flgTaxliable":0,"idmediaCg99":0,"indClibloc":0,"indGesfido":0,"indrottcig":0,"indSpesecum":0,"irs1099":"string","lastchange":"2024-11-15T13:23:29.068Z","linguaMg52":"string","macroarea":"string","macrocat":"string","notebloc":"string","raggcrf3":"string","raggrcf1":"string","raggrcf2":"string","regimeiva":"string","reminderterms":"string","scaglspbanc":0,"sottocat":"string","taxareaNv01":"string","taxexemptionno":"string","tipocfCg44":0,"typeofsupply":"string","zona":"string","areaCO":{"codiceAreaMG":"string","descrarea":"string","dittaCg18":0,"idprov":0,"macroareaMg07":"string","tipocfMg07":0,"zone":[{"areaMg08":"string","codiceZona":"string","descrzona":"string","dittaCg18":0,"idprov":0,"macroareaMg08":"string","tipocfMg08":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"categoryCO":{"categ":"string","descrcat":"string","dittaCg18":0,"macrocatMg10":"string","tipocfMg10":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"grouping1CO":{"codRaggrcf1":"string","descraggrcf1":"string","dittaCg18":0,"idmediaCg99":0,"idprov":0,"tipocf":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"grouping2CO":{"codRaggrcf2":"string","descraggrcf2":"string","dittaCg18":0,"idmediaCg99":0,"idprov":0,"tipocf":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"grouping3CO":{"codRaggrcf3":"string","descraggrcf3":"string","dittaCg18":0,"idmediaCg99":0,"idprov":0,"tipocf":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"macroAreaCO":{"codiceMacroarea":"string","descrmacroar":"string","dittaCg18":0,"idprov":0,"tipocf":0,"areas":[{"codiceAreaMG":"string","descrarea":"string","dittaCg18":0,"idprov":0,"macroareaMg07":"string","tipocfMg07":0,"zone":[{"areaMg08":"string","codiceZona":"string","descrzona":"string","dittaCg18":0,"idprov":0,"macroareaMg08":"string","tipocfMg08":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"macroCategoryCO":{"descrmacrocat":"string","dittaCg18":0,"macrocat":"string","tipocf":0,"categorie":[{"categ":"string","descrcat":"string","dittaCg18":0,"macrocatMg10":"string","tipocfMg10":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"subCategoryCO":{"categMg11":"string","descrsottocat":"string","dittaCg18":0,"macrocatMg11":"string","sottcat":"string","tipocfMg11":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"zoneCO":{"areaMg08":"string","codiceZona":"string","descrzona":"string","dittaCg18":0,"idprov":0,"macroareaMg08":"string","tipocfMg08":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"csJointlyHeldCO":[{"cliforCg44":0,"cliforcoCg44":0,"dittaCg18":0,"idcliforcoCg44":0,"percentuale":0,"tipocfCg44":0,"customerSupplierCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"csPaymentRangeCO":[{"aimpdoc":0,"cliforCg44":0,"codPagCg62":"string","codScagl":0,"dittaCg18":0,"id":0,"idCg62":0,"idmediaCg99":0,"indPagpart":0,"tipocfCg44":0,"valutaCg08":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.068Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"paymentTermCO":{"codPag":"string","descPag":"string","desPagAnal":"string","flgDesc":0,"flgDisgg":0,"flgPrefatt":0,"flgPrefpass":0,"flgStornoiva":0,"id":0,"rowversion":"string","scart26":0,"scpercart26":0,"scpercas":0,"scpermer1":0,"scpermer2":0,"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"paymentTermDetailCO":[{"aggfix1":0,"aggfix2":0,"codPagCg62":"string","daggfix1":0,"daggfix2":0,"el1frimp":0,"el1friva":0,"el2frimp":0,"el2friva":0,"flgFrpercimp":1,"flgFrperciva":1,"ggdecor":0,"ggmmfix":0,"ggscadfix1":0,"ggscadfix2":0,"id":0,"idCg62":0,"idCg64":0,"imporfix":0,"indDatarif":0,"indImpfix":0,"indTipocalend":0,"indTipodecor":1,"percimp":0,"perciva":0,"prog":0,"rowversion":"string","tipoeff":9,"subTypeCO":{"codiceCg07":0,"codPaguc":"string","codStipoeff":0,"descstipo":"string","flgAssegno":0,"ggoffset":0,"id":0,"indModfatturapa":0,"rowversion":"string","tipoeff":0,"foreignPaymentCodeCO":{"codice":"string","codIso":"string","descrpag":"string","flgIbanobbl":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.068Z","datafinblacklist":"2024-11-15T13:23:29.068Z","datainiblacklist":"2024-11-15T13:23:29.068Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.068Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"csPostponementPeriodCO":[{"ammgg":0,"cliforCg44":0,"dammgg":0,"dittaCg18":0,"ggmmfixslit":0,"ggslsucc":0,"id":0,"idmediaCg99":0,"indAppggfix":0,"indTiposlit":1,"tipocfCg44":0,"tipoeff":9,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"csSddCO":[{"bancaallineam":0,"causrich":0,"causrisp":0,"cfiscsottoscr":"string","cliforCg44":0,"codAutoriz":"string","codBicswift":"string","codClideb":"string","codClidebprec":"string","codIndiv":0,"codIndivprec":0,"codRif":"string","contocorr":"string","contocorrprec":"string","datamandato":"2024-11-15T13:23:29.068Z","dataprimascad":"2024-11-15T13:23:29.068Z","datarich":"2024-11-15T13:23:29.068Z","datarisp":"2024-11-15T13:23:29.068Z","dataultimascad":"2024-11-15T13:23:29.068Z","descrizione":"string","diniego":0,"dittaCg18":0,"flgAllineam":0,"flgDisattivato":0,"flgVariato":0,"id":0,"idmediaCg99":0,"impmaxrata":0,"indIrsottoscr":"string","indStorno":0,"indStornoprec":0,"indTipoinc":0,"indTiposdd":0,"locsottoscr":"string","nrrate":0,"nuovabanca":0,"progR":0,"ragsosottoscr":"string","ridabi":0,"ridabiprec":0,"ridcab":0,"ridcabprec":0,"ridiban":"string","ridibanprec":"string","soggtitibanCg16":0,"tipocfCg44":0,"tipoinclocked":0,"tipologia":1,"tipologiaprec":0,"csHistorySddCO":[{"codBicswift":"string","codClideb":"string","codIndiv":0,"datavar":"2024-11-15T13:23:29.069Z","id":0,"indStorno":0,"indTipoinc":0,"indTiposdd":0,"ridiban":"string","soggtitibanCg16":0,"tipologia":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.069Z","datafinblacklist":"2024-11-15T13:23:29.069Z","datainiblacklist":"2024-11-15T13:23:29.069Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.069Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"soggtitiban":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:23:29.069Z","datavalid":"2024-11-15T13:23:29.069Z","dtfinepec":"2024-11-15T13:23:29.069Z","dtiniziopec":"2024-11-15T13:23:29.069Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:23:29.069Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:23:29.069Z","datamod":"2024-11-15T13:23:29.069Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.069Z","datafinblacklist":"2024-11-15T13:23:29.069Z","datainiblacklist":"2024-11-15T13:23:29.069Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.069Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.069Z","datafinblacklist":"2024-11-15T13:23:29.069Z","datainiblacklist":"2024-11-15T13:23:29.069Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.069Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.069Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"customerSupplierCIGCUPCO":[{"cliforCg44":0,"dittaCg18":0,"id":0,"idcigcupCo1h":0,"progREf08":0,"progRMg35":0,"rowversion":"string","tipocfCg44":0,"cigcuPcode":{"cig":"string","cup":"string","descrizione":"string","docrifData":"2024-11-15T13:23:29.069Z","docrifId":"string","flgAttivo":0,"id":0,"indTipocontr":0,"indTipodocrif":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"companyBank":{"aprogressmav":0,"bancaCg12":0,"bbananticipi":"string","bbanconto":"string","bbaneffpresef":"string","bbanordpbonif":"string","bicbanca":"string","cabbonifCg13":0,"cabcontoCg13":0,"cabmavCg13":0,"cabribaCg13":0,"cabridCg13":0,"ccanticipi":"string","ccconto":"string","cceffpresef":"string","ccordpbonif":"string","codAzienda":"string","codiceCg07":0,"codicecuc":"string","codRappopor":"string","codSia":"string","creditidentifier":"string","daprogressmav":0,"descr":"string","dittaCg18":0,"flgAutattribnrmav":0,"flgCambiali":0,"flgCessioni":0,"flgMav":0,"flgPref":0,"flgRiba":0,"flgRibacamb":0,"flgRibacess":0,"flgRibaricba":0,"flgRibatratac":0,"flgRibatratte":0,"flgRidsdd":0,"flgRidsddraggr":0,"flgScfatt":0,"flgTratte":0,"ggvalcambalt":0,"ggvalcambfil":0,"ggvalmavincalt":0,"ggvalmavincfil":0,"ggvalmavincpos":0,"ggvalmavsbf":0,"ggvalribaalt":0,"ggvalribafil":0,"ggvalridalt":0,"ggvalridfil":0,"ggvalscfattalt":0,"ggvalscfattfil":0,"ggvaltratalt":0,"ggvaltratfil":0,"ibananticipi":"string","ibanconto":"string","ibaneffpresef":"string","ibanordpbonif":"string","id":0,"idbancaestera":"string","idcontratto":"string","idmediaCg99":0,"idsuccursale":0,"impcastel":0,"impfido":0,"indCheckpivacf":0,"indCompind":0,"indContpmtinf":0,"indPresmav":1,"indPresriba":1,"indPresrid":1,"indTipolib":1,"indTipopres":0,"locbancaestera":"string","maxgginsoluti":0,"prefissoattribmav":0,"progR":0,"rowversion":"string","scfindbasecalc":1,"scfnsdocrif":"string","scfpercpres":0,"scfperctasso":0,"scfvsdocrif":"string","spcommbonalt":0,"spcommbonfil":0,"spcommordpalt":0,"spcommordpfil":0,"spinccambalt":0,"spinccambfil":0,"spinccoralt":0,"spinccorfil":0,"spincesitopag":0,"spincmavincalt":0,"spincmavincfil":0,"spincmavincpos":0,"spincmavsbf":0,"spincribaalt":0,"spincribafil":0,"spincridalt":0,"spincridfil":0,"spinctraalt":0,"spinctrafil":0,"sppresdistinta":0,"spritcamb":0,"spritcambcl":0,"spritmavincas":0,"spritmavincascl":0,"spritmavsbf":0,"spritmavsbfcl":0,"spritriba":0,"spritribacl":0,"spritrid":0,"spritridcl":0,"sprittratte":0,"sprittrattecl":0,"tipobanca":0,"ultprogressmav":0,"bankCO":{"codBicswift":"string","codiceBanca":0,"descrizione":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.069Z","datafinblacklist":"2024-11-15T13:23:29.069Z","datainiblacklist":"2024-11-15T13:23:29.069Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.069Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"csBankCO":{"bban":"string","bicbancaestera":"string","ccaddetto":"string","ccdesagenz":"string","ccforn":"string","ccfornfactor":0,"ccfornfactoridCg44":0,"ccggval":0,"cliforCg44":0,"codiceCg07":0,"dittaCg18":0,"flgPref":0,"flgPrefIncassi":0,"iban":"string","id":0,"idbancaestera":"string","idcontratto":"string","idsuccursale":0,"indTipoop":0,"locbancaestera":"string","nomebancaestera":"string","progR":0,"tipobanca":0,"tipocfCg44":0,"agencyCO":{"codBanca":0,"codice":0,"descrizione":"string","localita":"string","prov":"string","bankCO":{"codBicswift":"string","codiceBanca":0,"descrizione":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"customerSupplierCO":"string","nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.069Z","datafinblacklist":"2024-11-15T13:23:29.069Z","datainiblacklist":"2024-11-15T13:23:29.069Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.069Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"custSupplDataInvoicePACO":{"codiceCg16":0,"emailcortesia":"string","flgAsw":0,"indTypeb2b":0,"tipocfCg44":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"dmsPublishedEntityFW":{"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","tipoarchHm30":0,"idknos":0,"dittaCg18":0,"protocollo":"string","flgInvalid":0,"percorso":"string","nome":"string","datapub":"2024-11-15T13:23:29.069Z","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"generalMasterDataCO":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:23:29.069Z","datavalid":"2024-11-15T13:23:29.069Z","dtfinepec":"2024-11-15T13:23:29.069Z","dtiniziopec":"2024-11-15T13:23:29.069Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:23:29.069Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:23:29.069Z","datamod":"2024-11-15T13:23:29.069Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.069Z","datafinblacklist":"2024-11-15T13:23:29.069Z","datainiblacklist":"2024-11-15T13:23:29.069Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.069Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.070Z","datafinblacklist":"2024-11-15T13:23:29.070Z","datainiblacklist":"2024-11-15T13:23:29.070Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.070Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"officeCO":{"cap":"string","citta":"string","codice":0,"dittaCg18":0,"idmediaCg99":0,"indDimcentrocomm":0,"indIrizzo":"string","numerorea":"string","progRea":0,"prov":"string","rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"officePACO":[{"cap":"string","codDestin":"string","codice":"string","codiceCg16":0,"comune":"string","flgPreferenziale":0,"idprovincia":0,"idregione":0,"indIrizzo":"string","indTypeb2b":0,"lastupdateB2b":"2024-11-15T13:23:29.070Z","nome":"string","tipocfCg44":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"paymentTermCO":{"codPag":"string","descPag":"string","desPagAnal":"string","flgDesc":0,"flgDisgg":0,"flgPrefatt":0,"flgPrefpass":0,"flgStornoiva":0,"id":0,"rowversion":"string","scart26":0,"scpercart26":0,"scpercas":0,"scpermer1":0,"scpermer2":0,"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"paymentTermDetailCO":[{"aggfix1":0,"aggfix2":0,"codPagCg62":"string","daggfix1":0,"daggfix2":0,"el1frimp":0,"el1friva":0,"el2frimp":0,"el2friva":0,"flgFrpercimp":1,"flgFrperciva":1,"ggdecor":0,"ggmmfix":0,"ggscadfix1":0,"ggscadfix2":0,"id":0,"idCg62":0,"idCg64":0,"imporfix":0,"indDatarif":0,"indImpfix":0,"indTipocalend":0,"indTipodecor":1,"percimp":0,"perciva":0,"prog":0,"rowversion":"string","tipoeff":9,"subTypeCO":{"codiceCg07":0,"codPaguc":"string","codStipoeff":0,"descstipo":"string","flgAssegno":0,"ggoffset":0,"id":0,"indModfatturapa":0,"rowversion":"string","tipoeff":0,"foreignPaymentCodeCO":{"codice":"string","codIso":"string","descrpag":"string","flgIbanobbl":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.070Z","datafinblacklist":"2024-11-15T13:23:29.070Z","datainiblacklist":"2024-11-15T13:23:29.070Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.070Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCO":{"aliqivavent":0,"annotazioni":"string","codice":"string","codiceagr":"string","codiceOss":"string","codPlafond":0,"descrizione":"string","flgAgri":0,"flgAllclifor":0,"flgAssport398":0,"flgAutoue":0,"flgCorrVent":0,"flgEscludiblacklist":0,"flgImpostadibollo":0,"flgIndet":0,"flgIvaedit":0,"flgMonofasersm":0,"flgMossgest":0,"flgMossrid":0,"flgNotvar":0,"flgSospimp":0,"idprov":0,"impostamonofasersm":0,"indNatassoswCg2n":0,"indNatura":0,"indStaper":0,"indtipopart":0,"mosscodCg07":0,"mossperc":0,"note":"string","percforf":0,"percindet":0,"perciva":0,"percmonofasersm":0,"rowVersion":"string","tipologia":1,"verslynfa":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.070Z","datafinblacklist":"2024-11-15T13:23:29.070Z","datainiblacklist":"2024-11-15T13:23:29.070Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.070Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureAssCO":{"codice":"string","datafineval":"2024-11-15T13:23:29.070Z","datainival":"2024-11-15T13:23:29.070Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureEsCO":{"codice":"string","datafineval":"2024-11-15T13:23:29.070Z","datainival":"2024-11-15T13:23:29.070Z","descr":"string","id":0,"rowversion":"string","natureAssCO":[{"codice":"string","datafineval":"2024-11-15T13:23:29.070Z","datainival":"2024-11-15T13:23:29.070Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCOAgr":"string","vatCodeCOOss":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"dmsPublishedEntityFW":{"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","tipoarchHm30":0,"idknos":0,"dittaCg18":0,"protocollo":"string","flgInvalid":0,"percorso":"string","nome":"string","datapub":"2024-11-15T13:23:29.070Z","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"estabilshedOrganization":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:23:29.070Z","datavalid":"2024-11-15T13:23:29.070Z","dtfinepec":"2024-11-15T13:23:29.070Z","dtiniziopec":"2024-11-15T13:23:29.070Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:23:29.070Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:23:29.070Z","datamod":"2024-11-15T13:23:29.070Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.070Z","datafinblacklist":"2024-11-15T13:23:29.070Z","datainiblacklist":"2024-11-15T13:23:29.070Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.070Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.070Z","datafinblacklist":"2024-11-15T13:23:29.070Z","datainiblacklist":"2024-11-15T13:23:29.070Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.070Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"fiscalRepresentative":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:23:29.070Z","datavalid":"2024-11-15T13:23:29.070Z","dtfinepec":"2024-11-15T13:23:29.070Z","dtiniziopec":"2024-11-15T13:23:29.070Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:23:29.070Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:23:29.070Z","datamod":"2024-11-15T13:23:29.070Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.070Z","datafinblacklist":"2024-11-15T13:23:29.070Z","datainiblacklist":"2024-11-15T13:23:29.070Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.070Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.071Z","datafinblacklist":"2024-11-15T13:23:29.071Z","datainiblacklist":"2024-11-15T13:23:29.071Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.071Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"generalMasterDataCOBlackList":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:23:29.071Z","datavalid":"2024-11-15T13:23:29.071Z","dtfinepec":"2024-11-15T13:23:29.071Z","dtiniziopec":"2024-11-15T13:23:29.071Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:23:29.071Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:23:29.071Z","datamod":"2024-11-15T13:23:29.071Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.071Z","datafinblacklist":"2024-11-15T13:23:29.071Z","datainiblacklist":"2024-11-15T13:23:29.071Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.071Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.071Z","datafinblacklist":"2024-11-15T13:23:29.071Z","datainiblacklist":"2024-11-15T13:23:29.071Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.071Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"generalMasterDataCODirectID":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:23:29.071Z","datavalid":"2024-11-15T13:23:29.071Z","dtfinepec":"2024-11-15T13:23:29.071Z","dtiniziopec":"2024-11-15T13:23:29.071Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:23:29.071Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:23:29.071Z","datamod":"2024-11-15T13:23:29.071Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.071Z","datafinblacklist":"2024-11-15T13:23:29.071Z","datainiblacklist":"2024-11-15T13:23:29.071Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.071Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.071Z","datafinblacklist":"2024-11-15T13:23:29.071Z","datainiblacklist":"2024-11-15T13:23:29.071Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.071Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"glEntryDetailFI":[{"debitAmount":0,"creditAmount":0,"glvatDetailFI":{"causaleiva":0,"dittaCg18":0,"flgDeducibile":0,"flgTsescluso":0,"flgTsinviato":0,"id":0,"idCg41":0,"idcontoCg24":0,"imponibile":0,"imponibileval":0,"imposta":0,"impostand":0,"impostandval":0,"impostaval":0,"indDetriva":0,"indIvaacqagric":0,"indNatura":0,"indProrata":0,"indTipo":0,"indTstipoop":0,"indTstiposp":0,"indTsvocesp":0,"numrigaiva":0,"percdetr":0,"percforf":0,"tsdatadocori":"2024-11-15T13:23:29.071Z","tsdocorigine":"string","coaAccountFI":{"accountType":0,"alias":"string","codeformatted":"string","codiceCg22":0,"codiceCgc0":0,"cogeprogeAbil":0,"cogeprogeAttivita":0,"cogeprogeMateriali":0,"cogeprogeNodo":0,"cogeprogeSpese":0,"conto":"string","contoape":"string","contochiu":"string","contocrsosp":"string","contoratatt":"string","contoratpass":"string","contorisatt":"string","contorispass":"string","descr":"string","flgAggfatt":0,"flgAnalit":0,"flgBilconsattpassdist":0,"flgContoimm":0,"flgGesec":0,"flgGespor":0,"flgIntercompany":0,"flgOpnonfin":0,"flgRaganal":0,"flgRarp":0,"flgSaldog":0,"flgValutaest":0,"gruppoCg10":0,"idconto":0,"idcontoapeCg24":0,"idcontochiuCg24":0,"idcontoratattCg24":0,"idcontoratpassCg24":0,"idcontorisattCg24":0,"idcontorispassCg24":0,"idparent":0,"idreverse":0,"idRifPdC80":0,"indAttpasspor":0,"indContoricav":0,"indCosvend":0,"indDaav":0,"indDaavec":0,"indLivchius":0,"indMastroCliFor":99,"indTipoconto":0,"percindeduc":0,"percindetra":0,"suddconti":0,"coaAccountCustomizationFI":[{"contoCg24":"string","descr":"string","dittaCg18":0,"gruppoCg10":0,"idCg24":0,"iddespcon":0,"idmediaCg99":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"coaAccountFIApe":"string","coaAccountFIChiu":"string","coaAccountFIParent":"string","coaAccountFIRatatt":"string","coaAccountFIRatpass":"string","coaAccountFIRisatt":"string","coaAccountFIRispass":"string","coaAccountStateFI":[{"consosCg24":"string","dittaCg18":0,"dtconsos":"2024-11-15T13:23:29.071Z","dtdisatt":"2024-11-15T13:23:29.071Z","flgDisatt":0,"grusosCg10":0,"idCg24":0,"idstatipdc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"coaGroupCodeFI":{"descr":"string","flgPdclib":0,"gruppo":0,"maskedit":"string","numlivcons":0,"numlivelli":0,"rowversion":"string","accountProposals":[{"codice":0,"contoCg24":"string","gruppoCg10":0,"id":0,"idCg24":0,"rowversion":"string","coaAccountFI":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"coaInternationalCustomizationFI":[{"categoria":0,"contoCg24":"string","esModulo347":0,"gbDeferralcode":"string","gruppoCg10":0,"id":0,"idCg24":0,"iso3166A2":"string","rowversion":"string","subcategoria":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"reverseTypeFI":{"reverseTypeCode":0,"reverseTypeDescription":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatTypeFI":{"agviaggio":0,"codice":0,"codiceCg0d":0,"descr":"string","indAutofattura":0,"indTipo":0,"localizzazione":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"reverseTypeFI":{"reverseTypeCode":0,"reverseTypeDescription":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCO":{"aliqivavent":0,"annotazioni":"string","codice":"string","codiceagr":"string","codiceOss":"string","codPlafond":0,"descrizione":"string","flgAgri":0,"flgAllclifor":0,"flgAssport398":0,"flgAutoue":0,"flgCorrVent":0,"flgEscludiblacklist":0,"flgImpostadibollo":0,"flgIndet":0,"flgIvaedit":0,"flgMonofasersm":0,"flgMossgest":0,"flgMossrid":0,"flgNotvar":0,"flgSospimp":0,"idprov":0,"impostamonofasersm":0,"indNatassoswCg2n":0,"indNatura":0,"indStaper":0,"indtipopart":0,"mosscodCg07":0,"mossperc":0,"note":"string","percforf":0,"percindet":0,"perciva":0,"percmonofasersm":0,"rowVersion":"string","tipologia":1,"verslynfa":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.071Z","datafinblacklist":"2024-11-15T13:23:29.071Z","datainiblacklist":"2024-11-15T13:23:29.071Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.071Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureAssCO":{"codice":"string","datafineval":"2024-11-15T13:23:29.072Z","datainival":"2024-11-15T13:23:29.072Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureEsCO":{"codice":"string","datafineval":"2024-11-15T13:23:29.072Z","datainival":"2024-11-15T13:23:29.072Z","descr":"string","id":0,"rowversion":"string","natureAssCO":[{"codice":"string","datafineval":"2024-11-15T13:23:29.072Z","datainival":"2024-11-15T13:23:29.072Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCOAgr":"string","vatCodeCOOss":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCompensationCO":{"aliqivavent":0,"annotazioni":"string","codice":"string","codiceagr":"string","codiceOss":"string","codPlafond":0,"descrizione":"string","flgAgri":0,"flgAllclifor":0,"flgAssport398":0,"flgAutoue":0,"flgCorrVent":0,"flgEscludiblacklist":0,"flgImpostadibollo":0,"flgIndet":0,"flgIvaedit":0,"flgMonofasersm":0,"flgMossgest":0,"flgMossrid":0,"flgNotvar":0,"flgSospimp":0,"idprov":0,"impostamonofasersm":0,"indNatassoswCg2n":0,"indNatura":0,"indStaper":0,"indtipopart":0,"mosscodCg07":0,"mossperc":0,"note":"string","percforf":0,"percindet":0,"perciva":0,"percmonofasersm":0,"rowVersion":"string","tipologia":1,"verslynfa":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.072Z","datafinblacklist":"2024-11-15T13:23:29.072Z","datainiblacklist":"2024-11-15T13:23:29.072Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.072Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureAssCO":{"codice":"string","datafineval":"2024-11-15T13:23:29.072Z","datainival":"2024-11-15T13:23:29.072Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureEsCO":{"codice":"string","datafineval":"2024-11-15T13:23:29.072Z","datainival":"2024-11-15T13:23:29.072Z","descr":"string","id":0,"rowversion":"string","natureAssCO":[{"codice":"string","datafineval":"2024-11-15T13:23:29.072Z","datainival":"2024-11-15T13:23:29.072Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCOAgr":"string","vatCodeCOOss":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatTypeFI":{"agviaggio":0,"codice":0,"codiceCg0d":0,"descr":"string","indAutofattura":0,"indTipo":0,"localizzazione":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"taxableAmount":0,"cambio":0,"codAttivitaCg96":0,"datacambio":"2024-11-15T13:23:29.072Z","datafincomp":"2024-11-15T13:23:29.072Z","datainicomp":"2024-11-15T13:23:29.072Z","dataoperazione":"2024-11-15T13:23:29.072Z","datareg":"2024-11-15T13:23:29.072Z","datavaluta":"2024-11-15T13:23:29.072Z","descausale":"string","descragg":"string","flgComp":0,"flgDescrstd":0,"flgMentry":0,"flgStpgior":0,"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"imptotale":0,"imptotaleval":0,"imptotaleval2":0,"indDaav":1,"indGiroliq":0,"indRatris":0,"indTipooper":1,"nrmovgruppo":0,"numrigacont":0,"progEserCg19":0,"progIvaCg43":0,"rifrigagior":0,"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"businessTypeDataCO":{"annoliq":0,"codAttivita":0,"codiceCg06":"string","codiceCg6a":"string","datastpliqiva":"2024-11-15T13:23:29.072Z","datastpplafon":"2024-11-15T13:23:29.072Z","datastpregacq":"2024-11-15T13:23:29.072Z","datastpregacqglob":"2024-11-15T13:23:29.072Z","datastpregcor":"2024-11-15T13:23:29.072Z","datastpregrie":"2024-11-15T13:23:29.072Z","datastpregunicanal":"2024-11-15T13:23:29.072Z","datastpregven":"2024-11-15T13:23:29.072Z","datastpregvenglob":"2024-11-15T13:23:29.072Z","descrattivita":"string","dittaCg18":0,"flgIvaedit":0,"indAgric":0,"indCatpart":0,"indRegimefiscale":1,"rowversion":"string","codAteco":{"codice":"string","descriz":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"istatActivityCO":{"codice":"string","descr":"string","idmediaCg99":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"coaAccountFI":{"accountType":0,"alias":"string","codeformatted":"string","codiceCg22":0,"codiceCgc0":0,"cogeprogeAbil":0,"cogeprogeAttivita":0,"cogeprogeMateriali":0,"cogeprogeNodo":0,"cogeprogeSpese":0,"conto":"string","contoape":"string","contochiu":"string","contocrsosp":"string","contoratatt":"string","contoratpass":"string","contorisatt":"string","contorispass":"string","descr":"string","flgAggfatt":0,"flgAnalit":0,"flgBilconsattpassdist":0,"flgContoimm":0,"flgGesec":0,"flgGespor":0,"flgIntercompany":0,"flgOpnonfin":0,"flgRaganal":0,"flgRarp":0,"flgSaldog":0,"flgValutaest":0,"gruppoCg10":0,"idconto":0,"idcontoapeCg24":0,"idcontochiuCg24":0,"idcontoratattCg24":0,"idcontoratpassCg24":0,"idcontorisattCg24":0,"idcontorispassCg24":0,"idparent":0,"idreverse":0,"idRifPdC80":0,"indAttpasspor":0,"indContoricav":0,"indCosvend":0,"indDaav":0,"indDaavec":0,"indLivchius":0,"indMastroCliFor":99,"indTipoconto":0,"percindeduc":0,"percindetra":0,"suddconti":0,"coaAccountCustomizationFI":[{"contoCg24":"string","descr":"string","dittaCg18":0,"gruppoCg10":0,"idCg24":0,"iddespcon":0,"idmediaCg99":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"coaAccountFIApe":"string","coaAccountFIChiu":"string","coaAccountFIParent":"string","coaAccountFIRatatt":"string","coaAccountFIRatpass":"string","coaAccountFIRisatt":"string","coaAccountFIRispass":"string","coaAccountStateFI":[{"consosCg24":"string","dittaCg18":0,"dtconsos":"2024-11-15T13:23:29.072Z","dtdisatt":"2024-11-15T13:23:29.072Z","flgDisatt":0,"grusosCg10":0,"idCg24":0,"idstatipdc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"coaGroupCodeFI":{"descr":"string","flgPdclib":0,"gruppo":0,"maskedit":"string","numlivcons":0,"numlivelli":0,"rowversion":"string","accountProposals":[{"codice":0,"contoCg24":"string","gruppoCg10":0,"id":0,"idCg24":0,"rowversion":"string","coaAccountFI":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"coaInternationalCustomizationFI":[{"categoria":0,"contoCg24":"string","esModulo347":0,"gbDeferralcode":"string","gruppoCg10":0,"id":0,"idCg24":0,"iso3166A2":"string","rowversion":"string","subcategoria":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"reverseTypeFI":{"reverseTypeCode":0,"reverseTypeDescription":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatTypeFI":{"agviaggio":0,"codice":0,"codiceCg0d":0,"descr":"string","indAutofattura":0,"indTipo":0,"localizzazione":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.072Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"customerSupplierCO":{"gmdUpdateAdditionalParams":{"codice":0,"ragSoAnag":"string","indirizzo":"string","numCiv":"string","cap":"string","citta":"string","prov":"string","codiceCg07":0,"partiva":"string","codFiscale":"string","tel1Num":"string","fax":"string","tipologia":"string","codLegCg01":"string","descrCg07":"string","nationIso":"string"},"clifor":0,"codAbiCg12":0,"codCabCg13":0,"codiceCg28":"string","contoCg24":"string","contorCg24":"string","contratto":"string","datavaliva":"2024-11-15T13:23:29.072Z","dittaCg18":0,"flgArt62":0,"flgAttivo":1,"flgCointestati":0,"flgIntercompany":0,"ggscadfix":0,"gruppoCg10":0,"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","idclifor":0,"idmediaCg99":0,"indElenchimov3000":99,"intermedioCg40":0,"lastchange":"2024-11-15T13:23:29.072Z","progREf08":0,"tipocf":0,"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"agentCO":{"agente":"string","anagenCg16":0,"datafineman":"2024-11-15T13:23:29.072Z","datainman":"2024-11-15T13:23:29.072Z","datainrapp":"2024-11-15T13:23:29.072Z","dittaCg18":0,"flgAdegdelta":0,"flgAdeguamscmag":0,"flgRegimeart":0,"flgRegimecl":0,"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","idagente":0,"idcapoareaMg17":0,"idcapozonaMg17":0,"idmediaCg99":0,"indBaseimpmag":0,"indBaseimpsc":0,"indCalcscmag":0,"indPrefstdoc":0,"indStdistenas":0,"indTipoage":0,"indTipoliq":0,"perprov":0,"regimeprov":0,"tipomand":0,"tiporappor":1,"tiposoc":0,"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"dmsPublishedEntityFW":{"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","tipoarchHm30":0,"idknos":0,"dittaCg18":0,"protocollo":"string","flgInvalid":0,"percorso":"string","nome":"string","datapub":"2024-11-15T13:23:29.072Z","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"generalMasterDataCO":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:23:29.072Z","datavalid":"2024-11-15T13:23:29.072Z","dtfinepec":"2024-11-15T13:23:29.072Z","dtiniziopec":"2024-11-15T13:23:29.072Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:23:29.072Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:23:29.072Z","datamod":"2024-11-15T13:23:29.072Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.072Z","datafinblacklist":"2024-11-15T13:23:29.072Z","datainiblacklist":"2024-11-15T13:23:29.072Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.072Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.072Z","datafinblacklist":"2024-11-15T13:23:29.072Z","datainiblacklist":"2024-11-15T13:23:29.072Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.072Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"blackListGeneralMasterData":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:23:29.072Z","datavalid":"2024-11-15T13:23:29.072Z","dtfinepec":"2024-11-15T13:23:29.072Z","dtiniziopec":"2024-11-15T13:23:29.072Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:23:29.072Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:23:29.073Z","datamod":"2024-11-15T13:23:29.073Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.073Z","datafinblacklist":"2024-11-15T13:23:29.073Z","datainiblacklist":"2024-11-15T13:23:29.073Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.073Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.073Z","datafinblacklist":"2024-11-15T13:23:29.073Z","datainiblacklist":"2024-11-15T13:23:29.073Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.073Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"csAccountingIndexCO":{"codCat":"string","descr":"string","dittaCg18":0,"tipocfCg44":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"csBankCO":[{"bban":"string","bicbancaestera":"string","ccaddetto":"string","ccdesagenz":"string","ccforn":"string","ccfornfactor":0,"ccfornfactoridCg44":0,"ccggval":0,"cliforCg44":0,"codiceCg07":0,"dittaCg18":0,"flgPref":0,"flgPrefIncassi":0,"iban":"string","id":0,"idbancaestera":"string","idcontratto":"string","idsuccursale":0,"indTipoop":0,"locbancaestera":"string","nomebancaestera":"string","progR":0,"tipobanca":0,"tipocfCg44":0,"agencyCO":{"codBanca":0,"codice":0,"descrizione":"string","localita":"string","prov":"string","bankCO":{"codBicswift":"string","codiceBanca":0,"descrizione":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"customerSupplierCO":"string","nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.073Z","datafinblacklist":"2024-11-15T13:23:29.073Z","datainiblacklist":"2024-11-15T13:23:29.073Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.073Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"csCompanyBankCO":[{"cliforCg44":0,"dittaCg18":0,"flgPref":0,"id":0,"progR":0,"progREf08":0,"rowversion":"string","tipocfCg44":0,"companyBankCO":{"aprogressmav":0,"bancaCg12":0,"bbananticipi":"string","bbanconto":"string","bbaneffpresef":"string","bbanordpbonif":"string","bicbanca":"string","cabbonifCg13":0,"cabcontoCg13":0,"cabmavCg13":0,"cabribaCg13":0,"cabridCg13":0,"ccanticipi":"string","ccconto":"string","cceffpresef":"string","ccordpbonif":"string","codAzienda":"string","codiceCg07":0,"codicecuc":"string","codRappopor":"string","codSia":"string","creditidentifier":"string","daprogressmav":0,"descr":"string","dittaCg18":0,"flgAutattribnrmav":0,"flgCambiali":0,"flgCessioni":0,"flgMav":0,"flgPref":0,"flgRiba":0,"flgRibacamb":0,"flgRibacess":0,"flgRibaricba":0,"flgRibatratac":0,"flgRibatratte":0,"flgRidsdd":0,"flgRidsddraggr":0,"flgScfatt":0,"flgTratte":0,"ggvalcambalt":0,"ggvalcambfil":0,"ggvalmavincalt":0,"ggvalmavincfil":0,"ggvalmavincpos":0,"ggvalmavsbf":0,"ggvalribaalt":0,"ggvalribafil":0,"ggvalridalt":0,"ggvalridfil":0,"ggvalscfattalt":0,"ggvalscfattfil":0,"ggvaltratalt":0,"ggvaltratfil":0,"ibananticipi":"string","ibanconto":"string","ibaneffpresef":"string","ibanordpbonif":"string","id":0,"idbancaestera":"string","idcontratto":"string","idmediaCg99":0,"idsuccursale":0,"impcastel":0,"impfido":0,"indCheckpivacf":0,"indCompind":0,"indContpmtinf":0,"indPresmav":1,"indPresriba":1,"indPresrid":1,"indTipolib":1,"indTipopres":0,"locbancaestera":"string","maxgginsoluti":0,"prefissoattribmav":0,"progR":0,"rowversion":"string","scfindbasecalc":1,"scfnsdocrif":"string","scfpercpres":0,"scfperctasso":0,"scfvsdocrif":"string","spcommbonalt":0,"spcommbonfil":0,"spcommordpalt":0,"spcommordpfil":0,"spinccambalt":0,"spinccambfil":0,"spinccoralt":0,"spinccorfil":0,"spincesitopag":0,"spincmavincalt":0,"spincmavincfil":0,"spincmavincpos":0,"spincmavsbf":0,"spincribaalt":0,"spincribafil":0,"spincridalt":0,"spincridfil":0,"spinctraalt":0,"spinctrafil":0,"sppresdistinta":0,"spritcamb":0,"spritcambcl":0,"spritmavincas":0,"spritmavincascl":0,"spritmavsbf":0,"spritmavsbfcl":0,"spritriba":0,"spritribacl":0,"spritrid":0,"spritridcl":0,"sprittratte":0,"sprittrattecl":0,"tipobanca":0,"ultprogressmav":0,"bankCO":{"codBicswift":"string","codiceBanca":0,"descrizione":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.073Z","datafinblacklist":"2024-11-15T13:23:29.073Z","datainiblacklist":"2024-11-15T13:23:29.073Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.073Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"csInfoCO":{"area":"string","areanielsenMg0e":"string","bacsaccountno":0,"categ":"string","cliforCg44":0,"codIclfatt":0,"codLivbloc":"string","codRifalf":"string","codRifnum":0,"codRischioMg2a":"string","datablocco":"2024-11-15T13:23:29.073Z","datacreaz":"2024-11-15T13:23:29.073Z","datadismis":"2024-11-15T13:23:29.073Z","datarischio":"2024-11-15T13:23:29.073Z","dataultvar":"2024-11-15T13:23:29.073Z","dittaCg18":0,"fidoaziendale":0,"fidofactoring":0,"fidolivello1":0,"fidolivello2":0,"finchargerterms":"string","flgEstrpayline":0,"flgSpbol":0,"flgSpeinc":0,"flgTaxliable":0,"idmediaCg99":0,"indClibloc":0,"indGesfido":0,"indrottcig":0,"indSpesecum":0,"irs1099":"string","lastchange":"2024-11-15T13:23:29.073Z","linguaMg52":"string","macroarea":"string","macrocat":"string","notebloc":"string","raggcrf3":"string","raggrcf1":"string","raggrcf2":"string","regimeiva":"string","reminderterms":"string","scaglspbanc":0,"sottocat":"string","taxareaNv01":"string","taxexemptionno":"string","tipocfCg44":0,"typeofsupply":"string","zona":"string","areaCO":{"codiceAreaMG":"string","descrarea":"string","dittaCg18":0,"idprov":0,"macroareaMg07":"string","tipocfMg07":0,"zone":[{"areaMg08":"string","codiceZona":"string","descrzona":"string","dittaCg18":0,"idprov":0,"macroareaMg08":"string","tipocfMg08":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"categoryCO":{"categ":"string","descrcat":"string","dittaCg18":0,"macrocatMg10":"string","tipocfMg10":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"grouping1CO":{"codRaggrcf1":"string","descraggrcf1":"string","dittaCg18":0,"idmediaCg99":0,"idprov":0,"tipocf":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"grouping2CO":{"codRaggrcf2":"string","descraggrcf2":"string","dittaCg18":0,"idmediaCg99":0,"idprov":0,"tipocf":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"grouping3CO":{"codRaggrcf3":"string","descraggrcf3":"string","dittaCg18":0,"idmediaCg99":0,"idprov":0,"tipocf":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"macroAreaCO":{"codiceMacroarea":"string","descrmacroar":"string","dittaCg18":0,"idprov":0,"tipocf":0,"areas":[{"codiceAreaMG":"string","descrarea":"string","dittaCg18":0,"idprov":0,"macroareaMg07":"string","tipocfMg07":0,"zone":[{"areaMg08":"string","codiceZona":"string","descrzona":"string","dittaCg18":0,"idprov":0,"macroareaMg08":"string","tipocfMg08":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"macroCategoryCO":{"descrmacrocat":"string","dittaCg18":0,"macrocat":"string","tipocf":0,"categorie":[{"categ":"string","descrcat":"string","dittaCg18":0,"macrocatMg10":"string","tipocfMg10":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"subCategoryCO":{"categMg11":"string","descrsottocat":"string","dittaCg18":0,"macrocatMg11":"string","sottcat":"string","tipocfMg11":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"zoneCO":{"areaMg08":"string","codiceZona":"string","descrzona":"string","dittaCg18":0,"idprov":0,"macroareaMg08":"string","tipocfMg08":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"csJointlyHeldCO":[{"cliforCg44":0,"cliforcoCg44":0,"dittaCg18":0,"idcliforcoCg44":0,"percentuale":0,"tipocfCg44":0,"customerSupplierCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"csPaymentRangeCO":[{"aimpdoc":0,"cliforCg44":0,"codPagCg62":"string","codScagl":0,"dittaCg18":0,"id":0,"idCg62":0,"idmediaCg99":0,"indPagpart":0,"tipocfCg44":0,"valutaCg08":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.073Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"paymentTermCO":{"codPag":"string","descPag":"string","desPagAnal":"string","flgDesc":0,"flgDisgg":0,"flgPrefatt":0,"flgPrefpass":0,"flgStornoiva":0,"id":0,"rowversion":"string","scart26":0,"scpercart26":0,"scpercas":0,"scpermer1":0,"scpermer2":0,"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"paymentTermDetailCO":[{"aggfix1":0,"aggfix2":0,"codPagCg62":"string","daggfix1":0,"daggfix2":0,"el1frimp":0,"el1friva":0,"el2frimp":0,"el2friva":0,"flgFrpercimp":1,"flgFrperciva":1,"ggdecor":0,"ggmmfix":0,"ggscadfix1":0,"ggscadfix2":0,"id":0,"idCg62":0,"idCg64":0,"imporfix":0,"indDatarif":0,"indImpfix":0,"indTipocalend":0,"indTipodecor":1,"percimp":0,"perciva":0,"prog":0,"rowversion":"string","tipoeff":9,"subTypeCO":{"codiceCg07":0,"codPaguc":"string","codStipoeff":0,"descstipo":"string","flgAssegno":0,"ggoffset":0,"id":0,"indModfatturapa":0,"rowversion":"string","tipoeff":0,"foreignPaymentCodeCO":{"codice":"string","codIso":"string","descrpag":"string","flgIbanobbl":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.073Z","datafinblacklist":"2024-11-15T13:23:29.073Z","datainiblacklist":"2024-11-15T13:23:29.073Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.073Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"csPostponementPeriodCO":[{"ammgg":0,"cliforCg44":0,"dammgg":0,"dittaCg18":0,"ggmmfixslit":0,"ggslsucc":0,"id":0,"idmediaCg99":0,"indAppggfix":0,"indTiposlit":1,"tipocfCg44":0,"tipoeff":9,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"csSddCO":[{"bancaallineam":0,"causrich":0,"causrisp":0,"cfiscsottoscr":"string","cliforCg44":0,"codAutoriz":"string","codBicswift":"string","codClideb":"string","codClidebprec":"string","codIndiv":0,"codIndivprec":0,"codRif":"string","contocorr":"string","contocorrprec":"string","datamandato":"2024-11-15T13:23:29.074Z","dataprimascad":"2024-11-15T13:23:29.074Z","datarich":"2024-11-15T13:23:29.074Z","datarisp":"2024-11-15T13:23:29.074Z","dataultimascad":"2024-11-15T13:23:29.074Z","descrizione":"string","diniego":0,"dittaCg18":0,"flgAllineam":0,"flgDisattivato":0,"flgVariato":0,"id":0,"idmediaCg99":0,"impmaxrata":0,"indIrsottoscr":"string","indStorno":0,"indStornoprec":0,"indTipoinc":0,"indTiposdd":0,"locsottoscr":"string","nrrate":0,"nuovabanca":0,"progR":0,"ragsosottoscr":"string","ridabi":0,"ridabiprec":0,"ridcab":0,"ridcabprec":0,"ridiban":"string","ridibanprec":"string","soggtitibanCg16":0,"tipocfCg44":0,"tipoinclocked":0,"tipologia":1,"tipologiaprec":0,"csHistorySddCO":[{"codBicswift":"string","codClideb":"string","codIndiv":0,"datavar":"2024-11-15T13:23:29.074Z","id":0,"indStorno":0,"indTipoinc":0,"indTiposdd":0,"ridiban":"string","soggtitibanCg16":0,"tipologia":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.074Z","datafinblacklist":"2024-11-15T13:23:29.074Z","datainiblacklist":"2024-11-15T13:23:29.074Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.074Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"soggtitiban":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:23:29.074Z","datavalid":"2024-11-15T13:23:29.074Z","dtfinepec":"2024-11-15T13:23:29.074Z","dtiniziopec":"2024-11-15T13:23:29.074Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:23:29.074Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:23:29.074Z","datamod":"2024-11-15T13:23:29.074Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.074Z","datafinblacklist":"2024-11-15T13:23:29.074Z","datainiblacklist":"2024-11-15T13:23:29.074Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.074Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.074Z","datafinblacklist":"2024-11-15T13:23:29.074Z","datainiblacklist":"2024-11-15T13:23:29.074Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.074Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.074Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"customerSupplierCIGCUPCO":[{"cliforCg44":0,"dittaCg18":0,"id":0,"idcigcupCo1h":0,"progREf08":0,"progRMg35":0,"rowversion":"string","tipocfCg44":0,"cigcuPcode":{"cig":"string","cup":"string","descrizione":"string","docrifData":"2024-11-15T13:23:29.074Z","docrifId":"string","flgAttivo":0,"id":0,"indTipocontr":0,"indTipodocrif":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"companyBank":{"aprogressmav":0,"bancaCg12":0,"bbananticipi":"string","bbanconto":"string","bbaneffpresef":"string","bbanordpbonif":"string","bicbanca":"string","cabbonifCg13":0,"cabcontoCg13":0,"cabmavCg13":0,"cabribaCg13":0,"cabridCg13":0,"ccanticipi":"string","ccconto":"string","cceffpresef":"string","ccordpbonif":"string","codAzienda":"string","codiceCg07":0,"codicecuc":"string","codRappopor":"string","codSia":"string","creditidentifier":"string","daprogressmav":0,"descr":"string","dittaCg18":0,"flgAutattribnrmav":0,"flgCambiali":0,"flgCessioni":0,"flgMav":0,"flgPref":0,"flgRiba":0,"flgRibacamb":0,"flgRibacess":0,"flgRibaricba":0,"flgRibatratac":0,"flgRibatratte":0,"flgRidsdd":0,"flgRidsddraggr":0,"flgScfatt":0,"flgTratte":0,"ggvalcambalt":0,"ggvalcambfil":0,"ggvalmavincalt":0,"ggvalmavincfil":0,"ggvalmavincpos":0,"ggvalmavsbf":0,"ggvalribaalt":0,"ggvalribafil":0,"ggvalridalt":0,"ggvalridfil":0,"ggvalscfattalt":0,"ggvalscfattfil":0,"ggvaltratalt":0,"ggvaltratfil":0,"ibananticipi":"string","ibanconto":"string","ibaneffpresef":"string","ibanordpbonif":"string","id":0,"idbancaestera":"string","idcontratto":"string","idmediaCg99":0,"idsuccursale":0,"impcastel":0,"impfido":0,"indCheckpivacf":0,"indCompind":0,"indContpmtinf":0,"indPresmav":1,"indPresriba":1,"indPresrid":1,"indTipolib":1,"indTipopres":0,"locbancaestera":"string","maxgginsoluti":0,"prefissoattribmav":0,"progR":0,"rowversion":"string","scfindbasecalc":1,"scfnsdocrif":"string","scfpercpres":0,"scfperctasso":0,"scfvsdocrif":"string","spcommbonalt":0,"spcommbonfil":0,"spcommordpalt":0,"spcommordpfil":0,"spinccambalt":0,"spinccambfil":0,"spinccoralt":0,"spinccorfil":0,"spincesitopag":0,"spincmavincalt":0,"spincmavincfil":0,"spincmavincpos":0,"spincmavsbf":0,"spincribaalt":0,"spincribafil":0,"spincridalt":0,"spincridfil":0,"spinctraalt":0,"spinctrafil":0,"sppresdistinta":0,"spritcamb":0,"spritcambcl":0,"spritmavincas":0,"spritmavincascl":0,"spritmavsbf":0,"spritmavsbfcl":0,"spritriba":0,"spritribacl":0,"spritrid":0,"spritridcl":0,"sprittratte":0,"sprittrattecl":0,"tipobanca":0,"ultprogressmav":0,"bankCO":{"codBicswift":"string","codiceBanca":0,"descrizione":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.074Z","datafinblacklist":"2024-11-15T13:23:29.074Z","datainiblacklist":"2024-11-15T13:23:29.074Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.074Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"csBankCO":{"bban":"string","bicbancaestera":"string","ccaddetto":"string","ccdesagenz":"string","ccforn":"string","ccfornfactor":0,"ccfornfactoridCg44":0,"ccggval":0,"cliforCg44":0,"codiceCg07":0,"dittaCg18":0,"flgPref":0,"flgPrefIncassi":0,"iban":"string","id":0,"idbancaestera":"string","idcontratto":"string","idsuccursale":0,"indTipoop":0,"locbancaestera":"string","nomebancaestera":"string","progR":0,"tipobanca":0,"tipocfCg44":0,"agencyCO":{"codBanca":0,"codice":0,"descrizione":"string","localita":"string","prov":"string","bankCO":{"codBicswift":"string","codiceBanca":0,"descrizione":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"customerSupplierCO":"string","nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.074Z","datafinblacklist":"2024-11-15T13:23:29.074Z","datainiblacklist":"2024-11-15T13:23:29.074Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.074Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"custSupplDataInvoicePACO":{"codiceCg16":0,"emailcortesia":"string","flgAsw":0,"indTypeb2b":0,"tipocfCg44":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"dmsPublishedEntityFW":{"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","tipoarchHm30":0,"idknos":0,"dittaCg18":0,"protocollo":"string","flgInvalid":0,"percorso":"string","nome":"string","datapub":"2024-11-15T13:23:29.074Z","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"generalMasterDataCO":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-11-15T13:23:29.074Z","datavalid":"2024-11-15T13:23:29.074Z","dtfinepec":"2024-11-15T13:23:29.074Z","dtiniziopec":"2024-11-15T13:23:29.074Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-11-15T13:23:29.074Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-11-15T13:23:29.074Z","datamod":"2024-11-15T13:23:29.074Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.075Z","datafinblacklist":"2024-11-15T13:23:29.075Z","datainiblacklist":"2024-11-15T13:23:29.075Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.075Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.075Z","datafinblacklist":"2024-11-15T13:23:29.075Z","datainiblacklist":"2024-11-15T13:23:29.075Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.075Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"officeCO":{"cap":"string","citta":"string","codice":0,"dittaCg18":0,"idmediaCg99":0,"indDimcentrocomm":0,"indIrizzo":"string","numerorea":"string","progRea":0,"prov":"string","rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"officePACO":[{"cap":"string","codDestin":"string","codice":"string","codiceCg16":0,"comune":"string","flgPreferenziale":0,"idprovincia":0,"idregione":0,"indIrizzo":"string","indTypeb2b":0,"lastupdateB2b":"2024-11-15T13:23:29.075Z","nome":"string","tipocfCg44":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"paymentTermCO":{"codPag":"string","descPag":"string","desPagAnal":"string","flgDesc":0,"flgDisgg":0,"flgPrefatt":0,"flgPrefpass":0,"flgStornoiva":0,"id":0,"rowversion":"string","scart26":0,"scpercart26":0,"scpercas":0,"scpermer1":0,"scpermer2":0,"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"paymentTermDetailCO":[{"aggfix1":0,"aggfix2":0,"codPagCg62":"string","daggfix1":0,"daggfix2":0,"el1frimp":0,"el1friva":0,"el2frimp":0,"el2friva":0,"flgFrpercimp":1,"flgFrperciva":1,"ggdecor":0,"ggmmfix":0,"ggscadfix1":0,"ggscadfix2":0,"id":0,"idCg62":0,"idCg64":0,"imporfix":0,"indDatarif":0,"indImpfix":0,"indTipocalend":0,"indTipodecor":1,"percimp":0,"perciva":0,"prog":0,"rowversion":"string","tipoeff":9,"subTypeCO":{"codiceCg07":0,"codPaguc":"string","codStipoeff":0,"descstipo":"string","flgAssegno":0,"ggoffset":0,"id":0,"indModfatturapa":0,"rowversion":"string","tipoeff":0,"foreignPaymentCodeCO":{"codice":"string","codIso":"string","descrpag":"string","flgIbanobbl":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.075Z","datafinblacklist":"2024-11-15T13:23:29.075Z","datainiblacklist":"2024-11-15T13:23:29.075Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.075Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCO":{"aliqivavent":0,"annotazioni":"string","codice":"string","codiceagr":"string","codiceOss":"string","codPlafond":0,"descrizione":"string","flgAgri":0,"flgAllclifor":0,"flgAssport398":0,"flgAutoue":0,"flgCorrVent":0,"flgEscludiblacklist":0,"flgImpostadibollo":0,"flgIndet":0,"flgIvaedit":0,"flgMonofasersm":0,"flgMossgest":0,"flgMossrid":0,"flgNotvar":0,"flgSospimp":0,"idprov":0,"impostamonofasersm":0,"indNatassoswCg2n":0,"indNatura":0,"indStaper":0,"indtipopart":0,"mosscodCg07":0,"mossperc":0,"note":"string","percforf":0,"percindet":0,"perciva":0,"percmonofasersm":0,"rowVersion":"string","tipologia":1,"verslynfa":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.075Z","datafinblacklist":"2024-11-15T13:23:29.075Z","datainiblacklist":"2024-11-15T13:23:29.075Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.075Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureAssCO":{"codice":"string","datafineval":"2024-11-15T13:23:29.075Z","datainival":"2024-11-15T13:23:29.075Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureEsCO":{"codice":"string","datafineval":"2024-11-15T13:23:29.075Z","datainival":"2024-11-15T13:23:29.075Z","descr":"string","id":0,"rowversion":"string","natureAssCO":[{"codice":"string","datafineval":"2024-11-15T13:23:29.075Z","datainival":"2024-11-15T13:23:29.075Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCOAgr":"string","vatCodeCOOss":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"officeCO":{"cap":"string","citta":"string","codice":0,"dittaCg18":0,"idmediaCg99":0,"indDimcentrocomm":0,"indIrizzo":"string","numerorea":"string","progRea":0,"prov":"string","rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"glvatDetailFI":[{"causaleiva":0,"dittaCg18":0,"flgDeducibile":0,"flgTsescluso":0,"flgTsinviato":0,"id":0,"idCg41":0,"idcontoCg24":0,"imponibile":0,"imponibileval":0,"imposta":0,"impostand":0,"impostandval":0,"impostaval":0,"indDetriva":0,"indIvaacqagric":0,"indNatura":0,"indProrata":0,"indTipo":0,"indTstipoop":0,"indTstiposp":0,"indTsvocesp":0,"numrigaiva":0,"percdetr":0,"percforf":0,"tsdatadocori":"2024-11-15T13:23:29.075Z","tsdocorigine":"string","coaAccountFI":{"accountType":0,"alias":"string","codeformatted":"string","codiceCg22":0,"codiceCgc0":0,"cogeprogeAbil":0,"cogeprogeAttivita":0,"cogeprogeMateriali":0,"cogeprogeNodo":0,"cogeprogeSpese":0,"conto":"string","contoape":"string","contochiu":"string","contocrsosp":"string","contoratatt":"string","contoratpass":"string","contorisatt":"string","contorispass":"string","descr":"string","flgAggfatt":0,"flgAnalit":0,"flgBilconsattpassdist":0,"flgContoimm":0,"flgGesec":0,"flgGespor":0,"flgIntercompany":0,"flgOpnonfin":0,"flgRaganal":0,"flgRarp":0,"flgSaldog":0,"flgValutaest":0,"gruppoCg10":0,"idconto":0,"idcontoapeCg24":0,"idcontochiuCg24":0,"idcontoratattCg24":0,"idcontoratpassCg24":0,"idcontorisattCg24":0,"idcontorispassCg24":0,"idparent":0,"idreverse":0,"idRifPdC80":0,"indAttpasspor":0,"indContoricav":0,"indCosvend":0,"indDaav":0,"indDaavec":0,"indLivchius":0,"indMastroCliFor":99,"indTipoconto":0,"percindeduc":0,"percindetra":0,"suddconti":0,"coaAccountCustomizationFI":[{"contoCg24":"string","descr":"string","dittaCg18":0,"gruppoCg10":0,"idCg24":0,"iddespcon":0,"idmediaCg99":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"coaAccountFIApe":"string","coaAccountFIChiu":"string","coaAccountFIParent":"string","coaAccountFIRatatt":"string","coaAccountFIRatpass":"string","coaAccountFIRisatt":"string","coaAccountFIRispass":"string","coaAccountStateFI":[{"consosCg24":"string","dittaCg18":0,"dtconsos":"2024-11-15T13:23:29.075Z","dtdisatt":"2024-11-15T13:23:29.075Z","flgDisatt":0,"grusosCg10":0,"idCg24":0,"idstatipdc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"coaGroupCodeFI":{"descr":"string","flgPdclib":0,"gruppo":0,"maskedit":"string","numlivcons":0,"numlivelli":0,"rowversion":"string","accountProposals":[{"codice":0,"contoCg24":"string","gruppoCg10":0,"id":0,"idCg24":0,"rowversion":"string","coaAccountFI":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"coaInternationalCustomizationFI":[{"categoria":0,"contoCg24":"string","esModulo347":0,"gbDeferralcode":"string","gruppoCg10":0,"id":0,"idCg24":0,"iso3166A2":"string","rowversion":"string","subcategoria":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"reverseTypeFI":{"reverseTypeCode":0,"reverseTypeDescription":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatTypeFI":{"agviaggio":0,"codice":0,"codiceCg0d":0,"descr":"string","indAutofattura":0,"indTipo":0,"localizzazione":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"reverseTypeFI":{"reverseTypeCode":0,"reverseTypeDescription":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCO":{"aliqivavent":0,"annotazioni":"string","codice":"string","codiceagr":"string","codiceOss":"string","codPlafond":0,"descrizione":"string","flgAgri":0,"flgAllclifor":0,"flgAssport398":0,"flgAutoue":0,"flgCorrVent":0,"flgEscludiblacklist":0,"flgImpostadibollo":0,"flgIndet":0,"flgIvaedit":0,"flgMonofasersm":0,"flgMossgest":0,"flgMossrid":0,"flgNotvar":0,"flgSospimp":0,"idprov":0,"impostamonofasersm":0,"indNatassoswCg2n":0,"indNatura":0,"indStaper":0,"indtipopart":0,"mosscodCg07":0,"mossperc":0,"note":"string","percforf":0,"percindet":0,"perciva":0,"percmonofasersm":0,"rowVersion":"string","tipologia":1,"verslynfa":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.075Z","datafinblacklist":"2024-11-15T13:23:29.075Z","datainiblacklist":"2024-11-15T13:23:29.075Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.075Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureAssCO":{"codice":"string","datafineval":"2024-11-15T13:23:29.075Z","datainival":"2024-11-15T13:23:29.075Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureEsCO":{"codice":"string","datafineval":"2024-11-15T13:23:29.075Z","datainival":"2024-11-15T13:23:29.075Z","descr":"string","id":0,"rowversion":"string","natureAssCO":[{"codice":"string","datafineval":"2024-11-15T13:23:29.075Z","datainival":"2024-11-15T13:23:29.075Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCOAgr":"string","vatCodeCOOss":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCompensationCO":{"aliqivavent":0,"annotazioni":"string","codice":"string","codiceagr":"string","codiceOss":"string","codPlafond":0,"descrizione":"string","flgAgri":0,"flgAllclifor":0,"flgAssport398":0,"flgAutoue":0,"flgCorrVent":0,"flgEscludiblacklist":0,"flgImpostadibollo":0,"flgIndet":0,"flgIvaedit":0,"flgMonofasersm":0,"flgMossgest":0,"flgMossrid":0,"flgNotvar":0,"flgSospimp":0,"idprov":0,"impostamonofasersm":0,"indNatassoswCg2n":0,"indNatura":0,"indStaper":0,"indtipopart":0,"mosscodCg07":0,"mossperc":0,"note":"string","percforf":0,"percindet":0,"perciva":0,"percmonofasersm":0,"rowVersion":"string","tipologia":1,"verslynfa":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-11-15T13:23:29.076Z","datafinblacklist":"2024-11-15T13:23:29.076Z","datainiblacklist":"2024-11-15T13:23:29.076Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-11-15T13:23:29.076Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureAssCO":{"codice":"string","datafineval":"2024-11-15T13:23:29.076Z","datainival":"2024-11-15T13:23:29.076Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureEsCO":{"codice":"string","datafineval":"2024-11-15T13:23:29.076Z","datainival":"2024-11-15T13:23:29.076Z","descr":"string","id":0,"rowversion":"string","natureAssCO":[{"codice":"string","datafineval":"2024-11-15T13:23:29.076Z","datainival":"2024-11-15T13:23:29.076Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCOAgr":"string","vatCodeCOOss":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatTypeFI":{"agviaggio":0,"codice":0,"codiceCg0d":0,"descr":"string","indAutofattura":0,"indTipo":0,"localizzazione":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"movementTypeCO":{"codice":0,"descr":"string","descrbreve":"string","descrmedia":"string","flgBilanci":0,"flgBilancicons":0,"flgCanrevoke":0,"flgCoan":0,"flgContrsaldi":0,"flgDoc":0,"flgEc":0,"flgElabiva":0,"flgHyperion":0,"flgMovcont":0,"flgMoviva":0,"flgPartitari":0,"flgPf":0,"flgQuerypn":0,"indAcconti":0,"indCambiali":0,"indChiuseff":0,"indConsolidamento":0,"indDatabilanci":0,"indEcportaper":0,"indEcportchius":0,"indIncassobf":0,"indInsoluti":0,"indProforma":0,"indRaggr":0,"indRatrisc":0,"indRettifica":0,"indSimulbilanci":0,"indTipoifrs":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"officeCO":{"cap":"string","citta":"string","codice":0,"dittaCg18":0,"idmediaCg99":0,"indDimcentrocomm":0,"indIrizzo":"string","numerorea":"string","progRea":0,"prov":"string","rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"sectionalMasterDataCO":{"caustcoll":"string","descsez":"string","dittaCg18":0,"flgNoLiqIva":0,"idagentecoll":0,"idprov":0,"indIntra1213":0,"indRegione":0,"indTipologia":0,"puntovenCg7a":0,"sezionale":"string","storeCO":{"descrizione":"string","dittaCg18":0,"puntoven":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}; // GLEntryFIDTO | Object of type to create
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIPost(environment, authorizationScope, gLEntryFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **gLEntryFIDTO** | [**GLEntryFIDTO**](GLEntryFIDTO.md)| Object of type to create | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**GLEntryFIDTO**](GLEntryFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIPreviewPost

> PreviewResultDTO apiV1EnvironmentFIGLEntryFIPreviewPost(environment, authorizationScope, idFIDTO, opts)

Preview of a gl entry

Preview of a gl entry

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let idFIDTO = new TseCloudFi.IdFIDTO(); // IdFIDTO | Id of selected gl entry 
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIPreviewPost(environment, authorizationScope, idFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **idFIDTO** | [**IdFIDTO**](IdFIDTO.md)| Id of selected gl entry  | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**PreviewResultDTO**](PreviewResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIReadPost

> GLEntryFIDTO apiV1EnvironmentFIGLEntryFIReadPost(environment, authorizationScope, searchElementDTO, opts)

Read

Read among object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let searchElementDTO = [new TseCloudFi.SearchElementDTO()]; // [SearchElementDTO] | Search criteria to apply
let opts = {
  'dlevel': "dlevel_example", // String | Serialization level
  'dlevelkey': "dlevelkey_example", // String | Serialization level key
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIReadPost(environment, authorizationScope, searchElementDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **searchElementDTO** | [**[SearchElementDTO]**](SearchElementDTO.md)| Search criteria to apply | 
 **dlevel** | **String**| Serialization level | [optional] 
 **dlevelkey** | **String**| Serialization level key | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**GLEntryFIDTO**](GLEntryFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIReelaborateInvoiceFepaPassFIPost

> OperationResultDTO apiV1EnvironmentFIGLEntryFIReelaborateInvoiceFepaPassFIPost(environment, authorizationScope, idFIDTO, opts)

Reelaborate file Fepa pass

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let idFIDTO = new TseCloudFi.IdFIDTO(); // IdFIDTO | Input parameters for reelaborate
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIReelaborateInvoiceFepaPassFIPost(environment, authorizationScope, idFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **idFIDTO** | [**IdFIDTO**](IdFIDTO.md)| Input parameters for reelaborate | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**OperationResultDTO**](OperationResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIResidualCalculationPost

> ResidualCalculationResultDTO apiV1EnvironmentFIGLEntryFIResidualCalculationPost(environment, authorizationScope, residualCalculationParametersDTO, opts)

Residual accounting entry calculation

Calculate the residual amount of the accounting entry

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let residualCalculationParametersDTO = new TseCloudFi.ResidualCalculationParametersDTO(); // ResidualCalculationParametersDTO | Input parameters for calculation
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIResidualCalculationPost(environment, authorizationScope, residualCalculationParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **residualCalculationParametersDTO** | [**ResidualCalculationParametersDTO**](ResidualCalculationParametersDTO.md)| Input parameters for calculation | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**ResidualCalculationResultDTO**](ResidualCalculationResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIRestoreB2BFileFepaPassPost

> FIGLEntriesExecutionResultDTO apiV1EnvironmentFIGLEntryFIRestoreB2BFileFepaPassPost(environment, authorizationScope, idFIDTO, opts)

Restore B2B file Fepa pass

Restore B2B file Fepa pass

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let idFIDTO = new TseCloudFi.IdFIDTO(); // IdFIDTO | Input params
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIRestoreB2BFileFepaPassPost(environment, authorizationScope, idFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **idFIDTO** | [**IdFIDTO**](IdFIDTO.md)| Input params | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIRestoreInvoiceFepaPassFIPost

> FilesFepaPassCODTO apiV1EnvironmentFIGLEntryFIRestoreInvoiceFepaPassFIPost(environment, authorizationScope, idFIDTO, opts)

Restore file Fepa pass

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let idFIDTO = new TseCloudFi.IdFIDTO(); // IdFIDTO | Input parameters for reelaborate
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIRestoreInvoiceFepaPassFIPost(environment, authorizationScope, idFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **idFIDTO** | [**IdFIDTO**](IdFIDTO.md)| Input parameters for reelaborate | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**FilesFepaPassCODTO**](FilesFepaPassCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIRetrieveCurrenciesOfExchangeRatesAdjPost

> RetrieveCurrenciesOfExchangeRatesAdjResultDTO apiV1EnvironmentFIGLEntryFIRetrieveCurrenciesOfExchangeRatesAdjPost(environment, authorizationScope, retrieveCurrenciesOfExchangeRatesAdjParametersDTO, opts)

Manages the recovery of all currencies and relative exchange rates belonging to an accounting process

manages the recovery of all currencies and relative exchange rates belonging to an accounting process

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let retrieveCurrenciesOfExchangeRatesAdjParametersDTO = new TseCloudFi.RetrieveCurrenciesOfExchangeRatesAdjParametersDTO(); // RetrieveCurrenciesOfExchangeRatesAdjParametersDTO | All necessary parameters for exchange rates 
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIRetrieveCurrenciesOfExchangeRatesAdjPost(environment, authorizationScope, retrieveCurrenciesOfExchangeRatesAdjParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **retrieveCurrenciesOfExchangeRatesAdjParametersDTO** | [**RetrieveCurrenciesOfExchangeRatesAdjParametersDTO**](RetrieveCurrenciesOfExchangeRatesAdjParametersDTO.md)| All necessary parameters for exchange rates  | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**RetrieveCurrenciesOfExchangeRatesAdjResultDTO**](RetrieveCurrenciesOfExchangeRatesAdjResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIRunreportrglentriesPost

> JobStatusDTO apiV1EnvironmentFIGLEntryFIRunreportrglentriesPost(environment, authorizationScope, gLEntryRunReportJobParamsDTO, opts)

RunReportGlentries

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let gLEntryRunReportJobParamsDTO = new TseCloudFi.GLEntryRunReportJobParamsDTO(); // GLEntryRunReportJobParamsDTO | List of entries to insert 
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIRunreportrglentriesPost(environment, authorizationScope, gLEntryRunReportJobParamsDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **gLEntryRunReportJobParamsDTO** | [**GLEntryRunReportJobParamsDTO**](GLEntryRunReportJobParamsDTO.md)| List of entries to insert  | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**JobStatusDTO**](JobStatusDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFISearchPost

> GLEntryFIDTO apiV1EnvironmentFIGLEntryFISearchPost(environment, authorizationScope, searchDTO, opts)

Search

Search among object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let searchDTO = new TseCloudFi.SearchDTO(); // SearchDTO | Search criteria to apply
let opts = {
  'loadEntireDomain': "loadEntireDomain_example", // String | Specify 'loadEntireDomain=true' if you want all the aggregate
  'gettotalcount': "gettotalcount_example", // String | Specify 'gettotalcount=true' if you want the total number of elements
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFISearchPost(environment, authorizationScope, searchDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **searchDTO** | [**SearchDTO**](SearchDTO.md)| Search criteria to apply | 
 **loadEntireDomain** | **String**| Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate | [optional] 
 **gettotalcount** | **String**| Specify &#39;gettotalcount&#x3D;true&#39; if you want the total number of elements | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**GLEntryFIDTO**](GLEntryFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFISetGLEntryFromBankTransactionsMovPost

> GLEntryFIDTO apiV1EnvironmentFIGLEntryFISetGLEntryFromBankTransactionsMovPost(environment, authorizationScope, idsListFIDTO, opts)

Import bank transactions

Prepares an accounting entry from a bank movement

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let idsListFIDTO = new TseCloudFi.IdsListFIDTO(); // IdsListFIDTO | Ids to import
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFISetGLEntryFromBankTransactionsMovPost(environment, authorizationScope, idsListFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **idsListFIDTO** | [**IdsListFIDTO**](IdsListFIDTO.md)| Ids to import | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**GLEntryFIDTO**](GLEntryFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFISetGLEntryFromTsDigitalPost

> GLEntryFIDTO apiV1EnvironmentFIGLEntryFISetGLEntryFromTsDigitalPost(environment, authorizationScope, idsListFIDTO, opts)

Import TsDigital entry

Import TsDigital entry

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let idsListFIDTO = new TseCloudFi.IdsListFIDTO(); // IdsListFIDTO | Ids to import
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFISetGLEntryFromTsDigitalPost(environment, authorizationScope, idsListFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **idsListFIDTO** | [**IdsListFIDTO**](IdsListFIDTO.md)| Ids to import | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**GLEntryFIDTO**](GLEntryFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFISetGLEntryLinkedF24MovementsIdPost

> FIGLEntriesExecutionResultDTO apiV1EnvironmentFIGLEntryFISetGLEntryLinkedF24MovementsIdPost(environment, authorizationScope, setGLEntryLinkedF24MovementsIdDTO, opts)

Set GLEntry linked F24 movements

Set GLEntry linked F24 movements

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let setGLEntryLinkedF24MovementsIdDTO = new TseCloudFi.SetGLEntryLinkedF24MovementsIdDTO(); // SetGLEntryLinkedF24MovementsIdDTO | Input params
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFISetGLEntryLinkedF24MovementsIdPost(environment, authorizationScope, setGLEntryLinkedF24MovementsIdDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **setGLEntryLinkedF24MovementsIdDTO** | [**SetGLEntryLinkedF24MovementsIdDTO**](SetGLEntryLinkedF24MovementsIdDTO.md)| Input params | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIShowPDFInvoicePost

> TSPaaSShowInvoicePDFResultDTO apiV1EnvironmentFIGLEntryFIShowPDFInvoicePost(environment, authorizationScope, tSPaaSShowInvoicePDFParametersDTO, opts)

View the invoice in PDF format

The PDF format is ADEPDF or SOURCEPDF

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let tSPaaSShowInvoicePDFParametersDTO = new TseCloudFi.TSPaaSShowInvoicePDFParametersDTO(); // TSPaaSShowInvoicePDFParametersDTO | Object that contains parameters to generate PDF
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIShowPDFInvoicePost(environment, authorizationScope, tSPaaSShowInvoicePDFParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **tSPaaSShowInvoicePDFParametersDTO** | [**TSPaaSShowInvoicePDFParametersDTO**](TSPaaSShowInvoicePDFParametersDTO.md)| Object that contains parameters to generate PDF | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**TSPaaSShowInvoicePDFResultDTO**](TSPaaSShowInvoicePDFResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIStageCleanGLEntryPost

> JobStatusDTO apiV1EnvironmentFIGLEntryFIStageCleanGLEntryPost(environment, authorizationScope, stageCleanFIParametersDTO, opts)

Cleaning GLEntry and related stage tables

Queues an asynchronous job that cleans up outdated stage tables related to GLEntry and linked tables

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let stageCleanFIParametersDTO = new TseCloudFi.StageCleanFIParametersDTO(); // StageCleanFIParametersDTO | Input parameters
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIStageCleanGLEntryPost(environment, authorizationScope, stageCleanFIParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **stageCleanFIParametersDTO** | [**StageCleanFIParametersDTO**](StageCleanFIParametersDTO.md)| Input parameters | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**JobStatusDTO**](JobStatusDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIToConsolidatePost

> GLEntryFIGetLinkedEntriesFromNumregResultsDTO apiV1EnvironmentFIGLEntryFIToConsolidatePost(environment, authorizationScope, gLEntryFIToConsolidateParametersDTO, opts)

Returns all gl entries starting from a registration number.

Search for the parent registration and all related registrations of which the entered registration number is a part

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let gLEntryFIToConsolidateParametersDTO = new TseCloudFi.GLEntryFIToConsolidateParametersDTO(); // GLEntryFIToConsolidateParametersDTO | Id or registration number to find
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIToConsolidatePost(environment, authorizationScope, gLEntryFIToConsolidateParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **gLEntryFIToConsolidateParametersDTO** | [**GLEntryFIToConsolidateParametersDTO**](GLEntryFIToConsolidateParametersDTO.md)| Id or registration number to find | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**GLEntryFIGetLinkedEntriesFromNumregResultsDTO**](GLEntryFIGetLinkedEntriesFromNumregResultsDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIUpdatehubidsdiPost

> OperationResultDTO apiV1EnvironmentFIGLEntryFIUpdatehubidsdiPost(environment, authorizationScope, gLEntryFIDTO, opts)

Update CG41_HUBID and CG41_IDSDI

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let gLEntryFIDTO = new TseCloudFi.GLEntryFIDTO(); // GLEntryFIDTO | The gl entry to update
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIUpdatehubidsdiPost(environment, authorizationScope, gLEntryFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **gLEntryFIDTO** | [**GLEntryFIDTO**](GLEntryFIDTO.md)| The gl entry to update | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**OperationResultDTO**](OperationResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIValidatePost

> apiV1EnvironmentFIGLEntryFIValidatePost(environment, authorizationScope, gLEntryFIDTO, opts)

Validate

Validation of object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let gLEntryFIDTO = new TseCloudFi.GLEntryFIDTO(); // GLEntryFIDTO | Object of type to validate
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIGLEntryFIValidatePost(environment, authorizationScope, gLEntryFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **gLEntryFIDTO** | [**GLEntryFIDTO**](GLEntryFIDTO.md)| Object of type to validate | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIGLEntryFIValidatePropertiesPost

> ValidateDTO apiV1EnvironmentFIGLEntryFIValidatePropertiesPost(environment, authorizationScope, opts)

Validation of one on more properties of Type

Validation of object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.GLEntryFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'", // String | Example for multilanguage
  'body': null // String |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br>
};
apiInstance.apiV1EnvironmentFIGLEntryFIValidatePropertiesPost(environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]
 **body** | **String**|  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED&lt;br&gt; - The id of an existing object to validate properties, or &#39;&#39; if the object does not exist yet &lt;br&gt; | [optional] 

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json, application/xml

