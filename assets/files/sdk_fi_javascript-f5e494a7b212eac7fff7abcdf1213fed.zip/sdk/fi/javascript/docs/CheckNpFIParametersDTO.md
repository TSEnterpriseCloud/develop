# TseCloudFi.CheckNpFIParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**contoCg24** | **String** |  | [optional] 
**dataDoc** | **Date** |  | [optional] 
**numPartita** | **Number** |  | [optional] 
**sezPartita** | **String** |  | [optional] 
**flagPartBis** | **Number** |  | [optional] 
**numReg** | **String** |  | [optional] 
**tipoCF** | **Number** |  | [optional] 
**clifor** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


