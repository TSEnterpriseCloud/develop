# TseCloudFi.LanguageDescriptionFI

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codLinguaMg52** | **String** |  | [optional] 
**descrizione** | **String** |  | [optional] 
**iddeslin** | **Number** |  | [optional] 
**idprov** | **Number** |  | [optional] 
**provid** | **Number** |  | [optional] 
**languageCO** | [**LanguageCO**](LanguageCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


