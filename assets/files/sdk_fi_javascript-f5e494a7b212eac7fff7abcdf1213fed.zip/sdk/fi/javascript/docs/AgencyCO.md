# TseCloudFi.AgencyCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codiceAgenziaCO** | **Number** |  | [optional] 
**codiceBanca** | **Number** |  | [optional] 
**descr** | **String** |  | [optional] 
**idmediaCg99** | **Number** |  | [optional] 
**localita** | **String** |  | [optional] 
**prov** | **String** |  | [optional] 
**bankCO** | [**BankCO**](BankCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


