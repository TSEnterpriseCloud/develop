# TseCloudFi.CSPostponementPeriodCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ammgg** | **Number** |  | [optional] 
**cliforCg44** | **Number** |  | [optional] 
**dammgg** | **Number** |  | [optional] 
**dittaCg18** | **Number** |  | [optional] 
**ggmmfixslit** | **Number** |  | [optional] 
**ggslsucc** | **Number** |  | [optional] 
**id** | **Number** |  | [optional] 
**idmediaCg99** | **Number** |  | [optional] 
**indAppggfix** | **Number** |  | [optional] 
**indTiposlit** | **Number** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**tipocfCg44** | **Number** |  | [optional] 
**tipoeff** | **Number** |  | [optional] 
**parent** | [**CustomerSupplierCO**](CustomerSupplierCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


