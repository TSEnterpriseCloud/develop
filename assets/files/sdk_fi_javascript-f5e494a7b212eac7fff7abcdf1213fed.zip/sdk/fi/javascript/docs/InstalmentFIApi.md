# TseCloudFi.InstalmentFIApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiV1EnvironmentFIInstalmentFICalcexchangeratedifferencePost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFICalcexchangeratedifferencePost) | **POST** /api/v1/{environment}/FI/InstalmentFI/calcexchangeratedifference | Exchange rate difference services
[**apiV1EnvironmentFIInstalmentFIChecknumpartisusedPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIChecknumpartisusedPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/checknumpartisused | Verify Vat Number
[**apiV1EnvironmentFIInstalmentFICollectioncontrachargePost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFICollectioncontrachargePost) | **POST** /api/v1/{environment}/FI/InstalmentFI/collectioncontracharge | TODO_DOCUMENTATION
[**apiV1EnvironmentFIInstalmentFICommissionpercentageofinstalmentsPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFICommissionpercentageofinstalmentsPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/commissionpercentageofinstalments | Return a percentage to settle commissions with expired instalments
[**apiV1EnvironmentFIInstalmentFIDeletepaymentdispositionPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIDeletepaymentdispositionPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/deletepaymentdisposition | Delete a payment order or bill of exchange belonging to the order
[**apiV1EnvironmentFIInstalmentFIDeleterecessedarrangementPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIDeleterecessedarrangementPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/deleterecessedarrangement | Deletes a collection order or a draft belonging to the order
[**apiV1EnvironmentFIInstalmentFIGet**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIGet) | **GET** /api/v1/{environment}/FI/InstalmentFI | Get new
[**apiV1EnvironmentFIInstalmentFIGetlastaccountingreasonPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIGetlastaccountingreasonPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/getlastaccountingreason | Returns the last accounting reason
[**apiV1EnvironmentFIInstalmentFIGroupinginstalmentcalculationPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIGroupinginstalmentcalculationPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/groupinginstalmentcalculation | Grouping instalments calculation info
[**apiV1EnvironmentFIInstalmentFIGroupingsavestagePost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIGroupingsavestagePost) | **POST** /api/v1/{environment}/FI/InstalmentFI/groupingsavestage | The service allows the writing of the origin and destination deadlines in stages belonging to a grouping of the processing Deadlines grouping
[**apiV1EnvironmentFIInstalmentFIIdDelete**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIIdDelete) | **DELETE** /api/v1/{environment}/FI/InstalmentFI/{id} | Delete
[**apiV1EnvironmentFIInstalmentFIIdDeletenotlinkedinstalmentPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIIdDeletenotlinkedinstalmentPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/{id}/deletenotlinkedinstalment | Delete instalment not linked to GL entry
[**apiV1EnvironmentFIInstalmentFIIdGet**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIIdGet) | **GET** /api/v1/{environment}/FI/InstalmentFI/{id} | Get by ID
[**apiV1EnvironmentFIInstalmentFIIdPatch**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIIdPatch) | **PATCH** /api/v1/{environment}/FI/InstalmentFI/{id} | Update partial
[**apiV1EnvironmentFIInstalmentFIIdPut**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIIdPut) | **PUT** /api/v1/{environment}/FI/InstalmentFI/{id} | Update
[**apiV1EnvironmentFIInstalmentFIInstalmentaccountingentriesPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIInstalmentaccountingentriesPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentaccountingentries | Writing in the first note stage of the movements of past collections / payments
[**apiV1EnvironmentFIInstalmentFIInstalmentapplyremoveincomingPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIInstalmentapplyremoveincomingPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentapplyremoveincoming | Suspension or deletion of collection suspension
[**apiV1EnvironmentFIInstalmentFIInstalmentapplyremovesuspensionPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIInstalmentapplyremovesuspensionPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentapplyremovesuspension | Suspension or cancellation of suspension expiration
[**apiV1EnvironmentFIInstalmentFIInstalmentchangeexpirationdatePost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIInstalmentchangeexpirationdatePost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentchangeexpirationdate | Change maximum due date
[**apiV1EnvironmentFIInstalmentFIInstalmentdeletemanualvariationPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIInstalmentdeletemanualvariationPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentdeletemanualvariation | Deletion of manual variation of an expiration date.
[**apiV1EnvironmentFIInstalmentFIInstalmentmanualvariationPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIInstalmentmanualvariationPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentmanualvariation | Manual change of deadline
[**apiV1EnvironmentFIInstalmentFIInstalmentreissuePost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIInstalmentreissuePost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentreissue | Massive effects reissue
[**apiV1EnvironmentFIInstalmentFIInstalmentreplacecompanybankPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIInstalmentreplacecompanybankPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentreplacecompanybank | Change the corporate bank linked to the bill
[**apiV1EnvironmentFIInstalmentFIInstalmentriskanalysisbillsPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIInstalmentriskanalysisbillsPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentriskanalysisbills | Calculate bills for risck analysis from the instalments
[**apiV1EnvironmentFIInstalmentFIInstalmentsadditionalinfoPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIInstalmentsadditionalinfoPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentsadditionalinfo | Instalments additional info
[**apiV1EnvironmentFIInstalmentFIInstalmentsexchangeadditionalinfoPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIInstalmentsexchangeadditionalinfoPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/instalmentsexchangeadditionalinfo | Instalments exchange additional info
[**apiV1EnvironmentFIInstalmentFIPaymentcontrachargePost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIPaymentcontrachargePost) | **POST** /api/v1/{environment}/FI/InstalmentFI/paymentcontracharge | TODO_DOCUMENTATION
[**apiV1EnvironmentFIInstalmentFIPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIPost) | **POST** /api/v1/{environment}/FI/InstalmentFI | Create
[**apiV1EnvironmentFIInstalmentFIPrintinstalmentgroupingPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIPrintinstalmentgroupingPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/printinstalmentgrouping | Return a MailRecipientDTO for print Instalment Grouping
[**apiV1EnvironmentFIInstalmentFIReadPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIReadPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/read | Read
[**apiV1EnvironmentFIInstalmentFISaveinstalmentdispositionPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFISaveinstalmentdispositionPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/saveinstalmentdisposition | Save an arrangement and transfer the effects and the history to the real tables
[**apiV1EnvironmentFIInstalmentFISavepaymentdispositionPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFISavepaymentdispositionPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/savepaymentdisposition | Saves a disposition and the transfer of the effects and history in the real tables
[**apiV1EnvironmentFIInstalmentFISearchPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFISearchPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/search | Search
[**apiV1EnvironmentFIInstalmentFIStageinstalmentandhistoryPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIStageinstalmentandhistoryPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/stageinstalmentandhistory | Update effects and insert historical effects in the stage tables
[**apiV1EnvironmentFIInstalmentFIStagepaymentinstalmentandhistoryPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIStagepaymentinstalmentandhistoryPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/stagepaymentinstalmentandhistory | Update effects and insert historical effects in the stage tables
[**apiV1EnvironmentFIInstalmentFISuspensioncommissionliquidationPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFISuspensioncommissionliquidationPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/suspensioncommissionliquidation | Commission settlement suspension / Commission settlement suspension deletion
[**apiV1EnvironmentFIInstalmentFIUpdateallcsbankforinstalmentPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIUpdateallcsbankforinstalmentPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/updateallcsbankforinstalment | Update missing bank information
[**apiV1EnvironmentFIInstalmentFIUpdatebankinstalmentsPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIUpdatebankinstalmentsPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/updatebankinstalments | Update the CSBankCO for a list of instalments
[**apiV1EnvironmentFIInstalmentFIUpdateidbankonopeninstalmentsPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIUpdateidbankonopeninstalmentsPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/updateidbankonopeninstalments | Update idBank on open instalments. In TS10 even on Doc Table DO11_DOCTESTATA, DO79_DOCSCADENZE
[**apiV1EnvironmentFIInstalmentFIUpdateinstalmentsourceselectstatePost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIUpdateinstalmentsourceselectstatePost) | **POST** /api/v1/{environment}/FI/InstalmentFI/updateinstalmentsourceselectstate | Instalments grouping source info
[**apiV1EnvironmentFIInstalmentFIValidatePost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIValidatePost) | **POST** /api/v1/{environment}/FI/InstalmentFI/validate | Validate
[**apiV1EnvironmentFIInstalmentFIValidatePropertiesPost**](InstalmentFIApi.md#apiV1EnvironmentFIInstalmentFIValidatePropertiesPost) | **POST** /api/v1/{environment}/FI/InstalmentFI/validateProperties | Validation of one on more properties of Type



## apiV1EnvironmentFIInstalmentFICalcexchangeratedifferencePost

> ExchangeRateDifferenceResultDTO apiV1EnvironmentFIInstalmentFICalcexchangeratedifferencePost(environment, authorizationScope, exchangeRateDifferenceParametersDTO, opts)

Exchange rate difference services

Exchange rate difference services

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let exchangeRateDifferenceParametersDTO = new TseCloudFi.ExchangeRateDifferenceParametersDTO(); // ExchangeRateDifferenceParametersDTO | Object that contains all the parameters necessary for the calculation of the exchange rate difference
let opts = {
  'stage': "stage_example", // String | if the stage parameter is true (stage = true), then the exchange difference is calculated by taking the necessary values ​​from the stage tables
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFICalcexchangeratedifferencePost(environment, authorizationScope, exchangeRateDifferenceParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **exchangeRateDifferenceParametersDTO** | [**ExchangeRateDifferenceParametersDTO**](ExchangeRateDifferenceParametersDTO.md)| Object that contains all the parameters necessary for the calculation of the exchange rate difference | 
 **stage** | **String**| if the stage parameter is true (stage &#x3D; true), then the exchange difference is calculated by taking the necessary values ​​from the stage tables | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**ExchangeRateDifferenceResultDTO**](ExchangeRateDifferenceResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIChecknumpartisusedPost

> CheckNpFIResultDTO apiV1EnvironmentFIInstalmentFIChecknumpartisusedPost(environment, authorizationScope, checkNpFIParametersDTO, opts)

Verify Vat Number

Verify Vat Number

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let checkNpFIParametersDTO = new TseCloudFi.CheckNpFIParametersDTO(); // CheckNpFIParametersDTO | Object that contains all the parameters necessary for the check
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIChecknumpartisusedPost(environment, authorizationScope, checkNpFIParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **checkNpFIParametersDTO** | [**CheckNpFIParametersDTO**](CheckNpFIParametersDTO.md)| Object that contains all the parameters necessary for the check | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**CheckNpFIResultDTO**](CheckNpFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFICollectioncontrachargePost

> BankDispositionFIParamsResultDTO apiV1EnvironmentFIInstalmentFICollectioncontrachargePost(environment, authorizationScope, bankDispositionFIParamsDTO, opts)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let bankDispositionFIParamsDTO = new TseCloudFi.BankDispositionFIParamsDTO(); // BankDispositionFIParamsDTO | TODO_DOCUMENTATION
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFICollectioncontrachargePost(environment, authorizationScope, bankDispositionFIParamsDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **bankDispositionFIParamsDTO** | [**BankDispositionFIParamsDTO**](BankDispositionFIParamsDTO.md)| TODO_DOCUMENTATION | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**BankDispositionFIParamsResultDTO**](BankDispositionFIParamsResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFICommissionpercentageofinstalmentsPost

> CommissionPercentageInstalmentResultDTO apiV1EnvironmentFIInstalmentFICommissionpercentageofinstalmentsPost(environment, authorizationScope, commissionPercentageInstalmentParameterDTO, opts)

Return a percentage to settle commissions with expired instalments

Return a percentage to settle commissions with expired instalments

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let commissionPercentageInstalmentParameterDTO = new TseCloudFi.CommissionPercentageInstalmentParameterDTO(); // CommissionPercentageInstalmentParameterDTO | Input parameters
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFICommissionpercentageofinstalmentsPost(environment, authorizationScope, commissionPercentageInstalmentParameterDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **commissionPercentageInstalmentParameterDTO** | [**CommissionPercentageInstalmentParameterDTO**](CommissionPercentageInstalmentParameterDTO.md)| Input parameters | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**CommissionPercentageInstalmentResultDTO**](CommissionPercentageInstalmentResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIDeletepaymentdispositionPost

> FIGLEntriesExecutionResultDTO apiV1EnvironmentFIInstalmentFIDeletepaymentdispositionPost(environment, authorizationScope, deleteRecessedArrangementParametersDTO, opts)

Delete a payment order or bill of exchange belonging to the order

Delete a payment order or bill of exchange belonging to the order

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let deleteRecessedArrangementParametersDTO = new TseCloudFi.DeleteRecessedArrangementParametersDTO(); // DeleteRecessedArrangementParametersDTO | Object containing the necessary parameters for the service
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIDeletepaymentdispositionPost(environment, authorizationScope, deleteRecessedArrangementParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **deleteRecessedArrangementParametersDTO** | [**DeleteRecessedArrangementParametersDTO**](DeleteRecessedArrangementParametersDTO.md)| Object containing the necessary parameters for the service | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIDeleterecessedarrangementPost

> FIGLEntriesExecutionResultDTO apiV1EnvironmentFIInstalmentFIDeleterecessedarrangementPost(environment, authorizationScope, deleteRecessedArrangementParametersDTO, opts)

Deletes a collection order or a draft belonging to the order

Deletes a collection order or a draft belonging to the order

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let deleteRecessedArrangementParametersDTO = new TseCloudFi.DeleteRecessedArrangementParametersDTO(); // DeleteRecessedArrangementParametersDTO | Object containing the necessary parameters for the service
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIDeleterecessedarrangementPost(environment, authorizationScope, deleteRecessedArrangementParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **deleteRecessedArrangementParametersDTO** | [**DeleteRecessedArrangementParametersDTO**](DeleteRecessedArrangementParametersDTO.md)| Object containing the necessary parameters for the service | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIGet

> InstalmentFIDTO apiV1EnvironmentFIInstalmentFIGet(op, environment, authorizationScope, opts)

Get new

Get an empty object of type corresponding

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let op = "op_example"; // String | The value must be 'new'
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIGet(op, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **op** | **String**| The value must be &#39;new&#39; | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentFIDTO**](InstalmentFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIGetlastaccountingreasonPost

> LastAccountingReasonResultDTO apiV1EnvironmentFIInstalmentFIGetlastaccountingreasonPost(environment, authorizationScope, opts)

Returns the last accounting reason

Returns the last accounting reason

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIGetlastaccountingreasonPost(environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**LastAccountingReasonResultDTO**](LastAccountingReasonResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIGroupinginstalmentcalculationPost

> apiV1EnvironmentFIInstalmentFIGroupinginstalmentcalculationPost(environment, authorizationScope, groupingInstalmentCalculationFIParametersDTO, opts)

Grouping instalments calculation info

Grouping instalments calculation info

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let groupingInstalmentCalculationFIParametersDTO = new TseCloudFi.GroupingInstalmentCalculationFIParametersDTO(); // GroupingInstalmentCalculationFIParametersDTO | Stage id of the selected deadline
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIGroupinginstalmentcalculationPost(environment, authorizationScope, groupingInstalmentCalculationFIParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **groupingInstalmentCalculationFIParametersDTO** | [**GroupingInstalmentCalculationFIParametersDTO**](GroupingInstalmentCalculationFIParametersDTO.md)| Stage id of the selected deadline | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined


## apiV1EnvironmentFIInstalmentFIGroupingsavestagePost

> InstalmentGroupingFIResultStageDTO apiV1EnvironmentFIInstalmentFIGroupingsavestagePost(environment, authorizationScope, instalmentGroupingStageParametersFIDTO, opts)

The service allows the writing of the origin and destination deadlines in stages belonging to a grouping of the processing Deadlines grouping

The service allows the writing of the origin and destination deadlines in stages belonging to a grouping of the processing Deadlines grouping

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentGroupingStageParametersFIDTO = new TseCloudFi.InstalmentGroupingStageParametersFIDTO(); // InstalmentGroupingStageParametersFIDTO | All necessaryparameters to the service
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIGroupingsavestagePost(environment, authorizationScope, instalmentGroupingStageParametersFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentGroupingStageParametersFIDTO** | [**InstalmentGroupingStageParametersFIDTO**](InstalmentGroupingStageParametersFIDTO.md)| All necessaryparameters to the service | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentGroupingFIResultStageDTO**](InstalmentGroupingFIResultStageDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIIdDelete

> apiV1EnvironmentFIInstalmentFIIdDelete(id, environment, authorizationScope, opts)

Delete

Deleting object of type 

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIIdDelete(id, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIIdDeletenotlinkedinstalmentPost

> apiV1EnvironmentFIInstalmentFIIdDeletenotlinkedinstalmentPost(id, environment, authorizationScope, opts)

Delete instalment not linked to GL entry

Delete instalment not linked to GL entry

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIIdDeletenotlinkedinstalmentPost(id, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIIdGet

> InstalmentFIDTO apiV1EnvironmentFIInstalmentFIIdGet(id, environment, authorizationScope, opts)

Get by ID

Get an object of type corresponding the requested id

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let id = "id_example"; // String | Id to get the object
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'dlevel': "dlevel_example", // String | Serialization level
  'dlevelkey': "dlevelkey_example", // String | Serialization level key
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIIdGet(id, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Id to get the object | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **dlevel** | **String**| Serialization level | [optional] 
 **dlevelkey** | **String**| Serialization level key | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentFIDTO**](InstalmentFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIIdPatch

> apiV1EnvironmentFIInstalmentFIIdPatch(id, environment, authorizationScope, body, opts)

Update partial

Patching an object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let body = null; // Object | Object of type to patch
let opts = {
  'force': "force_example", // String | The warning/s code to bypass (separated by ‘,’) during the execution
  'op': "op_example", // String | Set 'reload', if you want the DTO updated in the response request
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIIdPatch(id, environment, authorizationScope, body, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **body** | **Object**| Object of type to patch | 
 **force** | **String**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **String**| Set &#39;reload&#39;, if you want the DTO updated in the response request | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIIdPut

> InstalmentFIDTO apiV1EnvironmentFIInstalmentFIIdPut(id, environment, authorizationScope, instalmentFIDTO, opts)

Update

Updating an object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentFIDTO = new TseCloudFi.InstalmentFIDTO(); // InstalmentFIDTO | Object of type to update
let opts = {
  'force': "force_example", // String | The warning/s code to bypass (separated by ‘,’) during the execution
  'op': "op_example", // String | Set 'reload', if you want the DTO updated in the response request, otherwise will be returned null value
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIIdPut(id, environment, authorizationScope, instalmentFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentFIDTO** | [**InstalmentFIDTO**](InstalmentFIDTO.md)| Object of type to update | 
 **force** | **String**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **String**| Set &#39;reload&#39;, if you want the DTO updated in the response request, otherwise will be returned null value | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentFIDTO**](InstalmentFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIInstalmentaccountingentriesPost

> InstalmentAccountingEntriesFIResultDTO apiV1EnvironmentFIInstalmentFIInstalmentaccountingentriesPost(environment, authorizationScope, instalmentAccountingEntriesFIParametersDTO, opts)

Writing in the first note stage of the movements of past collections / payments

Given a list of receipts / payments entries, the aggregated journal entries for OperationNumber are generated

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentAccountingEntriesFIParametersDTO = new TseCloudFi.InstalmentAccountingEntriesFIParametersDTO(); // InstalmentAccountingEntriesFIParametersDTO | Object that contains the guid to recover receipts / payments through the InstalmentDataForReceiptsAndPayments service and the registration date
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIInstalmentaccountingentriesPost(environment, authorizationScope, instalmentAccountingEntriesFIParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentAccountingEntriesFIParametersDTO** | [**InstalmentAccountingEntriesFIParametersDTO**](InstalmentAccountingEntriesFIParametersDTO.md)| Object that contains the guid to recover receipts / payments through the InstalmentDataForReceiptsAndPayments service and the registration date | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentAccountingEntriesFIResultDTO**](InstalmentAccountingEntriesFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIInstalmentapplyremoveincomingPost

> InstalmentApplyRemoveIncomingFIResultDTO apiV1EnvironmentFIInstalmentFIInstalmentapplyremoveincomingPost(environment, authorizationScope, instalmentApplyRemoveIncomingFIParametersDTO, opts)

Suspension or deletion of collection suspension

Given a list of deadlines ids, they are suspended or the suspension is canceled for the purposes for which it is possible to carry out this operation

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentApplyRemoveIncomingFIParametersDTO = new TseCloudFi.InstalmentApplyRemoveIncomingFIParametersDTO(); // InstalmentApplyRemoveIncomingFIParametersDTO | Object that contains the id of the expiration for which to carry out the suspension or cancel the suspension if possible
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIInstalmentapplyremoveincomingPost(environment, authorizationScope, instalmentApplyRemoveIncomingFIParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentApplyRemoveIncomingFIParametersDTO** | [**InstalmentApplyRemoveIncomingFIParametersDTO**](InstalmentApplyRemoveIncomingFIParametersDTO.md)| Object that contains the id of the expiration for which to carry out the suspension or cancel the suspension if possible | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentApplyRemoveIncomingFIResultDTO**](InstalmentApplyRemoveIncomingFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIInstalmentapplyremovesuspensionPost

> InstalmentApplyRemoveSuspensionFIResultDTO apiV1EnvironmentFIInstalmentFIInstalmentapplyremovesuspensionPost(environment, authorizationScope, instalmentApplyRemoveSuspensionFIParametersDTO, opts)

Suspension or cancellation of suspension expiration

Suspension or cancellation of suspension expiration

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentApplyRemoveSuspensionFIParametersDTO = new TseCloudFi.InstalmentApplyRemoveSuspensionFIParametersDTO(); // InstalmentApplyRemoveSuspensionFIParametersDTO | Object that contains the id of the expiration for which to carry out the suspension or cancellation of the suspension if possible
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIInstalmentapplyremovesuspensionPost(environment, authorizationScope, instalmentApplyRemoveSuspensionFIParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentApplyRemoveSuspensionFIParametersDTO** | [**InstalmentApplyRemoveSuspensionFIParametersDTO**](InstalmentApplyRemoveSuspensionFIParametersDTO.md)| Object that contains the id of the expiration for which to carry out the suspension or cancellation of the suspension if possible | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentApplyRemoveSuspensionFIResultDTO**](InstalmentApplyRemoveSuspensionFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIInstalmentchangeexpirationdatePost

> InstalmentChangeExpirationDateFIResultDTO apiV1EnvironmentFIInstalmentFIInstalmentchangeexpirationdatePost(environment, authorizationScope, instalmentChangeExpirationDateFIParametersDTO, opts)

Change maximum due date

Given a list of expiration ids, the expiration dates for the effects for which this operation can be performed are modified

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentChangeExpirationDateFIParametersDTO = new TseCloudFi.InstalmentChangeExpirationDateFIParametersDTO(); // InstalmentChangeExpirationDateFIParametersDTO | Object that contains the id of the deadlines for which to change the due date if possible
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIInstalmentchangeexpirationdatePost(environment, authorizationScope, instalmentChangeExpirationDateFIParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentChangeExpirationDateFIParametersDTO** | [**InstalmentChangeExpirationDateFIParametersDTO**](InstalmentChangeExpirationDateFIParametersDTO.md)| Object that contains the id of the deadlines for which to change the due date if possible | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentChangeExpirationDateFIResultDTO**](InstalmentChangeExpirationDateFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIInstalmentdeletemanualvariationPost

> InstalmentDeleteManualVariationFIResultDTO apiV1EnvironmentFIInstalmentFIInstalmentdeletemanualvariationPost(environment, authorizationScope, instalmentDeleteManualVariationParametersDTO, opts)

Deletion of manual variation of an expiration date.

Deletion of manual variation of an expiration date and restoration of the historicized data.

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentDeleteManualVariationParametersDTO = new TseCloudFi.InstalmentDeleteManualVariationParametersDTO(); // InstalmentDeleteManualVariationParametersDTO | Object that contains the id of the expiration that contains the history to be deleted and the id of the real history to be deleted
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIInstalmentdeletemanualvariationPost(environment, authorizationScope, instalmentDeleteManualVariationParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentDeleteManualVariationParametersDTO** | [**InstalmentDeleteManualVariationParametersDTO**](InstalmentDeleteManualVariationParametersDTO.md)| Object that contains the id of the expiration that contains the history to be deleted and the id of the real history to be deleted | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentDeleteManualVariationFIResultDTO**](InstalmentDeleteManualVariationFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIInstalmentmanualvariationPost

> InstalmentManualVariationFIResultDTO apiV1EnvironmentFIInstalmentFIInstalmentmanualvariationPost(environment, authorizationScope, instalmentFIDTO, opts)

Manual change of deadline

Manual variation of a deadline and data logging if required

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentFIDTO = new TseCloudFi.InstalmentFIDTO(); // InstalmentFIDTO | Object that contains all the necessary parameters
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIInstalmentmanualvariationPost(environment, authorizationScope, instalmentFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentFIDTO** | [**InstalmentFIDTO**](InstalmentFIDTO.md)| Object that contains all the necessary parameters | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentManualVariationFIResultDTO**](InstalmentManualVariationFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIInstalmentreissuePost

> InstalmentReissueResultDTO apiV1EnvironmentFIInstalmentFIInstalmentreissuePost(environment, authorizationScope, instalmentReissueParameterDTO, opts)

Massive effects reissue

Given a list of bill of exchange ids and an expiration date, the bills for which it is possible to perform this operation are reissued

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentReissueParameterDTO = new TseCloudFi.InstalmentReissueParameterDTO(); // InstalmentReissueParameterDTO | Object that contains all the parameters needed to reissue bills for an expiration date
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIInstalmentreissuePost(environment, authorizationScope, instalmentReissueParameterDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentReissueParameterDTO** | [**InstalmentReissueParameterDTO**](InstalmentReissueParameterDTO.md)| Object that contains all the parameters needed to reissue bills for an expiration date | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentReissueResultDTO**](InstalmentReissueResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIInstalmentreplacecompanybankPost

> InstalmentReplaceCompanyBankFIResultDTO apiV1EnvironmentFIInstalmentFIInstalmentreplacecompanybankPost(environment, authorizationScope, instalmentReplaceCompanyBankFIParametersDTO, opts)

Change the corporate bank linked to the bill

Given a list of id of bills, the company banks are modified for the bills for which it is possible to carry out this operation

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentReplaceCompanyBankFIParametersDTO = new TseCloudFi.InstalmentReplaceCompanyBankFIParametersDTO(); // InstalmentReplaceCompanyBankFIParametersDTO | Object that contains the id of the effects to be modified, id of the old connected corporate banks and id of the new corporate banks
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIInstalmentreplacecompanybankPost(environment, authorizationScope, instalmentReplaceCompanyBankFIParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentReplaceCompanyBankFIParametersDTO** | [**InstalmentReplaceCompanyBankFIParametersDTO**](InstalmentReplaceCompanyBankFIParametersDTO.md)| Object that contains the id of the effects to be modified, id of the old connected corporate banks and id of the new corporate banks | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentReplaceCompanyBankFIResultDTO**](InstalmentReplaceCompanyBankFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIInstalmentriskanalysisbillsPost

> InstalmentRiskAnalysisBillsResultDTO apiV1EnvironmentFIInstalmentFIInstalmentriskanalysisbillsPost(environment, authorizationScope, instalmentRiskAnalysisBillsParametersDTO, opts)

Calculate bills for risck analysis from the instalments

Calculate bills for risck analysis from the instalments using DAL statement

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentRiskAnalysisBillsParametersDTO = new TseCloudFi.InstalmentRiskAnalysisBillsParametersDTO(); // InstalmentRiskAnalysisBillsParametersDTO | Object containing the parameters necessary for editing effects
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIInstalmentriskanalysisbillsPost(environment, authorizationScope, instalmentRiskAnalysisBillsParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentRiskAnalysisBillsParametersDTO** | [**InstalmentRiskAnalysisBillsParametersDTO**](InstalmentRiskAnalysisBillsParametersDTO.md)| Object containing the parameters necessary for editing effects | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentRiskAnalysisBillsResultDTO**](InstalmentRiskAnalysisBillsResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIInstalmentsadditionalinfoPost

> InstalmentsAdditionalInfoResultDTO apiV1EnvironmentFIInstalmentFIInstalmentsadditionalinfoPost(environment, authorizationScope, instalmentsAdditionalInfoParametersDTO, opts)

Instalments additional info

Instalments additional info

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentsAdditionalInfoParametersDTO = new TseCloudFi.InstalmentsAdditionalInfoParametersDTO(); // InstalmentsAdditionalInfoParametersDTO | Object that contains all the necessary parameters
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIInstalmentsadditionalinfoPost(environment, authorizationScope, instalmentsAdditionalInfoParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentsAdditionalInfoParametersDTO** | [**InstalmentsAdditionalInfoParametersDTO**](InstalmentsAdditionalInfoParametersDTO.md)| Object that contains all the necessary parameters | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentsAdditionalInfoResultDTO**](InstalmentsAdditionalInfoResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIInstalmentsexchangeadditionalinfoPost

> InstalmentsExchangeAdditionalInfoResultDTO apiV1EnvironmentFIInstalmentFIInstalmentsexchangeadditionalinfoPost(environment, authorizationScope, instalmentsExchangeAdditionalInfoParametersDTO, opts)

Instalments exchange additional info

Instalments exchange additional info

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentsExchangeAdditionalInfoParametersDTO = new TseCloudFi.InstalmentsExchangeAdditionalInfoParametersDTO(); // InstalmentsExchangeAdditionalInfoParametersDTO | Stage id of the selected deadline
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIInstalmentsexchangeadditionalinfoPost(environment, authorizationScope, instalmentsExchangeAdditionalInfoParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentsExchangeAdditionalInfoParametersDTO** | [**InstalmentsExchangeAdditionalInfoParametersDTO**](InstalmentsExchangeAdditionalInfoParametersDTO.md)| Stage id of the selected deadline | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentsExchangeAdditionalInfoResultDTO**](InstalmentsExchangeAdditionalInfoResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIPaymentcontrachargePost

> BankDispositionFIParamsResultDTO apiV1EnvironmentFIInstalmentFIPaymentcontrachargePost(environment, authorizationScope, bankDispositionFIParamsDTO, opts)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let bankDispositionFIParamsDTO = new TseCloudFi.BankDispositionFIParamsDTO(); // BankDispositionFIParamsDTO | TODO_DOCUMENTATION
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIPaymentcontrachargePost(environment, authorizationScope, bankDispositionFIParamsDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **bankDispositionFIParamsDTO** | [**BankDispositionFIParamsDTO**](BankDispositionFIParamsDTO.md)| TODO_DOCUMENTATION | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**BankDispositionFIParamsResultDTO**](BankDispositionFIParamsResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIPost

> InstalmentFIDTO apiV1EnvironmentFIInstalmentFIPost(environment, authorizationScope, instalmentFIDTO, opts)

Create

Creating new object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentFIDTO = new TseCloudFi.InstalmentFIDTO(); // InstalmentFIDTO | Object of type to create
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIPost(environment, authorizationScope, instalmentFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentFIDTO** | [**InstalmentFIDTO**](InstalmentFIDTO.md)| Object of type to create | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentFIDTO**](InstalmentFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIPrintinstalmentgroupingPost

> MailRecipientDTO apiV1EnvironmentFIInstalmentFIPrintinstalmentgroupingPost(environment, authorizationScope, groupingIdParametersDTO, opts)

Return a MailRecipientDTO for print Instalment Grouping

Print Instalment Grouping

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let groupingIdParametersDTO = new TseCloudFi.GroupingIdParametersDTO(); // GroupingIdParametersDTO | Input parameters
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIPrintinstalmentgroupingPost(environment, authorizationScope, groupingIdParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **groupingIdParametersDTO** | [**GroupingIdParametersDTO**](GroupingIdParametersDTO.md)| Input parameters | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**MailRecipientDTO**](MailRecipientDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIReadPost

> InstalmentFIDTO apiV1EnvironmentFIInstalmentFIReadPost(environment, authorizationScope, searchElementDTO, opts)

Read

Read among object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let searchElementDTO = [new TseCloudFi.SearchElementDTO()]; // [SearchElementDTO] | Search criteria to apply
let opts = {
  'dlevel': "dlevel_example", // String | Serialization level
  'dlevelkey': "dlevelkey_example", // String | Serialization level key
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIReadPost(environment, authorizationScope, searchElementDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **searchElementDTO** | [**[SearchElementDTO]**](SearchElementDTO.md)| Search criteria to apply | 
 **dlevel** | **String**| Serialization level | [optional] 
 **dlevelkey** | **String**| Serialization level key | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentFIDTO**](InstalmentFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFISaveinstalmentdispositionPost

> SaveInstalmentDispositionResultDTO apiV1EnvironmentFIInstalmentFISaveinstalmentdispositionPost(environment, authorizationScope, saveInstalmentDispositionParametersDTO, opts)

Save an arrangement and transfer the effects and the history to the real tables

Save an arrangement and transfer the effects and the history to the real tables

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let saveInstalmentDispositionParametersDTO = new TseCloudFi.SaveInstalmentDispositionParametersDTO(); // SaveInstalmentDispositionParametersDTO | Object containing the necessary parameters for the service
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFISaveinstalmentdispositionPost(environment, authorizationScope, saveInstalmentDispositionParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **saveInstalmentDispositionParametersDTO** | [**SaveInstalmentDispositionParametersDTO**](SaveInstalmentDispositionParametersDTO.md)| Object containing the necessary parameters for the service | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**SaveInstalmentDispositionResultDTO**](SaveInstalmentDispositionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFISavepaymentdispositionPost

> SavePaymentDispositionResultDTO apiV1EnvironmentFIInstalmentFISavepaymentdispositionPost(environment, authorizationScope, savePaymentDispositionParametersDTO, opts)

Saves a disposition and the transfer of the effects and history in the real tables

Saves a disposition and the transfer of the effects and history in the real tables

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let savePaymentDispositionParametersDTO = new TseCloudFi.SavePaymentDispositionParametersDTO(); // SavePaymentDispositionParametersDTO | Object containing the necessary parameters for the service
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFISavepaymentdispositionPost(environment, authorizationScope, savePaymentDispositionParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **savePaymentDispositionParametersDTO** | [**SavePaymentDispositionParametersDTO**](SavePaymentDispositionParametersDTO.md)| Object containing the necessary parameters for the service | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**SavePaymentDispositionResultDTO**](SavePaymentDispositionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFISearchPost

> InstalmentFIDTO apiV1EnvironmentFIInstalmentFISearchPost(environment, authorizationScope, searchDTO, opts)

Search

Search among object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let searchDTO = new TseCloudFi.SearchDTO(); // SearchDTO | Search criteria to apply
let opts = {
  'loadEntireDomain': "loadEntireDomain_example", // String | Specify 'loadEntireDomain=true' if you want all the aggregate
  'getTotalCount': "getTotalCount_example", // String | Specify 'getTotalCount=true' if you want the total number of elements
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFISearchPost(environment, authorizationScope, searchDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **searchDTO** | [**SearchDTO**](SearchDTO.md)| Search criteria to apply | 
 **loadEntireDomain** | **String**| Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate | [optional] 
 **getTotalCount** | **String**| Specify &#39;getTotalCount&#x3D;true&#39; if you want the total number of elements | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentFIDTO**](InstalmentFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIStageinstalmentandhistoryPost

> StageInstalmentAndHistoryResultDTO apiV1EnvironmentFIInstalmentFIStageinstalmentandhistoryPost(environment, authorizationScope, stageInstalmentAndHistoryParametersDTO, opts)

Update effects and insert historical effects in the stage tables

Update effects and insert historical effects in the stage tables

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let stageInstalmentAndHistoryParametersDTO = new TseCloudFi.StageInstalmentAndHistoryParametersDTO(); // StageInstalmentAndHistoryParametersDTO | Object containing the necessary parameters for the service
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIStageinstalmentandhistoryPost(environment, authorizationScope, stageInstalmentAndHistoryParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **stageInstalmentAndHistoryParametersDTO** | [**StageInstalmentAndHistoryParametersDTO**](StageInstalmentAndHistoryParametersDTO.md)| Object containing the necessary parameters for the service | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**StageInstalmentAndHistoryResultDTO**](StageInstalmentAndHistoryResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIStagepaymentinstalmentandhistoryPost

> StageInstalmentAndHistoryPaymentResultDTO apiV1EnvironmentFIInstalmentFIStagepaymentinstalmentandhistoryPost(environment, authorizationScope, stagePaymentInstalmentAndHistoryParametersDTO, opts)

Update effects and insert historical effects in the stage tables

Update effects and insert historical effects in the stage tables

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let stagePaymentInstalmentAndHistoryParametersDTO = new TseCloudFi.StagePaymentInstalmentAndHistoryParametersDTO(); // StagePaymentInstalmentAndHistoryParametersDTO | Object containing the necessary parameters for the service
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIStagepaymentinstalmentandhistoryPost(environment, authorizationScope, stagePaymentInstalmentAndHistoryParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **stagePaymentInstalmentAndHistoryParametersDTO** | [**StagePaymentInstalmentAndHistoryParametersDTO**](StagePaymentInstalmentAndHistoryParametersDTO.md)| Object containing the necessary parameters for the service | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**StageInstalmentAndHistoryPaymentResultDTO**](StageInstalmentAndHistoryPaymentResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFISuspensioncommissionliquidationPost

> InstalmentSuspensionCommissionLiquidationResultDTO apiV1EnvironmentFIInstalmentFISuspensioncommissionliquidationPost(environment, authorizationScope, instalmentSuspensionCommissionLiquidationParameterDTO, opts)

Commission settlement suspension / Commission settlement suspension deletion

The service allows you to activate or disable the Suspension of commission settlement, massively on a series of selected bills

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentSuspensionCommissionLiquidationParameterDTO = new TseCloudFi.InstalmentSuspensionCommissionLiquidationParameterDTO(); // InstalmentSuspensionCommissionLiquidationParameterDTO | Object that contains all the parameters necessary to perform the operation
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFISuspensioncommissionliquidationPost(environment, authorizationScope, instalmentSuspensionCommissionLiquidationParameterDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentSuspensionCommissionLiquidationParameterDTO** | [**InstalmentSuspensionCommissionLiquidationParameterDTO**](InstalmentSuspensionCommissionLiquidationParameterDTO.md)| Object that contains all the parameters necessary to perform the operation | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentSuspensionCommissionLiquidationResultDTO**](InstalmentSuspensionCommissionLiquidationResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIUpdateallcsbankforinstalmentPost

> UpdateAllCSBankForInstalmentResultDTO apiV1EnvironmentFIInstalmentFIUpdateallcsbankforinstalmentPost(environment, authorizationScope, updateAllCSBankForInstalmentParametersDTO, opts)

Update missing bank information

Updating of the bank of an effect or all the effects belonging to the same registry

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let updateAllCSBankForInstalmentParametersDTO = new TseCloudFi.UpdateAllCSBankForInstalmentParametersDTO(); // UpdateAllCSBankForInstalmentParametersDTO | Object containing the parameters necessary for editing effects
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIUpdateallcsbankforinstalmentPost(environment, authorizationScope, updateAllCSBankForInstalmentParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **updateAllCSBankForInstalmentParametersDTO** | [**UpdateAllCSBankForInstalmentParametersDTO**](UpdateAllCSBankForInstalmentParametersDTO.md)| Object containing the parameters necessary for editing effects | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**UpdateAllCSBankForInstalmentResultDTO**](UpdateAllCSBankForInstalmentResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIUpdatebankinstalmentsPost

> UpdateAllCSBankForInstalmentResultDTO apiV1EnvironmentFIInstalmentFIUpdatebankinstalmentsPost(environment, authorizationScope, updateBankInstalmentsParametersDTO, opts)

Update the CSBankCO for a list of instalments

Update the CSBankCO for a list of instalments

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let updateBankInstalmentsParametersDTO = new TseCloudFi.UpdateBankInstalmentsParametersDTO(); // UpdateBankInstalmentsParametersDTO | Input parameters
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIUpdatebankinstalmentsPost(environment, authorizationScope, updateBankInstalmentsParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **updateBankInstalmentsParametersDTO** | [**UpdateBankInstalmentsParametersDTO**](UpdateBankInstalmentsParametersDTO.md)| Input parameters | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**UpdateAllCSBankForInstalmentResultDTO**](UpdateAllCSBankForInstalmentResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIUpdateidbankonopeninstalmentsPost

> UpdateAllCSBankForInstalmentResultDTO apiV1EnvironmentFIInstalmentFIUpdateidbankonopeninstalmentsPost(environment, authorizationScope, updateIdBankOnOpenInstalmentsParametersDTO, opts)

Update idBank on open instalments. In TS10 even on Doc Table DO11_DOCTESTATA, DO79_DOCSCADENZE

Update idBank on open instalments using DAL statement. In TS10 even on Doc Table DO11_DOCTESTATA, DO79_DOCSCADENZE. This

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let updateIdBankOnOpenInstalmentsParametersDTO = new TseCloudFi.UpdateIdBankOnOpenInstalmentsParametersDTO(); // UpdateIdBankOnOpenInstalmentsParametersDTO | Object containing the parameters necessary for editing effects
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIUpdateidbankonopeninstalmentsPost(environment, authorizationScope, updateIdBankOnOpenInstalmentsParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **updateIdBankOnOpenInstalmentsParametersDTO** | [**UpdateIdBankOnOpenInstalmentsParametersDTO**](UpdateIdBankOnOpenInstalmentsParametersDTO.md)| Object containing the parameters necessary for editing effects | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**UpdateAllCSBankForInstalmentResultDTO**](UpdateAllCSBankForInstalmentResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIUpdateinstalmentsourceselectstatePost

> apiV1EnvironmentFIInstalmentFIUpdateinstalmentsourceselectstatePost(environment, authorizationScope, sourceSelectionStateDTO, opts)

Instalments grouping source info

Update of selection flag on deadlines by grouping

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let sourceSelectionStateDTO = new TseCloudFi.SourceSelectionStateDTO(); // SourceSelectionStateDTO | Parameters required to update the selection flag of a grouping deadline
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIUpdateinstalmentsourceselectstatePost(environment, authorizationScope, sourceSelectionStateDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **sourceSelectionStateDTO** | [**SourceSelectionStateDTO**](SourceSelectionStateDTO.md)| Parameters required to update the selection flag of a grouping deadline | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIValidatePost

> apiV1EnvironmentFIInstalmentFIValidatePost(environment, authorizationScope, instalmentFIDTO, opts)

Validate

Validation of object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentFIDTO = new TseCloudFi.InstalmentFIDTO(); // InstalmentFIDTO | Object of type to validate
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentFIValidatePost(environment, authorizationScope, instalmentFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentFIDTO** | [**InstalmentFIDTO**](InstalmentFIDTO.md)| Object of type to validate | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentFIValidatePropertiesPost

> ValidateDTO apiV1EnvironmentFIInstalmentFIValidatePropertiesPost(environment, authorizationScope, opts)

Validation of one on more properties of Type

Validation of object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'", // String | Example for multilanguage
  'body': null // String |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br>
};
apiInstance.apiV1EnvironmentFIInstalmentFIValidatePropertiesPost(environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]
 **body** | **String**|  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED&lt;br&gt; - The id of an existing object to validate properties, or &#39;&#39; if the object does not exist yet &lt;br&gt; | [optional] 

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json, application/xml

