# TseCloudFi.CSPostponementPeriodCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ammgg** | **Number** | MG21_AMMGG - A gg/mm | 
**cliforCg44** | **Number** | MG21_CLIFOR_CG44 - Codice Cliente / Fornitore | 
**dammgg** | **Number** | MG21_DAMMGG - Da gg/mm | 
**dittaCg18** | **Number** | MG21_DITTA_CG18 - DittaCg18 | 
**ggmmfixslit** | **Number** | MG21_GGMMFIXSLIT - gg/mm scad. | [optional] 
**ggslsucc** | **Number** | MG21_GGSLSUCC - gg slittamento scad. successiva | [optional] 
**id** | **Number** | MG21_ID - Id (Required only in PUT/PATCH) | [optional] 
**idmediaCg99** | **Number** | MG21_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**indAppggfix** | **Number** | MG21_INDAPPGGFIX - IndAppggfix | [optional] 
**indTiposlit** | **Number** | MG21_INDTIPOSLIT - Tipo slittamento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - 1° giorno dopo limite superiore&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - 1° giorno mese successivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Stesso giorno scadenza al mese successivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Giorno fisso&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Somma alla rata del mese successivo&lt;/li&gt;&lt;/ul&gt; | [optional] 
**tipocfCg44** | **Number** | MG21_TIPOCF_CG44 - Tipo Cliente / Fornitore | 
**tipoeff** | **Number** | MG21_TIPOEFF - Tipo effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Contrassegno&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Leasing&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Lettera di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - MAV&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Ricevuta bancaria&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - SDD&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Rimessa diretta&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Tratta&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Tratta accettata&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Bancomat&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Bonifico Bancario&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Cambiale&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Carta di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - C/C postale&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Cessione&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Contanti&lt;/li&gt;&lt;/ul&gt; | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndTiposlitEnum


* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)





## Enum: TipoeffEnum


* `9` (value: `9`)

* `12` (value: `12`)

* `10` (value: `10`)

* `16` (value: `16`)

* `2` (value: `2`)

* `11` (value: `11`)

* `13` (value: `13`)

* `3` (value: `3`)

* `4` (value: `4`)

* `8` (value: `8`)

* `14` (value: `14`)

* `6` (value: `6`)

* `7` (value: `7`)

* `15` (value: `15`)

* `5` (value: `5`)

* `1` (value: `1`)




