# TseCloudFi.CurrencyCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cambiofisso** | **Number** |  | [optional] 
**codice** | **String** |  | [optional] 
**dataattuem** | **Date** |  | [optional] 
**descr** | **String** |  | [optional] 
**flgValuem** | **Number** |  | [optional] 
**idmediaCg99** | **Number** |  | [optional] 
**indCertoincerto** | **Number** |  | [optional] 
**indSepmigl** | **Number** |  | [optional] 
**indValuem** | **Number** |  | [optional] 
**numdec** | **Number** |  | [optional] 
**sigla** | **String** |  | [optional] 
**exchangeRateCO** | [**[ExchangeRateCO]**](ExchangeRateCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


