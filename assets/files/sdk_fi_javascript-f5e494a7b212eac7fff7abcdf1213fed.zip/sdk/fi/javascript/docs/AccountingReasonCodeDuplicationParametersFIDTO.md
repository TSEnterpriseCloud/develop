# TseCloudFi.AccountingReasonCodeDuplicationParametersFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sourceAccountingReasonCode** | **String** |  | [optional] 
**targetAccountingReasonCode** | **String** |  | [optional] 
**targetAccountingReasonCodeDescription** | **String** |  | [optional] 
**isDuplLangDescriptions** | **Boolean** |  | [optional] 
**isDuplExtendedAttribute** | **Boolean** |  | [optional] 
**isDuplAccountingReasonCodeProposal** | **Boolean** |  | [optional] 


