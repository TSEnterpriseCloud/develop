# TseCloudFi.RetrieveCurrenciesOfExchangeRatesAdjParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exchangeType** | **Number** |  | [optional] 
**endYearDate** | **Date** |  | [optional] 
**isSimulation** | **Boolean** |  | [optional] 
**customersAdjustment** | **Boolean** |  | [optional] 
**suppliersAdjustment** | **Boolean** |  | [optional] 
**activeAccountsAdjustment** | **Boolean** |  | [optional] 
**passiveAccountsAdjustment** | **Boolean** |  | [optional] 
**includeEstablishedTransactions** | **Boolean** |  | [optional] 
**includeNotEstablishedTransactions** | **Boolean** |  | [optional] 
**includeProjectedTransactions** | **Boolean** |  | [optional] 
**officeCode** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


