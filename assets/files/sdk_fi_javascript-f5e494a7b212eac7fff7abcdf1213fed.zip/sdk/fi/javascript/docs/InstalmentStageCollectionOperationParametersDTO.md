# TseCloudFi.InstalmentStageCollectionOperationParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stageGuid** | **String** |  | [optional] 
**numreg** | **String** |  | [optional] 


