# TseCloudFi.InstalmentNoteFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | EF04_ID - ID note (Required only in PUT/PATCH) | [optional] 
**idEf01** | **Number** | EF04_ID_EF01 - Id Scadenza | 
**idmediaCg99** | **Number** | EF04_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**noteammin** | **String** | EF04_NOTEAMMIN - Note amministrazione | [optional] 
**noteraggr** | **String** | EF04_NOTERAGGR - Note raggruppamento effetti | [optional] 
**rowversion** | **Blob** | EF04_ROWVERSION - RowVersion | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


