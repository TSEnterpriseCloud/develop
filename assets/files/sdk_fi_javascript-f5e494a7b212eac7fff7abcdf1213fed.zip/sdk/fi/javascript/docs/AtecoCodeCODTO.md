# TseCloudFi.AtecoCodeCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codice** | **String** | CG6A_CODICE - Codice | 
**descriz** | **String** | CG6A_DESCRIZ - Descrizione | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


