# TseCloudFi.GLEntryFIMultipleCreateErrorMessagesDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**externalRif** | **String** |  | [optional] 
**message** | [**GLEntryFIMultipleCreateValidateMessageDTO**](GLEntryFIMultipleCreateValidateMessageDTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


