# TseCloudFi.B2BVatCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aliquota** | **Number** | IE87_ALIQUOTA - Aliquota | [optional] 
**aswcodiva** | **String** | IE87_ASWCODIVA - Aswcodiva | [optional] 
**codArtL** | **String** | IE87_CODART_L - CodArtL | [optional] 
**codIvaCg28** | **String** | IE87_CODIVA_CG28 - CodIvaCg28 | [optional] 
**codSedeCg31** | **Number** | IE87_CODSEDE_CG31 - CodSedeCg31 | [optional] 
**contoCg24** | **String** | IE87_CONTO_CG24 - ContoCg24 | [optional] 
**datafincomp** | **Date** | IE87_DATAFINCOMP - Datafincomp | [optional] 
**datainicomp** | **Date** | IE87_DATAINICOMP - Datainicomp | [optional] 
**descragg** | **String** | IE87_DESCRAGG - Descragg | [optional] 
**descrizioneL** | **String** | IE87_DESCRIZIONE_L - DescrizioneL | [optional] 
**esigibilita** | **String** | IE87_ESIGIBILITA - Esigibilita | [optional] 
**gruppoCg10** | **Number** | IE87_GRUPPO_CG10 - GruppoCg10 | [optional] 
**id** | **Number** | IE87_ID - Id (Required only in PUT/PATCH) | [optional] 
**idIe84** | **Number** | IE87_ID_IE84 - IdIe84 | 
**imponibile** | **Number** | IE87_IMPONIBILE - Imponibile | [optional] 
**imponibileVal** | **Number** | IE87_IMPONIBILE_VAL - ImponibileVal | [optional] 
**imposta** | **Number** | IE87_IMPOSTA - Imposta | [optional] 
**impostand** | **Number** | IE87_IMPOSTAND - Impostand | [optional] 
**impostandVal** | **Number** | IE87_IMPOSTAND_VAL - ImpostandVal | [optional] 
**impostaVal** | **Number** | IE87_IMPOSTA_VAL - ImpostaVal | [optional] 
**naturaL** | **String** | IE87_NATURA_L - NaturaL | [optional] 
**numLineaL** | **String** | IE87_NUMLINEA_L - NumLineaL | [optional] 
**ritenutaL** | **String** | IE87_RITENUTA_L - RitenutaL | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


