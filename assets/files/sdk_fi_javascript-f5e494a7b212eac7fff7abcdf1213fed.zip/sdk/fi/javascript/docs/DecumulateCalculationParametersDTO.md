# TseCloudFi.DecumulateCalculationParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **Number** |  | [optional] 
**percentage** | **Number** |  | [optional] 
**percentageNd** | **Number** |  | [optional] 
**vatCode** | **String** |  | [optional] 
**operationType** | **Number** |  | [optional] 
**rowIdStage** | **Number** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**currency** | **String** |  | [optional] 
**dataCambio** | **Date** |  | [optional] 
**cambio** | **Number** |  | [optional] 


