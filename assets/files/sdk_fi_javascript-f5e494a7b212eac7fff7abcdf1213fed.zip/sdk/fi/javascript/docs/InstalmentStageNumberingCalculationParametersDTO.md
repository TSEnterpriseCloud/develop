# TseCloudFi.InstalmentStageNumberingCalculationParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stageGuid** | **String** |  | [optional] 
**anno** | **Number** |  | [optional] 
**sez** | **String** |  | [optional] 
**tipodocint** | **Number** |  | [optional] 
**data** | **Date** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


