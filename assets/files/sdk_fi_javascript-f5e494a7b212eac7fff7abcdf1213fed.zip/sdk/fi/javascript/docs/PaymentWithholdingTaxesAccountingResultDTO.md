# TseCloudFi.PaymentWithholdingTaxesAccountingResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descriptionResult** | **String** |  | [optional] 
**result** | **Number** |  | [optional] 
**glEntryId** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


