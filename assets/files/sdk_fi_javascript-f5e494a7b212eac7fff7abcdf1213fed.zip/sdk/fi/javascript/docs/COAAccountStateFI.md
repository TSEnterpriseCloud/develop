# TseCloudFi.COAAccountStateFI

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**consosCg24** | **String** |  | [optional] 
**contoCg24** | **String** |  | [optional] 
**dittaCg18** | **Number** |  | [optional] 
**dtconsos** | **Date** |  | [optional] 
**dtdisatt** | **Date** |  | [optional] 
**flgDisatt** | **Number** |  | [optional] 
**gruppoCg10** | **Number** |  | [optional] 
**grusosCg10** | **Number** |  | [optional] 
**idCg24** | **Number** |  | [optional] 
**idstatipdc** | **Number** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**parent** | [**COAAccountFI**](COAAccountFI.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


