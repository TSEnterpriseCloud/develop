# TseCloudFi.InstalmentCalculationResultFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | **Boolean** |  | [optional] 
**elements** | [**[InstalmentCalculationResultElementDTO]**](InstalmentCalculationResultElementDTO.md) |  | [optional] [readonly] 
**codPagUtilizzato** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


