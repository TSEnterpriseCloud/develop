# TseCloudFi.NationCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**a2iso3166** | **String** |  | [optional] 
**a3iso3166** | **String** |  | [optional] 
**codice** | **Number** |  | [optional] 
**codiceCg08** | **String** |  | [optional] 
**codIso** | **String** |  | [optional] 
**codSian** | **Number** |  | [optional] 
**crtpiva** | **String** |  | [optional] 
**datacee** | **Date** |  | [optional] 
**datafinblacklist** | **Date** |  | [optional] 
**datainiblacklist** | **Date** |  | [optional] 
**descr** | **String** |  | [optional] 
**desiso3166** | **String** |  | [optional] 
**flgIban** | **Number** |  | [optional] 
**flgSepa** | **Number** |  | [optional] 
**idmediaCg99** | **Number** |  | [optional] 
**indTipostato** | **Number** |  | [optional] 
**leniban** | **Number** |  | [optional] 
**numiso3166** | **String** |  | [optional] 
**currencyCO** | [**CurrencyCO**](CurrencyCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


