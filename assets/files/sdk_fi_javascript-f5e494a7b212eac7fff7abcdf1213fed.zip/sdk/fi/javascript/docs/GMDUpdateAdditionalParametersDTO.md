# TseCloudFi.GMDUpdateAdditionalParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codice** | **Number** |  | [optional] 
**ragSoAnag** | **String** |  | [optional] 
**indirizzo** | **String** |  | [optional] 
**numCiv** | **String** |  | [optional] 
**cap** | **String** |  | [optional] 
**citta** | **String** |  | [optional] 
**prov** | **String** |  | [optional] 
**codiceCg07** | **Number** |  | [optional] 
**partiva** | **String** |  | [optional] 
**codFiscale** | **String** |  | [optional] 
**tel1Num** | **String** |  | [optional] 
**fax** | **String** |  | [optional] 
**tipologia** | **String** |  | [optional] 
**codLegCg01** | **String** |  | [optional] 
**descrCg07** | **String** |  | [optional] 
**nationIso** | **String** |  | [optional] 


