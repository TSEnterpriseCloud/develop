# TseCloudFi.FinanceCompanySectionalProposalCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sezionale** | **String** |  | [optional] 
**pagregvenglob** | **Number** |  | [optional] 
**pagregven** | **Number** |  | [optional] 
**pagregunicanal** | **Number** |  | [optional] 
**pagregcor** | **Number** |  | [optional] 
**pagregacqglob** | **Number** |  | [optional] 
**pagregacq** | **Number** |  | [optional] 
**idmediaCg99** | **Number** |  | [optional] 
**dittaCg18** | **Number** |  | [optional] 
**anno** | **Number** |  | [optional] 
**idattivitaCg86** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


