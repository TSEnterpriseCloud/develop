# TseCloudFi.UpdateCustomAndLanguageDescriptionsParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountId** | **Number** |  | [optional] 
**languageDescription** | **String** |  | [optional] 
**customDescription** | **String** |  | [optional] 
**customLanguageDescription** | **String** |  | [optional] 
**languageCode** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


