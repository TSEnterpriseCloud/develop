# TseCloudFi.InstalmentRiskAnalysisBillsParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**riskElabId** | **Number** |  | [optional] 
**elabDate** | **Date** |  | [optional] 
**idcliforCg44** | **Number** |  | [optional] 
**indBillDateType** | **Number** |  | [optional] 
**billMonthsNumber** | **Number** |  | [optional] 
**startBillDate** | **Date** |  | [optional] 
**flgConsolidBill** | **Number** |  | [optional] 
**flgToConsolidBill** | **Number** |  | [optional] 
**flgEstimatedBill** | **Number** |  | [optional] 
**flgBillNoAmount** | **Number** |  | [optional] 
**indBillForDelay** | **Number** |  | [optional] 
**indAllBillsCalcType** | **Number** |  | [optional] 
**indOpenedBillsCalcType** | **Number** |  | [optional] 
**indClosedBillsCalcType** | **Number** |  | [optional] 
**minAmountForUnsolved** | **Number** |  | [optional] 
**minAmountForDelay** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


