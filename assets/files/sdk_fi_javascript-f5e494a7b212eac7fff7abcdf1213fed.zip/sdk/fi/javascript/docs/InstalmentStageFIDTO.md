# TseCloudFi.InstalmentStageFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idExtendedAttributeEntity** | **Number** |  | [optional] 
**idExtendedAttributeSubEntity** | **Number** |  | [optional] 
**agenappCg13** | **Number** | EF01_AGENAPP_CG13 - Agenzia d&#39;appoggio | [optional] 
**agenpreScg13** | **Number** | EF01_AGENPRE_SCG13 - Agenzia di presentazione | [optional] 
**annopart** | **Number** | EF01_ANNOPART - Anno partita | [optional] 
**bancaappCg12** | **Number** | EF01_BANCAAPP_CG12 - Banca d&#39;appoggio | [optional] 
**bancapreScg12** | **Number** | EF01_BANCAPRE_SCG12 - Banca di presentazione | [optional] 
**bolli** | **Number** | EF01_BOLLI - Importo bolli in EURO | [optional] 
**bollival** | **Number** | EF01_BOLLIVAL - Importo bolli in valuta | [optional] 
**cambio** | **Number** | EF01_CAMBIO - Valore del cambio | [optional] 
**causaleCg33** | **String** | EF01_CAUSALE_CG33 - Codice causale | [optional] 
**causmgoMgfo** | **Number** | EF01_CAUSMGO_MGFO - Causale MGO | [optional] 
**changed** | **Boolean** | Changed - Changed | [optional] 
**cig** | **String** | EF01_CIG - Codice Identificativo Gara | [optional] 
**codCcred** | **String** | EF01_CODCCRED - Codice carta di credito | [optional] 
**codiceCg08** | **String** | EF01_CODICE_CG08 - Divisa | 
**cup** | **String** | EF01_CUP - Codice Unico di Progetto | [optional] 
**datacambio** | **Date** | EF01_DATACAMBIO - Data cambio | [optional] 
**datadecorr** | **Date** | EF01_DATADECORR - Data decorrenza per calcolo scadenza | [optional] 
**datadoc** | **Date** | EF01_DATADOC - Data documento | 
**datareg** | **Date** | EF01_DATAREG - Data registrazione effetto | 
**descausale** | **String** | EF01_DESCAUSALE - Descrizione causale | [optional] 
**descragg** | **String** | EF01_DESCRAGG - Descrizione aggiuntiva | [optional] 
**dittaCg18** | **Number** | EF01_DITTA_CG18 - Codice azienda | 
**flgAcconto** | **Number** | EF01_FLGACCONTO - Acconto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgDocbis** | **Number** | EF01_FLGDOCBIS - Bis&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgEffvar** | **Number** | EF01_FLGEFFVAR - Variato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgEstraz** | **Number** | EF01_FLGESTRAZ - Estratto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgGendarag** | **Number** | EF01_FLGGENDARAG - Da raggr.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgGiratoS** | **Number** | EF01_FLGGIRATO_S - Girato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgPartbis** | **Number** | EF01_FLGPARTBIS - Bis&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgRicevutoS** | **Number** | EF01_FLGRICEVUTO_S - Ricevuto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgSospeso** | **Number** | EF01_FLGSOSPESO - Sospeso&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgSteffS** | **Number** | EF01_FLGSTEFF_S - Stampato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**id** | **Number** | EF01_ID - Id Scadenza | [optional] 
**idagenteMg17** | **Number** | EF01_IDAGENTE_MG17 - ID Agente | [optional] 
**idCg24** | **Number** | EF01_ID_CG24 - ID Conto | 
**idCg44** | **Number** | EF01_ID_CG44 - ID cliente/fornitore | [optional] 
**idCg62** | **Number** | EF01_ID_CG62 - ID Condizione di pagamento | [optional] 
**idContoSpeseCg24** | **Number** | EF01_IDCONTOSPESE_CG24 - Conto spese | [optional] 
**idEf08** | **Number** | EF01_ID_EF08 - Banca aziendale | [optional] 
**idLinkEf01** | **Number** | EF01_IDLINK_EF01 - IdLinkEf01 | [optional] 
**idMg29** | **Number** | EF01_ID_MG29 - ID RID | [optional] 
**idMg35** | **Number** | EF01_ID_MG35 - ID CC | [optional] 
**idpreEf08** | **Number** | EF01_IDPRE_EF08 - Id banca | [optional] 
**idStage** | **Number** | EF01_ID_STAGE - IdStage (Required only in PUT/PATCH) | [optional] 
**idStageLinkEf01** | **Number** | EF01_IDSTAGELINK_EF01 - IdStageLinkEf01 | [optional] 
**impeffiva** | **Number** | EF01_IMPEFFIVA - Importo IVA originario in EURO | 
**impeffivaVal** | **Number** | EF01_IMPEFFIVA_VAL - Importo IVA originario in valuta | [optional] 
**impeffnetprevS** | **Number** | EF01_IMPEFFNETPREV_S - Importo effetto al netto dei mov. previsionali in EURO | 
**impeffnetprevvalS** | **Number** | EF01_IMPEFFNETPREVVAL_S - Importo effetto al netto dei mov. previsionali in valuta | [optional] 
**impefforig** | **Number** | EF01_IMPEFFORIG - Importo | 
**impefforigval** | **Number** | EF01_IMPEFFORIGVAL - Importo origine in valuta | [optional] 
**impeffS** | **Number** | EF01_IMPEFF_S - Importo | 
**impeffvalS** | **Number** | EF01_IMPEFFVAL_S - Importo in valuta | [optional] 
**importoDaAssociare** | **Number** | EF01_IMPORTODAASSOCIARE - Imp. da associare | [optional] 
**impritacc** | **Number** | EF01_IMPRITACC - Importo residuo della ritenuta di acconto in Euro | [optional] 
**impritaccorig** | **Number** | EF01_IMPRITACCORIG - Importo origine della ritenuta di acconto in EURO | [optional] 
**impritaccorigval** | **Number** | EF01_IMPRITACCORIGVAL - Importo origine della ritenuta di acconto in valuta | [optional] 
**impritaccval** | **Number** | EF01_IMPRITACCVAL - Importo residuo della ritenuta di acconto in valuta | [optional] 
**indConto** | **Number** | EF01_INDCONTO - Tipo conto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Attivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Passivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Conto attivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Conto passivo&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indGenstatoS** | **Number** | EF01_INDGENSTATO_S - Operazione che ha determinato lo stato dell&#39;effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Creazione iniziale&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Pagamento/Riscossione&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Chiusura effetti&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  Insoluto&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; -  Raggruppato&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; -  Riemissione&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; -  Richiamato&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indLiqprov** | **Number** | EF01_INDLIQPROV - Liquidazione provvigioni&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Liquidabile&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Liquidabile se tot. incassato&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Sospesa&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indMerceart62** | **Number** | EF01_INDMERCEART62 - Tipo merce in riferimento all&#39;Art. 62&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Non soggetta&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Deperibile&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Non deperibile&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indPresS** | **Number** | EF01_INDPRES_S - Presentazione dell&#39;effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Non soggetto&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  In portafoglio&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  S.b.f. ordinario&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  S.b.f. a maturazione valuta&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; -  S.b.f. anticipato&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; -  Dopo incasso&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; -  Allo sconto&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; -  Altre presentazioni&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; -  Sconto fatture&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; -  Cessione a factoring&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indSperitS** | **Number** | EF01_INDSPERIT_S - Modalità di gestione delle spese di ritorno&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Nessun addebito&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Solo annotate&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Sommate&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  Nuovo effetto&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indStatoS** | **Number** | EF01_INDSTATO_S - Stato effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Aperto&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Chiuso&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTipomov** | **Number** | EF01_INDTIPOMOV - Tipo movimento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Consolidato&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Da consolidare&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Previsionale&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  Previsionale per simulaz.&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; -  Previsionale per cash flow&lt;/li&gt;&lt;/ul&gt; | [optional] 
**numdoc** | **Number** | EF01_NUMDOC - Nr documento/Protocollo | 
**numdocorig** | **String** | EF01_NUMDOCORIG - Numero documento originario | [optional] 
**numeff** | **Number** | EF01_NUMEFF - Numero scadenza | [optional] 
**numpart** | **Number** | EF01_NUMPART - Numero partita | [optional] 
**numrata** | **Number** | EF01_NUMRATA - Nr. rata | 
**numregCo99** | **String** | EF01_NUMREG_CO99 - Numero di registrazione | [optional] 
**recordtype** | **Number** | RecordType - Recordtype | [optional] 
**rigacontCg42** | **Number** | EF01_RIGACONT_CG42 - Riga contabile | [optional] 
**rowversion** | **Blob** | EF01_ROWVERSION - RowVersion | [optional] 
**scadeorig** | **Date** | EF01_SCADEORIG - Data scadenza originaria | 
**scadeS** | **Date** | EF01_SCADE_S - Data scadenza | 
**sezdoc** | **String** | EF01_SEZDOC - Sezionale documento | 
**sezpart** | **String** | EF01_SEZPART - Sezionale partita | [optional] 
**speseritS** | **Number** | EF01_SPESERIT_S - Spese di ritorno | [optional] 
**spinc** | **Number** | EF01_SPINC - Spese incasso in EURO | [optional] 
**spincval** | **Number** | EF01_SPINCVAL - Spese incasso in valuta | [optional] 
**stageguid** | **String** | StageGuid - Stageguid | [optional] 
**stagestate** | **Number** | StageState - Stagestate&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - None&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Add&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Update&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Delete&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Hidden&lt;/li&gt;&lt;/ul&gt; | [optional] 
**stipoeff** | **Number** | EF01_STIPOEFF - Sottotipo effetto | [optional] 
**tipoeff** | **Number** | EF01_TIPOEFF - Tipo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Contanti&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Ricevuta bancaria&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Tratta&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Tratta accettata&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Cessione&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Cambiale&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Carta di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Bancomat&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Contrassegno&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Lettera di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - SDD&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Leasing&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Rimessa diretta&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Bonifico Bancario&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - C/C postale&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - MAV&lt;/li&gt;&lt;/ul&gt; | [optional] 
**totdoc** | **Number** | EF01_TOTDOC - Totale documento in EURO | 
**totdocval** | **Number** | EF01_TOTDOCVAL - Totale documento in valuta | [optional] 
**totrate** | **Number** | EF01_TOTRATE - Totale rate | 
**instalmentNoteStageFIDTO** | [**[InstalmentNoteStageFIDTO]**](InstalmentNoteStageFIDTO.md) |  | [optional] 
**instalmentStageHistoryFIDTO** | [**[InstalmentHistoryStageFIDTO]**](InstalmentHistoryStageFIDTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgAccontoEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgDocbisEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgEffvarEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgEstrazEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgGendaragEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgGiratoSEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgPartbisEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgRicevutoSEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgSospesoEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgSteffSEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndContoEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: IndGenstatoSEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)





## Enum: IndLiqprovEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndMerceart62Enum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndPresSEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)





## Enum: IndSperitSEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: IndStatoSEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndTipomovEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)





## Enum: StagestateEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)





## Enum: TipoeffEnum


* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)

* `10` (value: `10`)

* `11` (value: `11`)

* `12` (value: `12`)

* `13` (value: `13`)

* `14` (value: `14`)

* `15` (value: `15`)

* `16` (value: `16`)




