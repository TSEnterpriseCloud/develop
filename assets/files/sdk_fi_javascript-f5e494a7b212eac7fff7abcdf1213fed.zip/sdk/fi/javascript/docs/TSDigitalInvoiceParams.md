# TseCloudFi.TSDigitalInvoiceParams

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transmitterId** | **String** |  | [optional] 
**senderId** | **String** |  | [optional] 
**recipientId** | **String** |  | [optional] 
**fileName** | **String** |  | [optional] 
**flowType** | **String** |  | [optional] 
**hubId** | **String** |  | [optional] 
**sdiId** | **String** |  | [optional] 
**docDate** | **String** |  | [optional] 
**docId** | **String** |  | [optional] 
**category** | **String** |  | [optional] 
**format** | **String** |  | [optional] 
**recipientName** | **String** |  | [optional] 
**senderName** | **String** |  | [optional] 
**receiptDate** | **String** |  | [optional] 
**lastTimestamp** | **Number** |  | [optional] 
**active** | **Boolean** |  | [optional] 
**currentStatusName** | **String** |  | [optional] 
**currentStatusTimestamp** | **Number** |  | [optional] 
**currentNotificationType** | **String** |  | [optional] 
**messageCount** | **Number** |  | [optional] 
**currentStatusDescription** | **String** |  | [optional] 


