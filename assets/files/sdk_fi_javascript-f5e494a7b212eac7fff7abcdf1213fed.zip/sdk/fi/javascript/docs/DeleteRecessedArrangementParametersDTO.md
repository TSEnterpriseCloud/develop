# TseCloudFi.DeleteRecessedArrangementParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dispositionId** | **Number** |  | [optional] 
**instalmentId** | **Number** |  | [optional] 
**deleteAction** | [**EDeleteActions**](EDeleteActions.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


