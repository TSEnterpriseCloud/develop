# TseCloudFi.UpdateAllCSBankForInstalmentResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**executionResult** | **Boolean** |  | [optional] 
**instalmentIdsUpdated** | **[Number]** |  | [optional] 
**docuementIdsUpdated** | **[Number]** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


