# TseCloudFi.GLEntryFIGetLinkedEntriesFromNumregParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numreg** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


