# TseCloudFi.DuplicateAccountParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sourceAccountId** | **Number** |  | [optional] 
**accountCode** | **String** |  | [optional] 
**accountDescription** | **String** |  | [optional] 
**flgDuplLanguageDescriptions** | **Boolean** |  | [optional] 


