# TseCloudFi.GLEntryFIMultipleDTOCollectionBaseDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**[GLEntryFIMultipleDTO]**](GLEntryFIMultipleDTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


