# TseCloudFi.InstalmentGroupingStageParametersFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**elaborationGuid** | **String** |  | [optional] 
**instalmentsSourceIds** | **[Number]** |  | [optional] 
**instalmentsDestination** | [**[InstalmentGroupingDestStageParamsFIDTO]**](InstalmentGroupingDestStageParamsFIDTO.md) |  | [optional] 
**groupId** | **Number** |  | [optional] 
**paymentCode** | **String** |  | [optional] 
**currencyCode** | **String** |  | [optional] 
**notCleanDestinations** | **Boolean** |  | [optional] 
**reuseDataSourceInstalment** | **Boolean** |  | [optional] 


