# TseCloudFi.InstalmentsExchangeAdditionalInfoParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**historyIdStage** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


