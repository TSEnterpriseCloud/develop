# TseCloudFi.OfficeCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cap** | **String** |  | [optional] 
**citta** | **String** |  | [optional] 
**codice** | **Number** |  | [optional] 
**dittaCg18** | **Number** |  | [optional] 
**idmediaCg99** | **Number** |  | [optional] 
**indDimcentrocomm** | **Number** |  | [optional] 
**indIrizzo** | **String** |  | [optional] 
**numerorea** | **String** |  | [optional] 
**progRea** | **Number** |  | [optional] 
**prov** | **String** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


