# TseCloudFi.CalculateCreditLineParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**banksIds** | **[Number]** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


