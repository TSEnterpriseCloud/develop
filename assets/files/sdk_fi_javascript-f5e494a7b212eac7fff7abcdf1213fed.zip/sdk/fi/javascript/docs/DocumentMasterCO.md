# TseCloudFi.DocumentMasterCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**datacre** | **Date** |  | [optional] 
**datavar** | **Date** |  | [optional] 
**descnote1** | **String** |  | [optional] 
**dittaCg18** | **Number** |  | [optional] 
**editincoge** | **Number** |  | [optional] 
**flgDelnote1** | **Number** |  | [optional] 
**gruppocre** | **String** |  | [optional] 
**gruppovar** | **String** |  | [optional] 
**indCoin** | **Number** |  | [optional] 
**indCoinanomalia** | **Number** |  | [optional] 
**indCoincoge** | **Number** |  | [optional] 
**indNote1** | **Number** |  | [optional] 
**indTipoop** | **Number** |  | [optional] 
**numreg** | **String** |  | [optional] 
**utentecre** | **String** |  | [optional] 
**utentevar** | **String** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


