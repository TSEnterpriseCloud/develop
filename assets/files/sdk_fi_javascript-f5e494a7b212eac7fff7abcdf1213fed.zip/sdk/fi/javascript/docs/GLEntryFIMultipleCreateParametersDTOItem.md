# TseCloudFi.GLEntryFIMultipleCreateParametersDTOItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**externalRif** | **String** |  | [optional] 
**autoVatRow** | **Boolean** |  | [optional] 
**externalInfo** | **{String: String}** |  | [optional] 
**entry** | [**GLEntryFIDTO**](GLEntryFIDTO.md) |  | [optional] 
**instalments** | [**[InstalmentStageFIDTO]**](InstalmentStageFIDTO.md) |  | [optional] 
**instalmentsExtension** | [**[InstalmentStageFIExtensionDTO]**](InstalmentStageFIExtensionDTO.md) |  | [optional] 
**wtPurchases** | [**[PurchaseEntryWTInternalDTO]**](PurchaseEntryWTInternalDTO.md) |  | [optional] 
**vatTotals** | [**[VATTotals]**](VATTotals.md) |  | [optional] 
**instalmentsToPay** | [**[InstalmentPaymentDataDTO]**](InstalmentPaymentDataDTO.md) |  | [optional] 
**manageWithholdingTax** | **Boolean** |  | [optional] 
**withholdingTaxData** | [**WithholdingTaxData**](WithholdingTaxData.md) |  | [optional] 
**instalmentsPairing** | [**InstalmentPairingDataDTO**](InstalmentPairingDataDTO.md) |  | [optional] 
**outTransactionNumbering** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


