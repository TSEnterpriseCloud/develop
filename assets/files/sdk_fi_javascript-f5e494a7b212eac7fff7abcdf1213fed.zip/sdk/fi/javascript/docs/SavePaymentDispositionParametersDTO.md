# TseCloudFi.SavePaymentDispositionParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transferType** | [**ETransferType**](ETransferType.md) |  | [optional] 
**transferModeType** | [**ETransferModeType**](ETransferModeType.md) |  | [optional] 
**presentationBankId** | **Number** |  | [optional] 
**creationDate** | **Date** |  | [optional] 
**registrationDate** | **Date** |  | [optional] 
**executionDate** | **Date** |  | [optional] 
**chkConsolidated** | **Boolean** |  | [optional] 
**sendAddress** | **Boolean** |  | [optional] 
**accountingReasonForRegistration** | **String** |  | [optional] 
**bankAccount** | **String** |  | [optional] 
**expenseRegistration** | **Number** |  | [optional] 
**expenseAccount** | **String** |  | [optional] 
**withReputed** | **Boolean** |  | [optional] 
**outcomeNotification** | **Boolean** |  | [optional] 
**presentation** | **Boolean** |  | [optional] 
**flgPriorbon** | [**EFlgPriorbon**](EFlgPriorbon.md) |  | [optional] 
**seat** | **Number** |  | [optional] 
**codeSeat** | **Number** |  | [optional] 
**indTiporegban** | **Number** |  | [optional] 
**groupingType** | **Number** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**cg08Code** | **String** |  | [optional] 
**withholdingProf** | **String** |  | [optional] 
**otherWithProf** | **String** |  | [optional] 
**withholdingRappr** | **String** |  | [optional] 
**withholdingEnas** | **String** |  | [optional] 
**enasCompany** | **String** |  | [optional] 
**entiPrev** | **String** |  | [optional] 
**oneriPrev** | **String** |  | [optional] 
**idEf10** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


