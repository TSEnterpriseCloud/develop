# TseCloudFi.SourceSelectionStateDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idSource** | **Number** |  | [optional] 
**selectState** | **Number** |  | [optional] 


