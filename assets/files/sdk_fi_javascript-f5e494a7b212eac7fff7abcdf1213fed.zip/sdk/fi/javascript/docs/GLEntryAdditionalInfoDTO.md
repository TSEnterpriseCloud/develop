# TseCloudFi.GLEntryAdditionalInfoDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**numeroRegistrazione** | **String** |  | [optional] 
**sezionale** | **String** |  | [optional] 
**protocollo** | **Number** |  | [optional] 
**dataRegistrazione** | **Date** |  | [optional] 
**esercizio** | **Number** |  | [optional] 
**progressivoEsercizio** | **Number** |  | [optional] 
**numeroDocumento** | **String** |  | [optional] 
**dataDocumento** | **Date** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


