# TseCloudFi.StoreCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cap** | **String** |  | [optional] 
**citta** | **String** |  | [optional] 
**datafinegest** | **Date** |  | [optional] 
**datainizgest** | **Date** |  | [optional] 
**defNumrea** | **String** |  | [optional] 
**defProgRea** | **Number** |  | [optional] 
**defProv** | **String** |  | [optional] 
**descrizione** | **String** |  | [optional] 
**dittaCg18** | **Number** |  | [optional] 
**flgReqdimen** | **Number** |  | [optional] 
**flgVentil** | **Number** |  | [optional] 
**indIrizzo** | **String** |  | [optional] 
**proNumrea** | **String** |  | [optional] 
**proProgRea** | **Number** |  | [optional] 
**proProv** | **String** |  | [optional] 
**prov** | **String** |  | [optional] 
**puntoven** | **Number** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


