# TseCloudFi.COAAccountDescrFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**conto** | **String** | CG24_CONTO - Conto | 
**contoFormattato** | **String** | CG24_CONTO_FORMATTATO - ContoFormattato | [optional] 
**descr** | **String** | CG24_DESCR - Descr | [optional] 
**dittaCg18** | **Number** | CG18_DITTA - DittaCg18 | 
**flgAnalit** | **Number** | CG24_FLGANALIT - FlgAnalit | 
**gruppoCg10** | **Number** | CG24_GRUPPO_CG10 - GruppoCg10 | 
**idconto** | **Number** | CG24_IDCONTO - Idconto | 
**idparent** | **Number** | CG24_IDPARENT - Idparent | 
**coaAccountFI** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


