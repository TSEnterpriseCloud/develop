# TseCloudFi.InstalmentStageContextualFIParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stageGuid** | **String** |  | [optional] 
**stageId** | **Number** |  | [optional] 
**tipoEffetto** | **Number** |  | [optional] 
**sottotipoEffetto** | **Number** |  | [optional] 
**scadeS** | **Date** |  | [optional] 
**flgSospeso** | **Number** |  | [optional] 
**idEf08** | **Number** |  | [optional] 
**progrEf08** | **Number** |  | [optional] 
**idMg29** | **Number** |  | [optional] 
**idMg35** | **Number** |  | [optional] 
**bolli** | **Number** |  | [optional] 
**bolliVal** | **Number** |  | [optional] 
**spInc** | **Number** |  | [optional] 
**spIncVal** | **Number** |  | [optional] 
**impPagatoContestuale** | **Number** |  | [optional] 
**impPagatoContestualeVal** | **Number** |  | [optional] 
**impAbbuono** | **Number** |  | [optional] 
**impAbbuonoVal** | **Number** |  | [optional] 
**impScontoIncondizionato** | **Number** |  | [optional] 
**impScontoIncondizionatoVal** | **Number** |  | [optional] 
**impScontoOmaggio** | **Number** |  | [optional] 
**impScontoOmaggioVal** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**idExtendedAttributeSubEntity** | **Number** |  | [optional] 
**noteAmm** | **String** |  | [optional] 
**noteRaggr** | **String** |  | [optional] 
**impOrigine** | **Number** |  | [optional] 
**impOrigineVal** | **Number** |  | [optional] 
**impIva** | **Number** |  | [optional] 
**impIvaVal** | **Number** |  | [optional] 
**impRitenute** | **Number** |  | [optional] 
**impRitenuteVal** | **Number** |  | [optional] 


