# TseCloudFi.InstalmentReissueParameterDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instalmentIds** | **[Number]** |  | [optional] 
**expirationDate** | **Date** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


