# TseCloudFi.GLEntryFICreateFromBankMovementsParameters

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ids** | **[Number]** |  | [optional] 
**idProcessing** | **Number** |  | [optional] 
**service** | **Number** |  | [optional] 


