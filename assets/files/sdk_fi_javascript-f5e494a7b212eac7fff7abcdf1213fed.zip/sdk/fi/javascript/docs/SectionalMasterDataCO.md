# TseCloudFi.SectionalMasterDataCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**caustcoll** | **String** |  | [optional] 
**descsez** | **String** |  | [optional] 
**dittaCg18** | **Number** |  | [optional] 
**flgNoLiqIva** | **Number** |  | [optional] 
**idagentecoll** | **Number** |  | [optional] 
**idEntityWithDescriptions** | **Number** |  | [optional] 
**idprov** | **Number** |  | [optional] 
**indIntra1213** | **Number** |  | [optional] 
**indRegione** | **Number** |  | [optional] 
**indTipologia** | **Number** |  | [optional] 
**puntovenCg7a** | **Number** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**sezionale** | **String** |  | [optional] 
**descrizioniLingua** | [**[LanguageDescriptionCO]**](LanguageDescriptionCO.md) |  | [optional] 
**storeCO** | [**StoreCO**](StoreCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


