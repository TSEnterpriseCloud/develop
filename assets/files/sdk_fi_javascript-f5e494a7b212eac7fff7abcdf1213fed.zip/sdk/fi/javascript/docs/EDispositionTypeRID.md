# TseCloudFi.EDispositionTypeRID

## Enum


* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)


