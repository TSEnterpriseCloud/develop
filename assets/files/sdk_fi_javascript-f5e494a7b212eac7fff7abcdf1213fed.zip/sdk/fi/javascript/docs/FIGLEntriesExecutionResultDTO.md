# TseCloudFi.FIGLEntriesExecutionResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**executionResult** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


