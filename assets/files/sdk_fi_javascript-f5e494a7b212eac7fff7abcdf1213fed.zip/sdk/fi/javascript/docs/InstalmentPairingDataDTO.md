# TseCloudFi.InstalmentPairingDataDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pairingMode** | [**ModalitaAssociazioneScadenzeEnum**](ModalitaAssociazioneScadenzeEnum.md) |  | [optional] 
**instalments** | [**[InstalmentPairingDetailDTO]**](InstalmentPairingDetailDTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


