# TseCloudFi.InstalmentCalculationResultElementDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tipoEffetto** | **Number** |  | [optional] 
**sottotipoEffetto** | **Number** |  | [optional] 
**descSottotipoEffetto** | **String** |  | [optional] 
**dataScadenza** | **Date** |  | [optional] 
**idBancaAziendale** | **Number** |  | [optional] 
**idBancaCliFor** | **Number** |  | [optional] 
**importoScadenzaEuro** | **Number** |  | [optional] 
**importoScadenzaValuta** | **Number** |  | [optional] 
**importoIvaEuro** | **Number** |  | [optional] 
**importoIvaValuta** | **Number** |  | [optional] 
**importoRitenutaEuro** | **Number** |  | [optional] 
**importoRitenutaValuta** | **Number** |  | [optional] 
**dataDecorrenza** | **Date** |  | [optional] 


