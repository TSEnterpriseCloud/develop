# TseCloudFi.SepaReasonCodesFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codice** | **String** | CG6G_CODICE - Codice | 
**descr** | **String** | CG6G_DESCR - Descr | [optional] 
**indTipomov** | **Number** | CG6G_INDTIPOMOV - IndTipomov | 
**note** | **String** | CG6G_NOTE - Note | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


