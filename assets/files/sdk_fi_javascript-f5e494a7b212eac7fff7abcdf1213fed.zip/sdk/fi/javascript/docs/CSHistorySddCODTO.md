# TseCloudFi.CSHistorySddCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codBicswift** | **String** | MG2E_CODBICSWIFT - BICSWIFT | [optional] 
**codClideb** | **String** | MG2E_CODCLIDEB - Codice debitore | [optional] 
**codIndiv** | **Number** | MG2E_CODINDIV - Codice individuale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Utenza&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Matricola&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Codice fiscale&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Codice cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Codice fornitore&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Portafoglio commerciale&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Altro&lt;/li&gt;&lt;/ul&gt; | [optional] 
**datavar** | **Date** | MG2E_DATAVAR - Data | 
**id** | **Number** | MG2E_ID - Id | 
**indStorno** | **Number** | MG2E_INDSTORNO - Facoltà di storno&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Facoltà di storno dopo la scadenza (D+5)&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Facoltà di storno alla scadenza&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Nessuna facoltà di storno per contestazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Nessuna facoltà di storno per la banca domiciliataria&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Esiste diritto al rimborso (D+8 settimane)&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Nessuna facoltà di storno per le caratteristiche del mandato&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTipoinc** | **Number** | MG2E_INDTIPOINC - Tipo seq. incasso&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - First&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Recurrent&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Final&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - One-Off&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTiposdd** | **Number** | MG2E_INDTIPOSDD - Tipo SDD&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Core&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - B2B&lt;/li&gt;&lt;/ul&gt; | [optional] 
**ridiban** | **String** | MG2E_RIDIBAN - IBAN | [optional] 
**soggtitibanCg16** | **Number** | MG2E_SOGGTITIBAN_CG16 - Sogg. titolare IBAN | [optional] 
**tipologia** | **Number** | MG2E_TIPOLOGIA - Tipologia&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Consumatore&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Non Consumatore&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Microimpresa&lt;/li&gt;&lt;/ul&gt; | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: CodIndivEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `9` (value: `9`)





## Enum: IndStornoEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `8` (value: `8`)

* `9` (value: `9`)





## Enum: IndTipoincEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: IndTiposddEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: TipologiaEnum


* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)




