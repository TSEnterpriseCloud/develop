# TseCloudFi.InstalmentsPaymentResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instalmentId** | **Number** |  | [optional] 
**descriptionResult** | **String** |  | [optional] 
**result** | **Number** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**idStage** | **Number** |  | [optional] 
**impPagato** | **Number** |  | [optional] 
**impAbbuono** | **Number** |  | [optional] 
**impAcconto** | **Number** |  | [optional] 
**purchasePaymentStageGuid** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


