# TseCloudFi.GroupingInstalmentCalculationFIParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instalmentGroupingId** | **Number** |  | [optional] 
**elaborationGuid** | **String** |  | [optional] 
**indSubjects** | **Number** |  | [optional] 
**currencyCode** | **String** |  | [optional] 
**sectionalCode** | **String** |  | [optional] 
**numPart** | **Number** |  | [optional] 
**groupingPaymentCode** | **String** |  | [optional] 
**groupingEffectiveDate** | **Date** |  | [optional] 
**sourceIdRaggr** | [**[IdRaggrAndPaymentCodeDTO]**](IdRaggrAndPaymentCodeDTO.md) |  | [optional] 
**reuseDataSourceInstalment** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


