# TseCloudFi.InstalmentMarkDeletedStageDataDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stageGuid** | **String** |  | [optional] 
**rigacontCg42** | **Number** |  | [optional] 


