# TseCloudFi.InstalmentPairingDetailDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numInstalment** | **Number** |  | [optional] 
**idInstalmentToPair** | **Number** |  | [optional] 
**pairedAmount** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


