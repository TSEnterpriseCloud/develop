# TseCloudFi.SubTypeCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codiceCg07** | **Number** | CG64_CODICE_CG07 - Nazione di incasso | [optional] 
**codPaguc** | **String** | CG64_CODPAGUC - Codice pagamento estero | [optional] 
**codStipoeff** | **Number** | CG64_CODSTIPOEFF - Sottotipo effetto | 
**descstipo** | **String** | CG64_DESCSTIPO - Descrizione sottotipo effetto | [optional] 
**flgAssegno** | **Number** | CG64_FLGASSEGNO - Assegno | 
**ggoffset** | **Number** | CG64_GGOFFSET - Giorni spostamento scadenza | [optional] 
**id** | **Number** | CG64_ID - ID (Required only in PUT/PATCH) | [optional] 
**indModfatturapa** | **Number** | CG64_INDMODFATTURAPA - Modalità fattura elettronica&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuna&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Contanti&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Assegno&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Assegno circolare&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Contanti presso tesoreria&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Vaglia cambiario&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Bollettino bancario&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Quietanza erario&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Giroconto su conti di contabilità speciale&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Domiciliazione bancaria&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Domiciliazione postale&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - Trattenuta su somme già riscosse&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - PagoPa&lt;/li&gt;&lt;/ul&gt; | [optional] 
**rowversion** | **Blob** | CG64_ROWVERSION - RowVersion | [optional] 
**tipoeff** | **Number** | CG64_TIPOEFF - Tipo scadenza&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Tutti&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Contanti&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Ricevuta bancaria&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Tratta&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Tratta accettata&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Cessione&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Cambiale&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Carta di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Bancomat&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Contrassegno&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Lettera di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - RID&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Leasing&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Rimessa diretta&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Bonifico&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - C/C postale&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - MAV&lt;/li&gt;&lt;/ul&gt; | [optional] 
**foreignPaymentCodeCO** | [**ForeignPaymentCodeCODTO**](ForeignPaymentCodeCODTO.md) |  | [optional] 
**nationCO** | [**NationCODTO**](NationCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndModfatturapaEnum


* `0` (value: `0`)

* `10` (value: `10`)

* `2` (value: `2`)

* `3` (value: `3`)

* `1` (value: `1`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)

* `11` (value: `11`)

* `12` (value: `12`)





## Enum: TipoeffEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)

* `10` (value: `10`)

* `11` (value: `11`)

* `12` (value: `12`)

* `13` (value: `13`)

* `14` (value: `14`)

* `15` (value: `15`)

* `16` (value: `16`)




