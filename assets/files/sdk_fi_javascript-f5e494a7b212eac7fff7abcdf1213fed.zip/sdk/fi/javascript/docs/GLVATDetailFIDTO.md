# TseCloudFi.GLVATDetailFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**causaleiva** | **Number** | CG43_CAUSALEIVA - Tipo IVA | 
**dittaCg18** | **Number** | CG43_DITTA_CG18 - Azienda | 
**flgDeducibile** | **Number** | CG43_FLGDEDUCIBILE - FlgDeducibile | 
**flgTsescluso** | **Number** | CG43_FLGTSESCLUSO - FlgTsescluso | 
**flgTsinviato** | **Number** | CG43_FLGTSINVIATO - FlgTsinviato | 
**id** | **Number** | CG43_ID - ID (Required only in PUT/PATCH) | [optional] 
**idCg41** | **Number** | CG43_ID_CG41 - IdCg41 | 
**idcontoCg24** | **Number** | CG43_IDCONTO_CG24 - IdcontoCg24 | [optional] 
**imponibile** | **Number** | CG43_IMPONIBILE - Imponibile | [optional] 
**imponibileval** | **Number** | CG43_IMPONIBILEVAL - Imponibile in valuta | [optional] 
**imposta** | **Number** | CG43_IMPOSTA - Imposta | [optional] 
**impostand** | **Number** | CG43_IMPOSTAND - Imposta non detraibile | [optional] 
**impostandval** | **Number** | CG43_IMPOSTANDVAL - Imposta non detraibile in valuta | [optional] 
**impostaval** | **Number** | CG43_IMPOSTAVAL - Imposta in valuta | [optional] 
**indDetriva** | **Number** | CG43_INDDETRIVA - Indicatore trattamento indetraibilità IVA | 
**indIvaacqagric** | **Number** | CG43_INDIVAACQAGRIC - IndIvaacqagric | 
**indNatura** | **Number** | CG43_INDNATURA - Natura | [optional] 
**indProrata** | **Number** | CG43_INDPRORATA - Tipo pro-rata&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Si tenuta distinta dal costo&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTipo** | **Number** | CG43_INDTIPO - Tipo operazione | 
**indTstipoop** | **Number** | CG43_INDTSTIPOOP - IndTstipoop | 
**indTstiposp** | **Number** | CG43_INDTSTIPOSP - IndTstiposp | 
**indTsvocesp** | **Number** | CG43_INDTSVOCESP - IndTsvocesp | 
**numrigaiva** | **Number** | CG43_NUMRIGAIVA - Numero riga IVA | 
**percdetr** | **Number** | CG43_PERCDETR - % indetraibilità | [optional] 
**percforf** | **Number** | CG43_PERCFORF - % forfettiz. | [optional] 
**tsdatadocori** | **Date** | CG43_TSDATADOCORI - Tsdatadocori | [optional] 
**tsdocorigine** | **String** | CG43_TSDOCORIGINE - Tsdocorigine | [optional] 
**coaAccountFI** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**reverseTypeFI** | [**GLReverseTypeFIDTO**](GLReverseTypeFIDTO.md) |  | [optional] 
**vatCodeCO** | [**VatCodeCODTO**](VatCodeCODTO.md) |  | [optional] 
**vatCodeCompensationCO** | [**VatCodeCODTO**](VatCodeCODTO.md) |  | [optional] 
**vatTypeFI** | [**VATTypeFIDTO**](VATTypeFIDTO.md) |  | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndProrataEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)




