# TseCloudFi.LastAccountingReasonResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountingReason** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


