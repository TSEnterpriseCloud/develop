# TseCloudFi.InstalmentsAdditionalInfoResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totUtilizzatoEuro** | **Number** |  | [optional] 
**totUtilizzatoValuta** | **Number** |  | [optional] 
**totUtilizzatoIVAEuro** | **Number** |  | [optional] 
**totUtilizzatoIVAValuta** | **Number** |  | [optional] 
**totUtilizzatoRitEuro** | **Number** |  | [optional] 
**totUtilizzatoRitValuta** | **Number** |  | [optional] 
**totAssociabiliUtilizzatoEuro** | **Number** |  | [optional] 
**totAssociabiliUtilizzatoValuta** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


