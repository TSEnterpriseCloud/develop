# TseCloudFi.InstalmentGroupingDestStageParamsFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instalmentStageId** | **Number** |  | [optional] 
**_delete** | **Boolean** |  | [optional] 
**number** | **Number** |  | [optional] 
**type** | **Number** |  | [optional] 
**subType** | **Number** |  | [optional] 
**expiryDate** | **Date** |  | [optional] 
**taxableAmount** | **Number** |  | [optional] 
**vatAmount** | **Number** |  | [optional] 
**customerSupplierBankId** | **Number** |  | [optional] 
**companyBankId** | **Number** |  | [optional] 
**sezpart** | **String** |  | [optional] 
**numpart** | **Number** |  | [optional] 


