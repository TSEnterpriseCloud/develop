# TseCloudFi.StageInstalmentAndHistoryResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**executionResult** | **Boolean** |  | [optional] 
**instalmentIds** | **[Number]** |  | [optional] 
**instalments** | [**[InstalmentDataDTO]**](InstalmentDataDTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


