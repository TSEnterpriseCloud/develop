# TseCloudFi.BusinessTypeDataCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**annoliq** | **Number** |  | [optional] 
**codAttivita** | **Number** |  | [optional] 
**codiceCg06** | **String** |  | [optional] 
**codiceCg6a** | **String** |  | [optional] 
**datastpliqiva** | **Date** |  | [optional] 
**datastpplafon** | **Date** |  | [optional] 
**datastpregacq** | **Date** |  | [optional] 
**datastpregacqglob** | **Date** |  | [optional] 
**datastpregcor** | **Date** |  | [optional] 
**datastpregrie** | **Date** |  | [optional] 
**datastpregunicanal** | **Date** |  | [optional] 
**datastpregven** | **Date** |  | [optional] 
**datastpregvenglob** | **Date** |  | [optional] 
**descrattivita** | **String** |  | [optional] 
**dittaCg18** | **Number** |  | [optional] 
**flgIvaedit** | **Number** |  | [optional] 
**indAgric** | **Number** |  | [optional] 
**indCatpart** | **Number** |  | [optional] 
**indRegimefiscale** | **Number** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**codAteco** | [**AtecoCodeCO**](AtecoCodeCO.md) |  | [optional] 
**istatActivityCO** | [**ISTATActivityCO**](ISTATActivityCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


