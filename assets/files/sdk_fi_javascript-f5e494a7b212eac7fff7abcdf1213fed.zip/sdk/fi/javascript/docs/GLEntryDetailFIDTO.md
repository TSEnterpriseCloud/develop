# TseCloudFi.GLEntryDetailFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**debitAmount** | **Number** |  | [optional] 
**creditAmount** | **Number** |  | [optional] 
**glvatDetailFI** | [**GLVATDetailFIDTO**](GLVATDetailFIDTO.md) |  | [optional] 
**taxableAmount** | **Number** |  | [optional] 
**cambio** | **Number** | CG42_CAMBIO - Cambio | [optional] 
**codAttivitaCg96** | **Number** | CG42_CODATTIVITA_CG96 - Attivita&#39; | [optional] 
**datacambio** | **Date** | CG42_DATACAMBIO - Data cambio | [optional] 
**datafincomp** | **Date** | CG42_DATAFINCOMP - Data fine competenza | [optional] 
**datainicomp** | **Date** | CG42_DATAINICOMP - Data inizio competenza | [optional] 
**dataoperazione** | **Date** | CG42_DATAOPERAZIONE - Data operazione | [optional] 
**datareg** | **Date** | CG42_DATAREG - Data registrazione | 
**datavaluta** | **Date** | CG42_DATAVALUTA - Data valuta | [optional] 
**descausale** | **String** | CG42_DESCAUSALE - Descrizione causale | [optional] 
**descragg** | **String** | CG42_DESCRAGG - Descrizione aggiuntiva | [optional] 
**dittaCg18** | **Number** | CG42_DITTA_CG18 - Azienda | 
**flgComp** | **Number** | CG42_FLGCOMP - Date competenza | [optional] 
**flgDescrstd** | **Number** | CG42_FLGDESCRSTD - Descrizione standard | [optional] 
**flgMentry** | **Number** | CG42_FLGMENTRY - FlgMentry | [optional] 
**flgStpgior** | **Number** | CG42_FLGSTPGIOR - Stampato sul giornale contabile | [optional] 
**guid** | **String** | CG42_GUID - GUID | [optional] 
**id** | **Number** | CG42_ID - ID | 
**imptotale** | **Number** | CG42_IMPTOTALE - Importo | 
**imptotaleval** | **Number** | CG42_IMPTOTALEVAL - Importo    in valuta | [optional] 
**imptotaleval2** | **Number** | CG42_IMPTOTALEVAL2 - Importo    in valuta | [optional] 
**indDaav** | **Number** | CG42_INDDAAV - Segno&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Dare&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Avere&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indGiroliq** | **Number** | CG42_INDGIROLIQ - Tipo giroconto liquidazione IVA&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Default&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - IVA a credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - IVA a debito&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Rilevazione interessi&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Ventilazione corrispettivi&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Agenzia viaggi&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Vendite regime del margine analitico&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Corrispettivi regime del margine analitico&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Vendite regime del margine globale&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Corrispettivi regime del margine globale&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Vendite regime del margine forfettario 25%&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - Vendite regime del margine forfettario 50%&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Vendite regime del margine forfettario 60%&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Corrispettivi regime del margine forfettario 25%&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Corrispettivi regime del margine forfettario 50%&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - Corrispettivi regime del margine forfettario 60%&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indRatris** | **Number** | CG42_INDRATRIS - Ratei e risconti&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Rateo&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Risconto&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Rateo e risconto&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Competenza&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTipooper** | **Number** | CG42_INDTIPOOPER - Tipo operazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - DocumentoIVA_MovimentoPartitaDocumento&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - DocumentoIVA_IvaSuFatturaCorrispettivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - DocumentoIVA_ContropartiteSuFattura&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - DocumentoIVA_IVAIndetraibileSuFattura&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - DocumentoIVA_StornoIvaAutofattura&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - DocumentoIVA_MovimentoDiRateo&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - PagDoc_DareFornitoreAvereCliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - PagDoc_ImportoAbbuono&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - PagDoc_ImportoDiffCambio&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - PagDoc_ImportoPagatoCassa&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - PagRitenutaAcconto_ImpRitenutaAcconto&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - PagRitenutaPrevidenziale_ImpRitenutaPrevidenziale&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - PagRitenutaPrevidenziale_OneriPrevidenziali&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - PagRitenutaPrevidenziale_TotaleRitenute&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - PagAltreRitenute_ImpPrimaRitenuta&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - PagAltreRitenute_ImpSecondaRitenuta&lt;/li&gt;&lt;li&gt;&lt;i&gt;17&lt;/i&gt; - PagAltreRitenute_ImpTerzaRitenuta&lt;/li&gt;&lt;li&gt;&lt;i&gt;18&lt;/i&gt; - PagamentoAltreRitenute_ImpQuartaRitenuta&lt;/li&gt;&lt;li&gt;&lt;i&gt;19&lt;/i&gt; - VenditaCespite_AmmortamentoAnno&lt;/li&gt;&lt;li&gt;&lt;i&gt;20&lt;/i&gt; - VenditaCespite_TotaleFondo&lt;/li&gt;&lt;li&gt;&lt;i&gt;21&lt;/i&gt; - VenditaCespite_StornoContoImmobilizzi&lt;/li&gt;&lt;li&gt;&lt;i&gt;22&lt;/i&gt; - VenditaCespite_Plusvalenze&lt;/li&gt;&lt;li&gt;&lt;i&gt;23&lt;/i&gt; - VenditaCespite_Minusvalenze&lt;/li&gt;&lt;li&gt;&lt;i&gt;24&lt;/i&gt; - AutofattureIntraRSM_AvereClienteDareFornitore&lt;/li&gt;&lt;li&gt;&lt;i&gt;25&lt;/i&gt; - AutofattureIntraRSM_ContropartiteNoFatture&lt;/li&gt;&lt;li&gt;&lt;i&gt;26&lt;/i&gt; - GirocontoIvaSospesa&lt;/li&gt;&lt;li&gt;&lt;i&gt;27&lt;/i&gt; - DocumentoIVA_IVAAgricola&lt;/li&gt;&lt;li&gt;&lt;i&gt;28&lt;/i&gt; - MovimentiContabili_DiversiADiversi&lt;/li&gt;&lt;li&gt;&lt;i&gt;29&lt;/i&gt; - MovimentiContabili_DifferenzaConversione&lt;/li&gt;&lt;li&gt;&lt;i&gt;30&lt;/i&gt; - CompAmministratoriCollab_DareCostoPrestAvereDebitoPrest&lt;/li&gt;&lt;li&gt;&lt;i&gt;31&lt;/i&gt; - CompAmministratoriCollab_ImpRitenutaAcconto&lt;/li&gt;&lt;li&gt;&lt;i&gt;32&lt;/i&gt; - CompAmministratoriCollab_ImpRitenutaPrevidenziale&lt;/li&gt;&lt;li&gt;&lt;i&gt;33&lt;/i&gt; - CompAmministratoriCollab_OneriPrevidenziali&lt;/li&gt;&lt;li&gt;&lt;i&gt;34&lt;/i&gt; - DocumentoIVA_IvaEsigDifferita&lt;/li&gt;&lt;li&gt;&lt;i&gt;35&lt;/i&gt; - PagCompensiAmministratoriCollab_DareDebitoPrestazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;36&lt;/i&gt; - PagCompensiAmministratoriCollab_ImpAbbuono&lt;/li&gt;&lt;li&gt;&lt;i&gt;37&lt;/i&gt; - PagCompensiAmministratoriCollab_ImpPagatoCassa&lt;/li&gt;&lt;li&gt;&lt;i&gt;38&lt;/i&gt; - PagCompensiAmministratoriCollab_ImpAltreRitenute&lt;/li&gt;&lt;li&gt;&lt;i&gt;40&lt;/i&gt; - VersRitenuteAccontoPrevid_ImpPagatoCassa&lt;/li&gt;&lt;li&gt;&lt;i&gt;41&lt;/i&gt; - VersRitenuteAccontoPrevid_ImpErarioRitenuteAcconto&lt;/li&gt;&lt;li&gt;&lt;i&gt;42&lt;/i&gt; - VersRitenuteAccontoPrevid_ImpErarioRitenutePrevid&lt;/li&gt;&lt;li&gt;&lt;i&gt;43&lt;/i&gt; - VersRitenuteAccontoPrevid_StornoErarioRitenuteAcconto&lt;/li&gt;&lt;li&gt;&lt;i&gt;44&lt;/i&gt; - VersRitenuteAccontoPrevid_StornoErarioRitenutePrevid&lt;/li&gt;&lt;li&gt;&lt;i&gt;45&lt;/i&gt; - VersRitenuteAccontoPrevid_ImpAbbuonoRitenuteAccontoPrevid&lt;/li&gt;&lt;li&gt;&lt;i&gt;46&lt;/i&gt; - RiscontiAttiviPassiviFineAnno&lt;/li&gt;&lt;li&gt;&lt;i&gt;47&lt;/i&gt; - PagDocumento_ImportoAbbuonoSuAcconto&lt;/li&gt;&lt;li&gt;&lt;i&gt;48&lt;/i&gt; - IncIvaSplitPayment&lt;/li&gt;&lt;li&gt;&lt;i&gt;49&lt;/i&gt; - DocumentoIVA_IvaSplitPayment&lt;/li&gt;&lt;li&gt;&lt;i&gt;50&lt;/i&gt; - ChiusuraEffettiAttiviPasivi_ContoChiusuraEffetti&lt;/li&gt;&lt;li&gt;&lt;i&gt;51&lt;/i&gt; - ChiusuraEffettiAttiviPasivi_ContoClienteFornitore&lt;/li&gt;&lt;li&gt;&lt;i&gt;52&lt;/i&gt; - ChiusuraEffettiAttiviPasivi_ContoSpeseCommissioni&lt;/li&gt;&lt;li&gt;&lt;i&gt;55&lt;/i&gt; - PresentDistinteAttivePassive_DistintaEffetti&lt;/li&gt;&lt;li&gt;&lt;i&gt;56&lt;/i&gt; - PresentDistinteAttivePassive_SpeseCommissioni&lt;/li&gt;&lt;li&gt;&lt;i&gt;60&lt;/i&gt; - PagAltreRitenute_ImportoQuintaRitenuta&lt;/li&gt;&lt;li&gt;&lt;i&gt;61&lt;/i&gt; - PagAltreRitenute_ImportoSestaRitenuta&lt;/li&gt;&lt;li&gt;&lt;i&gt;62&lt;/i&gt; - GirocontoAssociazioneNotaCreditoFattureConRitenute&lt;/li&gt;&lt;li&gt;&lt;i&gt;65&lt;/i&gt; - ScontoIncondizionato_ContoClienteFornitore&lt;/li&gt;&lt;li&gt;&lt;i&gt;66&lt;/i&gt; - ScontoIncondizionato_ContoScontoIncondizionato&lt;/li&gt;&lt;li&gt;&lt;i&gt;67&lt;/i&gt; - ScontoIncondizionato_ContoOmaggioSenzaRivalsa&lt;/li&gt;&lt;li&gt;&lt;i&gt;69&lt;/i&gt; - DocumentoIVA_IvaOmaggi&lt;/li&gt;&lt;li&gt;&lt;i&gt;70&lt;/i&gt; - GirocontoIvaAutotrasportatori&lt;/li&gt;&lt;li&gt;&lt;i&gt;71&lt;/i&gt; - ContabECB_ContoBanca&lt;/li&gt;&lt;li&gt;&lt;i&gt;72&lt;/i&gt; - ContabECB_ContoContropartita&lt;/li&gt;&lt;li&gt;&lt;i&gt;73&lt;/i&gt; - ContabECB_ContoSpesa&lt;/li&gt;&lt;li&gt;&lt;i&gt;75&lt;/i&gt; - ContabAutomaticaLiquidazioneIVA&lt;/li&gt;&lt;li&gt;&lt;i&gt;76&lt;/i&gt; - ContabAutomaticaLiquidazioneIVAAnnuale&lt;/li&gt;&lt;li&gt;&lt;i&gt;77&lt;/i&gt; - ContabilitaCassa_Giroconto&lt;/li&gt;&lt;li&gt;&lt;i&gt;79&lt;/i&gt; - Cespiti_ScorporoTerreno&lt;/li&gt;&lt;li&gt;&lt;i&gt;80&lt;/i&gt; - VenditaCespite_AmmortamentoAnnoCiv&lt;/li&gt;&lt;li&gt;&lt;i&gt;81&lt;/i&gt; - VenditaCespite_TotaleFondoCiv&lt;/li&gt;&lt;li&gt;&lt;i&gt;82&lt;/i&gt; - VenditaCespite_StornoContoImmobilizziCiv&lt;/li&gt;&lt;li&gt;&lt;i&gt;83&lt;/i&gt; - VenditaCespite_PlusvalenzeCiv&lt;/li&gt;&lt;li&gt;&lt;i&gt;84&lt;/i&gt; - VenditaCespite_MinusvalenzeCiv&lt;/li&gt;&lt;li&gt;&lt;i&gt;85&lt;/i&gt; - IASCespiti_AdozioneIAS&lt;/li&gt;&lt;li&gt;&lt;i&gt;86&lt;/i&gt; - IASCespiti_ScorporoTerreno&lt;/li&gt;&lt;li&gt;&lt;i&gt;87&lt;/i&gt; - VendCespiteCessioneBeneCumul_ContoCessioneBeneCumul&lt;/li&gt;&lt;li&gt;&lt;i&gt;88&lt;/i&gt; - VendCespiteCessioneBeneCumulativo_ContoImmobilizzi&lt;/li&gt;&lt;li&gt;&lt;i&gt;89&lt;/i&gt; - IASCespiti_RealizzazioneRiserve&lt;/li&gt;&lt;li&gt;&lt;i&gt;90&lt;/i&gt; - GirocontoEnasarco&lt;/li&gt;&lt;li&gt;&lt;i&gt;93&lt;/i&gt; - PagDocumento_StornoDifferenzaCambio&lt;/li&gt;&lt;li&gt;&lt;i&gt;95&lt;/i&gt; - CorrispettiviMensili_Storno&lt;/li&gt;&lt;li&gt;&lt;i&gt;96&lt;/i&gt; - CorrispettiviMensili_Ricavo&lt;/li&gt;&lt;li&gt;&lt;i&gt;97&lt;/i&gt; - OperazioneValuta_AdeguamentoValuta&lt;/li&gt;&lt;li&gt;&lt;i&gt;98&lt;/i&gt; - OperazioneValuta_DifferenzaCambio&lt;/li&gt;&lt;li&gt;&lt;i&gt;99&lt;/i&gt; - MonofaseRSM_Giroconto&lt;/li&gt;&lt;li&gt;&lt;i&gt;39&lt;/i&gt; - RettificheProrataContoIVACredito&lt;/li&gt;&lt;li&gt;&lt;i&gt;53&lt;/i&gt; - DocumentoIVA_ContoVATOSS&lt;/li&gt;&lt;/ul&gt; | [optional] 
**nrmovgruppo** | **Number** | CG42_NRMOVGRUPPO - Nrmovgruppo | [optional] 
**numrigacont** | **Number** | CG42_NUMRIGACONT - Riga contabile | 
**progEserCg19** | **Number** | CG42_PROGESER_CG19 - Progressivo esercizio | 
**progIvaCg43** | **Number** | CG42_PROGIVA_CG43 - Numero riga IVA | [optional] 
**rifrigagior** | **Number** | CG42_RIFRIGAGIOR - Rifrigagior | [optional] 
**idExtendedAttributeEntity** | **Number** |  | [optional] 
**idExtendedAttributeSubEntity** | **Number** |  | [optional] 
**businessTypeDataCO** | [**BusinessTypeDataCODTO**](BusinessTypeDataCODTO.md) |  | [optional] 
**coaAccountFI** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | 
**currencyCO** | [**CurrencyCODTO**](CurrencyCODTO.md) |  | [optional] 
**customerSupplierCO** | [**CustomerSupplierCODTO**](CustomerSupplierCODTO.md) |  | [optional] 
**intragroupStructureCO** | [**IntragroupStructureCODTO**](IntragroupStructureCODTO.md) |  | [optional] 
**officeCO** | [**OfficeCODTO**](OfficeCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndDaavEnum


* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndGiroliqEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)

* `10` (value: `10`)

* `11` (value: `11`)

* `12` (value: `12`)

* `13` (value: `13`)

* `14` (value: `14`)

* `15` (value: `15`)





## Enum: IndRatrisEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)





## Enum: IndTipooperEnum


* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)

* `10` (value: `10`)

* `11` (value: `11`)

* `12` (value: `12`)

* `13` (value: `13`)

* `14` (value: `14`)

* `15` (value: `15`)

* `16` (value: `16`)

* `17` (value: `17`)

* `18` (value: `18`)

* `19` (value: `19`)

* `20` (value: `20`)

* `21` (value: `21`)

* `22` (value: `22`)

* `23` (value: `23`)

* `24` (value: `24`)

* `25` (value: `25`)

* `26` (value: `26`)

* `27` (value: `27`)

* `28` (value: `28`)

* `29` (value: `29`)

* `30` (value: `30`)

* `31` (value: `31`)

* `32` (value: `32`)

* `33` (value: `33`)

* `34` (value: `34`)

* `35` (value: `35`)

* `36` (value: `36`)

* `37` (value: `37`)

* `38` (value: `38`)

* `40` (value: `40`)

* `41` (value: `41`)

* `42` (value: `42`)

* `43` (value: `43`)

* `44` (value: `44`)

* `45` (value: `45`)

* `46` (value: `46`)

* `47` (value: `47`)

* `48` (value: `48`)

* `49` (value: `49`)

* `50` (value: `50`)

* `51` (value: `51`)

* `52` (value: `52`)

* `55` (value: `55`)

* `56` (value: `56`)

* `60` (value: `60`)

* `61` (value: `61`)

* `62` (value: `62`)

* `65` (value: `65`)

* `66` (value: `66`)

* `67` (value: `67`)

* `69` (value: `69`)

* `70` (value: `70`)

* `71` (value: `71`)

* `72` (value: `72`)

* `73` (value: `73`)

* `75` (value: `75`)

* `76` (value: `76`)

* `77` (value: `77`)

* `79` (value: `79`)

* `80` (value: `80`)

* `81` (value: `81`)

* `82` (value: `82`)

* `83` (value: `83`)

* `84` (value: `84`)

* `85` (value: `85`)

* `86` (value: `86`)

* `87` (value: `87`)

* `88` (value: `88`)

* `89` (value: `89`)

* `90` (value: `90`)

* `93` (value: `93`)

* `95` (value: `95`)

* `96` (value: `96`)

* `97` (value: `97`)

* `98` (value: `98`)

* `99` (value: `99`)

* `39` (value: `39`)

* `53` (value: `53`)




