# TseCloudFi.COAAccountProposalFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codice** | **Number** | CG36_CODICE - Codice proposta conti | 
**contoCg24** | **String** | CG36_CONTO_CG24 - Codice conto | 
**gruppoCg10** | **Number** | CG36_GRUPPO_CG10 - Piano dei conti | 
**id** | **Number** | CG36_ID - ID (Required only in PUT/PATCH) | [optional] 
**idCg24** | **Number** | CG36_ID_CG24 - ID Conto | 
**rowversion** | **Blob** | CG36_ROWVERSION - RowVersion | [optional] 
**coaAccountFI** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


