# TseCloudFi.StageInstalmentAndHistoryPaymentResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**executionResult** | **Boolean** |  | [optional] 
**instalmentIds** | **[Number]** |  | [optional] 
**instalments** | [**[InstalmentDataDTO]**](InstalmentDataDTO.md) |  | [optional] 
**descriptionResult** | **{String: String}** |  | [optional] 
**purchaseGuid** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


