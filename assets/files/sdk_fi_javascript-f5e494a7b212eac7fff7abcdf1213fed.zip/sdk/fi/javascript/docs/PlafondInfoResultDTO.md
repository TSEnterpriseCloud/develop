# TseCloudFi.PlafondInfoResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dataComp** | **Date** |  | [optional] 
**indPlafond** | **Number** |  | [optional] 


