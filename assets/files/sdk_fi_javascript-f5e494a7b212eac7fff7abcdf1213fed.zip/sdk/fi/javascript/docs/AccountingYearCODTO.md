# TseCloudFi.AccountingYearCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**anno** | **Number** | CG19_ANNO -  Esercizio | 
**dataape** | **Date** | CG19_DATAAPE - Data inizio | 
**datachiu** | **Date** | CG19_DATACHIU - Data fine | 
**dittaCg18** | **Number** | CG19_DITTA_CG18 - Codice azienda | 
**flgAdecbatt** | **Number** | CG19_FLGADECBATT - Adeguamento cambi conti attivi&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgAdecbcli** | **Number** | CG19_FLGADECBCLI - Adeguamento cambi clienti&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgAdecbfor** | **Number** | CG19_FLGADECBFOR - Adeguamento cambi fornitori&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgAdecbpas** | **Number** | CG19_FLGADECBPAS - Adeguamento cambi conti passivi&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgEserchiuso** | **Number** | CG19_FLGESERCHIUSO - Chiuso&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgEsercor** | **Number** | CG19_FLGESERCOR - Corrente&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgGencesp** | **Number** | CG19_FLGGENCESP - Ammortamenti generati&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgGenratei** | **Number** | CG19_FLGGENRATEI - FlgGenratei&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgGenrisc** | **Number** | CG19_FLGGENRISC - Risconti generati&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**id** | **Number** | CG19_ID - Id (Required only in PUT/PATCH) | [optional] 
**progEser** | **Number** | CG19_PROGESER - Pr. | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgAdecbattEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgAdecbcliEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgAdecbforEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgAdecbpasEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgEserchiusoEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgEsercorEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgGencespEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgGenrateiEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgGenriscEnum


* `0` (value: `0`)

* `1` (value: `1`)




