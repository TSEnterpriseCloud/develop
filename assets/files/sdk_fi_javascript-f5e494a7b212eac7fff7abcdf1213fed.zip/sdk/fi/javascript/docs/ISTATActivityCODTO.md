# TseCloudFi.ISTATActivityCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codice** | **String** | CG06_CODICE - Codice | 
**descr** | **String** | CG06_DESCR - Descrizione | [optional] 
**idmediaCg99** | **Number** | CG06_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


