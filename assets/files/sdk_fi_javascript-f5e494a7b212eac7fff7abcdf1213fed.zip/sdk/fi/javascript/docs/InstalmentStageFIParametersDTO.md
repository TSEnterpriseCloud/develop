# TseCloudFi.InstalmentStageFIParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idStageGuid** | **String** |  | [optional] 
**tipoOp** | **Number** |  | [optional] 
**tipoDoc** | **Number** |  | [optional] 
**idCg24** | **Number** |  | [optional] 
**numReg** | **String** |  | [optional] 
**codiceCg08** | **String** |  | [optional] 
**tipoCF** | **Number** |  | [optional] 
**clifor** | **Number** |  | [optional] 
**rigacontCg42** | **Number** |  | [optional] 
**customFilter** | [**SearchDTO**](SearchDTO.md) |  | [optional] 
**listId** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


