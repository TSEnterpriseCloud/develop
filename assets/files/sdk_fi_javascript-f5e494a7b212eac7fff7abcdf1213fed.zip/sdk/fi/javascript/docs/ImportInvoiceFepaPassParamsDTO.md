# TseCloudFi.ImportInvoiceFepaPassParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**invoice** | [**TSDigitalInvoiceParams**](TSDigitalInvoiceParams.md) |  | [optional] 
**contentXml** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


