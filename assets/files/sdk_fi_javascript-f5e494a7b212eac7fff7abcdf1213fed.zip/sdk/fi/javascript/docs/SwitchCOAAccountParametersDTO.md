# TseCloudFi.SwitchCOAAccountParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idconto** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


