# TseCloudFi.InstalmentsUnpairingResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descriptionResult** | **String** |  | [optional] 
**result** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


