# TseCloudFi.COAGroupCodeFI

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descr** | **String** |  | [optional] 
**flgPdclib** | **Number** |  | [optional] 
**gruppo** | **Number** |  | [optional] 
**maskedit** | **String** |  | [optional] 
**numlivcons** | **Number** |  | [optional] 
**numlivelli** | **Number** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**accountProposals** | [**[COAAccountProposalFI]**](COAAccountProposalFI.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


