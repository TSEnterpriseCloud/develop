# TseCloudFi.CSCompanyBankCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cliforCg44** | **Number** |  | [optional] 
**dittaCg18** | **Number** |  | [optional] 
**flgPref** | **Number** |  | [optional] 
**id** | **Number** |  | [optional] 
**progR** | **Number** |  | [optional] 
**progREf08** | **Number** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**tipocfCg44** | **Number** |  | [optional] 
**parent** | [**CustomerSupplierCO**](CustomerSupplierCO.md) |  | [optional] 
**companyBankCO** | [**CompanyBankCO**](CompanyBankCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


