# TseCloudFi.DecumulateCalculationResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**decumulatedAmount** | **Number** |  | [optional] 
**taxAmount** | **Number** |  | [optional] 
**taxNdAmount** | **Number** |  | [optional] 
**debitCreditIndicator** | **Number** |  | [optional] 
**decumulatedAmountCC** | **Number** |  | [optional] 
**taxAmountCC** | **Number** |  | [optional] 
**taxNdAmountCC** | **Number** |  | [optional] 
**dataCambio** | **Date** |  | [optional] 
**cambio** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


