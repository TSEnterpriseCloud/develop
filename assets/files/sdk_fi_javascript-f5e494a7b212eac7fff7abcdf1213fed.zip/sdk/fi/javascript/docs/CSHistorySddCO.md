# TseCloudFi.CSHistorySddCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codBicswift** | **String** |  | [optional] 
**codClideb** | **String** |  | [optional] 
**codIndiv** | **Number** |  | [optional] 
**datavar** | **Date** |  | [optional] 
**id** | **Number** |  | [optional] 
**indStorno** | **Number** |  | [optional] 
**indTipoinc** | **Number** |  | [optional] 
**indTiposdd** | **Number** |  | [optional] 
**indTipovar** | **Number** |  | [optional] 
**ridiban** | **String** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**soggtitibanCg16** | **Number** |  | [optional] 
**tipologia** | **Number** |  | [optional] 
**parent** | [**CSSddCO**](CSSddCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


