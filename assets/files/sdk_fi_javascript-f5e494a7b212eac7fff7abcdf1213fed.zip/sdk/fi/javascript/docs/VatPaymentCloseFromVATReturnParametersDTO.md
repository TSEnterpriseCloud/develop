# TseCloudFi.VatPaymentCloseFromVATReturnParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idCg41List** | **[Number]** |  | [optional] 
**dateVATReturn** | **Date** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


