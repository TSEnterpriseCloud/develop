# TseCloudFi.DMSPublishedEntityFW

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**annofisc** | **Number** |  | [optional] 
**datafin** | **Date** |  | [optional] 
**dataini** | **Date** |  | [optional] 
**datapub** | **Date** |  | [optional] 
**dittaCg18** | **Number** |  | [optional] 
**flgInvalid** | **Number** |  | [optional] 
**flgUploadFile** | **Number** |  | [optional] 
**guid** | **String** |  | [optional] 
**hubid** | **String** |  | [optional] 
**idcct** | **Number** |  | [optional] 
**iddbArchivia** | **String** |  | [optional] 
**idHm33** | **Number** |  | [optional] 
**idknos** | **Number** |  | [optional] 
**nome** | **String** |  | [optional] 
**percorso** | **String** |  | [optional] 
**protocollo** | **String** |  | [optional] 
**recordArchivia** | **Number** |  | [optional] 
**serialArchivia** | **String** |  | [optional] 
**stampadesc** | **String** |  | [optional] 
**tipoarchHm30** | **Number** |  | [optional] 
**dmsStorageTypeFW** | [**DMSStorageTypeFW**](DMSStorageTypeFW.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


