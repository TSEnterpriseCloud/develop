# TseCloudFi.ZoneCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**areaMg08** | **String** |  | [optional] 
**codiceZona** | **String** |  | [optional] 
**descrzona** | **String** |  | [optional] 
**dittaCg18** | **Number** |  | [optional] 
**idEntityWithDescriptions** | **Number** |  | [optional] 
**idmediaCg99** | **Number** |  | [optional] 
**idprov** | **Number** |  | [optional] 
**macroareaMg08** | **String** |  | [optional] 
**tipocfMg08** | **Number** |  | [optional] 
**descrizioniLingua** | [**[LanguageDescriptionMGCO]**](LanguageDescriptionMGCO.md) |  | [optional] 
**parent** | [**AreaCO**](AreaCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


