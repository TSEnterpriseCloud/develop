# TseCloudFi.AccountingReasonCodeClassificationFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descr** | **String** | CGD1_DESCR - Descrizione | [optional] 
**id** | **Number** | CGD1_ID - Codice tipologia (Required only in PUT/PATCH) | [optional] 
**idmediaCg99** | **Number** | CGD1_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**tipologia** | **String** | CGD1_TIPOLOGIA - Tipologia | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


