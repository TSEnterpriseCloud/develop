# TseCloudFi.CommissionPercentageInstalmentParameterDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**glEntryId** | **Number** |  | [optional] 
**referenceDate** | **Date** |  | [optional] 
**settlementType** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


