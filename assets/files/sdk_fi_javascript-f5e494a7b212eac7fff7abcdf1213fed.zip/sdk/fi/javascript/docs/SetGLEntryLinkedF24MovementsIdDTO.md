# TseCloudFi.SetGLEntryLinkedF24MovementsIdDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idCg4t** | **Number** |  | [optional] 
**stageGuidGLEntryFI** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


