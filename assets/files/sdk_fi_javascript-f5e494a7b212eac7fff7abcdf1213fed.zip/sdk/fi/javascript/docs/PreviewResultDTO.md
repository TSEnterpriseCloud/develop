# TseCloudFi.PreviewResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**contentXML** | **String** |  | [optional] 


