# TseCloudFi.CSPaymentRangeCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aimpdoc** | **Number** |  | [optional] 
**cliforCg44** | **Number** |  | [optional] 
**codPagCg62** | **String** |  | [optional] 
**codScagl** | **Number** |  | [optional] 
**dittaCg18** | **Number** |  | [optional] 
**id** | **Number** |  | [optional] 
**idCg62** | **Number** |  | [optional] 
**idmediaCg99** | **Number** |  | [optional] 
**indPagpart** | **Number** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**tipocfCg44** | **Number** |  | [optional] 
**valutaCg08** | **String** |  | [optional] 
**parent** | [**CustomerSupplierCO**](CustomerSupplierCO.md) |  | [optional] 
**currencyCO** | [**CurrencyCO**](CurrencyCO.md) |  | [optional] 
**paymentTermCO** | [**PaymentTermCO**](PaymentTermCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


