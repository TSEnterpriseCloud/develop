# TseCloudFi.UpdateCustomAndLanguageDescriptionsResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**updateResult** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


