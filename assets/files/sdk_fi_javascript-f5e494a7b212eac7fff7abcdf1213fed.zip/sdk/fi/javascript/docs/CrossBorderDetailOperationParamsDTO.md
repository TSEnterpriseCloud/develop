# TseCloudFi.CrossBorderDetailOperationParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**glEntryDetailID** | **Number** |  | [optional] 
**indNatura** | **Number** |  | [optional] 
**flgDeducibile** | **Number** |  | [optional] 
**percDetr** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


