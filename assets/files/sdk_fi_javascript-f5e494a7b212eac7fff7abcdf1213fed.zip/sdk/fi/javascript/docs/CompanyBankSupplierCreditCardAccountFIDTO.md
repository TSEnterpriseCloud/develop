# TseCloudFi.CompanyBankSupplierCreditCardAccountFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codCarta** | **String** | EF15_CODCARTA - Codice carta di credito | 
**conchiucarcreCg24** | **String** | EF15_CONCHIUCARCRE_CG24 - Conto per chiusura carta di credito | [optional] 
**descrcarta** | **String** | EF15_DESCRCARTA - Descrizione carta di credito | [optional] 
**dittaCg18** | **Number** | EF15_DITTA_CG18 - Ditta | 
**flgPref** | **Number** | EF15_FLGPREF - Carta di credito preferenziale | 
**gruchiucarcreCg24** | **Number** | EF15_GRUCHIUCARCRE_CG24 - GruchiucarcreCg24 | [optional] 
**id** | **Number** | EF15_ID - ID (Required only in PUT/PATCH) | [optional] 
**idCg64** | **Number** | EF15_ID_CG64 - IdCg64 | 
**idchiucarcreCg24** | **Number** | EF15_IDCHIUCARCRE_CG24 - IdchiucarcreCg24 | [optional] 
**idEf08** | **Number** | EF15_ID_EF08 - IdEf08 | [optional] 
**indStipoeff** | **Number** | EF15_INDSTIPOEFF - Sottotipo effetto | 
**indTipoeff** | **Number** | EF15_INDTIPOEFF - Tipo effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Carta di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Bancomat&lt;/li&gt;&lt;/ul&gt; | [optional] 
**progREf08** | **Number** | EF15_PROGR_EF08 - ProgREf08 | 
**rowversion** | **Blob** | EF15_ROWVERSION - Rowversion | [optional] 
**coaAccountFI** | [**COAAccountDescrFIDTO**](COAAccountDescrFIDTO.md) |  | [optional] 
**subTypeCO** | [**SubTypeCODTO**](SubTypeCODTO.md) |  | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndTipoeffEnum


* `7` (value: `7`)

* `8` (value: `8`)




