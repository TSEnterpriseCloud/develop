# TseCloudFi.InstalmentsExchangeAdditionalInfoResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isValid** | **Boolean** |  | [optional] 
**exchangeDate** | **Date** |  | [optional] 
**exchangeRate** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


