# TseCloudFi.CrossBorderOperationParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**glEntryIDs** | **[Number]** |  | [optional] 
**tipoOperazione** | **Number** |  | [optional] 
**tipoImpostato** | **Number** |  | [optional] 
**tipoDaImpostare** | **Number** |  | [optional] 
**detraibilitaDaImpostare** | **Number** |  | [optional] 
**dataFinale** | **Date** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


