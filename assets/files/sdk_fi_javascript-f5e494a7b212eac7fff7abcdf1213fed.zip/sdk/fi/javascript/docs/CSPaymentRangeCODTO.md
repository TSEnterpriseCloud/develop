# TseCloudFi.CSPaymentRangeCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aimpdoc** | **Number** | MG20_AIMPDOC - Limite superiore | [optional] 
**cliforCg44** | **Number** | MG20_CLIFOR_CG44 - Codice Cliente / Fornitore | 
**codPagCg62** | **String** | MG20_CODPAG_CG62 - Condizione pagamento | [optional] 
**codScagl** | **Number** | MG20_CODSCAGL - Scaglione | 
**dittaCg18** | **Number** | MG20_DITTA_CG18 - DittaCg18 | 
**id** | **Number** | MG20_ID - Id (Required only in PUT/PATCH) | [optional] 
**idCg62** | **Number** | MG20_ID_CG62 - IdCg62 | [optional] 
**idmediaCg99** | **Number** | MG20_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**indPagpart** | **Number** | MG20_INDPAGPART - Applica condizione di pagamento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - del documento&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - dello scaglione&lt;/li&gt;&lt;/ul&gt; | [optional] 
**tipocfCg44** | **Number** | MG20_TIPOCF_CG44 - Tipo Cliente / Fornitore | 
**valutaCg08** | **String** | MG20_VALUTA_CG08 - Valuta | 
**currencyCO** | [**CurrencyCODTO**](CurrencyCODTO.md) |  | 
**paymentTermCO** | [**PaymentTermCODTO**](PaymentTermCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndPagpartEnum


* `0` (value: `0`)

* `1` (value: `1`)




