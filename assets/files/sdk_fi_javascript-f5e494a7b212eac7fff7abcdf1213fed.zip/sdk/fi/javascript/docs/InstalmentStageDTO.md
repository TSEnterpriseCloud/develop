# TseCloudFi.InstalmentStageDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stageGuid** | **String** |  | [optional] 
**paymentTerm** | **Number** |  | [optional] 
**conto** | **Number** |  | [optional] 
**cliFor** | **Number** |  | [optional] 
**numRegCo99** | **String** |  | [optional] 


