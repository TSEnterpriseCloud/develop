# TseCloudFi.VatRegisterSerializedResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**iDs** | **[Number]** |  | [optional] 
**businessTypeDataCO** | [**[BusinessTypeDataCODTO]**](BusinessTypeDataCODTO.md) |  | [optional] 
**companySectionalProposalCO** | [**[FinanceCompanySectionalProposalCODTO]**](FinanceCompanySectionalProposalCODTO.md) |  | [optional] 
**idClosedElaboration** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


