# TseCloudFi.CustomerSupplierCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**gmdUpdateAdditionalParams** | [**GMDUpdateAdditionalParametersDTO**](GMDUpdateAdditionalParametersDTO.md) |  | [optional] 
**clifor** | **Number** | CG44_CLIFOR - Codice cli/for | 
**codAbiCg12** | **Number** | CG44_CODABI_CG12 - Codice banca | [optional] 
**codCabCg13** | **Number** | CG44_CODCAB_CG13 - Codice agenzia | [optional] 
**codiceCg28** | **String** | CG44_CODICE_CG28 - Codice aliquota IVA | [optional] 
**contoCg24** | **String** | CG44_CONTO_CG24 - Conto merci | [optional] 
**contorCg24** | **String** | CG44_CONTOR_CG24 - Conto merci reso | [optional] 
**contratto** | **String** | CG44_CONTRATTO - Codice contratto | [optional] 
**datavaliva** | **Date** | CG44_DATAVALIVA - Fine validità codice IVA | [optional] 
**dittaCg18** | **Number** | CG44_DITTA_CG18 - Ditta | 
**flgArt62** | **Number** | CG44_FLGART62 - Flag Art. 62 | [optional] 
**flgAttivo** | **Number** | CG44_FLGATTIVO - Attivo | [optional] 
**flgCointestati** | **Number** | CG44_FLGCOINTESTATI - Cointestati | [optional] 
**flgIntercompany** | **Number** | CG44_FLGINTERCOMPANY - Gest. Intercompany | [optional] 
**ggscadfix** | **Number** | CG44_GGSCADFIX - GG scad. fix | [optional] 
**gruppoCg10** | **Number** | CG44_GRUPPO_CG10 - Codice Pdc | [optional] 
**guid** | **String** | CG44_GUID - GUID | [optional] 
**idclifor** | **Number** | CG44_IDCLIFOR - ID cliente (Required only in PUT/PATCH) | [optional] 
**idmediaCg99** | **Number** | CG44_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**indElenchimov3000** | **Number** | CG44_INDELENCHIMOV3000 - Ind. gestione elenchi mov. 3.000€&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;99&lt;/i&gt; - Come da anag. generale&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Contratto &gt;&#x3D; 3.000€&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Contratto corrisp. periodici&lt;/li&gt;&lt;/ul&gt; | [optional] 
**intermedioCg40** | **Number** | CG44_INTERMEDIO_CG40 - Codice intermedio | [optional] 
**lastchange** | **Date** | CG44_LASTCHANGE - Data ultima variazione | [optional] 
**progREf08** | **Number** | CG44_PROGR_EF08 - Codice banca aziendale | [optional] 
**tipocf** | **Number** | CG44_TIPOCF - Tipo Cliente / Fornitore&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**idExtendedAttributeEntity** | **Number** |  | [optional] 
**idExtendedAttributeSubEntity** | **Number** |  | [optional] 
**agentCO** | [**AgentCODTO**](AgentCODTO.md) |  | [optional] 
**blackListGeneralMasterData** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | [optional] 
**csAccountingIndexCO** | [**CSAccountingIndexCODTO**](CSAccountingIndexCODTO.md) |  | [optional] 
**csBankCO** | [**[CSBankCODTO]**](CSBankCODTO.md) |  | [optional] 
**csCompanyBankCO** | [**[CSCompanyBankCODTO]**](CSCompanyBankCODTO.md) |  | [optional] 
**csInfoCO** | [**CSInfoCODTO**](CSInfoCODTO.md) |  | [optional] 
**csJointlyHeldCO** | [**[CSJointlyHeldCODTO]**](CSJointlyHeldCODTO.md) |  | [optional] 
**csPaymentRangeCO** | [**[CSPaymentRangeCODTO]**](CSPaymentRangeCODTO.md) |  | [optional] 
**csPostponementPeriodCO** | [**[CSPostponementPeriodCODTO]**](CSPostponementPeriodCODTO.md) |  | [optional] 
**csSddCO** | [**[CSSddCODTO]**](CSSddCODTO.md) |  | [optional] 
**currencyCO** | [**CurrencyCODTO**](CurrencyCODTO.md) |  | [optional] 
**customerSupplierCIGCUPCO** | [**[CustomerSupplierCIGCUPCODTO]**](CustomerSupplierCIGCUPCODTO.md) |  | [optional] 
**custSupplDataInvoicePACO** | [**CustSupplDataInvoicePACODTO**](CustSupplDataInvoicePACODTO.md) |  | [optional] 
**dmsPublishedEntityFW** | [**DMSPublishedEntityFWDTO**](DMSPublishedEntityFWDTO.md) |  | 
**generalMasterDataCO** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | 
**officeCO** | [**OfficeCODTO**](OfficeCODTO.md) |  | [optional] 
**officePACO** | [**[OfficePACODTO]**](OfficePACODTO.md) |  | [optional] 
**paymentTermCO** | [**PaymentTermCODTO**](PaymentTermCODTO.md) |  | [optional] 
**vatCodeCO** | [**VatCodeCODTO**](VatCodeCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndElenchimov3000Enum


* `99` (value: `99`)

* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: TipocfEnum


* `0` (value: `0`)

* `1` (value: `1`)




