# TseCloudFi.AccountBalanceResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**openBalance** | **Number** |  | [optional] 
**previousBalance** | **Number** |  | [optional] 
**debitTotal** | **Number** |  | [optional] 
**creditTotal** | **Number** |  | [optional] 
**debitCreditBalance** | **Number** |  | [optional] 
**finalBalance** | **Number** |  | [optional] 
**openBalanceCurrency** | **Number** |  | [optional] 
**previousBalanceCurrency** | **Number** |  | [optional] 
**debitTotalCurrency** | **Number** |  | [optional] 
**creditTotalCurrency** | **Number** |  | [optional] 
**debitCreditBalanceCurrency** | **Number** |  | [optional] 
**finalBalanceCurrency** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


