# TseCloudFi.Int64StringValueTuple

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**item1** | **Number** |  | [optional] 
**item2** | **String** |  | [optional] 


