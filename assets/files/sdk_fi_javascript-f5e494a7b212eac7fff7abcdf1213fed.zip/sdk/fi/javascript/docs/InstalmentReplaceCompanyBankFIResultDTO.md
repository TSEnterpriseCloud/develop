# TseCloudFi.InstalmentReplaceCompanyBankFIResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | **Boolean** |  | [optional] 
**changedInstalmentIds** | **[Number]** |  | [optional] 
**errorInstalmentIds** | [**[Int64StringValueTuple]**](Int64StringValueTuple.md) |  | [optional] 
**notUpdatableIds** | **[Number]** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


