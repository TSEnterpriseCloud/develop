# TseCloudFi.StoreCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descrizione** | **String** | CG7A_DESCRIZIONE - Descrizione | [optional] 
**dittaCg18** | **Number** | CG7A_DITTA_CG18 - Ditta | 
**puntoven** | **Number** | CG7A_PUNTOVEN - Codice punto vendita | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


