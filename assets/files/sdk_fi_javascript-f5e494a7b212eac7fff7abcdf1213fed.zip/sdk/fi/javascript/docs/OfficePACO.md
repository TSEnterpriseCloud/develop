# TseCloudFi.OfficePACO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cap** | **String** |  | [optional] 
**codDestin** | **String** |  | [optional] 
**codice** | **String** |  | [optional] 
**codiceCg16** | **Number** |  | [optional] 
**comune** | **String** |  | [optional] 
**flgPreferenziale** | **Number** |  | [optional] 
**idprovincia** | **Number** |  | [optional] 
**idregione** | **Number** |  | [optional] 
**indIrizzo** | **String** |  | [optional] 
**indTypeb2b** | **Number** |  | [optional] 
**lastupdateB2b** | **Date** |  | [optional] 
**nome** | **String** |  | [optional] 
**tipocfCg44** | **Number** |  | [optional] 
**parent** | [**CustomerSupplierCO**](CustomerSupplierCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


