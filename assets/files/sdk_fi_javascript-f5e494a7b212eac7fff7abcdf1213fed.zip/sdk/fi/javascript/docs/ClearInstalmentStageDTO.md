# TseCloudFi.ClearInstalmentStageDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stageGuid** | **String** |  | [optional] 


