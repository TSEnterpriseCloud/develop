# TseCloudFi.EntryReferenceDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idCliFor** | **Number** |  | [optional] 
**idConto** | **Number** |  | [optional] 
**annoPart** | **Number** |  | [optional] 
**numeroPart** | **Number** |  | [optional] 
**sezionalePart** | **String** |  | [optional] 
**bisPart** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


