# TseCloudFi.InstalmentStageSearchParamsSettingsResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**indTipoOperazioneDefault** | **Number** |  | [optional] 
**tipoOperazioneBlocked** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


