# TseCloudFi.QuerySqlParamsValues

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **Number** |  | [optional] [readonly] 


