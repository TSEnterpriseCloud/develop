# TseCloudFi.XSLTResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**contentXSLT** | **String** |  | [optional] 
**contentXml** | **String** |  | [optional] 


