# TseCloudFi.GLEntryFIModuleIntegrationInfosUpdateResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


