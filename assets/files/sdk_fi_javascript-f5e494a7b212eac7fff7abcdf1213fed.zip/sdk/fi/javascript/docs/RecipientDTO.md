# TseCloudFi.RecipientDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** |  | [optional] 
**header** | **String** |  | [optional] 
**companyName** | **String** |  | [optional] 
**body** | **String** |  | [optional] 
**recipientAddress** | **String** |  | [optional] 
**language** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


