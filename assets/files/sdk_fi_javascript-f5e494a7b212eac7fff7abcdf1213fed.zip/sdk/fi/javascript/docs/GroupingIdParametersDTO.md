# TseCloudFi.GroupingIdParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groupingId** | **Number** |  | [optional] 


