# TseCloudFi.PairedInstalmentDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numrata** | **Number** |  | [optional] 
**tipoeff** | **Number** |  | [optional] 
**stipoeff** | **Number** |  | [optional] 
**datadoc** | **Date** |  | [optional] 
**numdoc** | **Number** |  | [optional] 
**sezdoc** | **String** |  | [optional] 
**numdocorig** | **String** |  | [optional] 
**impefforig** | **Number** |  | [optional] 
**scadeS** | **Date** |  | [optional] 
**amountPaired** | **Number** |  | [optional] 
**amountPairedDoc** | **Number** |  | [optional] 
**pairingMode** | **Number** |  | [optional] 
**idEf01** | **Number** |  | [optional] 


