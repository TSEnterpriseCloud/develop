# TseCloudFi.COAInternationalCustomizationFI

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categoria** | **Number** |  | [optional] 
**contoCg24** | **String** |  | [optional] 
**esModulo347** | **Number** |  | [optional] 
**gbDeferralcode** | **String** |  | [optional] 
**gruppoCg10** | **Number** |  | [optional] 
**id** | **Number** |  | [optional] 
**idCg24** | **Number** |  | [optional] 
**iso3166A2** | **String** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**subcategoria** | **Number** |  | [optional] 
**parent** | [**COAAccountFI**](COAAccountFI.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


