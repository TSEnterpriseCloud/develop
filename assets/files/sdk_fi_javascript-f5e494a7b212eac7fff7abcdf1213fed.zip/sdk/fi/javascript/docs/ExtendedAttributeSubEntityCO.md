# TseCloudFi.ExtendedAttributeSubEntityCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descr** | **String** |  | [optional] 
**flgPref** | **Number** |  | [optional] 
**flgVisibile** | **Number** |  | [optional] 
**idstipo** | **Number** |  | [optional] 
**idtipoCo5a** | **Number** |  | [optional] 
**extendedAttributeEntityCO** | [**ExtendedAttributeEntityCO**](ExtendedAttributeEntityCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


