# TseCloudFi.GLEntryFIMultipleCreateParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**vatReverseIncoporated** | **Boolean** |  | [optional] 
**items** | [**[GLEntryFIMultipleCreateParametersDTOItem]**](GLEntryFIMultipleCreateParametersDTOItem.md) |  | [optional] 
**externalModule** | **String** |  | [optional] 
**numDocAlreadyExistsAsError** | **Boolean** |  | [optional] 
**forceAssignedNumReg** | **Boolean** |  | [optional] 
**viewWarnings** | **Boolean** |  | [optional] 
**warningsToByPass** | **[Number]** |  | [optional] 
**recoverReverseChargeIfNotDefined** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


