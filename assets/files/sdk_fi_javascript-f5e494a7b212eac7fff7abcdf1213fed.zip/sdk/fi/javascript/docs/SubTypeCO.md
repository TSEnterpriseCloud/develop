# TseCloudFi.SubTypeCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codiceCg07** | **Number** |  | [optional] 
**codPaguc** | **String** |  | [optional] 
**codStipoeff** | **Number** |  | [optional] 
**descstipo** | **String** |  | [optional] 
**flgAssegno** | **Number** |  | [optional] 
**ggoffset** | **Number** |  | [optional] 
**id** | **Number** |  | [optional] 
**indModfatturapa** | **Number** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**tipoeff** | **Number** |  | [optional] 
**foreignPaymentCodeCO** | [**ForeignPaymentCodeCO**](ForeignPaymentCodeCO.md) |  | [optional] 
**nationCO** | [**NationCO**](NationCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


