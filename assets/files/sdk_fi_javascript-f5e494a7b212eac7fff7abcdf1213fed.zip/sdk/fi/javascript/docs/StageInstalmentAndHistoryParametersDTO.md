# TseCloudFi.StageInstalmentAndHistoryParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instalmentId** | **Number** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**manualOperation** | **Boolean** |  | [optional] 
**createStage** | **Boolean** |  | [optional] 
**indOperationType** | [**EOperationType**](EOperationType.md) |  | [optional] 
**indPresentation** | [**EPresentationBank**](EPresentationBank.md) |  | [optional] 
**presentationBank** | **Number** |  | [optional] 
**chkConsolidated** | **Boolean** |  | [optional] 
**chkToConsolidate** | **Boolean** |  | [optional] 
**chkMavWithIdentifier** | **Boolean** |  | [optional] 
**instalmentStartDate** | **Date** |  | [optional] 
**creationDate** | **Date** |  | [optional] 
**indPresentationBank** | **Number** |  | [optional] 
**indBankFilter** | [**EFilterBank**](EFilterBank.md) |  | [optional] 
**indOrdering** | [**EOrdering**](EOrdering.md) |  | [optional] 
**indGrouping** | [**EGrouping**](EGrouping.md) |  | [optional] 
**indSuspended** | [**ESuspended**](ESuspended.md) |  | [optional] 
**indSddType** | [**ESddType**](ESddType.md) |  | [optional] 
**valoreAnticipato** | **Number** |  | [optional] 
**indGroupingMode** | [**EGroupingMode**](EGroupingMode.md) |  | [optional] 
**valoreAnticipatoVal** | **Number** |  | [optional] 
**indRecCambio** | **Number** |  | [optional] 
**cambio** | **Number** |  | [optional] 
**dataCambio** | **Date** |  | [optional] 
**codiceCG08** | **String** |  | [optional] 
**impCastelletto** | **Number** |  | [optional] 
**indCheckPIvaCf** | [**ECheckPIvaCf**](ECheckPIvaCf.md) |  | [optional] 
**externalSearchGroup** | [**[StageInstalmentAndHistoryParametersDTOExternalSearchGroupInner]**](StageInstalmentAndHistoryParametersDTOExternalSearchGroupInner.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


