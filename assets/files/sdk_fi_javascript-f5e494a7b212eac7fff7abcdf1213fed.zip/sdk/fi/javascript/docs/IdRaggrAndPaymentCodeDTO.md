# TseCloudFi.IdRaggrAndPaymentCodeDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idRaggr** | **Number** |  | [optional] 
**paymentCode** | **String** |  | [optional] 
**effectiveDate** | **Date** |  | [optional] 


