# TseCloudFi.UpdateBankInstalmentsParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bankId** | **Number** |  | [optional] 
**instalmentIds** | **[Number]** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


