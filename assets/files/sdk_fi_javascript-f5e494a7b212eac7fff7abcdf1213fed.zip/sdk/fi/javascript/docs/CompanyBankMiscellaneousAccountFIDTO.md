# TseCloudFi.CompanyBankMiscellaneousAccountFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bancaCg12** | **Number** | EF13_BANCA_CG12 - Abi | [optional] 
**conchiueffCg24** | **String** | EF13_CONCHIUEFF_CG24 - Conto chiusura effetti | [optional] 
**conritspebanCg24** | **String** | EF13_CONRITSPEBAN_CG24 - Conto spese rit. addeb. dalla banca | [optional] 
**conritspecliCg24** | **String** | EF13_CONRITSPECLI_CG24 - Conto spese rit. addeb. al cliente | [optional] 
**dittaCg18** | **Number** | EF13_DITTA_CG18 - Ditta | 
**gruchiueffCg24** | **Number** | EF13_GRUCHIUEFF_CG24 - GruchiueffCg24 | [optional] 
**gruritspebanCg24** | **Number** | EF13_GRURITSPEBAN_CG24 - GruritspebanCg24 | [optional] 
**gruritspecliCg24** | **Number** | EF13_GRURITSPECLI_CG24 - GruritspecliCg24 | [optional] 
**id** | **Number** | EF13_ID - ID (Required only in PUT/PATCH) | [optional] 
**idchiueffCg24** | **Number** | EF13_IDCHIUEFF_CG24 - IdchiueffCg24 | [optional] 
**idEf08** | **Number** | EF13_ID_EF08 - IdEf08 | [optional] 
**idritspebanCg24** | **Number** | EF13_IDRITSPEBAN_CG24 - IdritspebanCg24 | [optional] 
**idritspecliCg24** | **Number** | EF13_IDRITSPECLI_CG24 - IdritspecliCg24 | [optional] 
**indEffclifor** | **Number** | EF13_INDEFFCLIFOR - Cliente / Fornitore&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Clienti&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Fornitori&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTipoeff** | **Number** | EF13_INDTIPOEFF - Tipo effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Ri.Ba.&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Tratte, Tratte acc.&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Cessioni, Cambiali&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - RID&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - MAV&lt;/li&gt;&lt;/ul&gt; | [optional] 
**rowversion** | **Blob** | EF13_ROWVERSION - Rowversion | [optional] 
**bankCO** | [**BankCODTO**](BankCODTO.md) |  | [optional] 
**bankReturnFee** | [**COAAccountDescrFIDTO**](COAAccountDescrFIDTO.md) |  | [optional] 
**billClosing** | [**COAAccountDescrFIDTO**](COAAccountDescrFIDTO.md) |  | [optional] 
**customerReturnFee** | [**COAAccountDescrFIDTO**](COAAccountDescrFIDTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndEffcliforEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndTipoeffEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)




