# TseCloudFi.InstalmentAccountingEntriesFIParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**guid** | **String** |  | [optional] 
**joinDate** | **Date** |  | [optional] 
**opType** | [**OperationType**](OperationType.md) |  | [optional] 
**edited** | **Boolean** |  | [optional] 
**isGrouped** | **Boolean** |  | [optional] 
**bankTransactionId** | **Number** |  | [optional] 
**treasuryTransactionId** | **Number** |  | [optional] 
**operationBankId** | **Number** |  | [optional] 
**groupedInstalments** | **Boolean** |  | [optional] 
**glEntryId** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


