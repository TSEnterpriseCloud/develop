# TseCloudFi.CIGCUPMasterDataCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cig** | **String** |  | [optional] 
**cup** | **String** |  | [optional] 
**descrizione** | **String** |  | [optional] 
**docrifData** | **Date** |  | [optional] 
**docrifId** | **String** |  | [optional] 
**flgAttivo** | **Number** |  | [optional] 
**id** | **Number** |  | [optional] 
**indTipocontr** | **Number** |  | [optional] 
**indTipodocrif** | **Number** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


