# TseCloudFi.DeleteClosingReopeningResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**deletedProcessingDetailId** | **Number** |  | [optional] 
**deletedIdsCGY2** | **[Number]** |  | [optional] 
**deletedIdsGLEntry** | **[Number]** |  | [optional] 
**result** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


