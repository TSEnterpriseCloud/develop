# TseCloudFi.COAAccountMaskResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flgFreeFormatCode** | **Boolean** |  | [optional] 
**level** | **Number** |  | [optional] 
**maxLevel** | **Number** |  | [optional] 
**maskCG10** | **String** |  | [optional] 
**tsMask** | **String** |  | [optional] 
**regExpMask** | **String** |  | [optional] 
**regExpMaskAnyChar** | **[String]** |  | [optional] 
**prefixedPart** | **String** |  | [optional] 
**regExpVariablePart** | **String** |  | [optional] 
**suffixedPart** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


