# TseCloudFi.COAAccountProposalDefinitionFI

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codice** | **Number** |  | [optional] 
**descr** | **String** |  | [optional] 
**flgNoproco** | **Number** |  | [optional] 
**indProcoecb** | **Number** |  | [optional] 
**indProcof24** | **Number** |  | [optional] 
**posizione** | **Number** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


