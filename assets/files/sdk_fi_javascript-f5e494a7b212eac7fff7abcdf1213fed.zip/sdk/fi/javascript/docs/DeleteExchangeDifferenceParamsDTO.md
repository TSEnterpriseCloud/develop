# TseCloudFi.DeleteExchangeDifferenceParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isSimulated** | **Boolean** |  | [optional] 
**processingDetailId** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


