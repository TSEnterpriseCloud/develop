# TseCloudFi.SearchNodeDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**operator** | [**SearchLogicalOperators**](SearchLogicalOperators.md) |  | [optional] 


