# TseCloudFi.CreateMultiGLEntryJobResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | [**[GLEntryFIPublishStageJobDTO]**](GLEntryFIPublishStageJobDTO.md) |  | [optional] 
**id** | **String** |  | [optional] 
**jobId** | **Number** |  | [optional] 
**status** | **Number** |  | [optional] 
**additionalInfo** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


