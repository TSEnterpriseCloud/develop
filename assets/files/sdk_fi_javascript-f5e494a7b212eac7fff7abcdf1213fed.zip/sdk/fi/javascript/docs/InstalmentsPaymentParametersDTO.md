# TseCloudFi.InstalmentsPaymentParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dataOperazione** | **Date** |  | [optional] 
**tipoOperazione** | **Number** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**instalmentID** | **Number** |  | [optional] 
**importoIncassoPagamento** | **Number** |  | [optional] 
**importoAbbuono** | **Number** |  | [optional] 
**frazionamento** | **Boolean** |  | [optional] 
**tipoEffettoFrazionamento** | **Number** |  | [optional] 
**sottotipoEffettoFrazionamento** | **Number** |  | [optional] 
**dataScadenzaFrazionamento** | **Date** |  | [optional] 
**numeroAssegno** | **String** |  | [optional] 
**riferimentoAssegno** | **String** |  | [optional] 
**differenzaCambio** | **Boolean** |  | [optional] 
**cambioData** | **Date** |  | [optional] 
**cambioValore** | **Number** |  | [optional] 
**causaleContabile** | **String** |  | [optional] 
**modalitaDifferenzaCambi** | **Number** |  | [optional] 
**numReg** | **String** |  | [optional] 
**instalmentHistoryId** | **Number** |  | [optional] 
**tipoMovimento** | **Number** |  | [optional] 
**speseInsoluto** | **Number** |  | [optional] 
**importoSpeseInsoluto** | **Number** |  | [optional] 
**idContoSpese** | **Number** |  | [optional] 
**importoDiffCambio** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


