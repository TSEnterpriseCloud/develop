# TseCloudFi.TsDigitalImportDocParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**configCreationRequired** | **Boolean** |  | [optional] 
**ids** | **[Number]** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


