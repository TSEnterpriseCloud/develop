# TseCloudFi.GLReverseTypeFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reverseTypeCode** | **Number** |  | [optional] 
**reverseTypeDescription** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


