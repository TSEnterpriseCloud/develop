# TseCloudFi.InsertMissingExchangeRatesParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**companyCurrency** | **String** |  | [optional] 
**exchangeRates** | [**[ExchangeRateParamsDTO]**](ExchangeRateParamsDTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


