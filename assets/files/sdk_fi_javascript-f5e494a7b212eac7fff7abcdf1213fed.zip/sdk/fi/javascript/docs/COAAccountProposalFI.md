# TseCloudFi.COAAccountProposalFI

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codice** | **Number** |  | [optional] 
**contoCg24** | **String** |  | [optional] 
**gruppoCg10** | **Number** |  | [optional] 
**id** | **Number** |  | [optional] 
**idCg24** | **Number** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**parent** | [**COAGroupCodeFI**](COAGroupCodeFI.md) |  | [optional] 
**coaAccountFI** | [**COAAccountFI**](COAAccountFI.md) |  | [optional] 
**coaAccountProposalDefinitionFI** | [**COAAccountProposalDefinitionFI**](COAAccountProposalDefinitionFI.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


