# TseCloudFi.PaymentTermCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codPag** | **String** |  | [optional] 
**descPag** | **String** |  | [optional] 
**desPagAnal** | **String** |  | [optional] 
**flgDesc** | **Number** |  | [optional] 
**flgDisgg** | **Number** |  | [optional] 
**flgPrefatt** | **Number** |  | [optional] 
**flgPrefpass** | **Number** |  | [optional] 
**flgStornoiva** | **Number** |  | [optional] 
**guid** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**idEntityWithDescriptions** | **Number** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**scart26** | **Number** |  | [optional] 
**scpercart26** | **Number** |  | [optional] 
**scpercas** | **Number** |  | [optional] 
**scpermer1** | **Number** |  | [optional] 
**scpermer2** | **Number** |  | [optional] 
**removedExtendedAttribute** | [**ExtendedAttributeValuesCO**](ExtendedAttributeValuesCO.md) |  | [optional] 
**extendedAttribute** | [**ExtendedAttributeValuesCO**](ExtendedAttributeValuesCO.md) |  | [optional] 
**languageDescriptionCO** | [**[LanguageDescriptionCO]**](LanguageDescriptionCO.md) |  | [optional] 
**paymentTermDetailCO** | [**[PaymentTermDetailCO]**](PaymentTermDetailCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


