# TseCloudFi.ListSendingLetterCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dataimpegno** | **Date** |  | [optional] 
**dataprotocollo** | **Date** |  | [optional] 
**dittaCg18** | **Number** |  | [optional] 
**flgCessanmarino** | **Number** |  | [optional] 
**flgCessintra** | **Number** |  | [optional] 
**flgDichivapres** | **Number** |  | [optional] 
**flgEsport** | **Number** |  | [optional] 
**flgOperassim** | **Number** |  | [optional] 
**flgOperstraord** | **Number** |  | [optional] 
**id** | **Number** |  | [optional] 
**intermediarioCg77** | **Number** |  | [optional] 
**note** | **String** |  | [optional] 
**numprotocollo** | **Number** |  | [optional] 
**progR** | **Number** |  | [optional] 
**rowversion** | **Blob** |  | [optional] 
**tipoplafond** | **Number** |  | [optional] 
**digitalSendersCO** | [**DigitalSendersCO**](DigitalSendersCO.md) |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


