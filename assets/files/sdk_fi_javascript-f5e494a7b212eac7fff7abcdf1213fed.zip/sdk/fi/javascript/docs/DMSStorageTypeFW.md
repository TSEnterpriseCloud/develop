# TseCloudFi.DMSStorageTypeFW

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**campoguid** | **String** |  | [optional] 
**desc** | **String** |  | [optional] 
**flagstd** | **Number** |  | [optional] 
**id** | **Number** |  | [optional] 
**idvocets** | **Number** |  | [optional] 
**indPostingType** | **Number** |  | [optional] 
**indSyncType** | **Number** |  | [optional] 
**oldconf** | **Number** |  | [optional] 
**sqljoin** | **String** |  | [optional] 
**subidvocets** | **Number** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


