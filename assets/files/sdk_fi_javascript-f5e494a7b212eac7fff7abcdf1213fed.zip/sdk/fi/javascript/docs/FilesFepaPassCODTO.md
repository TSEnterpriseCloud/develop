# TseCloudFi.FilesFepaPassCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**batchid** | **String** | IE83_BATCHID - Batchid | [optional] 
**cedprestCodFisc** | **String** | IE83_CEDPREST_CODFISC - CedprestCodFisc | [optional] 
**cedprestCognome** | **String** | IE83_CEDPREST_COGNOME - CedprestCognome | [optional] 
**cedprestDenom** | **String** | IE83_CEDPREST_DENOM - CedprestDenom | [optional] 
**cedprestId** | **String** | IE83_CEDPREST_ID - CedprestId | [optional] 
**cedprestNome** | **String** | IE83_CEDPREST_NOME - CedprestNome | [optional] 
**cedprestPaeseid** | **String** | IE83_CEDPREST_PAESEID - CedprestPaeseid | [optional] 
**cedprestTitolo** | **String** | IE83_CEDPREST_TITOLO - CedprestTitolo | [optional] 
**cesscomCodFisc** | **String** | IE83_CESSCOM_CODFISC - CesscomCodFisc | [optional] 
**cesscomCognome** | **String** | IE83_CESSCOM_COGNOME - CesscomCognome | [optional] 
**cesscomDenom** | **String** | IE83_CESSCOM_DENOM - CesscomDenom | [optional] 
**cesscomId** | **String** | IE83_CESSCOM_ID - CesscomId | [optional] 
**cesscomNome** | **String** | IE83_CESSCOM_NOME - CesscomNome | [optional] 
**cesscomPaeseid** | **String** | IE83_CESSCOM_PAESEID - CesscomPaeseid | [optional] 
**changeType** | **Number** | IE83_CHANGETYPE - Tipo di modifica | 
**codiceraggr** | **String** | IE83_CODICERAGGR - Codiceraggr | [optional] 
**conallegato** | **Number** | IE83_CONALLEGATO - Conallegato | 
**dataconsegnasdi** | **Date** | IE83_DATACONSEGNASDI - Dataconsegnasdi | [optional] 
**datadoc** | **String** | IE83_DATADOC - Datadoc | [optional] 
**datecreation** | **Date** | IE83_DATECREATION - Datecreation | [optional] 
**dittaCg18** | **Number** | IE83_DITTA_CG18 - DittaCg18 | [optional] 
**divisa** | **String** | IE83_DIVISA - Divisa | [optional] 
**emitstrasmId** | **String** | IE83_EMITSTRASM_ID - EmitstrasmId | [optional] 
**emitstrasmPaeseid** | **String** | IE83_EMITSTRASM_PAESEID - EmitstrasmPaeseid | [optional] 
**errori** | **String** | IE83_ERRORI - Errori | [optional] 
**esito** | **Number** | IE83_ESITO - Esito | 
**esitoGenerazione** | **Number** | IE83_ESITO_GENERAZIONE - EsitoGenerazione | 
**esitoImport** | **Number** | IE83_ESITO_IMPORT - EsitoImport&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Non processato&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Sono presenti avvisi&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Sono presenti errori&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Importato&lt;/li&gt;&lt;/ul&gt; | [optional] 
**filedocdata** | **Date** | IE83_FILEDOCDATA - Filedocdata | [optional] 
**filedocnum** | **String** | IE83_FILEDOCNUM - Filedocnum | [optional] 
**filename** | **String** | IE83_FILENAME - Filename | [optional] 
**filetype** | **String** | IE83_FILETYPE - Filetype | [optional] 
**flowtype** | **String** | IE83_FLOWTYPE - Flowtype | [optional] 
**guidDo11** | **String** | IE83_GUID_DO11 - GuidDo11 | [optional] 
**hashcode** | **String** | IE83_HASHCODE - Hashcode | [optional] 
**hubid** | **String** | IE83_HUBID - Hubid | [optional] 
**id** | **Number** | IE83_ID - Id (Required only in PUT/PATCH) | [optional] 
**identificativosdi** | **String** | IE83_IDENTIFICATIVOSDI - Identificativo SDI | [optional] 
**idlotto** | **Number** | IE83_IDLOTTO - Idlotto | [optional] 
**idproformaCg41** | **Number** | IE83_IDPROFORMA_CG41 - Riferimento proforma | [optional] 
**imptotdoc** | **Number** | IE83_IMPTOTDOC - Imptotdoc | [optional] 
**modificato** | **Number** | IE83_MODIFICATO - Modificato | 
**objectcct** | **Number** | IE83_OBJECTCCT - Objectcct | [optional] 
**objectid** | **Number** | IE83_OBJECTID - Objectid | [optional] 
**posfat** | **Number** | IE83_POSFAT - Posfat | [optional] 
**progInvio** | **String** | IE83_PROGINVIO - ProgInvio | [optional] 
**recipientid** | **String** | IE83_RECIPIENTID - Recipientid | [optional] 
**senderid** | **String** | IE83_SENDERID - Senderid | [optional] 
**statecheck** | **Number** | IE83_STATECHECK - Statecheck | 
**statusdate** | **Date** | IE83_STATUSDATE - Statusdate | [optional] 
**statusid** | **Number** | IE83_STATUSID - Statusid | [optional] 
**statusname** | **String** | IE83_STATUSNAME - Statusname | [optional] 
**tipodoc** | **String** | IE83_TIPODOC - Tipodoc | [optional] 
**tipoentita** | **Number** | IE83_TIPOENTITA - Tipoentita | 
**tracciatoIe82** | **Number** | IE83_TRACCIATO_IE82 - TracciatoIe82 | [optional] 
**trasmitterid** | **String** | IE83_TRASMITTERID - Trasmitterid | [optional] 
**userfilename** | **String** | IE83_USERFILENAME - Userfilename | [optional] 
**versione** | **String** | IE83_VERSIONE - Versione | [optional] 
**xml** | **String** | IE83_XML - Xml | [optional] 
**b2BHeaderCODTO** | [**B2BHeaderCODTO**](B2BHeaderCODTO.md) |  | [optional] 
**b2BResultsCODTO** | [**[B2BResultsCODTO]**](B2BResultsCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: EsitoImportEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)




