# TseCloudFi.InstalmentAccountingEntriesFIResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**executionResult** | **Boolean** |  | [optional] 
**entries** | [**[GLEntryFI]**](GLEntryFI.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


