# TseCloudFi.InstalmentPaymentDataDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idInstalment** | **Number** |  | [optional] 
**entryReference** | [**EntryReferenceDTO**](EntryReferenceDTO.md) |  | [optional] 
**numRigaCont** | **Number** |  | [optional] 
**importoPagato** | **Number** |  | [optional] 
**importoAbbuono** | **Number** |  | [optional] 
**numeroAssegno** | **String** |  | [optional] 
**riferimentiAssegno** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


