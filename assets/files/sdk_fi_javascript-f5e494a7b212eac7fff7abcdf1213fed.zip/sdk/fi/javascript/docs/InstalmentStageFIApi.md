# TseCloudFi.InstalmentStageFIApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiV1EnvironmentFIInstalmentStageFICalculateNextInstalmentStageNumberingPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFICalculateNextInstalmentStageNumberingPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/calculate_next_instalment_stage_numbering | TODO_DOCUMENTATION
[**apiV1EnvironmentFIInstalmentStageFICheckglentrychangeallowedPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFICheckglentrychangeallowedPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/checkglentrychangeallowed | Check if a GLEnty can be modified or deleted
[**apiV1EnvironmentFIInstalmentStageFICheckglentryrowchangeallowedPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFICheckglentryrowchangeallowedPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/checkglentryrowchangeallowed | TODO_DOCUMENTATION
[**apiV1EnvironmentFIInstalmentStageFICheckinstalmentsstageamountsPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFICheckinstalmentsstageamountsPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/checkinstalmentsstageamounts | TODO_DOCUMENTATION
[**apiV1EnvironmentFIInstalmentStageFICheckstagedataPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFICheckstagedataPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/checkstagedata | Check instalment data on stage before save
[**apiV1EnvironmentFIInstalmentStageFIClearinstalmentstagePost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIClearinstalmentstagePost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/clearinstalmentstage | Delete all Stage table of a pairing account
[**apiV1EnvironmentFIInstalmentStageFIClearstagePost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIClearstagePost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/clearstage | TODO_DOCUMENTATION
[**apiV1EnvironmentFIInstalmentStageFIDeleteinstalmenthistorystagePost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIDeleteinstalmenthistorystagePost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/deleteinstalmenthistorystage | Delete Instalment History Stage
[**apiV1EnvironmentFIInstalmentStageFIGet**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIGet) | **GET** /api/v1/{environment}/FI/InstalmentStageFI | Get new
[**apiV1EnvironmentFIInstalmentStageFIGetInstalmentStageSearchParamsSettingsPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIGetInstalmentStageSearchParamsSettingsPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/get_instalment_stage_search_params_settings | TODO_DOCUMENTATION
[**apiV1EnvironmentFIInstalmentStageFIGetinstalmentdepositfromstagePost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIGetinstalmentdepositfromstagePost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/getinstalmentdepositfromstage | Retrieve deposit from stage
[**apiV1EnvironmentFIInstalmentStageFIGetinstalmentondocumentPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIGetinstalmentondocumentPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/getinstalmentondocument | Retrieve instalments of a document
[**apiV1EnvironmentFIInstalmentStageFIGetinstalmentpairingondocumentPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIGetinstalmentpairingondocumentPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/getinstalmentpairingondocument | Get Instalment paired on stage
[**apiV1EnvironmentFIInstalmentStageFIIdDelete**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIIdDelete) | **DELETE** /api/v1/{environment}/FI/InstalmentStageFI/{id} | Delete
[**apiV1EnvironmentFIInstalmentStageFIIdGet**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIIdGet) | **GET** /api/v1/{environment}/FI/InstalmentStageFI/{id} | Get by ID
[**apiV1EnvironmentFIInstalmentStageFIIdPatch**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIIdPatch) | **PATCH** /api/v1/{environment}/FI/InstalmentStageFI/{id} | Update partial
[**apiV1EnvironmentFIInstalmentStageFIIdPut**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIIdPut) | **PUT** /api/v1/{environment}/FI/InstalmentStageFI/{id} | Update
[**apiV1EnvironmentFIInstalmentStageFIInitializePost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIInitializePost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/initialize | Acquisition of deadlines in the staging tables
[**apiV1EnvironmentFIInstalmentStageFIInsertinstalmenttostagePost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIInsertinstalmenttostagePost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/insertinstalmenttostage | Insert instalments to stage
[**apiV1EnvironmentFIInstalmentStageFIInstalmentcalculationPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIInstalmentcalculationPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/instalmentcalculation | TODO_DOCUMENTATION
[**apiV1EnvironmentFIInstalmentStageFIInstalmentspairingPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIInstalmentspairingPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/instalmentspairing | Instalments pairing
[**apiV1EnvironmentFIInstalmentStageFIInstalmentspairingblockedPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIInstalmentspairingblockedPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/instalmentspairingblocked | TODO_DOCUMENTATION
[**apiV1EnvironmentFIInstalmentStageFIInstalmentspaymentPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIInstalmentspaymentPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/instalmentspayment | Instalments payment
[**apiV1EnvironmentFIInstalmentStageFIInstalmentsunpairingPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIInstalmentsunpairingPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/instalmentsunpairing | Instalments unpairing
[**apiV1EnvironmentFIInstalmentStageFIManagestageddataPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIManagestageddataPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/managestageddata | Insert InstalmentStageFI into InstalmentFI
[**apiV1EnvironmentFIInstalmentStageFIMarkdeletedstagedataPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIMarkdeletedstagedataPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/markdeletedstagedata | Mark deleted instalment data on stage
[**apiV1EnvironmentFIInstalmentStageFIPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI | Create
[**apiV1EnvironmentFIInstalmentStageFIReadPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIReadPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/read | Read
[**apiV1EnvironmentFIInstalmentStageFISearchPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFISearchPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/search | Search
[**apiV1EnvironmentFIInstalmentStageFIUpdatestageextensiondataPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIUpdatestageextensiondataPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/updatestageextensiondata | TODO_DOCUMENTATION
[**apiV1EnvironmentFIInstalmentStageFIValidatePost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIValidatePost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/validate | Validate
[**apiV1EnvironmentFIInstalmentStageFIValidatePropertiesPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIValidatePropertiesPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/validateProperties | Validation of one on more properties of Type
[**apiV1EnvironmentFIInstalmentStageFIWritestageoncontextualPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIWritestageoncontextualPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/writestageoncontextual | TODO_DOCUMENTATION
[**apiV1EnvironmentFIInstalmentStageFIWritingstageoncollectionoperationPost**](InstalmentStageFIApi.md#apiV1EnvironmentFIInstalmentStageFIWritingstageoncollectionoperationPost) | **POST** /api/v1/{environment}/FI/InstalmentStageFI/writingstageoncollectionoperation | Writing stage on collection operation



## apiV1EnvironmentFIInstalmentStageFICalculateNextInstalmentStageNumberingPost

> InstalmentNumberingCalculationResultDTO apiV1EnvironmentFIInstalmentStageFICalculateNextInstalmentStageNumberingPost(environment, authorizationScope, instalmentStageNumberingCalculationParametersDTO, opts)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentStageNumberingCalculationParametersDTO = new TseCloudFi.InstalmentStageNumberingCalculationParametersDTO(); // InstalmentStageNumberingCalculationParametersDTO | TODO_DOCUMENTATION
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFICalculateNextInstalmentStageNumberingPost(environment, authorizationScope, instalmentStageNumberingCalculationParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentStageNumberingCalculationParametersDTO** | [**InstalmentStageNumberingCalculationParametersDTO**](InstalmentStageNumberingCalculationParametersDTO.md)| TODO_DOCUMENTATION | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentNumberingCalculationResultDTO**](InstalmentNumberingCalculationResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFICheckglentrychangeallowedPost

> ExecutionResultMessageDTO apiV1EnvironmentFIInstalmentStageFICheckglentrychangeallowedPost(environment, authorizationScope, gLEntryChangeAllowedDTO, opts)

Check if a GLEnty can be modified or deleted

Check if a GLEnty can be modified or deleted

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let gLEntryChangeAllowedDTO = new TseCloudFi.GLEntryChangeAllowedDTO(); // GLEntryChangeAllowedDTO | Input parameter to verify if GLEntry can be modified, it contains the numReg
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFICheckglentrychangeallowedPost(environment, authorizationScope, gLEntryChangeAllowedDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **gLEntryChangeAllowedDTO** | [**GLEntryChangeAllowedDTO**](GLEntryChangeAllowedDTO.md)| Input parameter to verify if GLEntry can be modified, it contains the numReg | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**ExecutionResultMessageDTO**](ExecutionResultMessageDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFICheckglentryrowchangeallowedPost

> apiV1EnvironmentFIInstalmentStageFICheckglentryrowchangeallowedPost(environment, authorizationScope, gLEntryRowChangeAllowedDTO, opts)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let gLEntryRowChangeAllowedDTO = new TseCloudFi.GLEntryRowChangeAllowedDTO(); // GLEntryRowChangeAllowedDTO | TODO_DOCUMENTATION
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFICheckglentryrowchangeallowedPost(environment, authorizationScope, gLEntryRowChangeAllowedDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **gLEntryRowChangeAllowedDTO** | [**GLEntryRowChangeAllowedDTO**](GLEntryRowChangeAllowedDTO.md)| TODO_DOCUMENTATION | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFICheckinstalmentsstageamountsPost

> FIGLEntriesExecutionResultDTO apiV1EnvironmentFIInstalmentStageFICheckinstalmentsstageamountsPost(environment, authorizationScope, checkInstalmentsStageAmountsParametersDTO, opts)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let checkInstalmentsStageAmountsParametersDTO = new TseCloudFi.CheckInstalmentsStageAmountsParametersDTO(); // CheckInstalmentsStageAmountsParametersDTO | TODO_DOCUMENTATION
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFICheckinstalmentsstageamountsPost(environment, authorizationScope, checkInstalmentsStageAmountsParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **checkInstalmentsStageAmountsParametersDTO** | [**CheckInstalmentsStageAmountsParametersDTO**](CheckInstalmentsStageAmountsParametersDTO.md)| TODO_DOCUMENTATION | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFICheckstagedataPost

> apiV1EnvironmentFIInstalmentStageFICheckstagedataPost(environment, authorizationScope, checkInstalmentStageDTO, opts)

Check instalment data on stage before save

Instalment check

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let checkInstalmentStageDTO = new TseCloudFi.CheckInstalmentStageDTO(); // CheckInstalmentStageDTO | Input parameter to precede for instalment check before save
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFICheckstagedataPost(environment, authorizationScope, checkInstalmentStageDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **checkInstalmentStageDTO** | [**CheckInstalmentStageDTO**](CheckInstalmentStageDTO.md)| Input parameter to precede for instalment check before save | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIClearinstalmentstagePost

> FIGLEntriesExecutionResultDTO apiV1EnvironmentFIInstalmentStageFIClearinstalmentstagePost(environment, authorizationScope, clearInstalmentStageDTO, opts)

Delete all Stage table of a pairing account

Delete all Stage table of a pairing account

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let clearInstalmentStageDTO = new TseCloudFi.ClearInstalmentStageDTO(); // ClearInstalmentStageDTO | StageGuid of a pairing
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIClearinstalmentstagePost(environment, authorizationScope, clearInstalmentStageDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **clearInstalmentStageDTO** | [**ClearInstalmentStageDTO**](ClearInstalmentStageDTO.md)| StageGuid of a pairing | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIClearstagePost

> FIGLEntriesExecutionResultDTO apiV1EnvironmentFIInstalmentStageFIClearstagePost(environment, authorizationScope, clearInstalmentStageDTO, opts)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let clearInstalmentStageDTO = new TseCloudFi.ClearInstalmentStageDTO(); // ClearInstalmentStageDTO | TODO_DOCUMENTATION
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIClearstagePost(environment, authorizationScope, clearInstalmentStageDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **clearInstalmentStageDTO** | [**ClearInstalmentStageDTO**](ClearInstalmentStageDTO.md)| TODO_DOCUMENTATION | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIDeleteinstalmenthistorystagePost

> FIGLEntriesExecutionResultDTO apiV1EnvironmentFIInstalmentStageFIDeleteinstalmenthistorystagePost(environment, authorizationScope, clearInstalmentStageDTO, opts)

Delete Instalment History Stage

Delete the instalment stage 

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let clearInstalmentStageDTO = new TseCloudFi.ClearInstalmentStageDTO(); // ClearInstalmentStageDTO | The StageGuid of instalment
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIDeleteinstalmenthistorystagePost(environment, authorizationScope, clearInstalmentStageDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **clearInstalmentStageDTO** | [**ClearInstalmentStageDTO**](ClearInstalmentStageDTO.md)| The StageGuid of instalment | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIGet

> InstalmentStageFIDTO apiV1EnvironmentFIInstalmentStageFIGet(op, environment, authorizationScope, opts)

Get new

Get an empty object of type corresponding

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let op = "op_example"; // String | The value must be 'new'
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIGet(op, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **op** | **String**| The value must be &#39;new&#39; | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentStageFIDTO**](InstalmentStageFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIGetInstalmentStageSearchParamsSettingsPost

> InstalmentStageSearchParamsSettingsResultDTO apiV1EnvironmentFIInstalmentStageFIGetInstalmentStageSearchParamsSettingsPost(environment, authorizationScope, guidFIDTO, opts)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let guidFIDTO = new TseCloudFi.GuidFIDTO(); // GuidFIDTO | TODO_DOCUMENTATION
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIGetInstalmentStageSearchParamsSettingsPost(environment, authorizationScope, guidFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **guidFIDTO** | [**GuidFIDTO**](GuidFIDTO.md)| TODO_DOCUMENTATION | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentStageSearchParamsSettingsResultDTO**](InstalmentStageSearchParamsSettingsResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIGetinstalmentdepositfromstagePost

> Int64ListGLEntryGenericResultDTO apiV1EnvironmentFIInstalmentStageFIGetinstalmentdepositfromstagePost(environment, authorizationScope, instalmentToStageGuidParameterDTO, opts)

Retrieve deposit from stage

Retreve the list of Id of deposit in stage

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentToStageGuidParameterDTO = new TseCloudFi.InstalmentToStageGuidParameterDTO(); // InstalmentToStageGuidParameterDTO | Input parameters
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIGetinstalmentdepositfromstagePost(environment, authorizationScope, instalmentToStageGuidParameterDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentToStageGuidParameterDTO** | [**InstalmentToStageGuidParameterDTO**](InstalmentToStageGuidParameterDTO.md)| Input parameters | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**Int64ListGLEntryGenericResultDTO**](Int64ListGLEntryGenericResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIGetinstalmentondocumentPost

> DocumentInstalmentsResultDTO apiV1EnvironmentFIInstalmentStageFIGetinstalmentondocumentPost(environment, authorizationScope, documentInstalmentsParametersDTO, opts)

Retrieve instalments of a document

Retrieve instalments of a document

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let documentInstalmentsParametersDTO = new TseCloudFi.DocumentInstalmentsParametersDTO(); // DocumentInstalmentsParametersDTO | The Numreg of instalments
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIGetinstalmentondocumentPost(environment, authorizationScope, documentInstalmentsParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **documentInstalmentsParametersDTO** | [**DocumentInstalmentsParametersDTO**](DocumentInstalmentsParametersDTO.md)| The Numreg of instalments | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**DocumentInstalmentsResultDTO**](DocumentInstalmentsResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIGetinstalmentpairingondocumentPost

> DocumentInstalmentsResultDTO apiV1EnvironmentFIInstalmentStageFIGetinstalmentpairingondocumentPost(environment, authorizationScope, documentInstalmentsStageParametersDTO, opts)

Get Instalment paired on stage

Retrieve instalment paired on document and delete stage

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let documentInstalmentsStageParametersDTO = new TseCloudFi.DocumentInstalmentsStageParametersDTO(); // DocumentInstalmentsStageParametersDTO | The StageGuid of pairing operation
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIGetinstalmentpairingondocumentPost(environment, authorizationScope, documentInstalmentsStageParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **documentInstalmentsStageParametersDTO** | [**DocumentInstalmentsStageParametersDTO**](DocumentInstalmentsStageParametersDTO.md)| The StageGuid of pairing operation | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**DocumentInstalmentsResultDTO**](DocumentInstalmentsResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIIdDelete

> apiV1EnvironmentFIInstalmentStageFIIdDelete(id, environment, authorizationScope, opts)

Delete

Deleting object of type 

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIIdDelete(id, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIIdGet

> InstalmentStageFIDTO apiV1EnvironmentFIInstalmentStageFIIdGet(id, environment, authorizationScope, opts)

Get by ID

Get an object of type corresponding the requested id

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let id = "id_example"; // String | Id to get the object
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'dlevel': "dlevel_example", // String | Serialization level
  'dlevelkey': "dlevelkey_example", // String | Serialization level key
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIIdGet(id, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Id to get the object | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **dlevel** | **String**| Serialization level | [optional] 
 **dlevelkey** | **String**| Serialization level key | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentStageFIDTO**](InstalmentStageFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIIdPatch

> apiV1EnvironmentFIInstalmentStageFIIdPatch(id, environment, authorizationScope, body, opts)

Update partial

Patching an object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let body = null; // Object | Object of type to patch
let opts = {
  'force': "force_example", // String | The warning/s code to bypass (separated by ‘,’) during the execution
  'op': "op_example", // String | Set 'reload', if you want the DTO updated in the response request
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIIdPatch(id, environment, authorizationScope, body, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **body** | **Object**| Object of type to patch | 
 **force** | **String**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **String**| Set &#39;reload&#39;, if you want the DTO updated in the response request | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIIdPut

> InstalmentStageFIDTO apiV1EnvironmentFIInstalmentStageFIIdPut(id, environment, authorizationScope, instalmentStageFIDTO, opts)

Update

Updating an object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentStageFIDTO = new TseCloudFi.InstalmentStageFIDTO(); // InstalmentStageFIDTO | Object of type to update
let opts = {
  'force': "force_example", // String | The warning/s code to bypass (separated by ‘,’) during the execution
  'op': "op_example", // String | Set 'reload', if you want the DTO updated in the response request, otherwise will be returned null value
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIIdPut(id, environment, authorizationScope, instalmentStageFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentStageFIDTO** | [**InstalmentStageFIDTO**](InstalmentStageFIDTO.md)| Object of type to update | 
 **force** | **String**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **String**| Set &#39;reload&#39;, if you want the DTO updated in the response request, otherwise will be returned null value | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentStageFIDTO**](InstalmentStageFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIInitializePost

> InstalmentStageFIResultDTO apiV1EnvironmentFIInstalmentStageFIInitializePost(environment, authorizationScope, instalmentStageFIParametersDTO, opts)

Acquisition of deadlines in the staging tables

Acquisition of deadlines in the staging tables

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentStageFIParametersDTO = new TseCloudFi.InstalmentStageFIParametersDTO(); // InstalmentStageFIParametersDTO | Object that contains all the parameters necessary for the recovery and insertion in the stage of the deadlines
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIInitializePost(environment, authorizationScope, instalmentStageFIParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentStageFIParametersDTO** | [**InstalmentStageFIParametersDTO**](InstalmentStageFIParametersDTO.md)| Object that contains all the parameters necessary for the recovery and insertion in the stage of the deadlines | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentStageFIResultDTO**](InstalmentStageFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIInsertinstalmenttostagePost

> BooleanGLEntryGenericResultDTO apiV1EnvironmentFIInstalmentStageFIInsertinstalmenttostagePost(environment, authorizationScope, instalmentToStageParameterDTO, opts)

Insert instalments to stage

Insert instalments to stage

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentToStageParameterDTO = new TseCloudFi.InstalmentToStageParameterDTO(); // InstalmentToStageParameterDTO | Input parameters
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIInsertinstalmenttostagePost(environment, authorizationScope, instalmentToStageParameterDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentToStageParameterDTO** | [**InstalmentToStageParameterDTO**](InstalmentToStageParameterDTO.md)| Input parameters | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**BooleanGLEntryGenericResultDTO**](BooleanGLEntryGenericResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIInstalmentcalculationPost

> InstalmentCalculationResultFIDTO apiV1EnvironmentFIInstalmentStageFIInstalmentcalculationPost(environment, authorizationScope, instalmentCalculationParametersFIDTO, opts)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentCalculationParametersFIDTO = new TseCloudFi.InstalmentCalculationParametersFIDTO(); // InstalmentCalculationParametersFIDTO | TODO_DOCUMENTATION
let opts = {
  'create': "create_example", // String | create
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIInstalmentcalculationPost(environment, authorizationScope, instalmentCalculationParametersFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentCalculationParametersFIDTO** | [**InstalmentCalculationParametersFIDTO**](InstalmentCalculationParametersFIDTO.md)| TODO_DOCUMENTATION | 
 **create** | **String**| create | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentCalculationResultFIDTO**](InstalmentCalculationResultFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIInstalmentspairingPost

> InstalmentsPairingResultDTO apiV1EnvironmentFIInstalmentStageFIInstalmentspairingPost(environment, authorizationScope, instalmentsPairingParametersDTO, opts)

Instalments pairing

Instalments pairing

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentsPairingParametersDTO = new TseCloudFi.InstalmentsPairingParametersDTO(); // InstalmentsPairingParametersDTO | Object that contains all the parameters necessary for the association of advances to deadlines
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIInstalmentspairingPost(environment, authorizationScope, instalmentsPairingParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentsPairingParametersDTO** | [**InstalmentsPairingParametersDTO**](InstalmentsPairingParametersDTO.md)| Object that contains all the parameters necessary for the association of advances to deadlines | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentsPairingResultDTO**](InstalmentsPairingResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIInstalmentspairingblockedPost

> InstalmentsPairingBlockedResultDTO apiV1EnvironmentFIInstalmentStageFIInstalmentspairingblockedPost(environment, authorizationScope, instalmentsPairingBlockedParametersDTO, opts)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentsPairingBlockedParametersDTO = new TseCloudFi.InstalmentsPairingBlockedParametersDTO(); // InstalmentsPairingBlockedParametersDTO | TODO_DOCUMENTATION
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIInstalmentspairingblockedPost(environment, authorizationScope, instalmentsPairingBlockedParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentsPairingBlockedParametersDTO** | [**InstalmentsPairingBlockedParametersDTO**](InstalmentsPairingBlockedParametersDTO.md)| TODO_DOCUMENTATION | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentsPairingBlockedResultDTO**](InstalmentsPairingBlockedResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIInstalmentspaymentPost

> InstalmentsPaymentResultDTO apiV1EnvironmentFIInstalmentStageFIInstalmentspaymentPost(environment, authorizationScope, instalmentsPaymentParametersDTO, opts)

Instalments payment

Instalments payment

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentsPaymentParametersDTO = new TseCloudFi.InstalmentsPaymentParametersDTO(); // InstalmentsPaymentParametersDTO | Object that contains all the parameters necessary for payment / collection of deadlines
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIInstalmentspaymentPost(environment, authorizationScope, instalmentsPaymentParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentsPaymentParametersDTO** | [**InstalmentsPaymentParametersDTO**](InstalmentsPaymentParametersDTO.md)| Object that contains all the parameters necessary for payment / collection of deadlines | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentsPaymentResultDTO**](InstalmentsPaymentResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIInstalmentsunpairingPost

> InstalmentsUnpairingResultDTO apiV1EnvironmentFIInstalmentStageFIInstalmentsunpairingPost(force, environment, authorizationScope, instalmentsUnpairingParametersDTO, opts)

Instalments unpairing

Instalments unpairing

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let force = "force_example"; // String | force
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentsUnpairingParametersDTO = new TseCloudFi.InstalmentsUnpairingParametersDTO(); // InstalmentsUnpairingParametersDTO | Object that contains all the parameters necessary to disassociate advances from deadlines
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIInstalmentsunpairingPost(force, environment, authorizationScope, instalmentsUnpairingParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **force** | **String**| force | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentsUnpairingParametersDTO** | [**InstalmentsUnpairingParametersDTO**](InstalmentsUnpairingParametersDTO.md)| Object that contains all the parameters necessary to disassociate advances from deadlines | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentsUnpairingResultDTO**](InstalmentsUnpairingResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIManagestageddataPost

> InstalmentStageFIResultDTO apiV1EnvironmentFIInstalmentStageFIManagestageddataPost(environment, authorizationScope, instalmentStageDTO, opts)

Insert InstalmentStageFI into InstalmentFI

Insert all instalments from stage that correspond to the GUID and registration number

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentStageDTO = new TseCloudFi.InstalmentStageDTO(); // InstalmentStageDTO | TODO_DOCUMENTATION
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIManagestageddataPost(environment, authorizationScope, instalmentStageDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentStageDTO** | [**InstalmentStageDTO**](InstalmentStageDTO.md)| TODO_DOCUMENTATION | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentStageFIResultDTO**](InstalmentStageFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIMarkdeletedstagedataPost

> FIGLEntriesExecutionResultDTO apiV1EnvironmentFIInstalmentStageFIMarkdeletedstagedataPost(environment, authorizationScope, instalmentMarkDeletedStageDataDTO, opts)

Mark deleted instalment data on stage

Mark deleted instalment

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentMarkDeletedStageDataDTO = new TseCloudFi.InstalmentMarkDeletedStageDataDTO(); // InstalmentMarkDeletedStageDataDTO | Input parameter to precede for mark deleted instalment data
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIMarkdeletedstagedataPost(environment, authorizationScope, instalmentMarkDeletedStageDataDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentMarkDeletedStageDataDTO** | [**InstalmentMarkDeletedStageDataDTO**](InstalmentMarkDeletedStageDataDTO.md)| Input parameter to precede for mark deleted instalment data | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIPost

> InstalmentStageFIDTO apiV1EnvironmentFIInstalmentStageFIPost(environment, authorizationScope, instalmentStageFIDTO, opts)

Create

Creating new object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentStageFIDTO = new TseCloudFi.InstalmentStageFIDTO(); // InstalmentStageFIDTO | Object of type to create
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIPost(environment, authorizationScope, instalmentStageFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentStageFIDTO** | [**InstalmentStageFIDTO**](InstalmentStageFIDTO.md)| Object of type to create | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentStageFIDTO**](InstalmentStageFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIReadPost

> InstalmentStageFIDTO apiV1EnvironmentFIInstalmentStageFIReadPost(environment, authorizationScope, searchElementDTO, opts)

Read

Read among object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let searchElementDTO = [new TseCloudFi.SearchElementDTO()]; // [SearchElementDTO] | Search criteria to apply
let opts = {
  'dlevel': "dlevel_example", // String | Serialization level
  'dlevelkey': "dlevelkey_example", // String | Serialization level key
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIReadPost(environment, authorizationScope, searchElementDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **searchElementDTO** | [**[SearchElementDTO]**](SearchElementDTO.md)| Search criteria to apply | 
 **dlevel** | **String**| Serialization level | [optional] 
 **dlevelkey** | **String**| Serialization level key | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentStageFIDTO**](InstalmentStageFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFISearchPost

> InstalmentStageFIDTO apiV1EnvironmentFIInstalmentStageFISearchPost(environment, authorizationScope, searchDTO, opts)

Search

Search among object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let searchDTO = new TseCloudFi.SearchDTO(); // SearchDTO | Search criteria to apply
let opts = {
  'loadEntireDomain': "loadEntireDomain_example", // String | Specify 'loadEntireDomain=true' if you want all the aggregate
  'getTotalCount': "getTotalCount_example", // String | Specify 'getTotalCount=true' if you want the total number of elements
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFISearchPost(environment, authorizationScope, searchDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **searchDTO** | [**SearchDTO**](SearchDTO.md)| Search criteria to apply | 
 **loadEntireDomain** | **String**| Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate | [optional] 
 **getTotalCount** | **String**| Specify &#39;getTotalCount&#x3D;true&#39; if you want the total number of elements | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentStageFIDTO**](InstalmentStageFIDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIUpdatestageextensiondataPost

> FIGLEntriesExecutionResultDTO apiV1EnvironmentFIInstalmentStageFIUpdatestageextensiondataPost(environment, authorizationScope, instalmentStageFIDTO, opts)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentStageFIDTO = new TseCloudFi.InstalmentStageFIDTO(); // InstalmentStageFIDTO | TODO_DOCUMENTATION
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIUpdatestageextensiondataPost(environment, authorizationScope, instalmentStageFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentStageFIDTO** | [**InstalmentStageFIDTO**](InstalmentStageFIDTO.md)| TODO_DOCUMENTATION | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**FIGLEntriesExecutionResultDTO**](FIGLEntriesExecutionResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIValidatePost

> apiV1EnvironmentFIInstalmentStageFIValidatePost(environment, authorizationScope, instalmentStageFIDTO, opts)

Validate

Validation of object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentStageFIDTO = new TseCloudFi.InstalmentStageFIDTO(); // InstalmentStageFIDTO | Object of type to validate
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIValidatePost(environment, authorizationScope, instalmentStageFIDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentStageFIDTO** | [**InstalmentStageFIDTO**](InstalmentStageFIDTO.md)| Object of type to validate | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIValidatePropertiesPost

> ValidateDTO apiV1EnvironmentFIInstalmentStageFIValidatePropertiesPost(environment, authorizationScope, opts)

Validation of one on more properties of Type

Validation of object of type

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'", // String | Example for multilanguage
  'body': null // String |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br>
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIValidatePropertiesPost(environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]
 **body** | **String**|  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED&lt;br&gt; - The id of an existing object to validate properties, or &#39;&#39; if the object does not exist yet &lt;br&gt; | [optional] 

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIWritestageoncontextualPost

> InstalmentStageContextualFIResultDTO apiV1EnvironmentFIInstalmentStageFIWritestageoncontextualPost(environment, authorizationScope, instalmentStageContextualFIParametersDTO, opts)

TODO_DOCUMENTATION

TODO_DOCUMENTATION

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentStageContextualFIParametersDTO = new TseCloudFi.InstalmentStageContextualFIParametersDTO(); // InstalmentStageContextualFIParametersDTO | TODO_DOCUMENTATION
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIWritestageoncontextualPost(environment, authorizationScope, instalmentStageContextualFIParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentStageContextualFIParametersDTO** | [**InstalmentStageContextualFIParametersDTO**](InstalmentStageContextualFIParametersDTO.md)| TODO_DOCUMENTATION | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**InstalmentStageContextualFIResultDTO**](InstalmentStageContextualFIResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFIInstalmentStageFIWritingstageoncollectionoperationPost

> ExecutionResultMessageDTO apiV1EnvironmentFIInstalmentStageFIWritingstageoncollectionoperationPost(environment, authorizationScope, instalmentStageCollectionOperationParametersDTO, opts)

Writing stage on collection operation

Writing stage on collection operation

### Example

```javascript
import TseCloudFi from 'tse_cloud_fi';
let defaultClient = TseCloudFi.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFi.InstalmentStageFIApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let instalmentStageCollectionOperationParametersDTO = new TseCloudFi.InstalmentStageCollectionOperationParametersDTO(); // InstalmentStageCollectionOperationParametersDTO | Object that contains all the parameters necessary for payment / collection of deadlines
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFIInstalmentStageFIWritingstageoncollectionoperationPost(environment, authorizationScope, instalmentStageCollectionOperationParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **instalmentStageCollectionOperationParametersDTO** | [**InstalmentStageCollectionOperationParametersDTO**](InstalmentStageCollectionOperationParametersDTO.md)| Object that contains all the parameters necessary for payment / collection of deadlines | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**ExecutionResultMessageDTO**](ExecutionResultMessageDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml

