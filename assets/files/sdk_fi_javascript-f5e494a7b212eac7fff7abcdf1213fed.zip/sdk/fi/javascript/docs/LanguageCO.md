# TseCloudFi.LanguageCO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codLingua** | **String** |  | [optional] 
**descrlingua** | **String** |  | [optional] 
**idmediaCg99** | **Number** |  | [optional] 
**iso639** | **String** |  | [optional] 
**siglalingua** | **String** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**stageState** | [**StageState**](StageState.md) |  | [optional] 
**stageId** | **Number** |  | [optional] 
**stageParentId** | **Number** |  | [optional] 
**domainState** | [**DomainState**](DomainState.md) |  | [optional] 
**state** | [**State**](State.md) |  | [optional] 
**internalState** | [**State**](State.md) |  | [optional] 
**currentDeserializationLevel** | **String** |  | [optional] 
**modifiedProperties** | **[String]** |  | [optional] 
**isTransferring** | **Boolean** |  | [optional] 
**isExternalSyncEnabled** | **Boolean** |  | [optional] 
**isInMapping** | **Boolean** |  | [optional] 


