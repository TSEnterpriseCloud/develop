'use strict';


/**
 * Return Document processing status
 * Document processing status
 *
 * body SearchDTO Search criteria to apply
 * loadEntireDomain String Specify 'loadEntireDomain=true' if you want all the aggregate
 * getTotalCount String Specify 'getTotalCount=true' if you want the total number of elements (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns DocumentoStatoEvasoMGDTO
 **/
exports.apiV1EnvironmentMGDocumentServiceDocprocessingstatusPOST = function(body,loadEntireDomain,getTotalCount,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "flgDaevadere" : 2.3021358869347655,
  "valoreres" : 9.369310271410669,
  "valoretrasf" : 6.683562403749608,
  "qta1doc" : 1.0246457001441578,
  "qta2trasf" : 4.965218492984954,
  "indStatoriga" : 4,
  "collidoc" : 6.027456183070403,
  "qta2res" : 1.1730742509559433,
  "tipodocDo11" : 5.025004791520295,
  "flgEvasoparz" : 9.301444243932576,
  "flgEvaso" : 7.061401241503109,
  "collires" : 1.4658129805029452,
  "numregfatCo99" : "numregfatCo99",
  "annoDoc" : 0.8008281904610115,
  "numregCo99" : "numregCo99",
  "id" : 3,
  "additionalData" : {
    "key" : ""
  },
  "numdocDo11" : 7.386281948385884,
  "qta2doc" : 7.457744773683766,
  "idDo11" : 2,
  "progRigaDo30" : 1.2315135367772556,
  "valoredoc" : 9.965781217890562,
  "dataDoc" : "2000-01-23T04:56:07.000+00:00",
  "qta1res" : 1.4894159098541704,
  "qta1trasf" : 6.84685269835264,
  "collitrasf" : 5.962133916683182,
  "extensionData" : [ null, null ],
  "dittaCg18" : 5.637376656633329,
  "documentoStatoEvasoCorpoRifMG" : [ {
    "idrifDo33Do30" : 3,
    "numregDo33Co99" : "numregDo33Co99",
    "numregrifCo99Do33Do30" : "numregrifCo99Do33Do30",
    "idDo33" : 9,
    "dittaDo33Cg18" : 8.762042012749001,
    "idDo33Do30" : 6,
    "additionalData" : {
      "key" : ""
    },
    "extensionData" : [ {
      "value" : "",
      "key" : "key"
    }, {
      "value" : "",
      "key" : "key"
    } ],
    "progRigaDo33" : 6.965117697638846
  }, {
    "idrifDo33Do30" : 3,
    "numregDo33Co99" : "numregDo33Co99",
    "numregrifCo99Do33Do30" : "numregrifCo99Do33Do30",
    "idDo33" : 9,
    "dittaDo33Cg18" : 8.762042012749001,
    "idDo33Do30" : 6,
    "additionalData" : {
      "key" : ""
    },
    "extensionData" : [ {
      "value" : "",
      "key" : "key"
    }, {
      "value" : "",
      "key" : "key"
    } ],
    "progRigaDo33" : 6.965117697638846
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Insert Multiple Documents for async process
 * Document async multiple process
 *
 * body List Object of type to create
 * force String Force values (optional)
 * withvalidpreconditions Boolean Validate Preconditions (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns DocumentoTestataOutMGDTO
 **/
exports.apiV1EnvironmentMGDocumentServiceMultiplecreatePOST = function(body,force,withvalidpreconditions,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "guidSession" : "guidSession"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete records for multiple insert documents by guid
 * Deleting object of type 
 *
 * id String 
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * progress String Force values (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * acceptLanguage String Example for multilanguage (optional)
 * no response value expected for this operation
 **/
exports.apiV1EnvironmentMGDocumentServiceMultiplecreatehistoryIdDELETE = function(id,environment,authorizationScope,progress,company,user,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Multiple Documents reprocess operations for async insert by guid
 * Document async multiple reprocess
 *
 * body List Object of type to update
 * force String Force values (optional)
 * withvalidpreconditions Boolean Validate Preconditions (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * guid String That's Guid Session MixMatch documents insert value
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns DocumentoTestataOutMGDTO
 **/
exports.apiV1EnvironmentMGDocumentServiceMultiplecreatereprocessGuidPOST = function(body,force,withvalidpreconditions,company,user,guid,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "guidSession" : "guidSession"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete record for async process portfolio orders
 * Deleting object of type 
 *
 * id String 
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * acceptLanguage String Example for multilanguage (optional)
 * no response value expected for this operation
 **/
exports.apiV1EnvironmentMGDocumentServiceOrderavailabilityIdDELETE = function(id,environment,authorizationScope,company,user,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Return Documents Order Portfolio
 * Document processing status
 *
 * body DocumentoPortfolioEvadInMGDTO Object of type to validate
 * force String Force values (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns DocumentoPortfolioEvadOrdineOutMGSetDTO
 **/
exports.apiV1EnvironmentMGDocumentServiceOrderavailabilityPOST = function(body,force,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "guidSession" : "guidSession",
  "rows" : [ {
    "qtaTrasformazione" : 3.616076749251911,
    "qtaBloccata" : 4.965218492984954,
    "rifdata" : "rifdata",
    "descartMg87" : "descartMg87",
    "qta1Do30" : 2.3021358869347655,
    "giacEff" : 7.386281948385884,
    "impCli" : 6.84685269835264,
    "prior" : 5.637376656633329,
    "ragsoanagCg16" : "ragsoanagCg16",
    "cliforDo11" : 6.027456183070403,
    "codArtDo30" : "codArtDo30",
    "ordProd" : 1.4894159098541704,
    "numdocDo11" : 1.4658129805029452,
    "sezdocDo11" : "sezdocDo11",
    "giacenzaDisponibileUm1" : 2.027123023002322,
    "giacdispAllaData" : 1.2315135367772556,
    "importoRigares" : 5.025004791520295,
    "opzioneDo30" : "opzioneDo30",
    "progVisuastaDo30" : 5.962133916683182,
    "qtaord" : 9.301444243932576,
    "importoDo30" : 9.965781217890562,
    "totDocres" : 9.369310271410669,
    "giacAtt" : 4.145608029883936,
    "datacons" : "2000-01-23T04:56:07.000+00:00",
    "impClav" : 1.1730742509559433,
    "datadocDo11" : "2000-01-23T04:56:07.000+00:00",
    "documDo11" : "documDo11",
    "ordFor" : 1.0246457001441578,
    "statoRiga" : 0.8008281904610115,
    "qtagiac" : 7.061401241503109,
    "impProd" : 7.457744773683766
  }, {
    "qtaTrasformazione" : 3.616076749251911,
    "qtaBloccata" : 4.965218492984954,
    "rifdata" : "rifdata",
    "descartMg87" : "descartMg87",
    "qta1Do30" : 2.3021358869347655,
    "giacEff" : 7.386281948385884,
    "impCli" : 6.84685269835264,
    "prior" : 5.637376656633329,
    "ragsoanagCg16" : "ragsoanagCg16",
    "cliforDo11" : 6.027456183070403,
    "codArtDo30" : "codArtDo30",
    "ordProd" : 1.4894159098541704,
    "numdocDo11" : 1.4658129805029452,
    "sezdocDo11" : "sezdocDo11",
    "giacenzaDisponibileUm1" : 2.027123023002322,
    "giacdispAllaData" : 1.2315135367772556,
    "importoRigares" : 5.025004791520295,
    "opzioneDo30" : "opzioneDo30",
    "progVisuastaDo30" : 5.962133916683182,
    "qtaord" : 9.301444243932576,
    "importoDo30" : 9.965781217890562,
    "totDocres" : 9.369310271410669,
    "giacAtt" : 4.145608029883936,
    "datacons" : "2000-01-23T04:56:07.000+00:00",
    "impClav" : 1.1730742509559433,
    "datadocDo11" : "2000-01-23T04:56:07.000+00:00",
    "documDo11" : "documDo11",
    "ordFor" : 1.0246457001441578,
    "statoRiga" : 0.8008281904610115,
    "qtagiac" : 7.061401241503109,
    "impProd" : 7.457744773683766
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Document transformation based on the required parameters
 * Document transformation based on the required parameters
 *
 * body DocumentTransformationParameterDTO Document transformation parameters
 * force String Force values (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns DocumentTransformationParameterDTO
 **/
exports.apiV1EnvironmentMGDocumentServiceTransformPOST = function(body,force,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "rowSearchTransformationCriteria" : {
    "visibleColumns" : "visibleColumns",
    "selectList" : "selectList",
    "pageNumber" : 5,
    "pageSize" : 5,
    "idRow" : "idRow",
    "filters" : {
      "items" : [ "", "" ]
    },
    "orderingProperties" : {
      "key" : ""
    },
    "parameters" : {
      "key" : ""
    }
  },
  "documentTransformationPartialEvadContainerGeneralData" : [ {
    "documentTransformationGeneralData" : [ {
      "scper1" : 4.145608029883936,
      "scper2" : 7.386281948385884,
      "rowNotEvad" : false,
      "increase1" : 1.0246457001441578,
      "codartMg66" : "codartMg66",
      "increase2" : 1.4894159098541704,
      "progrRiga" : 2.3021358869347655,
      "descart" : "descart",
      "qtaTransf" : 9.301444243932576,
      "indtiporiga" : 7,
      "increaseImp" : 6.84685269835264,
      "price1" : 3.616076749251911,
      "scImp" : 1.2315135367772556,
      "price2" : 2.027123023002322
    }, {
      "scper1" : 4.145608029883936,
      "scper2" : 7.386281948385884,
      "rowNotEvad" : false,
      "increase1" : 1.0246457001441578,
      "codartMg66" : "codartMg66",
      "increase2" : 1.4894159098541704,
      "progrRiga" : 2.3021358869347655,
      "descart" : "descart",
      "qtaTransf" : 9.301444243932576,
      "indtiporiga" : 7,
      "increaseImp" : 6.84685269835264,
      "price1" : 3.616076749251911,
      "scImp" : 1.2315135367772556,
      "price2" : 2.027123023002322
    } ],
    "numRegOrigin" : "numRegOrigin"
  }, {
    "documentTransformationGeneralData" : [ {
      "scper1" : 4.145608029883936,
      "scper2" : 7.386281948385884,
      "rowNotEvad" : false,
      "increase1" : 1.0246457001441578,
      "codartMg66" : "codartMg66",
      "increase2" : 1.4894159098541704,
      "progrRiga" : 2.3021358869347655,
      "descart" : "descart",
      "qtaTransf" : 9.301444243932576,
      "indtiporiga" : 7,
      "increaseImp" : 6.84685269835264,
      "price1" : 3.616076749251911,
      "scImp" : 1.2315135367772556,
      "price2" : 2.027123023002322
    }, {
      "scper1" : 4.145608029883936,
      "scper2" : 7.386281948385884,
      "rowNotEvad" : false,
      "increase1" : 1.0246457001441578,
      "codartMg66" : "codartMg66",
      "increase2" : 1.4894159098541704,
      "progrRiga" : 2.3021358869347655,
      "descart" : "descart",
      "qtaTransf" : 9.301444243932576,
      "indtiporiga" : 7,
      "increaseImp" : 6.84685269835264,
      "price1" : 3.616076749251911,
      "scImp" : 1.2315135367772556,
      "price2" : 2.027123023002322
    } ],
    "numRegOrigin" : "numRegOrigin"
  } ],
  "codModelTransfDoc" : "codModelTransfDoc",
  "numRegOrigin" : [ "numRegOrigin", "numRegOrigin" ],
  "processExtremLimits" : {
    "destinationDocParams" : {
      "dataCompVatMan" : "2000-01-23T04:56:07.000+00:00",
      "sezdoc" : "sezdoc",
      "numDoc" : 6.027456183070403,
      "dataDoc" : "2000-01-23T04:56:07.000+00:00",
      "numDocOrig" : 1.4658129805029452,
      "dataReg" : "2000-01-23T04:56:07.000+00:00"
    },
    "acceptDocMode" : 0
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

