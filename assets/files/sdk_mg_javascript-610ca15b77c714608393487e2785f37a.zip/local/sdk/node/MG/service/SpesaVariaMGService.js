'use strict';


/**
 * Get new
 * Get an empty object of type corresponding
 *
 * _op String The value must be 'new'
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * acceptLanguage String Example for multilanguage (optional)
 * returns SpesaVariaMGDTO
 **/
exports.apiV1EnvironmentMGSpesaVariaMGGET = function(_op,environment,authorizationScope,company,user,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "flgRicfatriep" : 5.6644160867523485,
  "flgVentstat" : 4.372688051310086,
  "flgIvaincl" : 1,
  "indTipoevas" : 9.785002165136461,
  "idmediaCg99" : 5.7911894223693885,
  "codice" : "codice",
  "indTotspese" : 7.92839742024475,
  "indRotturacorpo" : 1.0639121808530916,
  "indTipospesa" : 7.3718573971919445,
  "extensionData" : [ null, null ],
  "indGesintra" : 3.8008573585058016,
  "descr" : "descr",
  "indFatriep" : 5.974942028545841,
  "indTipotot" : 7.726998920545485,
  "indTipoaliq" : 3.2841216543560217,
  "flgVentamm" : 1.5970080735609526,
  "additionalData" : {
    "key" : ""
  },
  "flgOramin" : 3.812761638325517
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete
 * Deleting object of type 
 *
 * id String 
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * acceptLanguage String Example for multilanguage (optional)
 * no response value expected for this operation
 **/
exports.apiV1EnvironmentMGSpesaVariaMGIdDELETE = function(id,environment,authorizationScope,company,user,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get by ID
 * Get an object of type corresponding the requested id
 *
 * id String Id to get the object
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * dlevel String Serialization level (optional)
 * dlevelkey String Serialization level key (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * acceptLanguage String Example for multilanguage (optional)
 * returns SpesaVariaMGDTO
 **/
exports.apiV1EnvironmentMGSpesaVariaMGIdGET = function(id,environment,authorizationScope,dlevel,dlevelkey,company,user,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "flgRicfatriep" : 5.6644160867523485,
  "flgVentstat" : 4.372688051310086,
  "flgIvaincl" : 1,
  "indTipoevas" : 9.785002165136461,
  "idmediaCg99" : 5.7911894223693885,
  "codice" : "codice",
  "indTotspese" : 7.92839742024475,
  "indRotturacorpo" : 1.0639121808530916,
  "indTipospesa" : 7.3718573971919445,
  "extensionData" : [ null, null ],
  "indGesintra" : 3.8008573585058016,
  "descr" : "descr",
  "indFatriep" : 5.974942028545841,
  "indTipotot" : 7.726998920545485,
  "indTipoaliq" : 3.2841216543560217,
  "flgVentamm" : 1.5970080735609526,
  "additionalData" : {
    "key" : ""
  },
  "flgOramin" : 3.812761638325517
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update partial
 * Patching an object of type
 *
 * body  Object of type to patch
 * force String The warning/s code to bypass (separated by ‘,’) during the execution (optional)
 * _op String Set 'reload', if you want the DTO updated in the response request (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * id String 
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * no response value expected for this operation
 **/
exports.apiV1EnvironmentMGSpesaVariaMGIdPATCH = function(body,force,_op,company,user,id,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Update
 * Updating an object of type
 *
 * body SpesaVariaMGDTO Object of type to update
 * force String The warning/s code to bypass (separated by ‘,’) during the execution (optional)
 * _op String Set 'reload', if you want the DTO updated in the response request, otherwise will be returned null value (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * id String 
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns SpesaVariaMGDTO
 **/
exports.apiV1EnvironmentMGSpesaVariaMGIdPUT = function(body,force,_op,company,user,id,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "flgRicfatriep" : 5.6644160867523485,
  "flgVentstat" : 4.372688051310086,
  "flgIvaincl" : 1,
  "indTipoevas" : 9.785002165136461,
  "idmediaCg99" : 5.7911894223693885,
  "codice" : "codice",
  "indTotspese" : 7.92839742024475,
  "indRotturacorpo" : 1.0639121808530916,
  "indTipospesa" : 7.3718573971919445,
  "extensionData" : [ null, null ],
  "indGesintra" : 3.8008573585058016,
  "descr" : "descr",
  "indFatriep" : 5.974942028545841,
  "indTipotot" : 7.726998920545485,
  "indTipoaliq" : 3.2841216543560217,
  "flgVentamm" : 1.5970080735609526,
  "additionalData" : {
    "key" : ""
  },
  "flgOramin" : 3.812761638325517
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Create
 * Creating new object of type
 *
 * body SpesaVariaMGDTO Object of type to create
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns SpesaVariaMGDTO
 **/
exports.apiV1EnvironmentMGSpesaVariaMGPOST = function(body,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "flgRicfatriep" : 5.6644160867523485,
  "flgVentstat" : 4.372688051310086,
  "flgIvaincl" : 1,
  "indTipoevas" : 9.785002165136461,
  "idmediaCg99" : 5.7911894223693885,
  "codice" : "codice",
  "indTotspese" : 7.92839742024475,
  "indRotturacorpo" : 1.0639121808530916,
  "indTipospesa" : 7.3718573971919445,
  "extensionData" : [ null, null ],
  "indGesintra" : 3.8008573585058016,
  "descr" : "descr",
  "indFatriep" : 5.974942028545841,
  "indTipotot" : 7.726998920545485,
  "indTipoaliq" : 3.2841216543560217,
  "flgVentamm" : 1.5970080735609526,
  "additionalData" : {
    "key" : ""
  },
  "flgOramin" : 3.812761638325517
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Read
 * Read among object of type
 *
 * body List Search criteria to apply
 * dlevel String Serialization level (optional)
 * dlevelkey String Serialization level key (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns SpesaVariaMGDTO
 **/
exports.apiV1EnvironmentMGSpesaVariaMGReadPOST = function(body,dlevel,dlevelkey,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "flgRicfatriep" : 5.6644160867523485,
  "flgVentstat" : 4.372688051310086,
  "flgIvaincl" : 1,
  "indTipoevas" : 9.785002165136461,
  "idmediaCg99" : 5.7911894223693885,
  "codice" : "codice",
  "indTotspese" : 7.92839742024475,
  "indRotturacorpo" : 1.0639121808530916,
  "indTipospesa" : 7.3718573971919445,
  "extensionData" : [ null, null ],
  "indGesintra" : 3.8008573585058016,
  "descr" : "descr",
  "indFatriep" : 5.974942028545841,
  "indTipotot" : 7.726998920545485,
  "indTipoaliq" : 3.2841216543560217,
  "flgVentamm" : 1.5970080735609526,
  "additionalData" : {
    "key" : ""
  },
  "flgOramin" : 3.812761638325517
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Search
 * Search among object of type
 *
 * body SearchDTO Search criteria to apply
 * loadEntireDomain String Specify 'loadEntireDomain=true' if you want all the aggregate (optional)
 * gettotalcount String Specify 'gettotalcount=true' if you want the total number of elements (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns SpesaVariaMGDTO
 **/
exports.apiV1EnvironmentMGSpesaVariaMGSearchPOST = function(body,loadEntireDomain,gettotalcount,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "flgRicfatriep" : 5.6644160867523485,
  "flgVentstat" : 4.372688051310086,
  "flgIvaincl" : 1,
  "indTipoevas" : 9.785002165136461,
  "idmediaCg99" : 5.7911894223693885,
  "codice" : "codice",
  "indTotspese" : 7.92839742024475,
  "indRotturacorpo" : 1.0639121808530916,
  "indTipospesa" : 7.3718573971919445,
  "extensionData" : [ null, null ],
  "indGesintra" : 3.8008573585058016,
  "descr" : "descr",
  "indFatriep" : 5.974942028545841,
  "indTipotot" : 7.726998920545485,
  "indTipoaliq" : 3.2841216543560217,
  "flgVentamm" : 1.5970080735609526,
  "additionalData" : {
    "key" : ""
  },
  "flgOramin" : 3.812761638325517
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Validate
 * Validation of object of type
 *
 * body SpesaVariaMGDTO Object of type to validate
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * no response value expected for this operation
 **/
exports.apiV1EnvironmentMGSpesaVariaMGValidatePOST = function(body,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Validation of one on more properties of Type
 * Validation of object of type
 *
 * body String  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br> (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns ValidateDTO
 **/
exports.apiV1EnvironmentMGSpesaVariaMGValidatePropertiesPOST = function(body,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "additionalData" : {
    "key" : ""
  },
  "items" : [ {
    "isError" : true,
    "isWarning" : true,
    "warningCode" : 0,
    "dtoName" : "dtoName",
    "dtoPropertyName" : "dtoPropertyName",
    "message" : "message",
    "entityPropertyPath" : "entityPropertyPath"
  }, {
    "isError" : true,
    "isWarning" : true,
    "warningCode" : 0,
    "dtoName" : "dtoName",
    "dtoPropertyName" : "dtoPropertyName",
    "message" : "message",
    "entityPropertyPath" : "entityPropertyPath"
  } ],
  "extensionData" : [ {
    "value" : "",
    "key" : "key"
  }, {
    "value" : "",
    "key" : "key"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

