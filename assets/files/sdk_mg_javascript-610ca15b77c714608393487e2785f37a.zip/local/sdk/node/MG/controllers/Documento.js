'use strict';

var utils = require('../utils/writer.js');
var Documento = require('../service/DocumentoService');

module.exports.apiV1EnvironmentMGDocumentoGET = function apiV1EnvironmentMGDocumentoGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  Documento.apiV1EnvironmentMGDocumentoGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGDocumentoIdDELETE = function apiV1EnvironmentMGDocumentoIdDELETE (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  Documento.apiV1EnvironmentMGDocumentoIdDELETE(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGDocumentoIdGET = function apiV1EnvironmentMGDocumentoIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  Documento.apiV1EnvironmentMGDocumentoIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGDocumentoIdPUT = function apiV1EnvironmentMGDocumentoIdPUT (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  Documento.apiV1EnvironmentMGDocumentoIdPUT(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGDocumentoIdPrintGET = function apiV1EnvironmentMGDocumentoIdPrintGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  Documento.apiV1EnvironmentMGDocumentoIdPrintGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGDocumentoPOST = function apiV1EnvironmentMGDocumentoPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  Documento.apiV1EnvironmentMGDocumentoPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGDocumentoSearchPOST = function apiV1EnvironmentMGDocumentoSearchPOST (req, res, next, body, loadEntireDomain, gettotalcount, company, user, environment, authorizationScope, acceptLanguage) {
  Documento.apiV1EnvironmentMGDocumentoSearchPOST(body, loadEntireDomain, gettotalcount, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
