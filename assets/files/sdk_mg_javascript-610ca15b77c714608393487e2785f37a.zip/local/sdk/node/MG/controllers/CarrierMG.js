'use strict';

var utils = require('../utils/writer.js');
var CarrierMG = require('../service/CarrierMGService');

module.exports.apiV1EnvironmentMGCarrierMGGET = function apiV1EnvironmentMGCarrierMGGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  CarrierMG.apiV1EnvironmentMGCarrierMGGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGCarrierMGIdDELETE = function apiV1EnvironmentMGCarrierMGIdDELETE (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  CarrierMG.apiV1EnvironmentMGCarrierMGIdDELETE(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGCarrierMGIdGET = function apiV1EnvironmentMGCarrierMGIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  CarrierMG.apiV1EnvironmentMGCarrierMGIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGCarrierMGIdPATCH = function apiV1EnvironmentMGCarrierMGIdPATCH (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  CarrierMG.apiV1EnvironmentMGCarrierMGIdPATCH(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGCarrierMGIdPUT = function apiV1EnvironmentMGCarrierMGIdPUT (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  CarrierMG.apiV1EnvironmentMGCarrierMGIdPUT(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGCarrierMGPOST = function apiV1EnvironmentMGCarrierMGPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CarrierMG.apiV1EnvironmentMGCarrierMGPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGCarrierMGReadPOST = function apiV1EnvironmentMGCarrierMGReadPOST (req, res, next, body, dlevel, dlevelkey, company, user, environment, authorizationScope, acceptLanguage) {
  CarrierMG.apiV1EnvironmentMGCarrierMGReadPOST(body, dlevel, dlevelkey, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGCarrierMGSearchPOST = function apiV1EnvironmentMGCarrierMGSearchPOST (req, res, next, body, loadEntireDomain, gettotalcount, company, user, environment, authorizationScope, acceptLanguage) {
  CarrierMG.apiV1EnvironmentMGCarrierMGSearchPOST(body, loadEntireDomain, gettotalcount, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGCarrierMGValidatePOST = function apiV1EnvironmentMGCarrierMGValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CarrierMG.apiV1EnvironmentMGCarrierMGValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGCarrierMGValidatePropertiesPOST = function apiV1EnvironmentMGCarrierMGValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CarrierMG.apiV1EnvironmentMGCarrierMGValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
