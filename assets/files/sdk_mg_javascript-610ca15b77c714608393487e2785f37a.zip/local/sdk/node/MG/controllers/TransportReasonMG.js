'use strict';

var utils = require('../utils/writer.js');
var TransportReasonMG = require('../service/TransportReasonMGService');

module.exports.apiV1EnvironmentMGTransportReasonMGGET = function apiV1EnvironmentMGTransportReasonMGGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  TransportReasonMG.apiV1EnvironmentMGTransportReasonMGGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGTransportReasonMGIdGET = function apiV1EnvironmentMGTransportReasonMGIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  TransportReasonMG.apiV1EnvironmentMGTransportReasonMGIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGTransportReasonMGReadPOST = function apiV1EnvironmentMGTransportReasonMGReadPOST (req, res, next, body, dlevel, dlevelkey, company, user, environment, authorizationScope, acceptLanguage) {
  TransportReasonMG.apiV1EnvironmentMGTransportReasonMGReadPOST(body, dlevel, dlevelkey, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGTransportReasonMGSearchPOST = function apiV1EnvironmentMGTransportReasonMGSearchPOST (req, res, next, body, loadEntireDomain, gettotalcount, company, user, environment, authorizationScope, acceptLanguage) {
  TransportReasonMG.apiV1EnvironmentMGTransportReasonMGSearchPOST(body, loadEntireDomain, gettotalcount, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGTransportReasonMGValidatePOST = function apiV1EnvironmentMGTransportReasonMGValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  TransportReasonMG.apiV1EnvironmentMGTransportReasonMGValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGTransportReasonMGValidatePropertiesPOST = function apiV1EnvironmentMGTransportReasonMGValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  TransportReasonMG.apiV1EnvironmentMGTransportReasonMGValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
