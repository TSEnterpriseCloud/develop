'use strict';

var utils = require('../utils/writer.js');
var SpesaVariaMG = require('../service/SpesaVariaMGService');

module.exports.apiV1EnvironmentMGSpesaVariaMGGET = function apiV1EnvironmentMGSpesaVariaMGGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  SpesaVariaMG.apiV1EnvironmentMGSpesaVariaMGGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGSpesaVariaMGIdDELETE = function apiV1EnvironmentMGSpesaVariaMGIdDELETE (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  SpesaVariaMG.apiV1EnvironmentMGSpesaVariaMGIdDELETE(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGSpesaVariaMGIdGET = function apiV1EnvironmentMGSpesaVariaMGIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  SpesaVariaMG.apiV1EnvironmentMGSpesaVariaMGIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGSpesaVariaMGIdPATCH = function apiV1EnvironmentMGSpesaVariaMGIdPATCH (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  SpesaVariaMG.apiV1EnvironmentMGSpesaVariaMGIdPATCH(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGSpesaVariaMGIdPUT = function apiV1EnvironmentMGSpesaVariaMGIdPUT (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  SpesaVariaMG.apiV1EnvironmentMGSpesaVariaMGIdPUT(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGSpesaVariaMGPOST = function apiV1EnvironmentMGSpesaVariaMGPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  SpesaVariaMG.apiV1EnvironmentMGSpesaVariaMGPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGSpesaVariaMGReadPOST = function apiV1EnvironmentMGSpesaVariaMGReadPOST (req, res, next, body, dlevel, dlevelkey, company, user, environment, authorizationScope, acceptLanguage) {
  SpesaVariaMG.apiV1EnvironmentMGSpesaVariaMGReadPOST(body, dlevel, dlevelkey, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGSpesaVariaMGSearchPOST = function apiV1EnvironmentMGSpesaVariaMGSearchPOST (req, res, next, body, loadEntireDomain, gettotalcount, company, user, environment, authorizationScope, acceptLanguage) {
  SpesaVariaMG.apiV1EnvironmentMGSpesaVariaMGSearchPOST(body, loadEntireDomain, gettotalcount, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGSpesaVariaMGValidatePOST = function apiV1EnvironmentMGSpesaVariaMGValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  SpesaVariaMG.apiV1EnvironmentMGSpesaVariaMGValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGSpesaVariaMGValidatePropertiesPOST = function apiV1EnvironmentMGSpesaVariaMGValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  SpesaVariaMG.apiV1EnvironmentMGSpesaVariaMGValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
