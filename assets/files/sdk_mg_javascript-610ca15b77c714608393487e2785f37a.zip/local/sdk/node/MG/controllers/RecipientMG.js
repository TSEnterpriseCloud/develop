'use strict';

var utils = require('../utils/writer.js');
var RecipientMG = require('../service/RecipientMGService');

module.exports.apiV1EnvironmentMGRecipientMGGET = function apiV1EnvironmentMGRecipientMGGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  RecipientMG.apiV1EnvironmentMGRecipientMGGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGRecipientMGIdDELETE = function apiV1EnvironmentMGRecipientMGIdDELETE (req, res, next, id, environment, cliforCg44, tipocfCg44, authorizationScope, company, user, acceptLanguage) {
  RecipientMG.apiV1EnvironmentMGRecipientMGIdDELETE(id, environment, cliforCg44, tipocfCg44, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGRecipientMGIdGET = function apiV1EnvironmentMGRecipientMGIdGET (req, res, next, id, environment, cliforCg44, tipocfCg44, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  RecipientMG.apiV1EnvironmentMGRecipientMGIdGET(id, environment, cliforCg44, tipocfCg44, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGRecipientMGIdPATCH = function apiV1EnvironmentMGRecipientMGIdPATCH (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  RecipientMG.apiV1EnvironmentMGRecipientMGIdPATCH(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGRecipientMGIdPUT = function apiV1EnvironmentMGRecipientMGIdPUT (req, res, next, body, force, _op, cliforCg44, tipocfCg44, company, user, id, environment, authorizationScope, acceptLanguage) {
  RecipientMG.apiV1EnvironmentMGRecipientMGIdPUT(body, force, _op, cliforCg44, tipocfCg44, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGRecipientMGPOST = function apiV1EnvironmentMGRecipientMGPOST (req, res, next, body, cliforCg44, tipocfCg44, company, user, environment, authorizationScope, acceptLanguage) {
  RecipientMG.apiV1EnvironmentMGRecipientMGPOST(body, cliforCg44, tipocfCg44, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGRecipientMGReadPOST = function apiV1EnvironmentMGRecipientMGReadPOST (req, res, next, body, dlevel, dlevelkey, cliforCg44, tipocfCg44, company, user, environment, authorizationScope, acceptLanguage) {
  RecipientMG.apiV1EnvironmentMGRecipientMGReadPOST(body, dlevel, dlevelkey, cliforCg44, tipocfCg44, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGRecipientMGSearchPOST = function apiV1EnvironmentMGRecipientMGSearchPOST (req, res, next, body, loadEntireDomain, gettotalcount, company, user, environment, authorizationScope, acceptLanguage) {
  RecipientMG.apiV1EnvironmentMGRecipientMGSearchPOST(body, loadEntireDomain, gettotalcount, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGRecipientMGValidatePOST = function apiV1EnvironmentMGRecipientMGValidatePOST (req, res, next, body, cliforCg44, tipocfCg44, company, user, environment, authorizationScope, acceptLanguage) {
  RecipientMG.apiV1EnvironmentMGRecipientMGValidatePOST(body, cliforCg44, tipocfCg44, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGRecipientMGValidatePropertiesPOST = function apiV1EnvironmentMGRecipientMGValidatePropertiesPOST (req, res, next, body, cliforCg44, tipocfCg44, company, user, environment, authorizationScope, acceptLanguage) {
  RecipientMG.apiV1EnvironmentMGRecipientMGValidatePropertiesPOST(body, cliforCg44, tipocfCg44, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
