'use strict';

var utils = require('../utils/writer.js');
var GiacenzaMG = require('../service/GiacenzaMGService');

module.exports.apiV1EnvironmentMGGiacenzaMGDisponibilitaPOST = function apiV1EnvironmentMGGiacenzaMGDisponibilitaPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  GiacenzaMG.apiV1EnvironmentMGGiacenzaMGDisponibilitaPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGGiacenzaMGRicalcologiacenzaPOST = function apiV1EnvironmentMGGiacenzaMGRicalcologiacenzaPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  GiacenzaMG.apiV1EnvironmentMGGiacenzaMGRicalcologiacenzaPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGGiacenzaMGValidatePOST = function apiV1EnvironmentMGGiacenzaMGValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  GiacenzaMG.apiV1EnvironmentMGGiacenzaMGValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
