# TseCloudMg.DocumentServiceApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiV1EnvironmentMGDocumentServiceDocprocessingstatusPost**](DocumentServiceApi.md#apiV1EnvironmentMGDocumentServiceDocprocessingstatusPost) | **POST** /api/v1/{environment}/MG/DocumentService/docprocessingstatus | Return Document processing status
[**apiV1EnvironmentMGDocumentServiceMultiplecreatePost**](DocumentServiceApi.md#apiV1EnvironmentMGDocumentServiceMultiplecreatePost) | **POST** /api/v1/{environment}/MG/DocumentService/multiplecreate | Insert Multiple Documents for async process
[**apiV1EnvironmentMGDocumentServiceMultiplecreatehistoryIdDelete**](DocumentServiceApi.md#apiV1EnvironmentMGDocumentServiceMultiplecreatehistoryIdDelete) | **DELETE** /api/v1/{environment}/MG/DocumentService/multiplecreatehistory/{id} | Delete records for multiple insert documents by guid
[**apiV1EnvironmentMGDocumentServiceMultiplecreatereprocessGuidPost**](DocumentServiceApi.md#apiV1EnvironmentMGDocumentServiceMultiplecreatereprocessGuidPost) | **POST** /api/v1/{environment}/MG/DocumentService/multiplecreatereprocess/{guid} | Multiple Documents reprocess operations for async insert by guid
[**apiV1EnvironmentMGDocumentServiceOrderavailabilityIdDelete**](DocumentServiceApi.md#apiV1EnvironmentMGDocumentServiceOrderavailabilityIdDelete) | **DELETE** /api/v1/{environment}/MG/DocumentService/orderavailability/{id} | Delete record for async process portfolio orders
[**apiV1EnvironmentMGDocumentServiceOrderavailabilityPost**](DocumentServiceApi.md#apiV1EnvironmentMGDocumentServiceOrderavailabilityPost) | **POST** /api/v1/{environment}/MG/DocumentService/orderavailability | Return Documents Order Portfolio
[**apiV1EnvironmentMGDocumentServiceTransformPost**](DocumentServiceApi.md#apiV1EnvironmentMGDocumentServiceTransformPost) | **POST** /api/v1/{environment}/MG/DocumentService/transform | Document transformation based on the required parameters



## apiV1EnvironmentMGDocumentServiceDocprocessingstatusPost

> DocumentoStatoEvasoMGDTO apiV1EnvironmentMGDocumentServiceDocprocessingstatusPost(loadEntireDomain, environment, authorizationScope, searchDTO, opts)

Return Document processing status

Document processing status

### Example

```javascript
import TseCloudMg from 'tse_cloud_mg';
let defaultClient = TseCloudMg.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudMg.DocumentServiceApi();
let loadEntireDomain = "loadEntireDomain_example"; // String | Specify 'loadEntireDomain=true' if you want all the aggregate
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let searchDTO = new TseCloudMg.SearchDTO(); // SearchDTO | Search criteria to apply
let opts = {
  'getTotalCount': "getTotalCount_example", // String | Specify 'getTotalCount=true' if you want the total number of elements
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentMGDocumentServiceDocprocessingstatusPost(loadEntireDomain, environment, authorizationScope, searchDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **loadEntireDomain** | **String**| Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **searchDTO** | [**SearchDTO**](SearchDTO.md)| Search criteria to apply | 
 **getTotalCount** | **String**| Specify &#39;getTotalCount&#x3D;true&#39; if you want the total number of elements | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**DocumentoStatoEvasoMGDTO**](DocumentoStatoEvasoMGDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentMGDocumentServiceMultiplecreatePost

> DocumentoTestataOutMGDTO apiV1EnvironmentMGDocumentServiceMultiplecreatePost(environment, authorizationScope, groupDocumentoTestataMGDTO, opts)

Insert Multiple Documents for async process

Document async multiple process

### Example

```javascript
import TseCloudMg from 'tse_cloud_mg';
let defaultClient = TseCloudMg.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudMg.DocumentServiceApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let groupDocumentoTestataMGDTO = [new TseCloudMg.GroupDocumentoTestataMGDTO()]; // [GroupDocumentoTestataMGDTO] | Object of type to create
let opts = {
  'force': "force_example", // String | Force values
  'withvalidpreconditions': true, // Boolean | Validate Preconditions
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentMGDocumentServiceMultiplecreatePost(environment, authorizationScope, groupDocumentoTestataMGDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **groupDocumentoTestataMGDTO** | [**[GroupDocumentoTestataMGDTO]**](GroupDocumentoTestataMGDTO.md)| Object of type to create | 
 **force** | **String**| Force values | [optional] 
 **withvalidpreconditions** | **Boolean**| Validate Preconditions | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**DocumentoTestataOutMGDTO**](DocumentoTestataOutMGDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentMGDocumentServiceMultiplecreatehistoryIdDelete

> apiV1EnvironmentMGDocumentServiceMultiplecreatehistoryIdDelete(id, environment, authorizationScope, opts)

Delete records for multiple insert documents by guid

Deleting object of type 

### Example

```javascript
import TseCloudMg from 'tse_cloud_mg';
let defaultClient = TseCloudMg.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudMg.DocumentServiceApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'progress': "progress_example", // String | Force values
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentMGDocumentServiceMultiplecreatehistoryIdDelete(id, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **progress** | **String**| Force values | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentMGDocumentServiceMultiplecreatereprocessGuidPost

> DocumentoTestataOutMGDTO apiV1EnvironmentMGDocumentServiceMultiplecreatereprocessGuidPost(guid, environment, authorizationScope, groupDocumentoTestataMGDTO, opts)

Multiple Documents reprocess operations for async insert by guid

Document async multiple reprocess

### Example

```javascript
import TseCloudMg from 'tse_cloud_mg';
let defaultClient = TseCloudMg.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudMg.DocumentServiceApi();
let guid = "guid_example"; // String | That's Guid Session MixMatch documents insert value
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let groupDocumentoTestataMGDTO = [new TseCloudMg.GroupDocumentoTestataMGDTO()]; // [GroupDocumentoTestataMGDTO] | Object of type to update
let opts = {
  'force': "force_example", // String | Force values
  'withvalidpreconditions': true, // Boolean | Validate Preconditions
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentMGDocumentServiceMultiplecreatereprocessGuidPost(guid, environment, authorizationScope, groupDocumentoTestataMGDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **guid** | **String**| That&#39;s Guid Session MixMatch documents insert value | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **groupDocumentoTestataMGDTO** | [**[GroupDocumentoTestataMGDTO]**](GroupDocumentoTestataMGDTO.md)| Object of type to update | 
 **force** | **String**| Force values | [optional] 
 **withvalidpreconditions** | **Boolean**| Validate Preconditions | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**DocumentoTestataOutMGDTO**](DocumentoTestataOutMGDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentMGDocumentServiceOrderavailabilityIdDelete

> apiV1EnvironmentMGDocumentServiceOrderavailabilityIdDelete(id, environment, authorizationScope, opts)

Delete record for async process portfolio orders

Deleting object of type 

### Example

```javascript
import TseCloudMg from 'tse_cloud_mg';
let defaultClient = TseCloudMg.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudMg.DocumentServiceApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentMGDocumentServiceOrderavailabilityIdDelete(id, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentMGDocumentServiceOrderavailabilityPost

> DocumentoPortfolioEvadOrdineOutMGSetDTO apiV1EnvironmentMGDocumentServiceOrderavailabilityPost(environment, authorizationScope, documentoPortfolioEvadInMGDTO, opts)

Return Documents Order Portfolio

Document processing status

### Example

```javascript
import TseCloudMg from 'tse_cloud_mg';
let defaultClient = TseCloudMg.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudMg.DocumentServiceApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let documentoPortfolioEvadInMGDTO = new TseCloudMg.DocumentoPortfolioEvadInMGDTO(); // DocumentoPortfolioEvadInMGDTO | Object of type to validate
let opts = {
  'force': "force_example", // String | Force values
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentMGDocumentServiceOrderavailabilityPost(environment, authorizationScope, documentoPortfolioEvadInMGDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **documentoPortfolioEvadInMGDTO** | [**DocumentoPortfolioEvadInMGDTO**](DocumentoPortfolioEvadInMGDTO.md)| Object of type to validate | 
 **force** | **String**| Force values | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**DocumentoPortfolioEvadOrdineOutMGSetDTO**](DocumentoPortfolioEvadOrdineOutMGSetDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentMGDocumentServiceTransformPost

> DocumentTransformationParameterDTO apiV1EnvironmentMGDocumentServiceTransformPost(environment, authorizationScope, documentTransformationParameterDTO, opts)

Document transformation based on the required parameters

Document transformation based on the required parameters

### Example

```javascript
import TseCloudMg from 'tse_cloud_mg';
let defaultClient = TseCloudMg.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudMg.DocumentServiceApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let documentTransformationParameterDTO = new TseCloudMg.DocumentTransformationParameterDTO(); // DocumentTransformationParameterDTO | Document transformation parameters
let opts = {
  'force': "force_example", // String | Force values
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentMGDocumentServiceTransformPost(environment, authorizationScope, documentTransformationParameterDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **documentTransformationParameterDTO** | [**DocumentTransformationParameterDTO**](DocumentTransformationParameterDTO.md)| Document transformation parameters | 
 **force** | **String**| Force values | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**DocumentTransformationParameterDTO**](DocumentTransformationParameterDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml

