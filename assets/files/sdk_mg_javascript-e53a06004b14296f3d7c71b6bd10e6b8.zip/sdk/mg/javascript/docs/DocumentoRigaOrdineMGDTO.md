# TseCloudMg.DocumentoRigaOrdineMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codPiano** | **String** | DO31_CODPIANO - Codice piano | [optional] 
**codTraclegdb** | **String** | DO31_CODTRACLEGDB - Codice tracciabilità legame distinta | [optional] 
**codTraclegwbs** | **String** | DO31_CODTRACLEGWBS - Codice tracciabilità legame WBS | [optional] 
**collicons** | **Number** | DO31_COLLICONS - Colli consegnati | [optional] 
**collitrasfddtcl** | **Number** | DO31_COLLITRASFDDTCL - Colli trasf. conto lavoro | [optional] 
**collitrasfp** | **Number** | DO31_COLLITRASFP - Colli trasf.p. | [optional] 
**contpcarPd79** | **Number** | DO31_CONTPCAR_PD79 - Piano carico | [optional] 
**datacons** | **Date** | DO31_DATACONS - Data consegna | [optional] 
**dataconsint** | **Date** | DO31_DATACONSINT - Data consegna interna | [optional] 
**dataconsorig** | **Date** | DO31_DATACONSORIG - Data consegna origine corpo | [optional] 
**datafineoap** | **Date** | DO31_DATAFINEOAP - Data fine validità ordine aperto | [optional] 
**datainizlav** | **Date** | DO31_DATAINIZLAV - Data inizio lavorazione | [optional] 
**datainizoap** | **Date** | DO31_DATAINIZOAP - Data inizio validità ordine aperto | [optional] 
**datalancio** | **Date** | DO31_DATALANCIO - Data lancio | [optional] 
**datapianif** | **Date** | DO31_DATAPIANIF - Data pianificazione | [optional] 
**dittaCg18** | **Number** | DO31_DITTA_CG18 - Ditta | [optional] 
**flgConsconf** | **Number** | DO31_FLGCONSCONF - Flag consegna confermata&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgNoevasparz** | **Number** | DO31_FLGNOEVASPARZ - Flag no evasione parziale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgNonpiuev** | **Number** | DO31_FLGNONPIUEV - Riga non piu evadibile&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgNosugg** | **Number** | DO31_FLGNOSUGG - Flag no suggerimento in MRP&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgRicpreev** | **Number** | DO31_FLGRICPREEV - Flag ricalcolo prezzi in evasione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgSospriga** | **Number** | DO31_FLGSOSPRIGA - Flag riga sospesa&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**ggtollercons** | **Number** | DO31_GGTOLLERCONS - Giorni di tolleranza consegna | [optional] 
**indEvasdescsp** | **Number** | DO31_INDEVASDESCSP - Indicatore evasione descrizioni e spese | [optional] 
**indStatocons** | **Number** | DO31_INDSTATOCONS - Indicatore stato consegnato | [optional] 
**indStatodescsp** | **Number** | DO31_INDSTATODESCSP - Indicatore stato trasf. descrizioni e spese | [optional] 
**numpiano** | **Number** | DO31_NUMPIANO - Numero piano | [optional] 
**numpropPd39** | **Number** | DO31_NUMPROP_PD39 - Numero proposta | [optional] 
**numregCo99** | **String** | DO31_NUMREG_CO99 - Numero registrazione | 
**progRiga** | **Number** | DO31_PROGRIGA - Progressivo Riga | 
**progRigpiaPd80** | **Number** | DO31_PROGRIGPIA_PD80 - Progressivo riga piano consegna | [optional] 
**qta1cons** | **Number** | DO31_QTA1CONS - Quantità consegnata | [optional] 
**qta1lanc** | **Number** | DO31_QTA1LANC - Quantità consegnata alla data lancio | [optional] 
**qta1prel** | **Number** | DO31_QTA1PREL - Quantità 1 prelevata | [optional] 
**qta1trasfddtcl** | **Number** | DO31_QTA1TRASFDDTCL - Quantità 1 trasf. conto lavoro | [optional] 
**qta1trasfp** | **Number** | DO31_QTA1TRASFP - Qta 1 trasf.p. | [optional] 
**qta2cons** | **Number** | DO31_QTA2CONS - Quantità consegnata 2 | [optional] 
**qta2lanc** | **Number** | DO31_QTA2LANC - Quantità consegnata alla data lancio | [optional] 
**qta2prel** | **Number** | DO31_QTA2PREL - Quantità 2 prelevata | [optional] 
**qta2trasfddtcl** | **Number** | DO31_QTA2TRASFDDTCL - Quantità 2 trasf. conto lavoro | [optional] 
**qta2trasfp** | **Number** | DO31_QTA2TRASFP - Qta 2 trasf.p. | [optional] 
**valorecons** | **Number** | DO31_VALORECONS - Valore cons. | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgConsconfEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgNoevasparzEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgNonpiuevEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgNosuggEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgRicpreevEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgSosprigaEnum


* `0` (value: `0`)

* `1` (value: `1`)




