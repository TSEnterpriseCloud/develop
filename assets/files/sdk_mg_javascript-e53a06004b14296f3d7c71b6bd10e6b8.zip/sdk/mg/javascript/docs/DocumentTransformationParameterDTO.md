# TseCloudMg.DocumentTransformationParameterDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numRegOrigin** | **[String]** | NumRegOrigin | 
**codModelTransfDoc** | **String** | CodModelTransfDoc | 
**processExtremLimits** | [**DocumentTransformationProcessExtremLimitDTO**](DocumentTransformationProcessExtremLimitDTO.md) |  | [optional] 
**rowSearchTransformationCriteria** | [**SearchDTO**](SearchDTO.md) |  | [optional] 
**documentTransformationPartialEvadContainerGeneralData** | [**[DocumentTransformationPartialEvadContainerGeneralDataDTO]**](DocumentTransformationPartialEvadContainerGeneralDataDTO.md) | Additional Document Body General Data for partial Data Evad. | [optional] 


