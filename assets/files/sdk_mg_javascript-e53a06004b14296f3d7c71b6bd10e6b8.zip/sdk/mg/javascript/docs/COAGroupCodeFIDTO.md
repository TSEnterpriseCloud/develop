# TseCloudMg.COAGroupCodeFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descr** | **String** | CG10_DESCR - Descrizione | [optional] 
**flgPdclib** | **Number** | CG10_FLGPDCLIB - PdC libero | 
**gruppo** | **Number** | CG10_GRUPPO - Piano dei conti | 
**maskedit** | **String** | CG10_MASKEDIT - Formato | [optional] 
**numlivcons** | **Number** | CG10_NUMLIVCONS - Livello per consolidamento | [optional] 
**numlivelli** | **Number** | CG10_NUMLIVELLI - Numero livelli | 
**rowversion** | **Blob** | CG10_ROWVERSION - RowVersion | [optional] 
**accountProposals** | [**[COAAccountProposalFIDTO]**](COAAccountProposalFIDTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


