# TseCloudMg.HeadingReferenceDocumentMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**datansconf** | **Date** | DO12_DATANSCONF - Data nostra conferma | [optional] 
**datansdoc** | **Date** | DO12_DATANSDOC - Data nostro documento | [optional] 
**datavsconf** | **Date** | DO12_DATAVSCONF - Data vostra conferma | [optional] 
**datavsdoc** | **Date** | DO12_DATAVSDOC - Data vostro documento | [optional] 
**dittaCg18** | **Number** | DO12_DITTA_CG18 - Ditta | [optional] 
**fedatadoc** | **Date** | DO12_FEDATADOC - Fedatadoc | [optional] 
**feiddoc** | **String** | DO12_FEIDDOC - Feiddoc | [optional] 
**feidsoggetto** | **String** | DO12_FEIDSOGGETTO - Feidsoggetto | [optional] 
**flgNsdocbis** | **Number** | DO12_FLGNSDOCBIS - Flag bis ns documento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indStipodoc** | **Number** | DO12_INDSTIPODOC - Indicatore sottotipo documento di riferimento | [optional] 
**indTipodoc** | **Number** | DO12_INDTIPODOC - Indicatore tipo documento di riferimento | [optional] 
**notensdoc** | **String** | DO12_NOTENSDOC - Note nostro documento | [optional] 
**notevsdoc** | **String** | DO12_NOTEVSDOC - Note vostro documento | [optional] 
**numnsdoc** | **Number** | DO12_NUMNSDOC - Numero nostro documento | [optional] 
**numregCo99** | **String** | DO12_NUMREG_CO99 - Numero registrazione | 
**numvsdoc** | **String** | DO12_NUMVSDOC - Numero vostro documento | [optional] 
**progRif** | **Number** | DO12_PROGRIF - Progressivo di rif. | 
**rifnsdoc** | **String** | DO12_RIFNSDOC - Riferimento nostro documento | [optional] 
**rifvsdoc** | **String** | DO12_RIFVSDOC - Riferimento vostro documento | [optional] 
**seznsdoc** | **String** | DO12_SEZNSDOC - Sezionale nostro documento | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgNsdocbisEnum


* `0` (value: `0`)

* `1` (value: `1`)




