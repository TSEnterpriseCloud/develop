# TseCloudMg.SearchElementDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**propertyName** | **String** | Property on witch apply the filter | 
**comparer** | [**SearchComparer**](SearchComparer.md) |  | 
**value** | **Object** |  | 
**operator** | [**SearchLogicalOperators**](SearchLogicalOperators.md) |  | [optional] 


