# TseCloudMg.GroupDocumentoTestataMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**keyDoc** | **Number** |  | 
**documentoTestataMGDTO** | [**DocumentoTestataMGDTO**](DocumentoTestataMGDTO.md) |  | 


