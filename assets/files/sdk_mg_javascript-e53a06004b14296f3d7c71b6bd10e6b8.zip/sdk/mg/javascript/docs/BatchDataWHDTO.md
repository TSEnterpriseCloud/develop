# TseCloudMg.BatchDataWHDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codArtMg66** | **String** | MG4G_CODART_MG66 - Codice Articolo | 
**codLotto** | **String** | MG4G_CODLOTTO - Codice Lotto | 
**datacre** | **Date** | MG4G_DATACRE - Data creazione | [optional] 
**datascad** | **Date** | MG4G_DATASCAD - Data scadenza | [optional] 
**desclotto** | **String** | MG4G_DESCLOTTO - Descrizione Lotto | [optional] 
**dittaCg18** | **Number** | MG4G_DITTA_CG18 - Ditta | [optional] 
**idmediaCg99** | **Number** | MG4G_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**lib1** | **Number** | MG4G_LIB1 - Lib1 | [optional] 
**note** | **String** | MG4G_NOTE - Note | [optional] 
**opzioneMg5e** | **String** | MG4G_OPZIONE_MG5E - Codice variante | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


