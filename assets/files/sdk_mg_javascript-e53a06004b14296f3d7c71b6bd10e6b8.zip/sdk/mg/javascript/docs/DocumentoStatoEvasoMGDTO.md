# TseCloudMg.DocumentoStatoEvasoMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**annoDoc** | **Number** | VFW_ANNODOC_DO11 - AnnodocDo11 | 
**collidoc** | **Number** | VFW_COLLIDOC - Collidoc | [optional] 
**collires** | **Number** | VFW_COLLIRES - Collires | [optional] 
**collitrasf** | **Number** | VFW_COLLITRASF - Collitrasf | [optional] 
**dataDoc** | **Date** | VFW_DATADOC_DO11 - DatadocDo11 | 
**dittaCg18** | **Number** | VFW_DITTA_CG18 - DittaCg18 | 
**flgDaevadere** | **Number** | VFW_FLGDAEVADERE - FlgDaevadere | [optional] 
**flgEvaso** | **Number** | VFW_FLGEVASO - FlgEvaso | [optional] 
**flgEvasoparz** | **Number** | VFW_FLGEVASOPARZ - FlgEvasoparz | [optional] 
**id** | **Number** | VFW_ID - Id | 
**idDo11** | **Number** | VFW_ID_DO11 - IdDo11 | 
**indStatoriga** | **Number** | VFW_INDSTATORIGA - IndStatoriga | 
**numdocDo11** | **Number** | VFW_NUMDOC_DO11 - NumdocDo11 | 
**numregCo99** | **String** | VFW_NUMREG_CO99 - NumregCo99 | 
**numregfatCo99** | **String** | VFW_NUMREGFAT_CO99 - NumregfatCo99 | 
**progRigaDo30** | **Number** | VFW_PROGRIGA_DO30 - ProgRigaDo30 | 
**qta1doc** | **Number** | VFW_QTA1DOC - Qta1doc | [optional] 
**qta1res** | **Number** | VFW_QTA1RES - Qta1res | [optional] 
**qta1trasf** | **Number** | VFW_QTA1TRASF - Qta1trasf | [optional] 
**qta2doc** | **Number** | VFW_QTA2DOC - Qta2doc | [optional] 
**qta2res** | **Number** | VFW_QTA2RES - Qta2res | [optional] 
**qta2trasf** | **Number** | VFW_QTA2TRASF - Qta2trasf | [optional] 
**tipodocDo11** | **Number** | VFW_TIPODOC_DO11 - TipodocDo11 | [optional] 
**valoredoc** | **Number** | VFW_VALOREDOC - Valoredoc | [optional] 
**valoreres** | **Number** | VFW_VALORERES - Valoreres | [optional] 
**valoretrasf** | **Number** | VFW_VALORETRASF - Valoretrasf | [optional] 
**documentoStatoEvasoCorpoRifMG** | [**[DocumentoStatoEvasoCorpoRifMGDTO]**](DocumentoStatoEvasoCorpoRifMGDTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


