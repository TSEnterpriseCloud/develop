# TseCloudMg.FederalStateViewCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**a2iso3166Cg07** | **String** | VCG1S_A2ISO3166_CG07 - A2iso3166Cg07 | 
**codiceCg07** | **Number** | VCG1S_CODICE_CG07 - Codice Stato | 
**descr** | **String** | VCG1S_DESCR - Descrizione | [optional] 
**iso3166statofed** | **String** | VCG1S_ISO3166STATOFED - Country ISO 3166 | [optional] 
**statofed** | **String** | VCG1S_STATOFED - Stato federato | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


