# TseCloudMg.DocumentoRigaProvvigioniMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codiceAgente** | **String** | Codice agente | [optional] 
**dittaCg18** | **Number** | DO32_DITTA_CG18 - Codice ditta | [optional] 
**flgVarprov** | **Number** | DO32_FLGVARPROV - Flag provvigione variata manualmente&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**idagenteMg17** | **Number** | DO32_IDAGENTE_MG17 - ID Agente | 
**imponprov** | **Number** | DO32_IMPONPROV - Imponibile provvigione | 
**imponprovVal** | **Number** | DO32_IMPONPROV_VAL - Imponibile provvigione in valuta | [optional] 
**imporprov** | **Number** | DO32_IMPORPROV - Importo provvigione | 
**imporprovVal** | **Number** | DO32_IMPORPROV_VAL - Importo provvigione in valuta | [optional] 
**indRegprov** | **Number** | DO32_INDREGPROV - Indicatore regime provvigione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No calcolo provv.&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - % dall&#39;agente&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - % dal cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - % dall&#39;anagrafica articolo&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - % dall&#39;anagrafica articolo/agente&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - % da listino fisso&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - % da listino anag. su cli./for.&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - % da listino fisso e scagl. sc./magg.&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - % da listino utilizzato&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - % da listino utilizzato: solo gest. scagl. di sc./magg.&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - % da listino utilizzato: provv. list. + scagl. di sc./magg.&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - % da tabella composta a due livelli&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - % da tabella composta a tre livelli&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - % da scaglioni di fatturato&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - % da condizioni multiple&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - % da listini parametrici&lt;/li&gt;&lt;/ul&gt; | [optional] 
**numregCo99** | **String** | DO32_NUMREG_CO99 - Numero registrazione | 
**percprov** | **Number** | DO32_PERCPROV - Percentuale provvigione | 
**progRiga** | **Number** | DO32_PROGRIGA - Progressivo riga interna | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgVarprovEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndRegprovEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)

* `10` (value: `10`)

* `11` (value: `11`)

* `12` (value: `12`)

* `13` (value: `13`)

* `14` (value: `14`)

* `15` (value: `15`)




