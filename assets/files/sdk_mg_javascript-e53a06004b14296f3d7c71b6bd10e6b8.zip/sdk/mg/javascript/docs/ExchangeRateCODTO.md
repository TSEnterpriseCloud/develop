# TseCloudMg.ExchangeRateCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**adegcambio** | **Number** | CG09_ADEGCAMBIO -  Cambio UIC Annuale | [optional] 
**anno** | **Number** | CG09_ANNO - Anno | 
**cambio** | **Number** | CG09_CAMBIO - Cambio | [optional] 
**codiceCg08** | **String** | CG09_CODICE_CG08 - Codice valuta | 
**codicerifCg08** | **String** | CG09_CODICERIF_CG08 - CodicerifCg08 | 
**giorno** | **Number** | CG09_GIORNO - Giorno | 
**idmediaCg99** | **Number** | CG09_IDMEDIA_CG99 - Hypermedia | [optional] 
**indCertoincerto** | **Number** | CG09_INDCERTOINCERTO - Cambio incerto per certo | 
**mese** | **Number** | CG09_MESE - Mese | 
**rowversion** | **Blob** | CG09_ROWVERSION - RowVersion | [optional] 
**currencyCO** | [**CurrencyCODTO**](CurrencyCODTO.md) |  | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


