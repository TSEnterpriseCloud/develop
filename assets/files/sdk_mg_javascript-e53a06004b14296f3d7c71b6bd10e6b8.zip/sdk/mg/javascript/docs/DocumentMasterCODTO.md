# TseCloudMg.DocumentMasterCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**datacre** | **Date** | CO99_DATACRE - Data creazione | [optional] 
**datavar** | **Date** | CO99_DATAVAR - Data ultima variazione | [optional] 
**descnote1** | **String** | CO99_DESCNOTE1 - Note | [optional] 
**dittaCg18** | **Number** | CO99_DITTA_CG18 - Ditta | [optional] 
**gruppocre** | **String** | CO99_GRUPPOCRE - Gruppo utente creazione | [optional] 
**gruppovar** | **String** | CO99_GRUPPOVAR - Gruppo variazione | [optional] 
**indTipoop** | **Number** | CO99_INDTIPOOP - Indicatore tipo operazione | [optional] 
**numreg** | **String** | CO99_NUMREG - Numero registrazione | 
**utentecre** | **String** | CO99_UTENTECRE - Utente creazione | [optional] 
**utentevar** | **String** | CO99_UTENTEVAR - Utente variazione | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


