# TseCloudMg.PaymentTermDetailCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aggfix1** | **Number** | CG63_AGGFIX1 - Aggfix1 | [optional] 
**aggfix2** | **Number** | CG63_AGGFIX2 - Aggfix2 | [optional] 
**codPagCg62** | **String** | CG63_CODPAG_CG62 - CodPagCg62 | 
**daggfix1** | **Number** | CG63_DAGGFIX1 - Daggfix1 | [optional] 
**daggfix2** | **Number** | CG63_DAGGFIX2 - Daggfix2 | [optional] 
**el1frimp** | **Number** | CG63_EL1FRIMP -  Num. | [optional] 
**el1friva** | **Number** | CG63_EL1FRIVA -  Num. | [optional] 
**el2frimp** | **Number** | CG63_EL2FRIMP - Den. | [optional] 
**el2friva** | **Number** | CG63_EL2FRIVA - Den. | [optional] 
**flgFrpercimp** | **Number** | CG63_FLGFRPERCIMP - Fr./% imp.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Percentuale&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Frazione&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgFrperciva** | **Number** | CG63_FLGFRPERCIVA - Fr./% iva.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Percentuale&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Frazione&lt;/li&gt;&lt;/ul&gt; | [optional] 
**ggdecor** | **Number** | CG63_GGDECOR - gg dec. | [optional] 
**ggmmfix** | **Number** | CG63_GGMMFIX - Ggmmfix | [optional] 
**ggscadfix1** | **Number** | CG63_GGSCADFIX1 - Ggscadfix1 | [optional] 
**ggscadfix2** | **Number** | CG63_GGSCADFIX2 - Ggscadfix2 | [optional] 
**id** | **Number** | CG63_ID - Id (Required only in PUT/PATCH) | [optional] 
**idCg62** | **Number** | CG63_ID_CG62 - IdCg62 | 
**idCg64** | **Number** | CG63_ID_CG64 - IdCg64 | [optional] 
**imporfix** | **Number** | CG63_IMPORFIX - Imporfix | [optional] 
**indDatarif** | **Number** | CG63_INDDATARIF - Rif. decorrenza&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Data fattura&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Data Bolla&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Data consegna&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Data ordine&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Data a richiesta&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Data fattura (+GG |-&gt; fine mese)&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Data fattura (|-&gt; fine mese + GG)&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indImpfix** | **Number** | CG63_INDIMPFIX - IndImpfix&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Non gestito&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Da condizione di pagamento&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Rich . nel doc. d&#39;origine&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTipocalend** | **Number** | CG63_INDTIPOCALEND - IndTipocalend&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Commerciale&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Civile&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTipodecor** | **Number** | CG63_INDTIPODECOR - Tipo decorrenza&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Mese commerciale / civile&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Giorno fisso&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Data fissa&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Giorno fisso per int. di gg&lt;/li&gt;&lt;/ul&gt; | [optional] 
**percimp** | **Number** | CG63_PERCIMP - % Imp. | [optional] 
**perciva** | **Number** | CG63_PERCIVA - % IVA | [optional] 
**prog** | **Number** | CG63_PROG - Rata | 
**rowversion** | **Blob** | CG63_ROWVERSION - RowVersion | [optional] 
**tipoeff** | **Number** | CG63_TIPOEFF - Tipo effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Contrassegno&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Leasing&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Lettera di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - MAV&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Ricevuta bancaria&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - SDD&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Rimessa diretta&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Tratta&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Tratta accettata&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Bancomat&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Bonifico Bancario&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Cambiale&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Carta di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - C/C postale&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Cessione&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Contanti&lt;/li&gt;&lt;/ul&gt; | [optional] 
**subTypeCO** | [**SubTypeCODTO**](SubTypeCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgFrpercimpEnum


* `1` (value: `1`)

* `0` (value: `0`)





## Enum: FlgFrpercivaEnum


* `1` (value: `1`)

* `0` (value: `0`)





## Enum: IndDatarifEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)





## Enum: IndImpfixEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndTipocalendEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndTipodecorEnum


* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)





## Enum: TipoeffEnum


* `9` (value: `9`)

* `12` (value: `12`)

* `10` (value: `10`)

* `16` (value: `16`)

* `2` (value: `2`)

* `11` (value: `11`)

* `13` (value: `13`)

* `3` (value: `3`)

* `4` (value: `4`)

* `8` (value: `8`)

* `14` (value: `14`)

* `6` (value: `6`)

* `7` (value: `7`)

* `15` (value: `15`)

* `5` (value: `5`)

* `1` (value: `1`)




