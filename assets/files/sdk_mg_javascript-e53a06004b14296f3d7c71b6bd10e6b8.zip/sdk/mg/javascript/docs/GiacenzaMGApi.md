# TseCloudMg.GiacenzaMGApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiV1EnvironmentMGGiacenzaMGDisponibilitaPost**](GiacenzaMGApi.md#apiV1EnvironmentMGGiacenzaMGDisponibilitaPost) | **POST** /api/v1/{environment}/MG/GiacenzaMG/disponibilita | Calculate stock availability based on the required parameters
[**apiV1EnvironmentMGGiacenzaMGRicalcologiacenzaPost**](GiacenzaMGApi.md#apiV1EnvironmentMGGiacenzaMGRicalcologiacenzaPost) | **POST** /api/v1/{environment}/MG/GiacenzaMG/ricalcologiacenza | Recalculate the stock based on the required parameters
[**apiV1EnvironmentMGGiacenzaMGValidatePost**](GiacenzaMGApi.md#apiV1EnvironmentMGGiacenzaMGValidatePost) | **POST** /api/v1/{environment}/MG/GiacenzaMG/validate | Validate



## apiV1EnvironmentMGGiacenzaMGDisponibilitaPost

> apiV1EnvironmentMGGiacenzaMGDisponibilitaPost(environment, authorizationScope, calcolaDisponibilitaParams, opts)

Calculate stock availability based on the required parameters

Calculate stock availability based on the required parameters

### Example

```javascript
import TseCloudMg from 'tse_cloud_mg';
let defaultClient = TseCloudMg.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudMg.GiacenzaMGApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let calcolaDisponibilitaParams = new TseCloudMg.CalcolaDisponibilitaParams(); // CalcolaDisponibilitaParams | Object that contains all the parameters that can affect the stock availability recalculation
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentMGGiacenzaMGDisponibilitaPost(environment, authorizationScope, calcolaDisponibilitaParams, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **calcolaDisponibilitaParams** | [**CalcolaDisponibilitaParams**](CalcolaDisponibilitaParams.md)| Object that contains all the parameters that can affect the stock availability recalculation | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined


## apiV1EnvironmentMGGiacenzaMGRicalcologiacenzaPost

> apiV1EnvironmentMGGiacenzaMGRicalcologiacenzaPost(environment, authorizationScope, ricalcoloGiacenzaParams, opts)

Recalculate the stock based on the required parameters

Recalculate the stock based on the required parameters

### Example

```javascript
import TseCloudMg from 'tse_cloud_mg';
let defaultClient = TseCloudMg.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudMg.GiacenzaMGApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let ricalcoloGiacenzaParams = new TseCloudMg.RicalcoloGiacenzaParams(); // RicalcoloGiacenzaParams | Object that contains all the parameters that can affect the stock recalculation
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentMGGiacenzaMGRicalcologiacenzaPost(environment, authorizationScope, ricalcoloGiacenzaParams, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **ricalcoloGiacenzaParams** | [**RicalcoloGiacenzaParams**](RicalcoloGiacenzaParams.md)| Object that contains all the parameters that can affect the stock recalculation | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined


## apiV1EnvironmentMGGiacenzaMGValidatePost

> apiV1EnvironmentMGGiacenzaMGValidatePost(environment, authorizationScope, giacenzaMGDTO, opts)

Validate

Validation of object of type

### Example

```javascript
import TseCloudMg from 'tse_cloud_mg';
let defaultClient = TseCloudMg.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudMg.GiacenzaMGApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let giacenzaMGDTO = new TseCloudMg.GiacenzaMGDTO(); // GiacenzaMGDTO | Object of type to validate
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentMGGiacenzaMGValidatePost(environment, authorizationScope, giacenzaMGDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **giacenzaMGDTO** | [**GiacenzaMGDTO**](GiacenzaMGDTO.md)| Object of type to validate | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml

