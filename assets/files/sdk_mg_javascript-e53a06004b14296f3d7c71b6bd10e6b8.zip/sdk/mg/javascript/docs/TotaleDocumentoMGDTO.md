# TseCloudMg.TotaleDocumentoMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totdocumento** | **Number** | DO13_TOTDOCUMENTO - Totale documento - This parameter is for Read Only use !! (Cannot set any value) | 
**totimponibile** | **Number** | DO13_TOTIMPONIBILE - Totale imponibile - This parameter is for Read Only use !! (Cannot set any value) | 
**totiva** | **Number** | DO13_TOTIVA - Totale IVA - This parameter is for Read Only use !! (Cannot set any value) | 
**abbuono** | **Number** | DO13_ABBUONO - Abbuono | [optional] 
**acconto** | **Number** | DO13_ACCONTO - Acconto | [optional] 
**imponibomag** | **Number** | DO13_IMPONIBOMAG - Imponibile omaggi | [optional] 
**ivaomag** | **Number** | DO13_IVAOMAG - Importo IVA omaggi | [optional] 
**marginedocumento** | **Number** | DO13_MARGINEDOCUMENTO - Importo margine totale | 
**scimpcassa** | **Number** | DO13_SCIMPCASSA - Sconto cassa ad importo | [optional] 
**scimpmerce** | **Number** | DO13_SCIMPMERCE - Sconto merce ad importo | [optional] 
**scpercassa1** | **Number** | DO13_SCPERCASSA1 - Sconto 1 cassa in percentuale | [optional] 
**scpercassa2** | **Number** | DO13_SCPERCASSA2 - Sconto 2 cassa in percentuale | [optional] 
**scpermerce1** | **Number** | DO13_SCPERMERCE1 - Sconto 1 merce in percentuale | [optional] 
**scpermerce2** | **Number** | DO13_SCPERMERCE2 - Sconto 2 merce in percentuale | [optional] 
**scpermerce3** | **Number** | DO13_SCPERMERCE3 - Sconto 3 merce in percentuale | [optional] 
**totaleCosto** | **Number** | DO13_TOTCOSTO - Totale costo | [optional] 
**totalePagare** | **Number** | DO13_TOTAPAGARE - Totale a pagare | 
**totspbolli** | **Number** | DO13_TOTSPBOLLI - Totale spese bolli | [optional] 
**totspinc** | **Number** | DO13_TOTSPINC - Totale spese incasso | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


