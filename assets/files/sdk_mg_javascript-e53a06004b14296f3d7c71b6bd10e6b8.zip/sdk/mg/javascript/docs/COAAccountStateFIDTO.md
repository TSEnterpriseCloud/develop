# TseCloudMg.COAAccountStateFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**consosCg24** | **String** | CG0S_CONSOS_CG24 - Non utilizzato | [optional] 
**dittaCg18** | **Number** | CG0S_DITTA_CG18 - Ditta | 
**dtconsos** | **Date** | CG0S_DTCONSOS - Non utilizzato | [optional] 
**dtdisatt** | **Date** | CG0S_DTDISATT - Data di disattivazione | [optional] 
**flgDisatt** | **Number** | CG0S_FLGDISATT - Conto disattivato | 
**grusosCg10** | **Number** | CG0S_GRUSOS_CG10 - Non utilizzato | [optional] 
**idCg24** | **Number** | CG0S_ID_CG24 - ID Conto | 
**idstatipdc** | **Number** | CG0S_IDSTATIPDC - ID (Required only in PUT/PATCH) | [optional] 
**rowversion** | **Blob** | CG0S_ROWVERSION - RowVersion | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


