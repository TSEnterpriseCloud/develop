# TseCloudMg.BlockLevelCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codBlocco** | **String** | MG25_CODBLOCCO - Codice Blocco | 
**descrblocco** | **String** | MG25_DESCRBLOCCO - Descrizione | [optional] 
**dittaCg18** | **Number** | MG25_DITTA_CG18 - Ditta | [optional] 
**idmediaCg99** | **Number** | MG25_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**indPayline** | **Number** | MG25_INDPAYLINE - Status Payline&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno Status Payline&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Status Bloccato Payline&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Status A Legale Payline&lt;/li&gt;&lt;/ul&gt; | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndPaylineEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)




