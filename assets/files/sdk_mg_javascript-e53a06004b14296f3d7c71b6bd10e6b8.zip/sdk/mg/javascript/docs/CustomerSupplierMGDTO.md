# TseCloudMg.CustomerSupplierMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**guid** | **String** |  | [optional] 
**cliFor** | **Number** | CG44_CLIFOR - Codice | 
**contratto** | **String** | CG44_CONTRATTO - Codice contratto | [optional] 
**datavaliva** | **Date** | CG44_DATAVALIVA - Fine validità codice IVA | [optional] 
**dittaCg18** | **Number** | CG44_DITTA_CG18 - Ditta | [optional] 
**flgart62** | **Number** | CG44_FLGART62 - Flag Art. 62&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgAttivo** | **Number** | CG44_FLGATTIVO - Attivo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgCointestati** | **Number** | CG44_FLGCOINTESTATI - Cointestati&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgInterCompany** | **Number** | CG44_FLGINTERCOMPANY - Intercompany&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**ggScadFix** | **Number** | CG44_GGSCADFIX - GG scad. fix | [optional] 
**gruppoCg10** | **Number** | CG44_GRUPPO_CG10 - Gruppo piano dei conti | [optional] 
**idCliFor** | **Number** | CG44_IDCLIFOR - ID cliente (Required only in PUT/PATCH) | [optional] 
**idmediaCg99** | **Number** | CG44_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**indElenchiMov3000** | **Number** | CG44_INDELENCHIMOV3000 - Ind. gestione elenchi mov. 3.000€&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;99&lt;/i&gt; - Come da anag. generale&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Contratto &gt;&#x3D; 3.000€&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Contratto corrisp. periodici&lt;/li&gt;&lt;/ul&gt; | [optional] 
**lastchange** | **Date** | CG44_LASTCHANGE - Data ultima variazione | [optional] 
**progrEf08** | **Number** | CG44_PROGR_EF08 - Codice banca aziendale | [optional] 
**tipoCf** | **Number** | CG44_TIPOCF - Tipo Cliente / Fornitore&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**tipocfCg40** | **Number** | CG44_TIPOCF_CG40 - Tipo Cliente / Fornitore | [optional] 
**idExtendedAttributeEntity** | **Number** |  | [optional] 
**idExtendedAttributeSubEntity** | **Number** |  | [optional] 
**blackListGeneralMasterData** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | [optional] 
**classificationData** | [**CustSuppClassificationMGDTO**](CustSuppClassificationMGDTO.md) |  | [optional] 
**currencyCO** | [**CurrencyCODTO**](CurrencyCODTO.md) |  | [optional] 
**dmsPublishedEntityFW** | [**DMSPublishedEntityFWDTO**](DMSPublishedEntityFWDTO.md) |  | 
**generalMasterDataCO** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | 
**goods** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**officeCO** | [**OfficeCODTO**](OfficeCODTO.md) |  | [optional] 
**paymentTermCO** | [**PaymentTermCODTO**](PaymentTermCODTO.md) |  | [optional] 
**returns** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**statoAttualeCO** | [**StatoAttualeDTO**](StatoAttualeDTO.md) |  | 
**vatCodeCO** | [**VatCodeCODTO**](VatCodeCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: Flgart62Enum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgAttivoEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgCointestatiEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgInterCompanyEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndElenchiMov3000Enum


* `99` (value: `99`)

* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: TipoCfEnum


* `0` (value: `0`)

* `1` (value: `1`)




