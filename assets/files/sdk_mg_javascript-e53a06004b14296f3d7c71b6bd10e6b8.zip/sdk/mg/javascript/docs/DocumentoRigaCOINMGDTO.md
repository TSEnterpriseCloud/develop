# TseCloudMg.DocumentoRigaCOINMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**contodestPc03** | **String** | DO53_CONTODEST_PC03 - Conto destinazione | [optional] 
**contoorigPc03** | **String** | DO53_CONTOORIG_PC03 - Conto origine | [optional] 
**dittaCg18** | **Number** | DO53_DITTA_CG18 - Codice ditta | [optional] 
**flgEsclriga** | **Number** | DO53_FLGESCLRIGA - Escludi&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**idmediaCg99** | **Number** | DO53_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**pdcdestPc01** | **Number** | DO53_PDCDEST_PC01 - Codice piano dei conti contabilità analitica | [optional] 
**pdcorigPc01** | **Number** | DO53_PDCORIG_PC01 - Codice piano dei conti origine | [optional] 
**pdcvdsdestPc01** | **Number** | DO53_PDCVDSDEST_PC01 - Codice piano dei conti V.d.S. destinazione | [optional] 
**pdcvdsorigPc01** | **Number** | DO53_PDCVDSORIG_PC01 - codice piano dei conti Vds | [optional] 
**vdsdestPc03** | **String** | DO53_VDSDEST_PC03 - Conto VDS destinazione | [optional] 
**vdsorigPc03** | **String** | DO53_VDSORIG_PC03 - Conto VDS origine | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgEsclrigaEnum


* `0` (value: `0`)

* `1` (value: `1`)




