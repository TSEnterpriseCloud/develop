# TseCloudMg.TransportReasonMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codice** | **String** | MG13_CODICE - Codice | 
**descr** | **String** | MG13_DESCR - Descrizione | [optional] 
**idmediaCg99** | **Number** | MG13_IDMEDIA_CG99 - Hypermedia | [optional] 
**idprov** | **Number** | MG13_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**indNatura** | **Number** | MG13_INDNATURA - Natura transazione per Intra&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - (nessuna)&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Transazioni_con_trasf_proprieta_e_corrisp_finanziario&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Restituzione_e_sostituzione_a_titolo_gratuito&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Transazioni_con_trasf_proprieta_senza_corrisp_finanz&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Transazioni_per_lavorazione_per_conto_terzi&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Transazioni_successive_a_una_lavorazione_per_conto_terzi&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Sdoganamento_non_comportante_un_trasferimento_di_proprieta&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Transaz_fornitura_mat_con_contr_costruz_o_genio_civile&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Altre_transazioni&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Z_Prestazioni_di_servizi_esclusi_dal_modello&lt;/li&gt;&lt;li&gt;&lt;i&gt;21&lt;/i&gt; - A_Transaz_con_trasf_proprieta_e_corrisp_finanziario&lt;/li&gt;&lt;li&gt;&lt;i&gt;22&lt;/i&gt; - B_Restituzione_e_sostituzione_a_titolo_gratuito&lt;/li&gt;&lt;li&gt;&lt;i&gt;23&lt;/i&gt; - C_Transaz_con_trasf_proprieta_senza_corrisp_finanz&lt;/li&gt;&lt;li&gt;&lt;i&gt;24&lt;/i&gt; - D_Transazioni_per_lavorazione_per_conto_terzi&lt;/li&gt;&lt;li&gt;&lt;i&gt;25&lt;/i&gt; - E_Transazioni_successive_a_lavorazione_per_conto_terzi&lt;/li&gt;&lt;li&gt;&lt;i&gt;27&lt;/i&gt; - F_Sdoganamento_non_comportante_un_trasf_di_proprieta&lt;/li&gt;&lt;li&gt;&lt;i&gt;28&lt;/i&gt; - G_Transaz_forn_mat_con_contr_costruz_o_genio_civile&lt;/li&gt;&lt;li&gt;&lt;i&gt;29&lt;/i&gt; - H_Altre_transazioni&lt;/li&gt;&lt;li&gt;&lt;i&gt;30&lt;/i&gt; - Triangolazioni non imponibili art.58 DL 331/93&lt;/li&gt;&lt;/ul&gt; | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndNaturaEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)

* `10` (value: `10`)

* `21` (value: `21`)

* `22` (value: `22`)

* `23` (value: `23`)

* `24` (value: `24`)

* `25` (value: `25`)

* `27` (value: `27`)

* `28` (value: `28`)

* `29` (value: `29`)

* `30` (value: `30`)




