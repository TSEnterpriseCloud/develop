# TseCloudMg.DocumentoPortfolioEvadInMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**guidSession** | **String** | Processing Unique Guid Session | [optional] 
**limiteEvadibilita** | **Number** | Evadability Limit (Filter Criteria) | 
**tipoEvadibilita** | **Number** | Evadibility type&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - All Items&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - For specific item&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - All Documents&lt;/li&gt;&lt;/ul&gt; | [optional] 
**codArt** | **String** | ItemWH (Only for Evadibility type &#x3D; 1) | [optional] 
**variante** | **String** | ItemWH (Only for Evadibility type &#x3D; 1 And CodArt setted) | [optional] 
**isAsyncMode** | **Boolean** | Elaboration Mode (Sync/Async) | 
**minExpire** | **Number** | Minute Expire Guid Rows | 



## Enum: TipoEvadibilitaEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)




