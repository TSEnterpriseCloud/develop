# TseCloudMg.DocumentHeaderCallOptionsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flgSpbolliForceZero** | **Boolean** | FlgSpbolliForceZero (default false): set to true if you want to force the value &#x3D; 0 of the tax stamps fees flag | [optional] [default to false]
**flgSpincasForceZero** | **Boolean** | FlgSpincasForceZero (default false): set to true if you want to force the value &#x3D; 0 of the collection expenses flag | [optional] [default to false]
**flgLockOnDocExist** | **Boolean** | FlgLockOnDocExist (default false): set to true to block the insertion of an already existing document | [optional] [default to false]
**esclusioneAgentiMultipli** | **Boolean** | EsclusioneAgentiMultipli (default false): set to true to exclude the loading of multiple agents in the header | [optional] [default to false]
**esclusioneIvaTestata** | **Boolean** | EsclusioneIvaTestata (default false): set to true to force the header VAT code of the document to Null. | [optional] [default to false]
**disableLetterOfIntent** | **Boolean** | DisableLetterOfIntent (default false): set to true to disable letters of intent | [optional] [default to false]
**esclusioneSpeseTestiCliFor** | **Boolean** | EsclusioneSpeseTestiCliFor (default false): set to true to exclude the proposal of Customer/Supplier expense rows and default fixed texts | [optional] [default to false]
**flgDisableItemControl** | **Boolean** | DisableItemControl (default false): parameter to disable the existence control of articles to optimize times | [optional] [default to false]


