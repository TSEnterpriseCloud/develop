# TseCloudMg.DocumentoTestataProgettiMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**causmgoMgfo** | **Number** | DO24_CAUSMGO_MGFO - CausmgoMgfo | [optional] 
**codCommessa** | **String** | DO24_CODCOMMESSA - Codice commessa | [optional] 
**codDipPd06** | **String** | DO24_CODDIP_PD06 - Codice dipendente | [optional] 
**codProgcol** | **String** | DO24_CODPROGCOL - Codice progetto collegato | [optional] 
**codProgetto** | **String** | DO24_CODPROGETTO - Codice progetto | [optional] 
**codScommessa** | **Number** | DO24_CODSCOMMESSA - Codice sottocommessa | [optional] 
**codSprogcol** | **Number** | DO24_CODSPROGCOL - Codice sottoprogetto collegato | [optional] 
**codSprogetto** | **Number** | DO24_CODSPROGETTO - Codice sottoprogetto | [optional] 
**dittaCg18** | **Number** | DO24_DITTA_CG18 - Codice ditta | [optional] 
**nodorifcolPd0c** | **String** | DO24_NODORIFCOL_PD0C - Codice nodo di riferimento collegato | [optional] 
**nodorifPd0c** | **String** | DO24_NODORIF_PD0C - Codice Nodo di riferimento | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


