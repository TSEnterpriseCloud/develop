# TseCloudMg.LocationWHDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**altezza** | **Number** | MG97_ALTEZZA - Altezza | [optional] 
**codClassestoc** | **Number** | MG97_CODCLASSESTOC - Classe stoccaggio | [optional] 
**codDepMg58** | **String** | MG97_CODDEP_MG58 - Codice deposito | 
**codPriorriemp** | **Number** | MG97_CODPRIORRIEMP - Priorità di riempimento | [optional] 
**coordin1** | **String** | MG97_COORDIN1 - Coordinata 1 | [optional] 
**coordin2** | **String** | MG97_COORDIN2 - Coordinata 2 | [optional] 
**coordin3** | **String** | MG97_COORDIN3 - Coordinata 3 | [optional] 
**descubicaz** | **String** | MG97_DESCUBICAZ - Descrizione ubicazione | 
**dittaCg18** | **Number** | MG97_DITTA_CG18 - Codice ditta | [optional] 
**indTipoubicaz** | **Number** | MG97_INDTIPOUBICAZ - Tipo ubicazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Di prelevamento&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Di scorta&lt;/li&gt;&lt;/ul&gt; | [optional] 
**larghezza** | **Number** | MG97_LARGHEZZA - Larghezza | [optional] 
**maxpeso** | **Number** | MG97_MAXPESO - Massimo peso | [optional] 
**profondita** | **Number** | MG97_PROFONDITA - Profondità | [optional] 
**ubicaz** | **String** | MG97_UBICAZ - Codice ubicazione | 
**umdimens** | **String** | MG97_UMDIMENS - UM dimensione | [optional] 
**umpeso** | **String** | MG97_UMPESO - UM Peso | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndTipoubicazEnum


* `0` (value: `0`)

* `1` (value: `1`)




