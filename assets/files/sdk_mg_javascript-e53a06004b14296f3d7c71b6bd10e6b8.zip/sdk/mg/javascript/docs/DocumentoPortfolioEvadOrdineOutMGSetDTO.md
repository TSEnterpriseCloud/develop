# TseCloudMg.DocumentoPortfolioEvadOrdineOutMGSetDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**guidSession** | **String** | Guid Session Result | [optional] 
**rows** | [**[DocumPortfolioEvaMGDTO]**](DocumPortfolioEvaMGDTO.md) | ResultSet Rows | [optional] 


