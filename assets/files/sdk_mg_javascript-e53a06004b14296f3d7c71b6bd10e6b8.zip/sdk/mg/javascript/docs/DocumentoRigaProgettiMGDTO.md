# TseCloudMg.DocumentoRigaProgettiMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attivitaPd0d** | **String** | DO41_ATTIVITA_PD0D - Codice Attività | [optional] 
**codCommessa** | **String** | DO41_CODCOMMESSA - Codice commessa | [optional] 
**codDipPd06** | **String** | DO41_CODDIP_PD06 - Codice dipendente | [optional] 
**codProgcol** | **String** | DO41_CODPROGCOL - Codice progetto collegato | [optional] 
**codProgetto** | **String** | DO41_CODPROGETTO - Codice progetto | [optional] 
**codScommessa** | **Number** | DO41_CODSCOMMESSA - Codice sottocommessa | [optional] 
**codSprogcol** | **Number** | DO41_CODSPROGCOL - Codice sottoprogetto collegato | [optional] 
**codSprogetto** | **Number** | DO41_CODSPROGETTO - Codice sottoprogetto | [optional] 
**dittaCg18** | **Number** | DO41_DITTA_CG18 - Codice ditta | [optional] 
**idartepuVc02** | **Number** | DO41_IDARTEPU_VC02 - Articolo EPU | [optional] 
**idattrezzaturaVc02** | **Number** | DO41_IDATTREZZATURA_VC02 - IDAttrezzatura | [optional] 
**idmedia** | **Number** | DO41_IDMEDIA - ID HyperMedia | [optional] 
**nodoPd0c** | **String** | DO41_NODO_PD0C - Codice Nodo | [optional] 
**nodorifcolPd0c** | **String** | DO41_NODORIFCOL_PD0C - Codice nodo di riferimento collegato | [optional] 
**nodorifPd0c** | **String** | DO41_NODORIF_PD0C - Codice Nodo di riferimento | [optional] 
**spesaPd64** | **String** | DO41_SPESA_PD64 - Codice spese accessorie | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


