# TseCloudMg.DocumentoTestataOrdiniMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**datacons** | **Date** | DO18_DATACONS - Data consegna | [optional] 
**dataconsint** | **Date** | DO18_DATACONSINT - Data consegna interna | [optional] 
**dataconsorig** | **Date** | DO18_DATACONSORIG - Data consegna origine | [optional] 
**dittaCg18** | **Number** | DO18_DITTA_CG18 - Ditta | [optional] 
**flgConfrit** | **Number** | DO18_FLGCONFRIT - Flag conferma ritornata&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgEvastot** | **Number** | DO18_FLGEVASTOT - Flag evasione totale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgNoevasparz** | **Number** | DO18_FLGNOEVASPARZ - Flag no evasione parziale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgNonann** | **Number** | DO18_FLGNONANN - Flag da non annullare&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgNonpiuev** | **Number** | DO18_FLGNONPIUEV - Flag ordine non più evadibile&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgRicpreev** | **Number** | DO18_FLGRICPREEV - Flag ricalcolo prezzi in evasione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**ggtollercons** | **Number** | DO18_GGTOLLERCONS - Giorni di tolleranza consegna | [optional] 
**numregCo99** | **String** | DO18_NUMREG_CO99 - Numero registrazione | 
**priorita** | **Number** | DO18_PRIORITA - Priorità | [optional] 
**tipoinoltro** | **Number** | DO18_TIPOINOLTRO - Tipo inoltro | [optional] 
**tipoordine** | **Number** | DO18_TIPOORDINE - Tipo ordine | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgConfritEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgEvastotEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgNoevasparzEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgNonannEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgNonpiuevEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgRicpreevEnum


* `0` (value: `0`)

* `1` (value: `1`)




