# TseCloudMg.FiltroDispArticolo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articolo** | **String** |  | [optional] 
**opzione** | **String** |  | [optional] 
**lotto** | **String** |  | [optional] 
**serNum** | **String** |  | [optional] 
**pallet** | **String** |  | [optional] 
**codBagnoMat** | **String** |  | [optional] 
**codProg** | **String** |  | [optional] 
**sotProg** | **Number** |  | [optional] 


