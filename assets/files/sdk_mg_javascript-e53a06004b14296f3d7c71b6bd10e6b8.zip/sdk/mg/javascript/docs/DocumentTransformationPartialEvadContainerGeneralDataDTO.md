# TseCloudMg.DocumentTransformationPartialEvadContainerGeneralDataDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numRegOrigin** | **String** | NumRegOrigin - Num Reg Origin | 
**documentTransformationGeneralData** | [**[DocumentTransformationGeneralDataDTO]**](DocumentTransformationGeneralDataDTO.md) | DocumentTransformationGeneralDataDTO - Container For partial rows | 


