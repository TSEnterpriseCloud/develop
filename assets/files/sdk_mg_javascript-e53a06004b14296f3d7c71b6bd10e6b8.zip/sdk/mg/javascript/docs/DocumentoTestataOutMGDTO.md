# TseCloudMg.DocumentoTestataOutMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**guidSession** | **String** | Guid Session Result Elab | 


