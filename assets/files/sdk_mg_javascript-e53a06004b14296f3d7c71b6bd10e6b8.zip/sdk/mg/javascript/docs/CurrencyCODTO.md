# TseCloudMg.CurrencyCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cambiofisso** | **Number** | CG08_CAMBIOFISSO - Cambio fisso | [optional] 
**codice** | **String** | CG08_CODICE - Codice | 
**dataattuem** | **Date** | CG08_DATAATTUEM - Data attuazione valuta UEM | [optional] 
**descr** | **String** | CG08_DESCR - Descrizione | [optional] 
**flgValuem** | **Number** | CG08_FLGVALUEM - Flag valuta UEM | [optional] 
**idmediaCg99** | **Number** | CG08_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**indCertoincerto** | **Number** | CG08_INDCERTOINCERTO - Cambio incerto per certo | [optional] 
**indSepmigl** | **Number** | CG08_INDSEPMIGL - Separatore migliaia&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - .&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - ,&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indValuem** | **Number** | CG08_INDVALUEM - Tipo valuta UEM&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No valuta UEM&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Franco belga&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Marco tedesco&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Peseta spagnola&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Franco francese&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Sterlina irlandese&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Lira italiana&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Fiorino olandese&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Scellino austriaco&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Escudo portoghese&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Marco finlandese&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - Franco lussemburghese&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Dracma greca&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Tallero sloveno&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Lira cipriota&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - Lira maltese&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - Corona slovacca&lt;/li&gt;&lt;li&gt;&lt;i&gt;17&lt;/i&gt; - Corona estone&lt;/li&gt;&lt;li&gt;&lt;i&gt;18&lt;/i&gt; - Lats lettone&lt;/li&gt;&lt;li&gt;&lt;i&gt;19&lt;/i&gt; - Litas lituano&lt;/li&gt;&lt;/ul&gt; | [optional] 
**numdec** | **Number** | CG08_NUMDEC - Numeri Decimali | [optional] 
**sigla** | **String** | CG08_SIGLA - Sigla | [optional] 
**exchangeRateCO** | [**[ExchangeRateCODTO]**](ExchangeRateCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndSepmiglEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndValuemEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)

* `10` (value: `10`)

* `11` (value: `11`)

* `12` (value: `12`)

* `13` (value: `13`)

* `14` (value: `14`)

* `15` (value: `15`)

* `16` (value: `16`)

* `17` (value: `17`)

* `18` (value: `18`)

* `19` (value: `19`)




