# TseCloudMg.StatoDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idStato** | **Number** | Codice stato | 
**seq** | **Number** | Numero sequenziale di stato | 
**indTipoStato** | **Number** | Indicatore tipo stato: 0 - stato standard, 1 - stato decisionale, 2 - stato autorizzato, 3 -  stato non autorizzato | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


