# TseCloudMg.DocumentTransformationProcessExtremLimitDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**acceptDocMode** | **Number** | AcceptDocMode (Combo filter criteria)&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Initial request only&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Initial request and proposal before generation&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Only request before generation&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Source document numbering replication&lt;/li&gt;&lt;/ul&gt; | [optional] 
**destinationDocParams** | [**DocumentTransfomationDocDestParamsDTO**](DocumentTransfomationDocDestParamsDTO.md) |  | [optional] 



## Enum: AcceptDocModeEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)




