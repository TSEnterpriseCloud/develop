# TseCloudMg.DocumentoTestataMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**esclusioneAgentiMultipli** | **Number** | Deprecated: use callOptions.EsclusioneAgentiMultipli | [optional] 
**esclusioneIvaTestata** | **Number** | Deprecated: use callOptions.EsclusioneIvaTestata | [optional] 
**flgLockOnDocExist** | **Boolean** | Deprecated: use callOptions.FlgLockOnDocExist | [optional] 
**acconto** | **Number** | DO13_ACCONTO - Acconto | [optional] 
**abbuono** | **Number** | DO13_ABBUONO - Abbuono | [optional] 
**callOptions** | [**DocumentHeaderCallOptionsDTO**](DocumentHeaderCallOptionsDTO.md) |  | [optional] 
**bancaCg12** | **Number** | DO11_BANCA_CG12 - Codice banca di appoggio | [optional] 
**cambio** | **Number** | DO11_CAMBIO - Cambio valuta | [optional] 
**cauprestCg15** | **String** | DO11_CAUPREST_CG15 - Codice causale prestazione | [optional] 
**causmagMg51** | **Number** | DO11_CAUSMAG_MG51 - Codice causale magazzino | [optional] 
**cig** | **String** | DO11_CIG - CIG | [optional] 
**cliForDest** | **String** | DO11_CLIFORDEST - Codice destinatario | [optional] 
**cliforfatt** | **Number** | DO11_CLIFORFATT - Codice cliente/fornitore per fatturazione | [optional] 
**codbloccoMg25** | **String** | DO11_CODBLOCCO_MG25 - Codice di blocco documento | [optional] 
**codcabCg13** | **Number** | DO11_CODCAB_CG13 - Codice agenzia di appoggio | [optional] 
**codpagCg62** | **String** | DO11_CODPAG_CG62 - Codice Pagamento | [optional] 
**cup** | **String** | DO11_CUP - CUP | [optional] 
**datacambio** | **Date** | DO11_DATACAMBIO - Data cambio | [optional] 
**datadoc** | **Date** | DO11_DATADOC - Data docum. | 
**datainiziopag** | **Date** | DO11_DATAINIZIOPAG - Data decorrenza pagamento manuale | [optional] 
**dataplafond** | **Date** | DO11_DATAPLAFOND - Data Plafond | [optional] 
**datareg** | **Date** | DO11_DATAREG - Data registrazione documento | 
**descraggcont** | **String** | DO11_DESCRAGGCONT - Descrizione aggiuntiva della registrazione in contabilità | [optional] 
**ditta** | **Number** | DO11_DITTA_CG18 - Ditta | [optional] 
**flgClifat** | **Number** | DO11_FLGCLIFAT - Flag cliente/fornitore per fatturazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgDocstamp** | **Number** | DO11_FLGDOCSTAMP - Flag documento stampato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgSpbolli** | **Number** | DO11_FLGSPBOLLI - Flag spese bolli&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgSpincas** | **Number** | DO11_FLGSPINCAS - Flag spese di incasso&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**idcontCo02** | **Number** | DO11_IDCONT_CO02 - Codice Contatto/Rif. Azienda | [optional] 
**idmediaCg99** | **Number** | DO11_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**indconvclifat** | **Number** | DO11_INDCONVCLIFAT - Conversione cliente per fatturazione | [optional] 
**indfattpa** | **Number** | DO11_INDFATTPA - Tipo fatt. PA | [optional] 
**lastchange** | **Date** | DO11_LASTCHANGE - Data ultima modifica | [optional] 
**lineaFa05** | **String** | DO11_LINEA_FA05 - Linea fashion | [optional] 
**listmag** | **Number** | DO11_LISTMAG - Listmag | [optional] 
**notedocum** | **String** | DO11_NOTEDOCUM - Note documento | [optional] 
**numautof** | **Number** | DO11_NUMAUTOF - Numero autofattura | [optional] 
**numdoc** | **Number** | DO11_NUMDOC - Numero documento | 
**numdocorig** | **String** | DO11_NUMDOCORIG - Numero documento originale | [optional] 
**numReg** | **String** | DO11_NUMREG_CO99 - Numero registrazione | [optional] [default to &#39;000000000000&#39;]
**progrEf08** | **Number** | DO11_PROGR_EF08 - Codice banca aziendale | [optional] 
**sezautof** | **String** | DO11_SEZAUTOF - Sezionale autofattura | [optional] 
**sezdoc** | **String** | DO11_SEZDOC - Sezionale documento | 
**stagioneMg5t** | **Number** | DO11_STAGIONE_MG5T - Codice stagione | [optional] 
**stipodoc** | **Number** | DO11_STIPODOC - Sottotipo documento | [optional] 
**testoletint** | **String** | DO11_TESTOLETINT - Descrizione lettera di intento | [optional] 
**tipodoc** | **Number** | DO11_TIPODOC - Tipo documento | [optional] 
**tipodocnumeraz** | **Number** | DO11_TIPODOCNUMERAZ - Indicatore tipo documento di riferimento numerazione | [optional] 
**tiponumautof** | **Number** | DO11_TIPONUMAUTOF - Tipo registro autofatture | [optional] 
**valutaCg08** | **String** | DO11_VALUTA_CG08 - Codice valuta | [optional] 
**idExtendedAttributeEntity** | **Number** |  | [optional] 
**idExtendedAttributeSubEntity** | **Number** |  | [optional] 
**anagraficaDocumentoDitta** | [**CompanyDocumentMasterDataMGDTO**](CompanyDocumentMasterDataMGDTO.md) |  | 
**codIva** | [**VatCodeCODTO**](VatCodeCODTO.md) |  | [optional] 
**customerSupplierMG** | [**CustomerSupplierMGDTO**](CustomerSupplierMGDTO.md) |  | [optional] 
**documentMaster** | [**DocumentMasterCODTO**](DocumentMasterCODTO.md) |  | [optional] 
**documentoDatiAccompagnamentoMG** | [**DocumentoDatiAccompagnamentoMGDTO**](DocumentoDatiAccompagnamentoMGDTO.md) |  | [optional] 
**documentoTestataAgentiMG** | [**[DocumentoTestataAgentiMGDTO]**](DocumentoTestataAgentiMGDTO.md) |  | [optional] 
**documentoTestataProgettiMG** | [**DocumentoTestataProgettiMGDTO**](DocumentoTestataProgettiMGDTO.md) |  | [optional] 
**documentoTestataProvvigioniMG** | [**[DocumentoTestataProvvigioniMGDTO]**](DocumentoTestataProvvigioniMGDTO.md) |  | [optional] 
**documentoTestataRateiMG** | [**DocumentoTestataRateiMGDTO**](DocumentoTestataRateiMGDTO.md) |  | [optional] 
**headingReferenceDocumentMG** | [**[HeadingReferenceDocumentMGDTO]**](HeadingReferenceDocumentMGDTO.md) |  | [optional] 
**officeCO** | [**OfficeCODTO**](OfficeCODTO.md) |  | [optional] 
**righe** | [**[DocumentoRigaMGDTO]**](DocumentoRigaMGDTO.md) |  | [optional] 
**statoAttuale** | [**StatoAttualeDTO**](StatoAttualeDTO.md) |  | 
**storageWH** | [**StorageWHDTO**](StorageWHDTO.md) |  | 
**storageWHCollegato** | [**StorageWHDTO**](StorageWHDTO.md) |  | [optional] 
**testataEstesa** | [**[DocumentoTestataEstesaMGDTO]**](DocumentoTestataEstesaMGDTO.md) |  | [optional] 
**testataOrdine** | [**DocumentoTestataOrdiniMGDTO**](DocumentoTestataOrdiniMGDTO.md) |  | [optional] 
**testataPersonalizzata** | [**[DocumentoTestataPersonalizzataMGDTO]**](DocumentoTestataPersonalizzataMGDTO.md) |  | [optional] 
**totaliDocumento** | [**TotaleDocumentoMGDTO**](TotaleDocumentoMGDTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgClifatEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgDocstampEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgSpbolliEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgSpincasEnum


* `0` (value: `0`)

* `1` (value: `1`)




