# TseCloudMg.ZoneCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**areaMg08** | **String** | MG09_AREA_MG08 - Area | 
**codiceZona** | **String** | MG09_ZONA - Zona | 
**descrzona** | **String** | MG09_DESCRZONA - Descrizione | [optional] 
**dittaCg18** | **Number** | MG09_DITTA_CG18 - Ditta | 
**idprov** | **Number** | MG09_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**macroareaMg08** | **String** | MG09_MACROAREA_MG08 - Macroarea | 
**tipocfMg08** | **Number** | MG09_TIPOCF_MG08 - Tipo Cli/For&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: TipocfMg08Enum


* `0` (value: `0`)

* `1` (value: `1`)




