# TseCloudMg.DocumPortfolioEvaMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**statoRiga** | **Number** | Riga - STATO_RIGA | [optional] 
**codArtDo30** | **String** | CodArt | [optional] 
**opzioneDo30** | **String** | Variante | [optional] 
**cliforDo11** | **Number** | Cliente | [optional] 
**documDo11** | **String** | Codice | [optional] 
**datadocDo11** | **Date** | Data | [optional] 
**numdocDo11** | **Number** | Numero | [optional] 
**sezdocDo11** | **String** | Sez. | [optional] 
**progVisuastaDo30** | **Number** | Riga | [optional] 
**prior** | **Number** | Prior. | [optional] 
**datacons** | **Date** | Consegna | [optional] 
**rifdata** | **String** | R/C | [optional] 
**qta1Do30** | **Number** | Qta | [optional] 
**qtagiac** | **Number** | Giac. utilizz | [optional] 
**qtaord** | **Number** | Disp. utilizz. | [optional] 
**qtaTrasformazione** | **Number** | Qta trasf. | [optional] 
**giacenzaDisponibileUm1** | **Number** | Giac. disponibile | [optional] 
**descartMg87** | **String** | Descrizione articolo | [optional] 
**ragsoanagCg16** | **String** | Ragione sociale | [optional] 
**giacAtt** | **Number** | Giacenza Att. | [optional] 
**giacEff** | **Number** | Giacenza Eff. | [optional] 
**giacdispAllaData** | **Number** | Disp. alla data | [optional] 
**ordFor** | **Number** | Ordinato For. | [optional] 
**ordProd** | **Number** | Ordinato Prod. | [optional] 
**impCli** | **Number** | Impegnato Cli. | [optional] 
**impProd** | **Number** | Impegnato Prod. | [optional] 
**impClav** | **Number** | Impegnato C/L. | [optional] 
**qtaBloccata** | **Number** | Blocco spedizione | [optional] 
**importoRigares** | **Number** | Importo riga residuo | [optional] 
**importoDo30** | **Number** | Importo riga | [optional] 
**totDocres** | **Number** | Importo merce residuo | [optional] 


