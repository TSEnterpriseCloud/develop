# TseCloudMg.COAAccountCustomizationFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**contoCg24** | **String** | CG39_CONTO_CG24 - Codice conto | 
**descr** | **String** | CG39_DESCR - Descrizione | [optional] 
**dittaCg18** | **Number** | CG39_DITTA_CG18 - Ditta | 
**gruppoCg10** | **Number** | CG39_GRUPPO_CG10 - Piano dei conti | 
**idCg24** | **Number** | CG39_ID_CG24 - ID Conto | 
**iddespcon** | **Number** | CG39_IDDESPCON - ID (Required only in PUT/PATCH) | [optional] 
**idmediaCg99** | **Number** | CG39_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**rowversion** | **Blob** | CG39_ROWVERSION - RowVersion | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


