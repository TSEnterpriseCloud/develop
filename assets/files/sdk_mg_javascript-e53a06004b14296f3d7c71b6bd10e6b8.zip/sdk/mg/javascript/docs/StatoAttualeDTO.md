# TseCloudMg.StatoAttualeDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**statoCorrente** | [**StatoDTO**](StatoDTO.md) |  | 
**statiDisponibili** | [**[StatoDTO]**](StatoDTO.md) | Lista di stati disponibili raggiungibili dallo stato corrente. | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


