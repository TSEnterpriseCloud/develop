# TseCloudMg.DocumentTransformationGeneralDataDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**progrRiga** | **Number** | ProgrRiga - Progr. Row | [optional] 
**indtiporiga** | **Number** | INDTIPORIGA - Indicatore tipo riga&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Warehouse item&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Manual article management of all fields&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Descriptive&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Expense&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Multiple tab&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Fixed text&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Letter of intent&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Phase&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Deposits&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Article + phase&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - Node&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - Activity&lt;/li&gt;&lt;li&gt;&lt;i&gt;17&lt;/i&gt; - Project expense&lt;/li&gt;&lt;/ul&gt; | [optional] 
**descart** | **String** | DESCART - Row Description | [optional] 
**codartMg66** | **String** | CODART_MG66 - CodartMg66 | [optional] 
**qtaTransf** | **Number** | QTATRANSF - Transformation Qta  | 
**price1** | **Number** | Price1 - Price1 in transformation | [optional] 
**price2** | **Number** | Price2 - Price2 in transformation | [optional] 
**scper1** | **Number** | Scper1 - Discount 1 in % | [optional] 
**scper2** | **Number** | Scper2 - Discount 2 in % | [optional] 
**scImp** | **Number** | SctImp - Discount in value | [optional] 
**increase1** | **Number** | Increase1 - Increase 1 in % | [optional] 
**increase2** | **Number** | Increase2 - Increase 2 in % | [optional] 
**increaseImp** | **Number** | IncreaseImp - Taxable increase in % | [optional] 
**rowNotEvad** | **Boolean** | RowNotEvad - Row will be not evadible | [optional] [default to false]



## Enum: IndtiporigaEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `8` (value: `8`)

* `10` (value: `10`)

* `12` (value: `12`)

* `14` (value: `14`)

* `15` (value: `15`)

* `16` (value: `16`)

* `17` (value: `17`)




