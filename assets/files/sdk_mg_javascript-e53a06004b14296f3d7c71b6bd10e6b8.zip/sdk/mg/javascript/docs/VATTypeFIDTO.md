# TseCloudMg.VATTypeFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agviaggio** | **Number** | CG0T_AGVIAGGIO - Agviaggio | 
**codice** | **Number** | CG0T_CODICE - Codice | 
**codiceCg0d** | **Number** | CG0T_CODICE_CG0D - CodiceCg0d | [optional] 
**descr** | **String** | CG0T_DESCR - Descr | [optional] 
**indAutofattura** | **Number** | CG0T_INDAUTOFATTURA - IndAutofattura | 
**indTipo** | **Number** | CG0T_INDTIPO - IndTipo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Ordinario&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Rep. San Marino&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Agenzia viaggi&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Agricoltura&lt;/li&gt;&lt;li&gt;&lt;i&gt;99&lt;/i&gt; - Obsoleti&lt;/li&gt;&lt;/ul&gt; | [optional] 
**localizzazione** | **Number** | CG0T_LOCALIZZAZIONE - Localizzazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuna&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - FRANCIA&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Stati Uniti&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Spagna&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Regno Unito&lt;/li&gt;&lt;/ul&gt; | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndTipoEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `99` (value: `99`)





## Enum: LocalizzazioneEnum


* `0` (value: `0`)

* `2` (value: `2`)

* `1` (value: `1`)

* `3` (value: `3`)

* `4` (value: `4`)




