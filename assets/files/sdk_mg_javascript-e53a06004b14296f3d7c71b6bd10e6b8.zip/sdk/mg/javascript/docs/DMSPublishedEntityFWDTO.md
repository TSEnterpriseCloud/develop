# TseCloudMg.DMSPublishedEntityFWDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**guid** | **String** | Guid entità. | [optional] 
**tipoarchHm30** | **Number** | Tipologia entità. | [optional] 
**idknos** | **Number** | Id Knos. | [optional] 
**dittaCg18** | **Number** | Azienda | [optional] 
**protocollo** | **String** | Prtocollo | [optional] 
**flgInvalid** | **Number** | Flag invalido | [optional] 
**percorso** | **String** | Path | [optional] 
**nome** | **String** | File name | [optional] 
**datapub** | **Date** | Data pubblicazione | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


