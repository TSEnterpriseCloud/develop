# TseCloudMg.DocumentoApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiV1EnvironmentMGDocumentoGet**](DocumentoApi.md#apiV1EnvironmentMGDocumentoGet) | **GET** /api/v1/{environment}/MG/Documento | Get new
[**apiV1EnvironmentMGDocumentoIdDelete**](DocumentoApi.md#apiV1EnvironmentMGDocumentoIdDelete) | **DELETE** /api/v1/{environment}/MG/Documento/{id} | Delete the document having Numreg equals to {ID}
[**apiV1EnvironmentMGDocumentoIdGet**](DocumentoApi.md#apiV1EnvironmentMGDocumentoIdGet) | **GET** /api/v1/{environment}/MG/Documento/{id} | Get the document having Numreg equals to {ID}
[**apiV1EnvironmentMGDocumentoIdPrintGet**](DocumentoApi.md#apiV1EnvironmentMGDocumentoIdPrintGet) | **GET** /api/v1/{environment}/MG/Documento/{id}/print | Get by ID with print document
[**apiV1EnvironmentMGDocumentoIdPut**](DocumentoApi.md#apiV1EnvironmentMGDocumentoIdPut) | **PUT** /api/v1/{environment}/MG/Documento/{id} | Update the document having Numreg equals to {ID}
[**apiV1EnvironmentMGDocumentoPost**](DocumentoApi.md#apiV1EnvironmentMGDocumentoPost) | **POST** /api/v1/{environment}/MG/Documento | Create
[**apiV1EnvironmentMGDocumentoSearchPost**](DocumentoApi.md#apiV1EnvironmentMGDocumentoSearchPost) | **POST** /api/v1/{environment}/MG/Documento/search | Search



## apiV1EnvironmentMGDocumentoGet

> DocumentoTestataMGDTO apiV1EnvironmentMGDocumentoGet(op, environment, authorizationScope, opts)

Get new

Get an empty object of type corresponding

### Example

```javascript
import TseCloudMg from 'tse_cloud_mg';
let defaultClient = TseCloudMg.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudMg.DocumentoApi();
let op = "op_example"; // String | The value must be 'new'
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentMGDocumentoGet(op, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **op** | **String**| The value must be &#39;new&#39; | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**DocumentoTestataMGDTO**](DocumentoTestataMGDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentMGDocumentoIdDelete

> apiV1EnvironmentMGDocumentoIdDelete(id, environment, authorizationScope, opts)

Delete the document having Numreg equals to {ID}

Deleting object of type

### Example

```javascript
import TseCloudMg from 'tse_cloud_mg';
let defaultClient = TseCloudMg.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudMg.DocumentoApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentMGDocumentoIdDelete(id, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentMGDocumentoIdGet

> DocumentoTestataMGDTO apiV1EnvironmentMGDocumentoIdGet(id, environment, authorizationScope, opts)

Get the document having Numreg equals to {ID}

Get an object of type corresponding the requested id

### Example

```javascript
import TseCloudMg from 'tse_cloud_mg';
let defaultClient = TseCloudMg.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudMg.DocumentoApi();
let id = "id_example"; // String | Id to get the object
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'dlevel': "dlevel_example", // String | Serialization level
  'dlevelkey': "dlevelkey_example", // String | Serialization level key
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentMGDocumentoIdGet(id, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Id to get the object | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **dlevel** | **String**| Serialization level | [optional] 
 **dlevelkey** | **String**| Serialization level key | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**DocumentoTestataMGDTO**](DocumentoTestataMGDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentMGDocumentoIdPrintGet

> String apiV1EnvironmentMGDocumentoIdPrintGet(id, environment, authorizationScope, opts)

Get by ID with print document

Get an object of type corresponding the requested id and print it

### Example

```javascript
import TseCloudMg from 'tse_cloud_mg';
let defaultClient = TseCloudMg.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudMg.DocumentoApi();
let id = "id_example"; // String | Id to get the object
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'dlevel': "dlevel_example", // String | Serialization level
  'dlevelkey': "dlevelkey_example", // String | Serialization level key
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentMGDocumentoIdPrintGet(id, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Id to get the object | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **dlevel** | **String**| Serialization level | [optional] 
 **dlevelkey** | **String**| Serialization level key | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

**String**

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentMGDocumentoIdPut

> DocumentoTestataMGDTO apiV1EnvironmentMGDocumentoIdPut(id, environment, authorizationScope, documentoTestataMGDTO, opts)

Update the document having Numreg equals to {ID}

Updating an object of type

### Example

```javascript
import TseCloudMg from 'tse_cloud_mg';
let defaultClient = TseCloudMg.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudMg.DocumentoApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let documentoTestataMGDTO = new TseCloudMg.DocumentoTestataMGDTO(); // DocumentoTestataMGDTO | Object of type to update
let opts = {
  'force': "force_example", // String | The warning/s code to bypass (separated by ‘,’) during the execution
  'op': "op_example", // String | Set 'reload', if you want the DTO updated in the response request
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentMGDocumentoIdPut(id, environment, authorizationScope, documentoTestataMGDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **documentoTestataMGDTO** | [**DocumentoTestataMGDTO**](DocumentoTestataMGDTO.md)| Object of type to update | 
 **force** | **String**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **String**| Set &#39;reload&#39;, if you want the DTO updated in the response request | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**DocumentoTestataMGDTO**](DocumentoTestataMGDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentMGDocumentoPost

> DocumentoTestataMGDTO apiV1EnvironmentMGDocumentoPost(environment, authorizationScope, documentoTestataMGDTO, opts)

Create

Creating new object of type

### Example

```javascript
import TseCloudMg from 'tse_cloud_mg';
let defaultClient = TseCloudMg.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudMg.DocumentoApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let documentoTestataMGDTO = {"acconto":0,"abbuono":0,"callOptions":{"flgSpbolliForceZero":false,"flgSpincasForceZero":false,"flgLockOnDocExist":false,"esclusioneAgentiMultipli":false,"esclusioneIvaTestata":false,"disableLetterOfIntent":false,"esclusioneSpeseTestiCliFor":false,"flgDisableItemControl":false},"bancaCg12":0,"cambio":0,"cauprestCg15":"string","causmagMg51":0,"cig":"string","cliForDest":"string","cliforfatt":0,"codbloccoMg25":"string","codcabCg13":0,"codpagCg62":"string","cup":"string","datacambio":"2024-10-28T10:19:20.384Z","datadoc":"2024-10-28T10:19:20.384Z","datainiziopag":"2024-10-28T10:19:20.384Z","dataplafond":"2024-10-28T10:19:20.384Z","datareg":"2024-10-28T10:19:20.384Z","descraggcont":"string","ditta":0,"flgClifat":0,"flgDocstamp":0,"flgSpbolli":0,"flgSpincas":0,"idcontCo02":0,"idmediaCg99":0,"indconvclifat":0,"indfattpa":0,"lastchange":"2024-10-28T10:19:20.384Z","lineaFa05":"string","listmag":0,"notedocum":"string","numautof":0,"numdoc":0,"numdocorig":"string","numReg":"000000000000","progrEf08":0,"sezautof":"string","sezdoc":"string","stagioneMg5t":0,"stipodoc":0,"testoletint":"string","tipodoc":0,"tipodocnumeraz":0,"tiponumautof":0,"valutaCg08":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"anagraficaDocumentoDitta":{"codDocumMg36":"string","dittaCg18":0,"indStaperMg36":0,"sezdefault":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"codIva":{"aliqivavent":0,"annotazioni":"string","codice":"string","codiceagr":"string","codiceOss":"string","codPlafond":0,"descrizione":"string","flgAgri":0,"flgAllclifor":0,"flgAssport398":0,"flgAutoue":0,"flgCorrVent":0,"flgEscludiblacklist":0,"flgImpostadibollo":0,"flgIndet":0,"flgIvaedit":0,"flgMonofasersm":0,"flgMossgest":0,"flgMossrid":0,"flgNotvar":0,"flgSospimp":0,"idprov":0,"impostamonofasersm":0,"indNatassoswCg2n":0,"indNatura":0,"indStaper":0,"indtipopart":0,"mosscodCg07":0,"mossperc":0,"note":"string","percforf":0,"percindet":0,"perciva":0,"percmonofasersm":0,"rowVersion":"string","tipologia":1,"verslynfa":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-10-28T10:19:20.384Z","datafinblacklist":"2024-10-28T10:19:20.384Z","datainiblacklist":"2024-10-28T10:19:20.384Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-10-28T10:19:20.385Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureAssCO":{"codice":"string","datafineval":"2024-10-28T10:19:20.385Z","datainival":"2024-10-28T10:19:20.385Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureEsCO":{"codice":"string","datafineval":"2024-10-28T10:19:20.385Z","datainival":"2024-10-28T10:19:20.385Z","descr":"string","id":0,"rowversion":"string","natureAssCO":[{"codice":"string","datafineval":"2024-10-28T10:19:20.385Z","datainival":"2024-10-28T10:19:20.385Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCOAgr":"string","vatCodeCOOss":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"customerSupplierMG":{"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","cliFor":0,"contratto":"string","datavaliva":"2024-10-28T10:19:20.385Z","dittaCg18":0,"flgart62":0,"flgAttivo":1,"flgCointestati":0,"flgInterCompany":0,"ggScadFix":0,"gruppoCg10":0,"idCliFor":0,"idmediaCg99":0,"indElenchiMov3000":99,"lastchange":"2024-10-28T10:19:20.385Z","progrEf08":0,"tipoCf":0,"tipocfCg40":0,"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"blackListGeneralMasterData":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-10-28T10:19:20.385Z","datavalid":"2024-10-28T10:19:20.385Z","dtfinepec":"2024-10-28T10:19:20.385Z","dtiniziopec":"2024-10-28T10:19:20.385Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-10-28T10:19:20.385Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-10-28T10:19:20.385Z","datamod":"2024-10-28T10:19:20.385Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-10-28T10:19:20.385Z","datafinblacklist":"2024-10-28T10:19:20.385Z","datainiblacklist":"2024-10-28T10:19:20.385Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-10-28T10:19:20.385Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-10-28T10:19:20.385Z","datafinblacklist":"2024-10-28T10:19:20.385Z","datainiblacklist":"2024-10-28T10:19:20.385Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-10-28T10:19:20.385Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"classificationData":{"areaMGnielsenMg0e":"string","art62txt":"string","cliforCg44":0,"coddestprev":"string","coddocumMg3g":"string","codprevragb":"string","codrifalf":"string","codrifnum":0,"datablocco":"2024-10-28T10:19:20.385Z","datacreaz":"2024-10-28T10:19:20.385Z","datadismis":"2024-10-28T10:19:20.385Z","datarischio":"2024-10-28T10:19:20.385Z","dataultcalsp":"2024-10-28T10:19:20.385Z","dataultdoc":"2024-10-28T10:19:20.385Z","dataultfat":"2024-10-28T10:19:20.385Z","dataultord":"2024-10-28T10:19:20.385Z","dataultvar":"2024-10-28T10:19:20.385Z","dittaCg18":0,"fidoaziendale":1000,"fidofactoring":0,"fidolivello1":0,"fidolivello2":0,"flgart62ctr":0,"flgdaticlfat":0,"flgesclspepor":0,"flgEstrpayline":0,"flgprzcamp":0,"flgqualita":0,"flgrottcig":0,"flgrottsingdoc":0,"flgspbol":0,"flgspeinc":0,"flgTaxliable":0,"ggcons":0,"idmediaCg99":0,"imparrotprec":0,"impdaarrot":0,"indarrinfat":0,"indarrl96":0,"indclibloc":0,"indclifat":0,"inddesdocest":0,"indFattper":0,"indgesfido":0,"indgiorni":0,"indprefstdoc":0,"indrottcig":0,"indspesecum":0,"indstscadest":0,"indtestof1":0,"indtestof2":"0","irs1099":"string","lastchange":"2024-10-28T10:19:20.385Z","listmag":0,"magimpcor":10,"magpercor":0,"notebloc":"string","sc1percor":0,"sc2percor":0,"sc3percor":0,"scaglspbanc":0,"scimpcor":0,"scperpiede":0,"taxexemptionno":"string","tipocfCg44":0,"tipoclxdoc":0,"areaCO":{"codiceAreaMG":"string","descrarea":"string","dittaCg18":0,"idprov":0,"macroareaMg07":"string","tipocfMg07":0,"zone":[{"areaMg08":"string","codiceZona":"string","descrzona":"string","dittaCg18":0,"idprov":0,"macroareaMg08":"string","tipocfMg08":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"blockLevelCO":{"codBlocco":"string","descrblocco":"string","dittaCg18":0,"idmediaCg99":0,"indPayline":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"categoryCO":{"categ":"string","descrcat":"string","dittaCg18":0,"macrocatMg10":"string","tipocfMg10":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"cliForFatturazione":"string","datiAccompagnamento":{"aspettoMg99":"string","cliforCg44":0,"dittaCg18":0,"idmediaCg99":0,"imballoMg95":"string","portoMg91":"string","spedizMg15":"string","tipocfCg44":0,"tipospedMg93":"string","vett1Mg14":"string","vett2Mg14":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"fixedExp1":{"codice":"string","descr":"string","flgIvaincl":0,"flgOramin":0,"flgRicfatriep":0,"flgVentamm":0,"flgVentstat":0,"idmediaCg99":0,"indFatriep":0,"indGesintra":0,"indRotturacorpo":0,"indTipoaliq":0,"indTipoevas":0,"indTipospesa":0,"indTipotot":0,"indTotspese":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"fixedExp2":{"codice":"string","descr":"string","flgIvaincl":0,"flgOramin":0,"flgRicfatriep":0,"flgVentamm":0,"flgVentstat":0,"idmediaCg99":0,"indFatriep":0,"indGesintra":0,"indRotturacorpo":0,"indTipoaliq":0,"indTipoevas":0,"indTipospesa":0,"indTipotot":0,"indTotspese":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"fixedText1":{"codice":"string","datafineval":"2024-10-28T10:19:20.385Z","datainizioval":"2024-10-28T10:19:20.385Z","descr":"string","idmediaCg99":0,"idprov":0,"indTipoevas":0,"testo":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"fixedText2":{"codice":"string","datafineval":"2024-10-28T10:19:20.385Z","datainizioval":"2024-10-28T10:19:20.385Z","descr":"string","idmediaCg99":0,"idprov":0,"indTipoevas":0,"testo":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"grouping1CO":{"codRaggrcf1":"string","descraggrcf1":"string","dittaCg18":0,"idmediaCg99":0,"idprov":0,"tipocf":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"grouping2CO":{"codRaggrcf2":"string","descraggrcf2":"string","dittaCg18":0,"idmediaCg99":0,"idprov":0,"tipocf":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"grouping3CO":{"codRaggrcf3":"string","descraggrcf3":"string","dittaCg18":0,"idmediaCg99":0,"idprov":0,"tipocf":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"language":{"codLingua":"string","descrlingua":"string","idmediaCg99":0,"iso639":"string","siglalingua":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"macAreaCO":{"codiceMacroarea":"string","descrmacroar":"string","dittaCg18":0,"idprov":0,"tipocf":0,"areas":[{"codiceAreaMG":"string","descrarea":"string","dittaCg18":0,"idprov":0,"macroareaMg07":"string","tipocfMg07":0,"zone":[{"areaMg08":"string","codiceZona":"string","descrzona":"string","dittaCg18":0,"idprov":0,"macroareaMg08":"string","tipocfMg08":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"macroCategoryCO":{"descrmacrocat":"string","dittaCg18":0,"macrocat":"string","tipocf":0,"categorie":[{"categ":"string","descrcat":"string","dittaCg18":0,"macrocatMg10":"string","tipocfMg10":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"priceListSalePurchase":{"desclist":"string","dittaCg18":0,"flgVenacq":0,"numlist":0,"valutaCg08":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"priceListWithMultipleItems":{"codice":"string","descr":"string","dittaCg18":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"raggruppamentoPrevalente":{"cliforCg44":0,"codRag":"string","descragg":"string","dittaCg18":0,"idmediaCg99":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"rischio":{"codice":"string","descrizione":"string","dittaCg18":0,"flgAttivo":0,"flgCalceffcons":0,"flgCalceffdacons":0,"flgCalceffprev":0,"flgCalcmovcons":0,"flgCalcmovdacons":0,"flgCalcmovprev":0,"flgEffettiscaduti":0,"flgOrdini":0,"flgSaldocon":0,"flgScadereins":0,"flgScaderenoins":0,"flgScadutoins":0,"flgScadutonoins":0,"flgSelclifortrasf":0,"flgSolobusinesriskattivo":0,"indAttivatrasf":0,"indElabscadinsol":0,"indProvenienzafido":0,"indSegnalazionecorpo":0,"mesiricdocdafatt":0,"mesiricordini":0,"mesiricscadenze":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"subCategoryCO":{"categMg11":"string","descrsottocat":"string","dittaCg18":0,"macrocatMg11":"string","sottcat":"string","tipocfMg11":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"zoneCO":{"areaMg08":"string","codiceZona":"string","descrzona":"string","dittaCg18":0,"idprov":0,"macroareaMg08":"string","tipocfMg08":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-10-28T10:19:20.385Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"dmsPublishedEntityFW":{"guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","tipoarchHm30":0,"idknos":0,"dittaCg18":0,"protocollo":"string","flgInvalid":0,"percorso":"string","nome":"string","datapub":"2024-10-28T10:19:20.385Z","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"generalMasterDataCO":{"alias":"string","auidAu04":0,"cap":"string","capcor":"string","capfisc":"string","cellnum":"string","citta":"string","cittacor":"string","cittafisc":"string","codfiscale":"string","codice":0,"codiceCg07":0,"codiceCg15":"string","codiceCgc0":0,"codicecorCg07":0,"codiceident":"string","codicesfed":"string","codrichiamo":0,"cognome":"string","comfisCg01":"string","comnascita":"string","comnascitaCg01":"string","datanascita":"2024-10-28T10:19:20.385Z","datavalid":"2024-10-28T10:19:20.385Z","dtfinepec":"2024-10-28T10:19:20.385Z","dtiniziopec":"2024-10-28T10:19:20.385Z","faxnum":"string","flgAnagval":1,"flgFattpa":0,"flgNoblacklist":0,"flgOmonimo":0,"flgPrsfis":0,"idmediaCg99":0,"indemail":"string","indFiscale":"string","indFiscaleEX":"string","indirCor":"string","indirCorEX":"string","indirizzo":"string","indirizzoEX":"string","indsoggrit":0,"indweb":"string","lastchange":"2024-10-28T10:19:20.386Z","nome":"string","partitaIVA":"string","partiva":"string","partivaEst":"string","prov":"string","provcor":"string","provfisc":"string","provnascita":"string","ragSoAnag":"string","ragsoanagex":"string","ragsocor":"string","ragsocorex":"string","ragsofisc":"string","ragsofiscex":"string","rapazestCg16":0,"sesso":0,"statofed":"string","statofedfisc":"string","statofiscCg07":0,"statonascitaCg07":0,"tel1num":"string","tel2num":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"addresses":[{"codiceCg16":0,"cap":"string","cellnum":"string","citta":"string","codicesfed":"string","codlinguaMg52":"string","comanaCg01":"string","contea":"string","datacre":"2024-10-28T10:19:20.386Z","datamod":"2024-10-28T10:19:20.386Z","edificio":"string","email":"string","emailPec":"string","fax":"string","frazione":"string","guid":"3fa85f64-5717-4562-b3fc-2c963f66afa6","id":0,"idTeamportal":0,"indirizzocomp":"string","indirizzocomp2":"string","indirizzoex":"string","indweb":"string","latitudine":0,"longitudine":0,"numciv":"string","precisione":"string","presso":"string","pv":"string","ragsoc":"string","ragsocex":"string","rifindirizzo":"string","risregione":"string","risstato":"string","riswarning":"string","riszip":"string","statoCg07":0,"statofed":"string","telefono":"string","tipologia":"string","via":"string","addressesType":[{"id":0,"idCG1J":0,"tipo":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"federalStateViewCO":{"a2iso3166Cg07":"string","codiceCg07":0,"descr":"string","iso3166statofed":"string","statofed":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoEst":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-10-28T10:19:20.386Z","datafinblacklist":"2024-10-28T10:19:20.386Z","datainiblacklist":"2024-10-28T10:19:20.386Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-10-28T10:19:20.386Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"fiscalRepresentative":"string","intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO_Birth":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-10-28T10:19:20.386Z","datafinblacklist":"2024-10-28T10:19:20.386Z","datainiblacklist":"2024-10-28T10:19:20.386Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-10-28T10:19:20.386Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"substitutiveMasterdata":"string","wtCodeCO":{"causdd1":"string","codFiscPrev":"string","codice":"string","codNonsog":0,"codPrev":"string","codTribrp":"string","codTributo":"string","descr":"string","flgGlad":0,"flgMinimi":0,"flgPignTerzi":0,"flgProteo360":0,"flgRegagevo":0,"flgRitImposta":0,"flgSosprit":0,"gcprev":0,"idmediaCg99":0,"idprov":0,"indCodattglad":0,"indTipocassa":0,"inpsivs":0,"percbaseimp":0,"percci":0,"percra":0,"percripaz":0,"percRipPerc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"goods":{"accountType":0,"alias":"string","codeformatted":"string","codiceCg22":0,"codiceCgc0":0,"cogeprogeAbil":0,"cogeprogeAttivita":0,"cogeprogeMateriali":0,"cogeprogeNodo":0,"cogeprogeSpese":0,"conto":"string","contoape":"string","contochiu":"string","contocrsosp":"string","contoratatt":"string","contoratpass":"string","contorisatt":"string","contorispass":"string","descr":"string","flgAggfatt":0,"flgAnalit":0,"flgBilconsattpassdist":0,"flgContoimm":0,"flgGesec":0,"flgGespor":0,"flgIntercompany":0,"flgOpnonfin":0,"flgRaganal":0,"flgRarp":0,"flgSaldog":0,"flgValutaest":0,"gruppoCg10":0,"idconto":0,"idcontoapeCg24":0,"idcontochiuCg24":0,"idcontoratattCg24":0,"idcontoratpassCg24":0,"idcontorisattCg24":0,"idcontorispassCg24":0,"idparent":0,"idreverse":0,"idRifPdC80":0,"indAttpasspor":0,"indContoricav":0,"indCosvend":0,"indDaav":0,"indDaavec":0,"indLivchius":0,"indMastroCliFor":99,"indTipoconto":0,"percindeduc":0,"percindetra":0,"suddconti":0,"coaAccountCustomizationFI":[{"contoCg24":"string","descr":"string","dittaCg18":0,"gruppoCg10":0,"idCg24":0,"iddespcon":0,"idmediaCg99":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"coaAccountFIApe":"string","coaAccountFIChiu":"string","coaAccountFIParent":"string","coaAccountFIRatatt":"string","coaAccountFIRatpass":"string","coaAccountFIRisatt":"string","coaAccountFIRispass":"string","coaAccountStateFI":[{"consosCg24":"string","dittaCg18":0,"dtconsos":"2024-10-28T10:19:20.386Z","dtdisatt":"2024-10-28T10:19:20.386Z","flgDisatt":0,"grusosCg10":0,"idCg24":0,"idstatipdc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"coaGroupCodeFI":{"descr":"string","flgPdclib":0,"gruppo":0,"maskedit":"string","numlivcons":0,"numlivelli":0,"rowversion":"string","accountProposals":[{"codice":0,"contoCg24":"string","gruppoCg10":0,"id":0,"idCg24":0,"rowversion":"string","coaAccountFI":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"coaInternationalCustomizationFI":[{"categoria":0,"contoCg24":"string","esModulo347":0,"gbDeferralcode":"string","gruppoCg10":0,"id":0,"idCg24":0,"iso3166A2":"string","rowversion":"string","subcategoria":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"reverseTypeFI":{"reverseTypeCode":0,"reverseTypeDescription":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatTypeFI":{"agviaggio":0,"codice":0,"codiceCg0d":0,"descr":"string","indAutofattura":0,"indTipo":0,"localizzazione":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"officeCO":{"cap":"string","citta":"string","codice":0,"dittaCg18":0,"idmediaCg99":0,"indDimcentrocomm":0,"indIrizzo":"string","numerorea":"string","progRea":0,"prov":"string","rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"paymentTermCO":{"codPag":"string","descPag":"string","desPagAnal":"string","flgDesc":0,"flgDisgg":0,"flgPrefatt":0,"flgPrefpass":0,"flgStornoiva":0,"id":0,"rowversion":"string","scart26":0,"scpercart26":0,"scpercas":0,"scpermer1":0,"scpermer2":0,"idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"paymentTermDetailCO":[{"aggfix1":0,"aggfix2":0,"codPagCg62":"string","daggfix1":0,"daggfix2":0,"el1frimp":0,"el1friva":0,"el2frimp":0,"el2friva":0,"flgFrpercimp":1,"flgFrperciva":1,"ggdecor":0,"ggmmfix":0,"ggscadfix1":0,"ggscadfix2":0,"id":0,"idCg62":0,"idCg64":0,"imporfix":0,"indDatarif":0,"indImpfix":0,"indTipocalend":0,"indTipodecor":1,"percimp":0,"perciva":0,"prog":0,"rowversion":"string","tipoeff":9,"subTypeCO":{"codiceCg07":0,"codPaguc":"string","codStipoeff":0,"descstipo":"string","flgAssegno":0,"ggoffset":0,"id":0,"indModfatturapa":0,"rowversion":"string","tipoeff":0,"foreignPaymentCodeCO":{"codice":"string","codIso":"string","descrpag":"string","flgIbanobbl":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-10-28T10:19:20.386Z","datafinblacklist":"2024-10-28T10:19:20.386Z","datainiblacklist":"2024-10-28T10:19:20.386Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-10-28T10:19:20.386Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"returns":{"accountType":0,"alias":"string","codeformatted":"string","codiceCg22":0,"codiceCgc0":0,"cogeprogeAbil":0,"cogeprogeAttivita":0,"cogeprogeMateriali":0,"cogeprogeNodo":0,"cogeprogeSpese":0,"conto":"string","contoape":"string","contochiu":"string","contocrsosp":"string","contoratatt":"string","contoratpass":"string","contorisatt":"string","contorispass":"string","descr":"string","flgAggfatt":0,"flgAnalit":0,"flgBilconsattpassdist":0,"flgContoimm":0,"flgGesec":0,"flgGespor":0,"flgIntercompany":0,"flgOpnonfin":0,"flgRaganal":0,"flgRarp":0,"flgSaldog":0,"flgValutaest":0,"gruppoCg10":0,"idconto":0,"idcontoapeCg24":0,"idcontochiuCg24":0,"idcontoratattCg24":0,"idcontoratpassCg24":0,"idcontorisattCg24":0,"idcontorispassCg24":0,"idparent":0,"idreverse":0,"idRifPdC80":0,"indAttpasspor":0,"indContoricav":0,"indCosvend":0,"indDaav":0,"indDaavec":0,"indLivchius":0,"indMastroCliFor":99,"indTipoconto":0,"percindeduc":0,"percindetra":0,"suddconti":0,"coaAccountCustomizationFI":[{"contoCg24":"string","descr":"string","dittaCg18":0,"gruppoCg10":0,"idCg24":0,"iddespcon":0,"idmediaCg99":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"coaAccountFIApe":"string","coaAccountFIChiu":"string","coaAccountFIParent":"string","coaAccountFIRatatt":"string","coaAccountFIRatpass":"string","coaAccountFIRisatt":"string","coaAccountFIRispass":"string","coaAccountStateFI":[{"consosCg24":"string","dittaCg18":0,"dtconsos":"2024-10-28T10:19:20.386Z","dtdisatt":"2024-10-28T10:19:20.386Z","flgDisatt":0,"grusosCg10":0,"idCg24":0,"idstatipdc":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"coaGroupCodeFI":{"descr":"string","flgPdclib":0,"gruppo":0,"maskedit":"string","numlivcons":0,"numlivelli":0,"rowversion":"string","accountProposals":[{"codice":0,"contoCg24":"string","gruppoCg10":0,"id":0,"idCg24":0,"rowversion":"string","coaAccountFI":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"coaInternationalCustomizationFI":[{"categoria":0,"contoCg24":"string","esModulo347":0,"gbDeferralcode":"string","gruppoCg10":0,"id":0,"idCg24":0,"iso3166A2":"string","rowversion":"string","subcategoria":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"intragroupStructureCO":{"codAnagGen":0,"codice":0,"codIntercompany":0,"descr":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"reverseTypeFI":{"reverseTypeCode":0,"reverseTypeDescription":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatTypeFI":{"agviaggio":0,"codice":0,"codiceCg0d":0,"descr":"string","indAutofattura":0,"indTipo":0,"localizzazione":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoAttualeCO":{"statoCorrente":{"idStato":0,"seq":0,"indTipoStato":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statiDisponibili":[{"idStato":0,"seq":0,"indTipoStato":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCO":{"aliqivavent":0,"annotazioni":"string","codice":"string","codiceagr":"string","codiceOss":"string","codPlafond":0,"descrizione":"string","flgAgri":0,"flgAllclifor":0,"flgAssport398":0,"flgAutoue":0,"flgCorrVent":0,"flgEscludiblacklist":0,"flgImpostadibollo":0,"flgIndet":0,"flgIvaedit":0,"flgMonofasersm":0,"flgMossgest":0,"flgMossrid":0,"flgNotvar":0,"flgSospimp":0,"idprov":0,"impostamonofasersm":0,"indNatassoswCg2n":0,"indNatura":0,"indStaper":0,"indtipopart":0,"mosscodCg07":0,"mossperc":0,"note":"string","percforf":0,"percindet":0,"perciva":0,"percmonofasersm":0,"rowVersion":"string","tipologia":1,"verslynfa":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-10-28T10:19:20.386Z","datafinblacklist":"2024-10-28T10:19:20.386Z","datainiblacklist":"2024-10-28T10:19:20.386Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-10-28T10:19:20.386Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureAssCO":{"codice":"string","datafineval":"2024-10-28T10:19:20.386Z","datainival":"2024-10-28T10:19:20.386Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureEsCO":{"codice":"string","datafineval":"2024-10-28T10:19:20.386Z","datainival":"2024-10-28T10:19:20.386Z","descr":"string","id":0,"rowversion":"string","natureAssCO":[{"codice":"string","datafineval":"2024-10-28T10:19:20.386Z","datainival":"2024-10-28T10:19:20.386Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCOAgr":"string","vatCodeCOOss":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"documentMaster":{"datacre":"2024-10-28T10:19:20.386Z","datavar":"2024-10-28T10:19:20.386Z","descnote1":"string","dittaCg18":0,"gruppocre":"string","gruppovar":"string","indTipoop":0,"numreg":"string","utentecre":"string","utentevar":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"documentoDatiAccompagnamentoMG":{"codAspettoMg99":"string","codCautraspMg13":"string","codImballoMg95":"string","codPortoMg91":"string","codTipospedMg93":"string","datainiztrasp":"2024-10-28T10:19:20.387Z","dataritvet1":"2024-10-28T10:19:20.387Z","dataritvet2":"2024-10-28T10:19:20.387Z","descaspetto":"string","descrlettint":"string","dittaCg18":0,"numregCo99":"string","orainiziotrasp":0,"oraritvet1":0,"oraritvet2":0,"pesolordo":0,"pesonetto":0,"spedizMg15":"string","targarim1":"string","targarim2":"string","targavet1":"string","targavet2":"string","totcolli":0,"umpeso":"string","umvolume":"string","vettore1Mg14":"string","vettore2Mg14":"string","volume":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"documentoTestataAgentiMG":[{"codiceAgente":"string","dittaCg18":0,"flgAgerifer":0,"idagenteMg17":0,"indModcalc":0,"indRegprov":0,"numregCo99":"string","perprov":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"documentoTestataProgettiMG":{"causmgoMgfo":0,"codCommessa":"string","codDipPd06":"string","codProgcol":"string","codProgetto":"string","codScommessa":0,"codSprogcol":0,"codSprogetto":0,"dittaCg18":0,"nodorifcolPd0c":"string","nodorifPd0c":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"documentoTestataProvvigioniMG":[{"annoPa23":0,"codiceAgente":"string","dittaCg18":0,"flgPers":0,"flgProvsosp":0,"flgProvvar":0,"flgSt":0,"flgStarcred":0,"flgStenas":0,"idagenteMg17":0,"idmediaCg99":0,"imponprov":0,"imponprovVal":0,"imporprov":0,"imporprovVal":0,"indPers":0,"indSt":0,"indTipomov":0,"noteprov":"string","numregCo99":"string","provmedia":0,"trimestrePa23":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"documentoTestataRateiMG":{"adatacomp":"2024-10-28T10:19:20.387Z","contopar":"string","dadatacomp":"2024-10-28T10:19:20.387Z","datacompivaman":"2024-10-28T10:19:20.387Z","dataregesinc":"2024-10-28T10:19:20.387Z","dataregesprec":"2024-10-28T10:19:20.387Z","dittaCg18":0,"flgDaav":0,"flgDisatcoge":0,"indTipocomp":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"headingReferenceDocumentMG":[{"datansconf":"2024-10-28T10:19:20.387Z","datansdoc":"2024-10-28T10:19:20.387Z","datavsconf":"2024-10-28T10:19:20.387Z","datavsdoc":"2024-10-28T10:19:20.387Z","dittaCg18":0,"fedatadoc":"2024-10-28T10:19:20.387Z","feiddoc":"string","feidsoggetto":"string","flgNsdocbis":0,"indStipodoc":0,"indTipodoc":0,"notensdoc":"string","notevsdoc":"string","numnsdoc":0,"numregCo99":"string","numvsdoc":"string","progRif":0,"rifnsdoc":"string","rifvsdoc":"string","seznsdoc":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"officeCO":{"cap":"string","citta":"string","codice":0,"dittaCg18":0,"idmediaCg99":0,"indDimcentrocomm":0,"indIrizzo":"string","numerorea":"string","progRea":0,"prov":"string","rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"righe":[{"alivacompCg28":"string","altezza":0,"base":0,"capacita":0,"causmagMg51":0,"cig":"string","codartMg66":"string","coddepcolMg58":"string","coddepMg58":"string","codschedaMg42":"string","colli":0,"costotot":0,"cpmerceCg24":"string","cup":"string","descart":"string","ditta":0,"estdescart":"string","fatconv":0,"fatconvcf":0,"flgContribinteg":0,"flgContribprev":0,"flgPriceDiscForce":true,"flgRitacc":0,"flgRitenas":0,"importo":0,"indlisacqven":0,"indlisfisso":0,"indlisprior":0,"indtipoomag":0,"indtiporiga":0,"lineaFa05":"string","magimp":0,"magper1":0,"magper2":0,"numReg":"string","opzioneMg5e":"string","pesol":0,"peson":0,"prezzo1":0,"prezzo1iva":0,"prezzo2":0,"prezzo2iva":0,"profondita":0,"progPadre":0,"progrRiga":0,"progvisuasta":0,"pzconf":0,"qta1":0,"qta2":0,"scimp":0,"scper1":0,"scper2":0,"scper3":0,"scper4":0,"scper5":0,"scper6":0,"stagioneMg5t":0,"svar1":"string","svar2":"string","tara":0,"um1":"string","um2":"string","codIva":{"aliqivavent":0,"annotazioni":"string","codice":"string","codiceagr":"string","codiceOss":"string","codPlafond":0,"descrizione":"string","flgAgri":0,"flgAllclifor":0,"flgAssport398":0,"flgAutoue":0,"flgCorrVent":0,"flgEscludiblacklist":0,"flgImpostadibollo":0,"flgIndet":0,"flgIvaedit":0,"flgMonofasersm":0,"flgMossgest":0,"flgMossrid":0,"flgNotvar":0,"flgSospimp":0,"idprov":0,"impostamonofasersm":0,"indNatassoswCg2n":0,"indNatura":0,"indStaper":0,"indtipopart":0,"mosscodCg07":0,"mossperc":0,"note":"string","percforf":0,"percindet":0,"perciva":0,"percmonofasersm":0,"rowVersion":"string","tipologia":1,"verslynfa":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-10-28T10:19:20.387Z","datafinblacklist":"2024-10-28T10:19:20.387Z","datainiblacklist":"2024-10-28T10:19:20.387Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-10-28T10:19:20.387Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureAssCO":{"codice":"string","datafineval":"2024-10-28T10:19:20.387Z","datainival":"2024-10-28T10:19:20.387Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureEsCO":{"codice":"string","datafineval":"2024-10-28T10:19:20.387Z","datainival":"2024-10-28T10:19:20.387Z","descr":"string","id":0,"rowversion":"string","natureAssCO":[{"codice":"string","datafineval":"2024-10-28T10:19:20.387Z","datainival":"2024-10-28T10:19:20.387Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCOAgr":"string","vatCodeCOOss":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"codIvaEff":{"aliqivavent":0,"annotazioni":"string","codice":"string","codiceagr":"string","codiceOss":"string","codPlafond":0,"descrizione":"string","flgAgri":0,"flgAllclifor":0,"flgAssport398":0,"flgAutoue":0,"flgCorrVent":0,"flgEscludiblacklist":0,"flgImpostadibollo":0,"flgIndet":0,"flgIvaedit":0,"flgMonofasersm":0,"flgMossgest":0,"flgMossrid":0,"flgNotvar":0,"flgSospimp":0,"idprov":0,"impostamonofasersm":0,"indNatassoswCg2n":0,"indNatura":0,"indStaper":0,"indtipopart":0,"mosscodCg07":0,"mossperc":0,"note":"string","percforf":0,"percindet":0,"perciva":0,"percmonofasersm":0,"rowVersion":"string","tipologia":1,"verslynfa":"string","idExtendedAttributeEntity":0,"idExtendedAttributeSubEntity":0,"nationCO":{"a2iso3166":"string","a3iso3166":"string","codice":0,"codiceCg08":"string","codIso":"string","codSian":0,"crtpiva":"string","datacee":"2024-10-28T10:19:20.387Z","datafinblacklist":"2024-10-28T10:19:20.387Z","datainiblacklist":"2024-10-28T10:19:20.387Z","descr":"string","desiso3166":"string","flgIban":0,"flgSepa":0,"idmediaCg99":0,"indTipostato":0,"leniban":0,"numiso3166":"string","currencyCO":{"cambiofisso":0,"codice":"string","dataattuem":"2024-10-28T10:19:20.387Z","descr":"string","flgValuem":0,"idmediaCg99":0,"indCertoincerto":0,"indSepmigl":0,"indValuem":0,"numdec":0,"sigla":"string","exchangeRateCO":[{"adegcambio":0,"anno":0,"cambio":0,"codiceCg08":"string","codicerifCg08":"string","giorno":0,"idmediaCg99":0,"indCertoincerto":0,"mese":0,"rowversion":"string","currencyCO":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureAssCO":{"codice":"string","datafineval":"2024-10-28T10:19:20.387Z","datainival":"2024-10-28T10:19:20.387Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"natureEsCO":{"codice":"string","datafineval":"2024-10-28T10:19:20.387Z","datainival":"2024-10-28T10:19:20.387Z","descr":"string","id":0,"rowversion":"string","natureAssCO":[{"codice":"string","datafineval":"2024-10-28T10:19:20.387Z","datainival":"2024-10-28T10:19:20.387Z","descr":"string","idassosw":0,"idCg2m":0,"rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"vatCodeCOAgr":"string","vatCodeCOOss":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"documentoRigaCOINMG":{"contodestPc03":"string","contoorigPc03":"string","dittaCg18":0,"flgEsclriga":0,"idmediaCg99":0,"pdcdestPc01":0,"pdcorigPc01":0,"pdcvdsdestPc01":0,"pdcvdsorigPc01":0,"vdsdestPc03":"string","vdsorigPc03":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"documentoRigaProgettiMG":{"attivitaPd0d":"string","codCommessa":"string","codDipPd06":"string","codProgcol":"string","codProgetto":"string","codScommessa":0,"codSprogcol":0,"codSprogetto":0,"dittaCg18":0,"idartepuVc02":0,"idattrezzaturaVc02":0,"idmedia":0,"nodoPd0c":"string","nodorifcolPd0c":"string","nodorifPd0c":"string","spesaPd64":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"documentoRigaProvvigioniMG":[{"codiceAgente":"string","dittaCg18":0,"flgVarprov":0,"idagenteMg17":0,"imponprov":0,"imponprovVal":0,"imporprov":0,"imporprovVal":0,"indRegprov":0,"numregCo99":"string","percprov":0,"progRiga":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"documentoRigaRateiMG":{"adatacomp":"2024-10-28T10:19:20.387Z","codBeneusato":0,"contoparCg24":"string","dadatacomp":"2024-10-28T10:19:20.387Z","dataregesinc":"2024-10-28T10:19:20.387Z","dataregesprec":"2024-10-28T10:19:20.387Z","dittaCg18":0,"flgDaav":0,"flgDisatcoge":0,"importo":0,"imprettcostobu":0,"imprettcostobuVal":0,"indTipocomp":0,"indTipomovbu":0,"percforf":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"officeCO":{"cap":"string","citta":"string","codice":0,"dittaCg18":0,"idmediaCg99":0,"indDimcentrocomm":0,"indIrizzo":"string","numerorea":"string","progRea":0,"prov":"string","rowversion":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"packaging":{"capacita":0,"codConfezMg96":"string","colliConf":0,"dittaCg18":0,"numregCo99":"string","pesoLordo":0,"pesoNetto":0,"progRiga":0,"pzConf":0,"qta1Conf":0,"qta2Conf":0,"umCapac":"string","umPeso":"string","umVolume":"string","volume":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"rigaEstesa":[{"alfst1":"string","alfst10":"string","alfst11":"string","alfst12":"string","alfst2":"string","alfst3":"string","alfst4":"string","alfst5":"string","alfst6":"string","alfst7":"string","alfst8":"string","alfst9":"string","datast1":"2024-10-28T10:19:20.387Z","datast2":"2024-10-28T10:19:20.387Z","datast3":"2024-10-28T10:19:20.387Z","datast4":"2024-10-28T10:19:20.387Z","datast5":"2024-10-28T10:19:20.387Z","datast6":"2024-10-28T10:19:20.387Z","dittaCg18":0,"flgSt1":0,"flgSt2":0,"flgSt3":0,"flgSt4":0,"idmediaCg99":0,"indSt1":0,"indSt2":0,"numregCo99":"string","numst1":0,"numst10":0,"numst11":0,"numst12":0,"numst2":0,"numst3":0,"numst4":0,"numst5":0,"numst6":0,"numst7":0,"numst8":0,"numst9":0,"prog":1,"progRiga":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"rigaLotti":[{"causmagMg51":0,"cliforCg44":0,"codArtMg66":"string","codArtpfMg66":"string","codBagnomat":"string","codConfezMg96":"string","codDepMg58":"string","codLottoMg4g":"string","codLottopfMg4g":"string","codPallets":"string","codProgPd14":"string","codSscc":"string","dittaCg18":0,"flgNonpiuev":0,"idmediaCg99":0,"note":"string","numregCo99":"string","numregrifCo99":"string","opzioneMg5e":"string","opzionepfMg5e":"string","prog":1,"progMg4f":0,"progRifDo52":0,"progRiga":0,"progRigarifDo30":0,"qta1":0,"qta1cons":0,"qta2":0,"qta2cons":0,"scadenza":"2024-10-28T10:19:20.387Z","sernum":"string","sotprogPd14":0,"tipocfCg44":0,"ubicazcollMg97":"string","ubicazMg97":"string","anagraficaLotto":{"codArtMg66":"string","codLotto":"string","datacre":"2024-10-28T10:19:20.387Z","datascad":"2024-10-28T10:19:20.387Z","desclotto":"string","dittaCg18":0,"idmediaCg99":0,"lib1":0,"note":"string","opzioneMg5e":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"parametroMovimentazioneLotto":{"dittaCg18":0,"flgAggprogval":0,"flgNote":0,"indGiacsca":0,"prog":0,"tipomov":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"rigaOrdine":{"codPiano":"string","codTraclegdb":"string","codTraclegwbs":"string","collicons":0,"collitrasfddtcl":0,"collitrasfp":0,"contpcarPd79":0,"datacons":"2024-10-28T10:19:20.387Z","dataconsint":"2024-10-28T10:19:20.387Z","dataconsorig":"2024-10-28T10:19:20.387Z","datafineoap":"2024-10-28T10:19:20.387Z","datainizlav":"2024-10-28T10:19:20.387Z","datainizoap":"2024-10-28T10:19:20.387Z","datalancio":"2024-10-28T10:19:20.387Z","datapianif":"2024-10-28T10:19:20.387Z","dittaCg18":0,"flgConsconf":0,"flgNoevasparz":0,"flgNonpiuev":0,"flgNosugg":0,"flgRicpreev":0,"flgSospriga":0,"ggtollercons":0,"indEvasdescsp":0,"indStatocons":0,"indStatodescsp":0,"numpiano":0,"numpropPd39":0,"numregCo99":"string","progRiga":0,"progRigpiaPd80":0,"qta1cons":0,"qta1lanc":0,"qta1prel":0,"qta1trasfddtcl":0,"qta1trasfp":0,"qta2cons":0,"qta2lanc":0,"qta2prel":0,"qta2trasfddtcl":0,"qta2trasfp":0,"valorecons":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"rigaPersonalizzata":[{"alfpers1":"string","alfpers10":"string","alfpers11":"string","alfpers12":"string","alfpers2":"string","alfpers3":"string","alfpers4":"string","alfpers5":"string","alfpers6":"string","alfpers7":"string","alfpers8":"string","alfpers9":"string","datapers1":"2024-10-28T10:19:20.387Z","datapers2":"2024-10-28T10:19:20.387Z","datapers3":"2024-10-28T10:19:20.387Z","datapers4":"2024-10-28T10:19:20.387Z","datapers5":"2024-10-28T10:19:20.387Z","datapers6":"2024-10-28T10:19:20.387Z","dittaCg18":0,"flgPers1":0,"flgPers2":0,"flgPers3":0,"flgPers4":0,"idmediaCg99":0,"indPers1":0,"indPers2":0,"numpers1":0,"numpers10":0,"numpers11":0,"numpers12":0,"numpers2":0,"numpers3":0,"numpers4":0,"numpers5":0,"numpers6":0,"numpers7":0,"numpers8":0,"numpers9":0,"numregCo99":"string","prog":1,"progRiga":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"rigaRiferimenti":[{"collimov":0,"datansconf":"2024-10-28T10:19:20.387Z","datansdoc":"2024-10-28T10:19:20.387Z","datavsconf":"2024-10-28T10:19:20.387Z","datavsdoc":"2024-10-28T10:19:20.387Z","dittaCg18":0,"fasePd12":0,"flgAggprescvar":0,"flgAggqtatrasf":0,"flgNonpiuevpdc":0,"flgNsdocbis":0,"flgStornoqtaval":0,"indAggdocorigine":0,"indQtaordres":0,"indStipodoc":0,"indTipodoc":0,"notensdoc":"string","notevsdoc":"string","numnsdoc":0,"numregCo99":"string","numregpadreCo99":"string","numregrifCo99":"string","numvsdoc":"string","progPdcDo65":0,"progPdcrifDo65":0,"progRif":0,"progRiga":0,"progRigapadreDo30":0,"progRigarifDo30":0,"qta1mov":0,"qta2mov":0,"rifnsdoc":"string","rifvsdoc":"string","seqfase":0,"seznsdoc":"string","valoremov":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"spesaVariaMG":{"codice":"string","descr":"string","flgIvaincl":0,"flgOramin":0,"flgRicfatriep":0,"flgVentamm":0,"flgVentstat":0,"idmediaCg99":0,"indFatriep":0,"indGesintra":0,"indRotturacorpo":0,"indTipoaliq":0,"indTipoevas":0,"indTipospesa":0,"indTipotot":0,"indTotspese":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statoAttualeCO":{"statoCorrente":{"idStato":0,"seq":0,"indTipoStato":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statiDisponibili":[{"idStato":0,"seq":0,"indTipoStato":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"testoFissoMG":{"codice":"string","datafineval":"2024-10-28T10:19:20.388Z","datainizioval":"2024-10-28T10:19:20.388Z","descr":"string","idmediaCg99":0,"idprov":0,"indTipoevas":0,"testo":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"statoAttuale":{"statoCorrente":{"idStato":0,"seq":0,"indTipoStato":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"statiDisponibili":[{"idStato":0,"seq":0,"indTipoStato":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"storageWH":{"capdep":"string","codDep":"string","dataatt":"2024-10-28T10:19:20.388Z","datacess":"2024-10-28T10:19:20.388Z","descrdep":"string","dittaCg18":0,"faxnumdep":"string","flgDepprinc":0,"indEmail":"string","indIdep":"string","indInterest":0,"locdep":"string","provdep":"string","respdep":"string","telnumdep":"string","locationWH":[{"altezza":0,"codClassestoc":0,"codDepMg58":"string","codPriorriemp":0,"coordin1":"string","coordin2":"string","coordin3":"string","descubicaz":"string","dittaCg18":0,"indTipoubicaz":0,"larghezza":0,"maxpeso":0,"profondita":0,"ubicaz":"string","umdimens":"string","umpeso":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"storageWHCollegato":{"capdep":"string","codDep":"string","dataatt":"2024-10-28T10:19:20.388Z","datacess":"2024-10-28T10:19:20.388Z","descrdep":"string","dittaCg18":0,"faxnumdep":"string","flgDepprinc":0,"indEmail":"string","indIdep":"string","indInterest":0,"locdep":"string","provdep":"string","respdep":"string","telnumdep":"string","locationWH":[{"altezza":0,"codClassestoc":0,"codDepMg58":"string","codPriorriemp":0,"coordin1":"string","coordin2":"string","coordin3":"string","descubicaz":"string","dittaCg18":0,"indTipoubicaz":0,"larghezza":0,"maxpeso":0,"profondita":0,"ubicaz":"string","umdimens":"string","umpeso":"string","extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"testataEstesa":[{"alfst1":"string","alfst10":"string","alfst11":"string","alfst12":"string","alfst2":"string","alfst3":"string","alfst4":"string","alfst5":"string","alfst6":"string","alfst7":"string","alfst8":"string","alfst9":"string","datast1":"2024-10-28T10:19:20.388Z","datast2":"2024-10-28T10:19:20.388Z","datast3":"2024-10-28T10:19:20.388Z","datast4":"2024-10-28T10:19:20.388Z","datast5":"2024-10-28T10:19:20.388Z","datast6":"2024-10-28T10:19:20.388Z","dittaCg18":0,"flgSt1":0,"flgSt2":0,"flgSt3":0,"flgSt4":0,"idmediaCg99":0,"indSt1":0,"indSt2":0,"numregCo99":"string","numst1":0,"numst10":0,"numst11":0,"numst12":0,"numst2":0,"numst3":0,"numst4":0,"numst5":0,"numst6":0,"numst7":0,"numst8":0,"numst9":0,"prog":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"testataOrdine":{"datacons":"2024-10-28T10:19:20.388Z","dataconsint":"2024-10-28T10:19:20.388Z","dataconsorig":"2024-10-28T10:19:20.388Z","dittaCg18":0,"flgConfrit":0,"flgEvastot":0,"flgNoevasparz":0,"flgNonann":0,"flgNonpiuev":0,"flgRicpreev":0,"ggtollercons":0,"numregCo99":"string","priorita":0,"tipoinoltro":0,"tipoordine":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"testataPersonalizzata":[{"alfpers1":"string","alfpers10":"string","alfpers11":"string","alfpers12":"string","alfpers2":"string","alfpers3":"string","alfpers4":"string","alfpers5":"string","alfpers6":"string","alfpers7":"string","alfpers8":"string","alfpers9":"string","datapers1":"2024-10-28T10:19:20.388Z","datapers2":"2024-10-28T10:19:20.388Z","datapers3":"2024-10-28T10:19:20.388Z","datapers4":"2024-10-28T10:19:20.388Z","datapers5":"2024-10-28T10:19:20.388Z","datapers6":"2024-10-28T10:19:20.388Z","dittaCg18":0,"flgPers1":0,"flgPers2":0,"flgPers3":0,"flgPers4":0,"idmediaCg99":0,"indPers1":0,"indPers2":0,"numpers1":0,"numpers10":0,"numpers11":0,"numpers12":0,"numpers2":0,"numpers3":0,"numpers4":0,"numpers5":0,"numpers6":0,"numpers7":0,"numpers8":0,"numpers9":0,"numregCo99":"string","prog":1,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}],"totaliDocumento":{"abbuono":0,"acconto":0,"imponibomag":0,"ivaomag":0,"marginedocumento":0,"scimpcassa":0,"scimpmerce":0,"scpercassa1":0,"scpercassa2":0,"scpermerce1":0,"scpermerce2":0,"scpermerce3":0,"totaleCosto":0,"totalePagare":0,"totdocumento":0,"totimponibile":0,"totiva":0,"totspbolli":0,"totspinc":0,"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}},"extensionData":[{"key":"string","value":"string"}],"additionalData":{"additionalProp1":"string","additionalProp2":"string","additionalProp3":"string"}}; // DocumentoTestataMGDTO | Object of type to create
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentMGDocumentoPost(environment, authorizationScope, documentoTestataMGDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **documentoTestataMGDTO** | [**DocumentoTestataMGDTO**](DocumentoTestataMGDTO.md)| Object of type to create | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**DocumentoTestataMGDTO**](DocumentoTestataMGDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentMGDocumentoSearchPost

> DocumentoTestataMGDTO apiV1EnvironmentMGDocumentoSearchPost(environment, authorizationScope, searchDTO, opts)

Search

Search among object of type

### Example

```javascript
import TseCloudMg from 'tse_cloud_mg';
let defaultClient = TseCloudMg.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudMg.DocumentoApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let searchDTO = new TseCloudMg.SearchDTO(); // SearchDTO | Search criteria to apply
let opts = {
  'loadEntireDomain': "loadEntireDomain_example", // String | Specify 'loadEntireDomain=true' if you want all the aggregate
  'gettotalcount': "gettotalcount_example", // String | Specify 'gettotalcount=true' if you want the total number of elements
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentMGDocumentoSearchPost(environment, authorizationScope, searchDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **searchDTO** | [**SearchDTO**](SearchDTO.md)| Search criteria to apply | 
 **loadEntireDomain** | **String**| Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate | [optional] 
 **gettotalcount** | **String**| Specify &#39;gettotalcount&#x3D;true&#39; if you want the total number of elements | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**DocumentoTestataMGDTO**](DocumentoTestataMGDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml

