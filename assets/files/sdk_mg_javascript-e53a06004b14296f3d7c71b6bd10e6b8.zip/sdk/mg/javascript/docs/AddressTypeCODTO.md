# TseCloudMg.AddressTypeCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | CG1K_ID - ID (Required only in PUT/PATCH) | [optional] 
**idCG1J** | **Number** | CG1K_ID_CG1J - IdCG1J | 
**tipo** | **Number** | CG1K_TIPO - Tipo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Sede attività&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Residenza&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Corrispondenza&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Indirizzo legale&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Residenza estera&lt;/li&gt;&lt;/ul&gt; | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: TipoEnum


* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)




