# TseCloudMg.CalcolaDisponibilitaParams

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**deposito** | **String** |  | [optional] 
**tipoQta** | **Number** |  | [optional] 
**filtro** | [**[FiltroDispArticolo]**](FiltroDispArticolo.md) |  | [optional] 


