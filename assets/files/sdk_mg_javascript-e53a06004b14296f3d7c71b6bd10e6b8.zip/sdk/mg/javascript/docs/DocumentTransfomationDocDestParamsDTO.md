# TseCloudMg.DocumentTransfomationDocDestParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dataReg** | **Date** | DataReg (In compile: Registration Data) | [optional] 
**dataDoc** | **Date** | DataDoc (In compile: Document Data) | [optional] 
**dataCompVatMan** | **Date** | DataCompVatMan (In compile: Manual Vat compilation Data) | [optional] 
**sezdoc** | **String** | SezDoc - In compile: (In compile: Sez. for Document) | [optional] 
**numDoc** | **Number** | NumDoc (In compile: Document number) | [optional] 
**numDocOrig** | **Number** | NumDocOrig (In compile: Document orig. number) | [optional] 


