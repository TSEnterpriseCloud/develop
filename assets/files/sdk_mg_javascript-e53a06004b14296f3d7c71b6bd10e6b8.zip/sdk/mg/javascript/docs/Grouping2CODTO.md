# TseCloudMg.Grouping2CODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codRaggrcf2** | **String** | MG32_CODRAGGRCF2 - Raggruppamento 2 | 
**descraggrcf2** | **String** | MG32_DESCRAGGRCF2 - Descrizione | [optional] 
**dittaCg18** | **Number** | MG32_DITTA_CG18 - Ditta | [optional] 
**idmediaCg99** | **Number** | MG32_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**idprov** | **Number** | MG32_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**tipocf** | **Number** | MG32_TIPOCF - Tipo Cli/For&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: TipocfEnum


* `0` (value: `0`)

* `1` (value: `1`)




