# TseCloudMg.DocumentoRigaConfMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**capacita** | **Number** | DO39_CAPACITA - Capacità | [optional] 
**codConfezMg96** | **String** | DO39_CODCONFEZ_MG96 - Codice confezione | 
**colliConf** | **Number** | DO39_COLLICONF - Colli confezione | 
**dittaCg18** | **Number** | DO39_DITTA_CG18 - Ditta | [optional] 
**numregCo99** | **String** | DO39_NUMREG_CO99 - Numero registrazione | 
**pesoLordo** | **Number** | DO39_PESOL - Peso lordo | [optional] 
**pesoNetto** | **Number** | DO39_PESON - Peso netto | [optional] 
**progRiga** | **Number** | DO39_PROGRIGA - Progressivo Riga | 
**pzConf** | **Number** | DO39_PZCONF - Pezzi per confezione | 
**qta1Conf** | **Number** | DO39_QTA1CONF - Qta1 | 
**qta2Conf** | **Number** | DO39_QTA2CONF - Qta2 | 
**umCapac** | **String** | DO39_UMCAPAC - UM capacità | [optional] 
**umPeso** | **String** | DO39_UMPESO - Unità di misura del peso | [optional] 
**umVolume** | **String** | DO39_UMVOLUME - UM Volume | [optional] 
**volume** | **Number** | DO39_VOLUME - Volume | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


