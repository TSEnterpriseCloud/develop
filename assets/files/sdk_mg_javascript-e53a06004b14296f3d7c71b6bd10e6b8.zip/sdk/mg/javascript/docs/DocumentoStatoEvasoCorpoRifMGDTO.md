# TseCloudMg.DocumentoStatoEvasoCorpoRifMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dittaDo33Cg18** | **Number** | VFW_DITTA_DO33_CG18 - DittaDo33Cg18 | 
**idDo33** | **Number** | VFW_ID_DO33 - IdDo33 (Required only in PUT/PATCH) | [optional] 
**idDo33Do30** | **Number** | VFW_ID_DO33_DO30 - IdDo33Do30 | 
**idrifDo33Do30** | **Number** | VFW_IDRIF_DO33_DO30 - IdrifDo33Do30 | 
**numregDo33Co99** | **String** | VFW_NUMREG_DO33_CO99 - NumregDo33Co99 | 
**numregrifCo99Do33Do30** | **String** | VFW_NUMREGRIF_CO99_DO33_DO30 - NumregrifCo99Do33Do30 | [optional] 
**progRigaDo33** | **Number** | VFW_PROGRIGA_DO33 - ProgRigaDo33 | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


