# TseCloudMg.CliForDatiAccompagnamentoMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aspettoMg99** | **String** | MG27_ASPETTO_MG99 - Aspetto dei beni | [optional] 
**cliforCg44** | **Number** | MG27_CLIFOR_CG44 - Codice Cliente / Fornitore | 
**dittaCg18** | **Number** | MG27_DITTA_CG18 - Ditta | [optional] 
**idmediaCg99** | **Number** | MG27_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**imballoMg95** | **String** | MG27_IMBALLO_MG95 - Codice Imballo | [optional] 
**portoMg91** | **String** | MG27_PORTO_MG91 - Codice Porto | [optional] 
**spedizMg15** | **String** | MG27_SPEDIZ_MG15 - Codice Spedizioniere | [optional] 
**tipocfCg44** | **Number** | MG27_TIPOCF_CG44 - Tipo Cliente / Fornitore | 
**tipospedMg93** | **String** | MG27_TIPOSPED_MG93 - Codice tipo spedizione | [optional] 
**vett1Mg14** | **String** | MG27_VETT1_MG14 - Codice Vettore 1 | [optional] 
**vett2Mg14** | **String** | MG27_VETT2_MG14 - Codice Vettore 2 | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


