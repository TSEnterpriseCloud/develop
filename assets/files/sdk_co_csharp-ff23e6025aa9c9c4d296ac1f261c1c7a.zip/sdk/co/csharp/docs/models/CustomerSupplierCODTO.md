# It.TSEnterprise.Sdk.Model.CustomerSupplierCODTO
CG44_CLIFOR - Cliente fornitore<br>Proprietà chiave:<ul><li><b>Idclifor</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Clifor** | **double** | CG44_CLIFOR - Codice cli/for | 
**DittaCg18** | **double** | CG44_DITTA_CG18 - Ditta | 
**DmsPublishedEntityFW** | [**DMSPublishedEntityFWDTO**](DMSPublishedEntityFWDTO.md) |  | 
**GeneralMasterDataCO** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | 
**StatoAttualeCO** | [**StatoAttualeDTO**](StatoAttualeDTO.md) |  | 
**GmdUpdateAdditionalParams** | [**GMDUpdateAdditionalParametersDTO**](GMDUpdateAdditionalParametersDTO.md) |  | [optional] 
**CodAbiCg12** | **double** | CG44_CODABI_CG12 - Codice banca | [optional] 
**CodCabCg13** | **double** | CG44_CODCAB_CG13 - Codice agenzia | [optional] 
**CodiceCg28** | **string** | CG44_CODICE_CG28 - Codice aliquota IVA | [optional] 
**ContoCg24** | **string** | CG44_CONTO_CG24 - Conto merci | [optional] 
**ContorCg24** | **string** | CG44_CONTOR_CG24 - Conto merci reso | [optional] 
**Contratto** | **string** | CG44_CONTRATTO - Codice contratto | [optional] 
**Datavaliva** | **DateTime** | CG44_DATAVALIVA - Fine validità codice IVA | [optional] 
**FlgArt62** | **int** | CG44_FLGART62 - Flag Art. 62 | [optional] [default to 0]
**FlgAttivo** | **double** | CG44_FLGATTIVO - Attivo | [optional] [default to 1D]
**FlgCointestati** | **double** | CG44_FLGCOINTESTATI - Cointestati | [optional] [default to 0D]
**FlgIntercompany** | **double** | CG44_FLGINTERCOMPANY - Gest. Intercompany | [optional] [default to 0D]
**Ggscadfix** | **double** | CG44_GGSCADFIX - GG scad. fix | [optional] 
**GruppoCg10** | **double** | CG44_GRUPPO_CG10 - Codice Pdc | [optional] 
**Guid** | **Guid** | CG44_GUID - GUID | [optional] 
**Idclifor** | **int** | CG44_IDCLIFOR - ID cliente (Required only in PUT/PATCH) | [optional] 
**IdmediaCg99** | **double** | CG44_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**IndElenchimov3000** | **int** | CG44_INDELENCHIMOV3000 - Ind. gestione elenchi mov. 3.000€&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;99&lt;/i&gt; - Come da anag. generale&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Contratto &gt;&#x3D; 3.000€&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Contratto corrisp. periodici&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndElenchimov3000Enum.NUMBER_99]
**IntermedioCg40** | **double** | CG44_INTERMEDIO_CG40 - Codice intermedio | [optional] 
**Lastchange** | **DateTime** | CG44_LASTCHANGE - Data ultima variazione | [optional] 
**ProgREf08** | **double** | CG44_PROGR_EF08 - Codice banca aziendale | [optional] 
**Tipocf** | **double** | CG44_TIPOCF - Tipo Cliente / Fornitore&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IdExtendedAttributeEntity** | **int** |  | [optional] 
**IdExtendedAttributeSubEntity** | **int** |  | [optional] 
**AgentCO** | [**AgentCODTO**](AgentCODTO.md) |  | [optional] 
**BlackListGeneralMasterData** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | [optional] 
**CsAccountingIndexCO** | [**CSAccountingIndexCODTO**](CSAccountingIndexCODTO.md) |  | [optional] 
**CsBankCO** | [**List&lt;CSBankCODTO&gt;**](CSBankCODTO.md) |  | [optional] 
**CsCompanyBankCO** | [**List&lt;CSCompanyBankCODTO&gt;**](CSCompanyBankCODTO.md) |  | [optional] 
**CsInfoCO** | [**CSInfoCODTO**](CSInfoCODTO.md) |  | [optional] 
**CsJointlyHeldCO** | [**List&lt;CSJointlyHeldCODTO&gt;**](CSJointlyHeldCODTO.md) |  | [optional] 
**CsPaymentRangeCO** | [**List&lt;CSPaymentRangeCODTO&gt;**](CSPaymentRangeCODTO.md) |  | [optional] 
**CsPostponementPeriodCO** | [**List&lt;CSPostponementPeriodCODTO&gt;**](CSPostponementPeriodCODTO.md) |  | [optional] 
**CsSddCO** | [**List&lt;CSSddCODTO&gt;**](CSSddCODTO.md) |  | [optional] 
**CurrencyCO** | [**CurrencyCODTO**](CurrencyCODTO.md) |  | [optional] 
**CustomerSupplierCIGCUPCO** | [**List&lt;CustomerSupplierCIGCUPCODTO&gt;**](CustomerSupplierCIGCUPCODTO.md) |  | [optional] 
**CustSupplDataInvoicePACO** | [**CustSupplDataInvoicePACODTO**](CustSupplDataInvoicePACODTO.md) |  | [optional] 
**OfficeCO** | [**OfficeCODTO**](OfficeCODTO.md) |  | [optional] 
**OfficePACO** | [**List&lt;OfficePACODTO&gt;**](OfficePACODTO.md) |  | [optional] 
**PaymentTermCO** | [**PaymentTermCODTO**](PaymentTermCODTO.md) |  | [optional] 
**VatCodeCO** | [**VatCodeCODTO**](VatCodeCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

