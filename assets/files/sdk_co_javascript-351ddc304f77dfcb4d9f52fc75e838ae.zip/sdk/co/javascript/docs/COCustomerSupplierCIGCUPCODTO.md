# TseCloudCo.COCustomerSupplierCIGCUPCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cliforCg44** | **Number** | CO1I_CLIFOR_CG44 - CliforCg44 | 
**dittaCg18** | **Number** | CO1I_DITTA_CG18 - Ditta | 
**id** | **Number** | CO1I_ID - ID (Required only in PUT/PATCH) | [optional] 
**idcigcupCo1h** | **Number** | CO1I_IDCIGCUP_CO1H - IdcigcupCo1h | 
**progREf08** | **Number** | CO1I_PROGR_EF08 - ProgREf08 | [optional] 
**progRMg35** | **Number** | CO1I_PROGR_MG35 - ProgRMg35 | [optional] 
**rowversion** | **Blob** | CO1I_ROWVERSION - Rowversion | [optional] 
**tipocfCg44** | **Number** | CO1I_TIPOCF_CG44 - TipocfCg44 | 
**cigcuPcode** | [**COCIGCUPMasterDataCODTO**](COCIGCUPMasterDataCODTO.md) |  | 
**companyBank** | [**COCompanyBankCODTO**](COCompanyBankCODTO.md) |  | [optional] 
**csBankCO** | [**COCSBankCODTO**](COCSBankCODTO.md) |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


