# TseCloudCo.ImportCustomerSupplierCOAddParameterDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**typeImportModeCustomerSupplier** | **String** | Type import mode Customer/Supplier&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Search by general master data&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Search by code and verify general master data&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Search by code (with overwriting of non-corresponding data)&lt;/li&gt;&lt;/ul&gt; | [optional] [default to &#39;0&#39;]
**insertCustomerSupplier** | **Boolean** | Inserting a new Customer/Supplier | [optional] [default to true]
**updateExistingCustomerSupplier** | **Boolean** | Update existing Customer/Supplier | [optional] [default to false]



## Enum: TypeImportModeCustomerSupplierEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)

* `2` (value: `"2"`)




