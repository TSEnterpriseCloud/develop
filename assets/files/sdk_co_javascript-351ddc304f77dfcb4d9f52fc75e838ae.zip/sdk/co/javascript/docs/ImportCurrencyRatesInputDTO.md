# TseCloudCo.ImportCurrencyRatesInputDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**referenceDate** | **Date** |  | [optional] 
**numberOfPreviousDays** | **Number** |  | [optional] 
**overwrite** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


