# TseCloudCo.CalculateAmountParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fromCurrencyCode** | **String** |  | [optional] 
**toCurrencyCode** | **String** |  | [optional] 
**date** | **Date** |  | [optional] 
**amount** | **Number** |  | [optional] 
**currencyExchange** | **Number** |  | [optional] 
**toCurrencyIsCompanyCurrency** | **Boolean** |  | [optional] 


