# TseCloudCo.CONumDocOrigProposalDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**updEnabled** | **Boolean** |  | [optional] 
**numDocOrig** | **String** |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


