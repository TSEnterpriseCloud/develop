# TseCloudCo.COGetFirstAvailableNumNsProtLetterOfIntentParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tipoCS** | **Number** |  | [optional] 
**anno** | **Number** |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


