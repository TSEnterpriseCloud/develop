# TseCloudCo.COSendingLettersToInsertRowCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idCliFor** | **Number** |  | [optional] 
**annoCompetenza** | **Number** |  | [optional] 
**validaDa** | **Date** |  | [optional] 
**validaA** | **Date** |  | [optional] 
**dataStampa** | **Date** |  | [optional] 
**indTipoDich** | **Number** |  | [optional] 
**ammontare** | **Number** |  | [optional] 
**dogana** | **String** |  | [optional] 
**ivaEsenz** | **String** |  | [optional] 
**note** | **String** |  | [optional] 
**codRap** | **Number** |  | [optional] 
**codCarica** | **Number** |  | [optional] 


