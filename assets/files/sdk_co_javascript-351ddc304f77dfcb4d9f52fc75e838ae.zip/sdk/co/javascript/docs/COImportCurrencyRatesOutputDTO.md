# TseCloudCo.COImportCurrencyRatesOutputDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**operationResult** | **Boolean** |  | [optional] 
**errorMessages** | **[String]** |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


