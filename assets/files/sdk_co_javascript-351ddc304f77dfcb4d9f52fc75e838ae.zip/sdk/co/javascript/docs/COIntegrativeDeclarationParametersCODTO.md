# TseCloudCo.COIntegrativeDeclarationParametersCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mg28Id** | **Number** |  | [optional] 
**dataIniVal** | **Date** |  | [optional] 
**dataFineVal** | **Date** |  | [optional] 
**indTipoDich** | **Number** |  | [optional] 
**ammontare** | **Number** |  | [optional] 
**idIntermediario** | **Number** |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


