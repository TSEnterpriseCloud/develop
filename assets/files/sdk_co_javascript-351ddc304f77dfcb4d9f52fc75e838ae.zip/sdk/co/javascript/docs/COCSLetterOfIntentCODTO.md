# TseCloudCo.COCSLetterOfIntentCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alqIvaCg28** | **String** | MG28_ALQIVA_CG28 - Aliquota IVA | 
**anno** | **Number** | MG28_ANNO - Anno | 
**cliForCg44** | **Number** | MG28_CLIFOR_CG44 - Codice Cliente / Fornitore | 
**dataFineVal** | **Date** | MG28_DATAFINEVAL - Data fine validità | 
**dataInVal** | **Date** | MG28_DATAINVAL - Data inizio validità | 
**dataNsReg** | **Date** | MG28_DATANSREG - Data emissione | [optional] 
**dataProtocollo** | **Date** | MG28_DATAPROTOCOLLO - Data protocollo | [optional] 
**datarevoca** | **Date** | MG28_DATAREVOCA - Data revoca | [optional] 
**dataRicez** | **Date** | MG28_DATARICEZ - Data ricezione | [optional] 
**dittaCg18** | **Number** | MG28_DITTA_CG18 - Ditta | 
**dogana** | **String** | MG28_DOGANA - Dogana | [optional] 
**finoAEuro** | **Number** | MG28_FINOAEURO - Fino a Euro | [optional] 
**flagDisattiv** | **Number** | MG28_FLGDISATTIV - Non attiva | 
**flagStDich** | **Number** | MG28_FLGSTDICH - Stampa dichiarazioni di intento | 
**flagStReg** | **Number** | MG28_FLGSTREG - Reg. st. | 
**flgScartata** | **Number** | MG28_FLGSCARTATA - Scartata | 
**id** | **Number** | MG28_ID - ID tabella MG28 (lettera di intento) (Required only in PUT/PATCH) | [optional] 
**indTipoDich** | **Number** | MG28_INDTIPODICH - Tipo Dichiarazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - La sola operazione specificata&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Le operazioni effettuate nell&#39;anno...fino a concorrenza di EURO&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Le operazioni effettuate nell&#39;anno .... per il&lt;/li&gt;&lt;/ul&gt; | [optional] 
**note** | **String** | MG28_NOTE - Note | [optional] 
**numLetDich** | **String** | MG28_NUMLETDICH - Numero lettera dichiarante | [optional] 
**numNsProt** | **Number** | MG28_NUMNSPROT - Num ns Prot. | [optional] 
**numProtocollo** | **Number** | MG28_NUMPROTOCOLLO - Numero protocollo | [optional] 
**progRinvio** | **Number** | MG28_PROGRINVIO - Progressivo invio | [optional] 
**rowversion** | **Blob** | MG28_ROWVERSION - Rowversion | [optional] 
**tipoCFCg44** | **Number** | MG28_TIPOCF_CG44 - Tipo cliente fornitore | 
**vatCodeCO** | [**COVatCodeCODTO**](COVatCodeCODTO.md) |  | 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndTipoDichEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)




