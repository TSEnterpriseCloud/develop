# TseCloudCo.ExportCustomerSupplierCOParameterDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**addParameters** | [**ExportCustomerSupplierCOAddParameterDTO**](ExportCustomerSupplierCOAddParameterDTO.md) |  | [optional] 
**isAsyncMode** | **Boolean** | Asynchronous processing | [optional] [default to false]
**codLayout** | **String** | Code Layout | 
**searchFilter** | [**SearchDTO**](SearchDTO.md) |  | [optional] 


