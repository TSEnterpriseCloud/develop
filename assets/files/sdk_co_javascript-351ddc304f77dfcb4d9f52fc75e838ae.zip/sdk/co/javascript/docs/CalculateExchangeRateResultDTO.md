# TseCloudCo.CalculateExchangeRateResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tipoCambioRecuperato** | **Number** |  | [optional] 
**numeroDecimali** | **Number** |  | [optional] 
**cambio** | **Number** |  | [optional] 
**dataCambio** | **Date** |  | [optional] 
**indicatoreCertoIncerto** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


