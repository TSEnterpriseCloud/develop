# TseCloudCo.COCustSupplDataInvoicePACODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codiceCg16** | **Number** | CG1O_CODICE_CG16 - CodiceCg16 | 
**emailcortesia** | **String** | CG1O_EMAILCORTESIA - Emailcortesia | [optional] 
**flgAsw** | **Number** | CG1O_FLGASW - FlgAsw | 
**indTypeb2b** | **Number** | CG1O_INDTYPEB2B - IndTypeb2b | 
**tipocfCg44** | **Number** | CG1O_TIPOCF_CG44 - TipocfCg44 | 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


