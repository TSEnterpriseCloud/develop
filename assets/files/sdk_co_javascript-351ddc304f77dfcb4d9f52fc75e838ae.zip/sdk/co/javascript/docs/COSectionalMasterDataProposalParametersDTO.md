# TseCloudCo.COSectionalMasterDataProposalParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**anno** | **Number** |  | [optional] 
**causale** | **String** |  | [optional] 
**codAttivita** | **Number** |  | [optional] 
**calcolaProtocollo** | **Boolean** |  | [optional] 
**tipoMovimento** | **Number** |  | [optional] 
**ignoraCodAttivita** | **Boolean** |  | [optional] 
**ignoraProtocollazioneMovimenti** | **Boolean** |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


