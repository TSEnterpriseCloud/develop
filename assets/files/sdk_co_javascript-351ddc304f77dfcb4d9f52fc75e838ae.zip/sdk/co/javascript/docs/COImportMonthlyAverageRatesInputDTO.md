# TseCloudCo.COImportMonthlyAverageRatesInputDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**baseCurrencyIsoCode** | **[String]** |  | [optional] 
**referenceYear** | **Number** |  | [optional] 
**referenceMonth** | **Number** |  | [optional] 
**overwrite** | **Boolean** |  | [optional] 


