# TseCloudCo.CalculateExchangeRateParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**valutaRiferimento** | **String** |  | [optional] 
**valuta** | **String** |  | [optional] 
**data** | **Date** |  | [optional] 
**tipoCambioRichiesto** | **Number** |  | [optional] 


