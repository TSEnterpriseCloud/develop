# TseCloudCo.SendingLetterResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**opResult** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


