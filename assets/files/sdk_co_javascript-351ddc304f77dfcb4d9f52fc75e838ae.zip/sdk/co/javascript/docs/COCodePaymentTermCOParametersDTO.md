# TseCloudCo.COCodePaymentTermCOParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codePag** | **String** |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


