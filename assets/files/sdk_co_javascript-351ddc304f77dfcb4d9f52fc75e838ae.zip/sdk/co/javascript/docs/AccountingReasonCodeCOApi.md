# TseCloudCo.AccountingReasonCodeCOApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiV1EnvironmentCOAccountingReasonCodeCOGet**](AccountingReasonCodeCOApi.md#apiV1EnvironmentCOAccountingReasonCodeCOGet) | **GET** /api/v1/{environment}/CO/AccountingReasonCodeCO | Get new
[**apiV1EnvironmentCOAccountingReasonCodeCOIdGet**](AccountingReasonCodeCOApi.md#apiV1EnvironmentCOAccountingReasonCodeCOIdGet) | **GET** /api/v1/{environment}/CO/AccountingReasonCodeCO/{id} | Get by ID
[**apiV1EnvironmentCOAccountingReasonCodeCOReadPost**](AccountingReasonCodeCOApi.md#apiV1EnvironmentCOAccountingReasonCodeCOReadPost) | **POST** /api/v1/{environment}/CO/AccountingReasonCodeCO/read | Read
[**apiV1EnvironmentCOAccountingReasonCodeCOSearchPost**](AccountingReasonCodeCOApi.md#apiV1EnvironmentCOAccountingReasonCodeCOSearchPost) | **POST** /api/v1/{environment}/CO/AccountingReasonCodeCO/search | Search
[**apiV1EnvironmentCOAccountingReasonCodeCOValidatePost**](AccountingReasonCodeCOApi.md#apiV1EnvironmentCOAccountingReasonCodeCOValidatePost) | **POST** /api/v1/{environment}/CO/AccountingReasonCodeCO/validate | Validate
[**apiV1EnvironmentCOAccountingReasonCodeCOValidatePropertiesPost**](AccountingReasonCodeCOApi.md#apiV1EnvironmentCOAccountingReasonCodeCOValidatePropertiesPost) | **POST** /api/v1/{environment}/CO/AccountingReasonCodeCO/validateProperties | Validation of one on more properties of Type



## apiV1EnvironmentCOAccountingReasonCodeCOGet

> AccountingReasonCodeCODTO apiV1EnvironmentCOAccountingReasonCodeCOGet(op, environment, authorizationScope, opts)

Get new

Get an empty object of type corresponding

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.AccountingReasonCodeCOApi();
let op = "op_example"; // String | The value must be 'new'
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOAccountingReasonCodeCOGet(op, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **op** | **String**| The value must be &#39;new&#39; | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**AccountingReasonCodeCODTO**](AccountingReasonCodeCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOAccountingReasonCodeCOIdGet

> AccountingReasonCodeCODTO apiV1EnvironmentCOAccountingReasonCodeCOIdGet(id, environment, authorizationScope, opts)

Get by ID

Get an object of type corresponding the requested id

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.AccountingReasonCodeCOApi();
let id = "id_example"; // String | Id to get the object
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'dlevel': "dlevel_example", // String | Serialization level
  'dlevelkey': "dlevelkey_example", // String | Serialization level key
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOAccountingReasonCodeCOIdGet(id, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Id to get the object | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **dlevel** | **String**| Serialization level | [optional] 
 **dlevelkey** | **String**| Serialization level key | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**AccountingReasonCodeCODTO**](AccountingReasonCodeCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOAccountingReasonCodeCOReadPost

> AccountingReasonCodeCODTO apiV1EnvironmentCOAccountingReasonCodeCOReadPost(environment, authorizationScope, searchElementDTO, opts)

Read

Read among object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.AccountingReasonCodeCOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let searchElementDTO = [new TseCloudCo.SearchElementDTO()]; // [SearchElementDTO] | Search criteria to apply
let opts = {
  'dlevel': "dlevel_example", // String | Serialization level
  'dlevelkey': "dlevelkey_example", // String | Serialization level key
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOAccountingReasonCodeCOReadPost(environment, authorizationScope, searchElementDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **searchElementDTO** | [**[SearchElementDTO]**](SearchElementDTO.md)| Search criteria to apply | 
 **dlevel** | **String**| Serialization level | [optional] 
 **dlevelkey** | **String**| Serialization level key | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**AccountingReasonCodeCODTO**](AccountingReasonCodeCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOAccountingReasonCodeCOSearchPost

> AccountingReasonCodeCODTO apiV1EnvironmentCOAccountingReasonCodeCOSearchPost(environment, authorizationScope, searchDTO, opts)

Search

Search among object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.AccountingReasonCodeCOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let searchDTO = new TseCloudCo.SearchDTO(); // SearchDTO | Search criteria to apply
let opts = {
  'loadEntireDomain': "loadEntireDomain_example", // String | Specify 'loadEntireDomain=true' if you want all the aggregate
  'gettotalcount': "gettotalcount_example", // String | Specify 'gettotalcount=true' if you want the total number of elements
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOAccountingReasonCodeCOSearchPost(environment, authorizationScope, searchDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **searchDTO** | [**SearchDTO**](SearchDTO.md)| Search criteria to apply | 
 **loadEntireDomain** | **String**| Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate | [optional] 
 **gettotalcount** | **String**| Specify &#39;gettotalcount&#x3D;true&#39; if you want the total number of elements | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**AccountingReasonCodeCODTO**](AccountingReasonCodeCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOAccountingReasonCodeCOValidatePost

> apiV1EnvironmentCOAccountingReasonCodeCOValidatePost(environment, authorizationScope, accountingReasonCodeCODTO, opts)

Validate

Validation of object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.AccountingReasonCodeCOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let accountingReasonCodeCODTO = new TseCloudCo.AccountingReasonCodeCODTO(); // AccountingReasonCodeCODTO | Object of type to validate
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOAccountingReasonCodeCOValidatePost(environment, authorizationScope, accountingReasonCodeCODTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **accountingReasonCodeCODTO** | [**AccountingReasonCodeCODTO**](AccountingReasonCodeCODTO.md)| Object of type to validate | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOAccountingReasonCodeCOValidatePropertiesPost

> ValidateDTO apiV1EnvironmentCOAccountingReasonCodeCOValidatePropertiesPost(environment, authorizationScope, opts)

Validation of one on more properties of Type

Validation of object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.AccountingReasonCodeCOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'", // String | Example for multilanguage
  'body': null // String |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br>
};
apiInstance.apiV1EnvironmentCOAccountingReasonCodeCOValidatePropertiesPost(environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]
 **body** | **String**|  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED&lt;br&gt; - The id of an existing object to validate properties, or &#39;&#39; if the object does not exist yet &lt;br&gt; | [optional] 

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json, application/xml

