# TseCloudCo.COIntragroupStructureCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codAnagGen** | **Number** | Codice anagrafica | [optional] 
**codice** | **Number** | CGC0_CODICE - Codice | 
**codIntercompany** | **Number** | Codice intercompany | [optional] 
**descr** | **String** | CGC0_DESCR - Descrizione | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


