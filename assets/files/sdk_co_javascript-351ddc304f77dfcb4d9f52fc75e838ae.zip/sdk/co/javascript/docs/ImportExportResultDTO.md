# TseCloudCo.ImportExportResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**guidSession** | **String** | Guid Process | [optional] 
**stateProcess** | **String** | State Process | [optional] 
**idStateProcess** | **Number** | Id State Process&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Inserted&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Processing&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Terminate&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Terminate with error&lt;/li&gt;&lt;/ul&gt; | [optional] 
**headProcess** | [**ImportExportHeadResultDTO**](ImportExportHeadResultDTO.md) |  | [optional] 
**streamFileExport** | **String** | Stream File Export | [optional] 



## Enum: IdStateProcessEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)




