# TseCloudCo.COImportExportHeadResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**guidResult** | **String** | Guid Result | [optional] 
**totRowImpExp** | **Number** | total rows processed | [optional] 
**impExpWithErrors** | **Boolean** | Import/Export with Error | [optional] 
**rowElab** | [**[COImportExportRowResultDTO]**](COImportExportRowResultDTO.md) | Information/Error rows | [optional] 


