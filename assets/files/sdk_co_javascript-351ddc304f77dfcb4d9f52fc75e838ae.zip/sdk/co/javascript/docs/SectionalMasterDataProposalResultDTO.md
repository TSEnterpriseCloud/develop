# TseCloudCo.SectionalMasterDataProposalResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**executionResult** | **Boolean** |  | [optional] 
**sectionalData** | [**SectionalMasterDataProposalInfoDTO**](SectionalMasterDataProposalInfoDTO.md) |  | [optional] 
**selfInvoiceSectionalData** | [**SectionalMasterDataProposalInfoDTO**](SectionalMasterDataProposalInfoDTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


