# TseCloudCo.IELayoutCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bytesToExclude** | **Number** | IE25_BYTEDAESCL - Bytes da escludere | [optional] 
**codLayout** | **String** | IE25_TRACCIATO - Tracciato | 
**codStructureSubType** | **Number** | IE25_SOTTOTIPO_IE37 - Sottotipo struttura | 
**codStructureType** | **Number** | IE25_STRUTTURA_IE21 - Struttura | 
**description** | **String** | IE25_DESCRIZIONE - Descrizione tracciato | 
**filePath** | **String** | IE25_NOMEFILE - Percorso e nome file | [optional] 
**headerWithFieldNames** | **Number** | IE25_FLGINTESTAZIONE - Intestazione con nomi campi&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**note** | **String** | IE25_NOTE - Note | [optional] 
**rowLength** | **Number** | IE25_LENREC - Lunghezza riga | [optional] 
**tableFile** | **String** | IE25_TABELLAFILE - Tabella file | [optional] 
**tableSingle** | **String** | IE25_TABELLA - Tabella | [optional] 
**typeCharset** | **Number** | IE25_INDCHARSET - Codifica&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Ansi&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Utf-8&lt;/li&gt;&lt;/ul&gt; | [optional] 
**typeEndRow** | **Number** | IE25_INDFINERIGA - Indicatore fine riga&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - CR+LF&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - CR&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - LF&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;/ul&gt; | [optional] 
**typeFile** | **Number** | IE25_INDTIPOFILE - Tipo file&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Testo&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Testo delimitato&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Binario&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Excel(Xls)&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - XML&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Tabella&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Excel(Xlsx)&lt;/li&gt;&lt;/ul&gt; | [optional] 
**typeImpExp** | **Number** | IE25_INDIMPEXP - Modalità Import/Export&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Import/Export&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Import&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Export&lt;/li&gt;&lt;/ul&gt; | [optional] 
**typeRecord** | **Number** | IE25_INDGESTTIPIREC - Gestione tipi record&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**typeSeparation** | **Number** | IE25_INDSEPARATORE - Separatore&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - ,&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Punto (.)&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Barra (/)&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Tab&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - !&lt;/li&gt;&lt;/ul&gt; | [optional] 
**typeTextQualification** | **Number** | IE25_INDQUALIFICATESTO - Qualificatore di testo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Virgolette (\&quot;)&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Apice (&#39;)&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Virgolette (\&quot;) e raddoppio virgolette presenti&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Apice (&#39;) e raddoppio apici presenti&lt;/li&gt;&lt;/ul&gt; | [optional] 
**structureSubType** | [**IEStructureSubTypeCODTO**](IEStructureSubTypeCODTO.md) |  | 
**structureType** | [**IEStructureTypeCODTO**](IEStructureTypeCODTO.md) |  | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: HeaderWithFieldNamesEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: TypeCharsetEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: TypeEndRowEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: TypeFileEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)





## Enum: TypeImpExpEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: TypeRecordEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: TypeSeparationEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)





## Enum: TypeTextQualificationEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)




