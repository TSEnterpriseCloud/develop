# TseCloudCo.COIntegrativeDeclarationResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**opResult** | [**COCSLetterOfIntentCODTO**](COCSLetterOfIntentCODTO.md) |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


