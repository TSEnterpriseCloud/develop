# TseCloudCo.CodePaymentTermCOParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codePag** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


