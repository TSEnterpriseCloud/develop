# TseCloudCo.OfficePACODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cap** | **String** | CG1M_CAP - Cap | [optional] 
**codDestin** | **String** | CG1M_CODDESTIN - Codice destinatario | 
**codice** | **String** | CG1M_CODICE - Codice | 
**codiceCg16** | **Number** | CG1M_CODICE_CG16 - Codice anagrafica generale | 
**comune** | **String** | CG1M_COMUNE - Comune | [optional] 
**flgPreferenziale** | **Number** | CG1M_FLGPREFERENZIALE - Preferenziale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**idprovincia** | **Number** | CG1M_IDPROVINCIA - Cod. Provincia | [optional] 
**idregione** | **Number** | CG1M_IDREGIONE - Cod. Regione | [optional] 
**indIrizzo** | **String** | CG1M_INDIRIZZO - Indirizzo | [optional] 
**indTypeb2b** | **Number** | CG1M_INDTYPEB2B - Instradamento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Non attivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - FEPA&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - FEPR&lt;/li&gt;&lt;/ul&gt; | [optional] 
**lastupdateB2b** | **Date** | CG1M_LASTUPDATE_B2B - Data ultimo aggiornamento | [optional] 
**nome** | **String** | CG1M_NOME - Denominazione | 
**tipocfCg44** | **Number** | CG1M_TIPOCF_CG44 - Tipo Cliente / Fornitore&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgPreferenzialeEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndTypeb2bEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `6` (value: `6`)





## Enum: TipocfCg44Enum


* `0` (value: `0`)

* `1` (value: `1`)




