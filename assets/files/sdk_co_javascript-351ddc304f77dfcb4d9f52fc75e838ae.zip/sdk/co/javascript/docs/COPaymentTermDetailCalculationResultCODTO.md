# TseCloudCo.COPaymentTermDetailCalculationResultCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sumImp** | **Number** |  | [optional] 
**sumIva** | **Number** |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


