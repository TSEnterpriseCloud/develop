# TseCloudCo.ContactTypeCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codice** | **String** | CO01_CODICE - Codice tipo contatto/riferimento azienda | 
**descr** | **String** | CO01_DESCR - Descrizione | 
**flgUsosoll** | **Number** | CO01_FLGUSOSOLL - Utilizza per solleciti pagamento | [optional] 
**rowversion** | **Blob** | CO01_ROWVERSION - RowVersion | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


