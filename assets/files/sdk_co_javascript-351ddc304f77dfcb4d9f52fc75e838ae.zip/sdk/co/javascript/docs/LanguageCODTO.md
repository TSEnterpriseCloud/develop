# TseCloudCo.LanguageCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codLingua** | **String** | MG52_CODLINGUA - Codice lingua | 
**descrlingua** | **String** | MG52_DESCRLINGUA - Descrizione lingua | [optional] 
**idmediaCg99** | **Number** | MG52_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**iso639** | **String** | MG52_ISO639 - Codice ISO639 | [optional] 
**siglalingua** | **String** | MG52_SIGLALINGUA - Sigla | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


