# TseCloudCo.COSearchGroupDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**[COOneOfSearchNodeDTOSearchElementDTOSearchGroupDTO]**](COOneOfSearchNodeDTOSearchElementDTOSearchGroupDTO.md) | Items list to apply: any element can be a &#39;SearchGroupDTO&#39; or a &#39;SearchElementDTO&#39; | [optional] 
**operator** | [**COSearchLogicalOperators**](COSearchLogicalOperators.md) |  | [optional] 


