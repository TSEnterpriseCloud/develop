# TseCloudCo.VatCodeCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aliqivavent** | **Number** | CG28_ALIQIVAVENT - % acquisti in ventilazione | [optional] 
**annotazioni** | **String** | CG28_ANNOTAZIONI - Annotazioni su fatture di vendita e sui registri IVA art.21 comma 6 DPR 633/72 | [optional] 
**codice** | **String** | CG28_CODICE - Codice aliquota | 
**codiceagr** | **String** | CG28_CODICEAGR - Codice IVA per compensazione agricoltura | [optional] 
**codiceOss** | **String** | CG28_OSSCOD_CG28 - Codice IVA correlato | [optional] 
**codPlafond** | **Number** | CG28_CODPLAFOND - Plafond&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No plafond&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Esportazioni art.8 1°c. a/b, 9 1°c.-Cessioni art.8 1°c. c,2°c.&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Acquisti interni art.8 2°c., 8 bis 2°c., 9 2°c.&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Importazioni art.8 2°c., 68 l.a, 8 bis, 9 2°c.&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Acquisti intracomunitari art. 42 1°c.&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Cessioni intracomunitarie art. 41 2°c.&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Cessioni art.8 bis, 1°c. (no lettera intento)&lt;/li&gt;&lt;/ul&gt; | [optional] 
**descrizione** | **String** | CG28_DESCR - Descrizione | 
**flgAgri** | **Number** | CG28_FLGAGRI - Indicare se codice IVA utilizzato per agricoltura&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgAllclifor** | **Number** | CG28_FLGALLCLIFOR - Progressivi aliquota IVA inclusi negli allegati clienti fornitori&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgAssport398** | **Number** | CG28_FLGASSPORT398 - Soc. sportiva dilettantistica (L.398/91)&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgAutoue** | **Number** | CG28_FLGAUTOUE - Vendita auto UE L. 286&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgCorrVent** | **Number** | CG28_FLGCORRVENT - Aliquota IVA utilizzata per la registrazione dei corrispettivi da ventilare&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgEscludiblacklist** | **Number** | CG28_FLGESCLUDIBLACKLIST - Escludi da black list&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgImpostadibollo** | **Number** | CG28_FLGIMPOSTADIBOLLO - Imposta di bollo applicabile&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgIndet** | **Number** | CG28_FLGINDET - IVA indetraibile&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgIvaedit** | **Number** | CG28_FLGIVAEDIT - Indicare se codice IVA utilizzato per editoria&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Non movimentato&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Movimentato&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgMonofasersm** | **Number** | CG28_FLGMONOFASERSM - Monofase Repubblica di San Marino | [optional] 
**flgMossgest** | **Number** | CG28_FLGMOSSGEST - One Stop Shop (OSS)&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgMossrid** | **Number** | CG28_FLGMOSSRID - Aliquota ridotta&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgNotvar** | **Number** | CG28_FLGNOTVAR - Indicare se codice IVA utilizzato per note variazioni IVA&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgSospimp** | **Number** | CG28_FLGSOSPIMP - IVA esigibilità differita&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Immediata&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Differita Enti Pubblici&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Differita altre società&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Enti pubblici Art.17-ter (Split Payment)&lt;/li&gt;&lt;/ul&gt; | [optional] 
**idprov** | **Number** | CG28_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**impostamonofasersm** | **Number** | CG28_IMPOSTAMONOFASERSM - Importo imposta fissa | [optional] 
**indNatassoswCg2n** | **Number** | CG28_INDNATASSOSW_CG2N - Natura Assosoftware | [optional] 
**indNatura** | **Number** | CG28_INDNATURA - Natura | [optional] 
**indStaper** | **Number** | CG28_INDSTAPER - Standard/Pers.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Standard&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Personalizzato&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indtipopart** | **Number** | CG28_INDTIPOPART - Indtipopart&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - NessunValore&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Operazioni con IVA non esposta in fattura&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Operazioni imponibili (es.: reverse charge)&lt;/li&gt;&lt;/ul&gt; | [optional] 
**mosscodCg07** | **Number** | CG28_MOSSCOD_CG07 - Codice Stato | [optional] 
**mossperc** | **Number** | CG28_MOSSPERC - VAT rate (%) | [optional] 
**note** | **String** | CG28_NOTE - Note | [optional] 
**percforf** | **Number** | CG28_PERCFORF - % forfetizzazione editoria/agricoltura | [optional] 
**percindet** | **Number** | CG28_PERCINDET - % assoggettamento ad indetraibilità | [optional] 
**perciva** | **Number** | CG28_PERCIVA - % assoggettamento aliquota | [optional] 
**percmonofasersm** | **Number** | CG28_PERCMONOFASERSM - % Monofase | [optional] 
**rowVersion** | **Blob** | CG28_ROWVERSION - RowVersion | [optional] 
**stdcodivarifCg28** | **String** | CG28_STDCODIVARIF_CG28 - StdcodivarifCg28 | [optional] 
**tipologia** | **Number** | CG28_TIPOLOGIA - Tipologia&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Imponibile&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Non imponibile&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Esente&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Escluso&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Fuori campo IVA&lt;/li&gt;&lt;/ul&gt; | [optional] 
**verslynfa** | **String** | CG28_VERSLYNFA - Verslynfa | [optional] 
**idExtendedAttributeEntity** | **Number** |  | [optional] 
**idExtendedAttributeSubEntity** | **Number** |  | [optional] 
**nationCO** | [**NationCODTO**](NationCODTO.md) |  | [optional] 
**natureAssCO** | [**NatureAssCODTO**](NatureAssCODTO.md) |  | [optional] 
**natureEsCO** | [**NatureEsCODTO**](NatureEsCODTO.md) |  | [optional] 
**vatCodeCOAgr** | [**VatCodeCODTO**](VatCodeCODTO.md) |  | [optional] 
**vatCodeCOAIRif** | [**VatCodeCODTO**](VatCodeCODTO.md) |  | [optional] 
**vatCodeCOOss** | [**VatCodeCODTO**](VatCodeCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: CodPlafondEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)





## Enum: FlgAgriEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgAllcliforEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgAssport398Enum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgAutoueEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgCorrVentEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgEscludiblacklistEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgImpostadibolloEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgIndetEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgIvaeditEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgMossgestEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgMossridEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgNotvarEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgSospimpEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: IndStaperEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndtipopartEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: TipologiaEnum


* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)




