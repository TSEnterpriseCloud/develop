# TseCloudCo.COCSAccountingIndexCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codCat** | **String** | MGA3_CODCAT -  Codice | 
**descr** | **String** | MGA3_DESCR - Descrizione | [optional] 
**dittaCg18** | **Number** | MGA3_DITTA_CG18 - Ditta | 
**tipocfCg44** | **Number** | MGA3_TIPOCF_CG44 - Tipo cliente fornitore | 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


