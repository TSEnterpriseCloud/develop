# TseCloudCo.COSectionalMasterDataProposalInfoDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**causale** | **String** |  | [optional] 
**codSez** | **String** |  | [optional] 
**descSez** | **String** |  | [optional] 
**indTipologia** | **Number** |  | [optional] 
**protocolData** | [**COProtocolCalculationResultDTO**](COProtocolCalculationResultDTO.md) |  | [optional] 
**codAttivita** | **Number** |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


