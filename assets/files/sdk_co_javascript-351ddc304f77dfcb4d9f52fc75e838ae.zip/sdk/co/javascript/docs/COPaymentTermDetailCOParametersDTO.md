# TseCloudCo.COPaymentTermDetailCOParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idCg62** | **Number** |  | [optional] 
**isInStage** | **Boolean** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


