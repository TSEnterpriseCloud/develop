# TseCloudCo.JointlyHeldCOAlreadyExistsResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alreadyExists** | **Boolean** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


