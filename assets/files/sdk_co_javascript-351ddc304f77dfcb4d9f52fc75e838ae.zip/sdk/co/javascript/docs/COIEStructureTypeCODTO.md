# TseCloudCo.COIEStructureTypeCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**classExport** | **String** | IE21_CLSEXPORT - Classe export | [optional] 
**classImport** | **String** | IE21_CLSIMPORT - Classe import | [optional] 
**codStructureType** | **Number** | IE21_STRUTTURA - Struttura | 
**description** | **String** | IE21_DESCRIZIONE - Descrizione struttura | 
**excludeFlag** | **Number** | IE21_FLGESCLUDI - Escludi&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**sortingEnabledFlag** | **Number** | IE21_FLGRICORD - Ordinamento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**typeImpExp** | **Number** | IE21_INDIMPEXP - Modalità Import/Export&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Import/Export&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Import&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Export&lt;/li&gt;&lt;/ul&gt; | [optional] 
**typeProcedure** | **Number** | IE21_INDTIPOPROC - Tipo procedura | 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: ExcludeFlagEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: SortingEnabledFlagEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: TypeImpExpEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)




