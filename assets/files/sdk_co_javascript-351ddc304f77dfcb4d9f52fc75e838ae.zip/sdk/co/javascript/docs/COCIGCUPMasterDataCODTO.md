# TseCloudCo.COCIGCUPMasterDataCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cig** | **String** | CO1H_CIG - Cig | 
**cup** | **String** | CO1H_CUP - Cup | [optional] 
**descrizione** | **String** | CO1H_DESCRIZIONE - Descrizione | [optional] 
**docrifData** | **Date** | CO1H_DOCRIF_DATA - DocrifData | [optional] 
**docrifId** | **String** | CO1H_DOCRIF_ID - DocrifId | [optional] 
**flgAttivo** | **Number** | CO1H_FLGATTIVO - FlgAttivo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**id** | **Number** | CO1H_ID - ID (Required only in PUT/PATCH) | [optional] 
**indTipocontr** | **Number** | CO1H_INDTIPOCONTR - IndTipocontr&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Appalto&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Subappalto&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTipodocrif** | **Number** | CO1H_INDTIPODOCRIF - IndTipodocrif | 
**rowversion** | **Blob** | CO1H_ROWVERSION - Rowversion | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgAttivoEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndTipocontrEnum


* `0` (value: `0`)

* `1` (value: `1`)




