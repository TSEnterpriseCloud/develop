# TseCloudCo.COGetFirstAvailableNumNsProtLetterOfIntentResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numNsProt** | **Number** |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


