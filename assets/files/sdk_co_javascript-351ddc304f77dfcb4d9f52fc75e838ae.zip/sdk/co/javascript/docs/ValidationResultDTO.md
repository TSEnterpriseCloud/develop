# TseCloudCo.ValidationResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **String** | Validation message | [optional] 
**warningCode** | **Number** |  | [optional] 
**isWarning** | **Boolean** | It means the message is a warning | [optional] 
**isError** | **Boolean** | It means the message is an error | [optional] 
**dtoName** | **String** | the DTO name who the property belong | [optional] 
**dtoPropertyName** | **String** | The DTO invalid property name | [optional] 
**entityPropertyPath** | **String** |  | [optional] 


