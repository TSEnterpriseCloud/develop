# TseCloudCo.CONationCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**a2iso3166** | **String** | CG07_A2ISO3166 - Alpha-2 ISO 3166 | [optional] 
**a3iso3166** | **String** | CG07_A3ISO3166 - Alpha-3 ISO 3166 | [optional] 
**codice** | **Number** | CG07_CODICE - Codice | 
**codiceCg08** | **String** | CG07_CODICE_CG08 - Divisa | [optional] 
**codIso** | **String** | CG07_CODISO - Codice ISO | [optional] 
**codSian** | **Number** | CG07_CODSIAN - Codice SIAN | [optional] 
**crtpiva** | **String** | CG07_CRTPIVA - Caratteri lunghezza partita IVA (separati da /) | [optional] 
**datacee** | **Date** | CG07_DATACEE - Data ingresso CEE | [optional] 
**datafinblacklist** | **Date** | CG07_DATAFINBLACKLIST - Data uscita Black List | [optional] 
**datainiblacklist** | **Date** | CG07_DATAINIBLACKLIST - Data ingresso Black List | [optional] 
**descr** | **String** | CG07_DESCR - Descrizione | [optional] 
**desiso3166** | **String** | CG07_DESISO3166 - Descrizione Stato ISO 3166 | [optional] 
**flgIban** | **Number** | CG07_FLGIBAN - Utilizzo IBAN&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgSepa** | **Number** | CG07_FLGSEPA - Utilizzo standard SEPA&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**idmediaCg99** | **Number** | CG07_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**indTipostato** | **Number** | CG07_INDTIPOSTATO - Tipo Nazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Extracomunitario&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Intracomunitario&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Rep. San Marino&lt;/li&gt;&lt;/ul&gt; | [optional] 
**leniban** | **Number** | CG07_LENIBAN - Lunghezza IBAN | [optional] 
**numiso3166** | **String** | CG07_NUMISO3166 - Number ISO 3166 | [optional] 
**currencyCO** | [**COCurrencyCODTO**](COCurrencyCODTO.md) |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgIbanEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgSepaEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndTipostatoEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)




