# TseCloudCo.COAccountingReasonCodeClassificationCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descr** | **String** | CGD1_DESCR - Descr | [optional] 
**id** | **Number** | CGD1_ID - Id (Required only in PUT/PATCH) | [optional] 
**idmediaCg99** | **Number** | CGD1_IDMEDIA_CG99 - IdmediaCg99 | [optional] 
**tipologia** | **String** | CGD1_TIPOLOGIA - Tipologia | 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


