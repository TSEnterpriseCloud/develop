# TseCloudCo.COMacroAreaCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codiceMacroarea** | **String** | MG07_MACROAREA - Macroarea | 
**descrmacroar** | **String** | MG07_DESCRMACROAR - Descrizione | 
**dittaCg18** | **Number** | MG07_DITTA_CG18 - Ditta | 
**idprov** | **Number** | MG07_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**tipocf** | **Number** | MG07_TIPOCF - Tipo Cli/For&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**areas** | [**[COAreaCODTO]**](COAreaCODTO.md) |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: TipocfEnum


* `0` (value: `0`)

* `1` (value: `1`)




