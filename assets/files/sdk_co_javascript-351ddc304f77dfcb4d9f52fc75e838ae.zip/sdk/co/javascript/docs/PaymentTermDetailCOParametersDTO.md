# TseCloudCo.PaymentTermDetailCOParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idCg62** | **Number** |  | [optional] 
**isInStage** | **Boolean** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


