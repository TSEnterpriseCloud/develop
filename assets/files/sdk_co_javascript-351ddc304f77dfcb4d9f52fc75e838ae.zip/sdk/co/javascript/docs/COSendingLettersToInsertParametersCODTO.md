# TseCloudCo.COSendingLettersToInsertParametersCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sendingLettersToInsert** | [**[COSendingLettersToInsertRowCODTO]**](COSendingLettersToInsertRowCODTO.md) |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


