# TseCloudCo.SectionalMasterDataCOApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiV1EnvironmentCOSectionalMasterDataCOGet**](SectionalMasterDataCOApi.md#apiV1EnvironmentCOSectionalMasterDataCOGet) | **GET** /api/v1/{environment}/CO/SectionalMasterDataCO | Get new
[**apiV1EnvironmentCOSectionalMasterDataCOGetSectionalMasterDataProposalPost**](SectionalMasterDataCOApi.md#apiV1EnvironmentCOSectionalMasterDataCOGetSectionalMasterDataProposalPost) | **POST** /api/v1/{environment}/CO/SectionalMasterDataCO/Get_SectionalMasterDataProposal | Proposes the sectional
[**apiV1EnvironmentCOSectionalMasterDataCOIdDelete**](SectionalMasterDataCOApi.md#apiV1EnvironmentCOSectionalMasterDataCOIdDelete) | **DELETE** /api/v1/{environment}/CO/SectionalMasterDataCO/{id} | Delete
[**apiV1EnvironmentCOSectionalMasterDataCOIdGet**](SectionalMasterDataCOApi.md#apiV1EnvironmentCOSectionalMasterDataCOIdGet) | **GET** /api/v1/{environment}/CO/SectionalMasterDataCO/{id} | Get by ID
[**apiV1EnvironmentCOSectionalMasterDataCOIdPatch**](SectionalMasterDataCOApi.md#apiV1EnvironmentCOSectionalMasterDataCOIdPatch) | **PATCH** /api/v1/{environment}/CO/SectionalMasterDataCO/{id} | Update partial
[**apiV1EnvironmentCOSectionalMasterDataCOIdPut**](SectionalMasterDataCOApi.md#apiV1EnvironmentCOSectionalMasterDataCOIdPut) | **PUT** /api/v1/{environment}/CO/SectionalMasterDataCO/{id} | Update
[**apiV1EnvironmentCOSectionalMasterDataCOPost**](SectionalMasterDataCOApi.md#apiV1EnvironmentCOSectionalMasterDataCOPost) | **POST** /api/v1/{environment}/CO/SectionalMasterDataCO | Create
[**apiV1EnvironmentCOSectionalMasterDataCOReadPost**](SectionalMasterDataCOApi.md#apiV1EnvironmentCOSectionalMasterDataCOReadPost) | **POST** /api/v1/{environment}/CO/SectionalMasterDataCO/read | Read
[**apiV1EnvironmentCOSectionalMasterDataCOSearchPost**](SectionalMasterDataCOApi.md#apiV1EnvironmentCOSectionalMasterDataCOSearchPost) | **POST** /api/v1/{environment}/CO/SectionalMasterDataCO/search | Search
[**apiV1EnvironmentCOSectionalMasterDataCOValidatePost**](SectionalMasterDataCOApi.md#apiV1EnvironmentCOSectionalMasterDataCOValidatePost) | **POST** /api/v1/{environment}/CO/SectionalMasterDataCO/validate | Validate
[**apiV1EnvironmentCOSectionalMasterDataCOValidatePropertiesPost**](SectionalMasterDataCOApi.md#apiV1EnvironmentCOSectionalMasterDataCOValidatePropertiesPost) | **POST** /api/v1/{environment}/CO/SectionalMasterDataCO/validateProperties | Validation of one on more properties of Type



## apiV1EnvironmentCOSectionalMasterDataCOGet

> SectionalMasterDataCODTO apiV1EnvironmentCOSectionalMasterDataCOGet(op, environment, authorizationScope, opts)

Get new

Get an empty object of type corresponding

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.SectionalMasterDataCOApi();
let op = "op_example"; // String | The value must be 'new'
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOSectionalMasterDataCOGet(op, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **op** | **String**| The value must be &#39;new&#39; | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**SectionalMasterDataCODTO**](SectionalMasterDataCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOSectionalMasterDataCOGetSectionalMasterDataProposalPost

> SectionalMasterDataProposalResultDTO apiV1EnvironmentCOSectionalMasterDataCOGetSectionalMasterDataProposalPost(environment, authorizationScope, sectionalMasterDataProposalParametersDTO, opts)

Proposes the sectional

Proposes the sectional based on the parameters passed in the request. If requested, it also returns the relative protocol. If they exist, it also returns the data relating to the self-invoice.

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.SectionalMasterDataCOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let sectionalMasterDataProposalParametersDTO = new TseCloudCo.SectionalMasterDataProposalParametersDTO(); // SectionalMasterDataProposalParametersDTO | Object that contains all the parameters that are used in the calculation
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOSectionalMasterDataCOGetSectionalMasterDataProposalPost(environment, authorizationScope, sectionalMasterDataProposalParametersDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **sectionalMasterDataProposalParametersDTO** | [**SectionalMasterDataProposalParametersDTO**](SectionalMasterDataProposalParametersDTO.md)| Object that contains all the parameters that are used in the calculation | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**SectionalMasterDataProposalResultDTO**](SectionalMasterDataProposalResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOSectionalMasterDataCOIdDelete

> apiV1EnvironmentCOSectionalMasterDataCOIdDelete(id, environment, dittaCg18, authorizationScope, opts)

Delete

Deleting object of type 

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.SectionalMasterDataCOApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let dittaCg18 = "dittaCg18_example"; // String | DittaCg18 Mandatory to execute current action
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOSectionalMasterDataCOIdDelete(id, environment, dittaCg18, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **dittaCg18** | **String**| DittaCg18 Mandatory to execute current action | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOSectionalMasterDataCOIdGet

> SectionalMasterDataCODTO apiV1EnvironmentCOSectionalMasterDataCOIdGet(id, environment, dittaCg18, authorizationScope, opts)

Get by ID

Get an object of type corresponding the requested id

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.SectionalMasterDataCOApi();
let id = "id_example"; // String | Id to get the object
let environment = "environment_example"; // String | 
let dittaCg18 = "dittaCg18_example"; // String | DittaCg18 Mandatory to execute current action
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'dlevel': "dlevel_example", // String | Serialization level
  'dlevelkey': "dlevelkey_example", // String | Serialization level key
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOSectionalMasterDataCOIdGet(id, environment, dittaCg18, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Id to get the object | 
 **environment** | **String**|  | 
 **dittaCg18** | **String**| DittaCg18 Mandatory to execute current action | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **dlevel** | **String**| Serialization level | [optional] 
 **dlevelkey** | **String**| Serialization level key | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**SectionalMasterDataCODTO**](SectionalMasterDataCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOSectionalMasterDataCOIdPatch

> apiV1EnvironmentCOSectionalMasterDataCOIdPatch(id, environment, dittaCg18, authorizationScope, body, opts)

Update partial

Patching an object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.SectionalMasterDataCOApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let dittaCg18 = "dittaCg18_example"; // String | DittaCg18 Mandatory to execute current action
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let body = null; // Object | Object of type to patch
let opts = {
  'force': "force_example", // String | The warning/s code to bypass (separated by ‘,’) during the execution
  'op': "op_example", // String | Set 'reload', if you want the DTO updated in the response request
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOSectionalMasterDataCOIdPatch(id, environment, dittaCg18, authorizationScope, body, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **dittaCg18** | **String**| DittaCg18 Mandatory to execute current action | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **body** | **Object**| Object of type to patch | 
 **force** | **String**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **String**| Set &#39;reload&#39;, if you want the DTO updated in the response request | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOSectionalMasterDataCOIdPut

> SectionalMasterDataCODTO apiV1EnvironmentCOSectionalMasterDataCOIdPut(id, environment, dittaCg18, authorizationScope, sectionalMasterDataCODTO, opts)

Update

Updating an object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.SectionalMasterDataCOApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let dittaCg18 = "dittaCg18_example"; // String | DittaCg18 Mandatory to execute current action
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let sectionalMasterDataCODTO = new TseCloudCo.SectionalMasterDataCODTO(); // SectionalMasterDataCODTO | Object of type to update
let opts = {
  'force': "force_example", // String | The warning/s code to bypass (separated by ‘,’) during the execution
  'op': "op_example", // String | Set 'reload', if you want the DTO updated in the response request, otherwise will be returned null value
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOSectionalMasterDataCOIdPut(id, environment, dittaCg18, authorizationScope, sectionalMasterDataCODTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **dittaCg18** | **String**| DittaCg18 Mandatory to execute current action | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **sectionalMasterDataCODTO** | [**SectionalMasterDataCODTO**](SectionalMasterDataCODTO.md)| Object of type to update | 
 **force** | **String**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **String**| Set &#39;reload&#39;, if you want the DTO updated in the response request, otherwise will be returned null value | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**SectionalMasterDataCODTO**](SectionalMasterDataCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOSectionalMasterDataCOPost

> SectionalMasterDataCODTO apiV1EnvironmentCOSectionalMasterDataCOPost(environment, authorizationScope, sectionalMasterDataCODTO, opts)

Create

Creating new object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.SectionalMasterDataCOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let sectionalMasterDataCODTO = new TseCloudCo.SectionalMasterDataCODTO(); // SectionalMasterDataCODTO | Object of type to create
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOSectionalMasterDataCOPost(environment, authorizationScope, sectionalMasterDataCODTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **sectionalMasterDataCODTO** | [**SectionalMasterDataCODTO**](SectionalMasterDataCODTO.md)| Object of type to create | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**SectionalMasterDataCODTO**](SectionalMasterDataCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOSectionalMasterDataCOReadPost

> SectionalMasterDataCODTO apiV1EnvironmentCOSectionalMasterDataCOReadPost(environment, dittaCg18, authorizationScope, searchElementDTO, opts)

Read

Read among object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.SectionalMasterDataCOApi();
let environment = "environment_example"; // String | 
let dittaCg18 = "dittaCg18_example"; // String | DittaCg18 Mandatory to execute current action
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let searchElementDTO = [new TseCloudCo.SearchElementDTO()]; // [SearchElementDTO] | Search criteria to apply
let opts = {
  'dlevel': "dlevel_example", // String | Serialization level
  'dlevelkey': "dlevelkey_example", // String | Serialization level key
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOSectionalMasterDataCOReadPost(environment, dittaCg18, authorizationScope, searchElementDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **dittaCg18** | **String**| DittaCg18 Mandatory to execute current action | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **searchElementDTO** | [**[SearchElementDTO]**](SearchElementDTO.md)| Search criteria to apply | 
 **dlevel** | **String**| Serialization level | [optional] 
 **dlevelkey** | **String**| Serialization level key | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**SectionalMasterDataCODTO**](SectionalMasterDataCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOSectionalMasterDataCOSearchPost

> SectionalMasterDataCODTO apiV1EnvironmentCOSectionalMasterDataCOSearchPost(environment, authorizationScope, searchDTO, opts)

Search

Search among object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.SectionalMasterDataCOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let searchDTO = new TseCloudCo.SearchDTO(); // SearchDTO | Search criteria to apply
let opts = {
  'loadEntireDomain': "loadEntireDomain_example", // String | Specify 'loadEntireDomain=true' if you want all the aggregate
  'gettotalcount': "gettotalcount_example", // String | Specify 'gettotalcount=true' if you want the total number of elements
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOSectionalMasterDataCOSearchPost(environment, authorizationScope, searchDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **searchDTO** | [**SearchDTO**](SearchDTO.md)| Search criteria to apply | 
 **loadEntireDomain** | **String**| Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate | [optional] 
 **gettotalcount** | **String**| Specify &#39;gettotalcount&#x3D;true&#39; if you want the total number of elements | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**SectionalMasterDataCODTO**](SectionalMasterDataCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOSectionalMasterDataCOValidatePost

> apiV1EnvironmentCOSectionalMasterDataCOValidatePost(environment, authorizationScope, sectionalMasterDataCODTO, opts)

Validate

Validation of object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.SectionalMasterDataCOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let sectionalMasterDataCODTO = new TseCloudCo.SectionalMasterDataCODTO(); // SectionalMasterDataCODTO | Object of type to validate
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOSectionalMasterDataCOValidatePost(environment, authorizationScope, sectionalMasterDataCODTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **sectionalMasterDataCODTO** | [**SectionalMasterDataCODTO**](SectionalMasterDataCODTO.md)| Object of type to validate | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOSectionalMasterDataCOValidatePropertiesPost

> ValidateDTO apiV1EnvironmentCOSectionalMasterDataCOValidatePropertiesPost(environment, authorizationScope, opts)

Validation of one on more properties of Type

Validation of object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.SectionalMasterDataCOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'", // String | Example for multilanguage
  'body': null // String |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br>
};
apiInstance.apiV1EnvironmentCOSectionalMasterDataCOValidatePropertiesPost(environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]
 **body** | **String**|  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED&lt;br&gt; - The id of an existing object to validate properties, or &#39;&#39; if the object does not exist yet &lt;br&gt; | [optional] 

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json, application/xml

