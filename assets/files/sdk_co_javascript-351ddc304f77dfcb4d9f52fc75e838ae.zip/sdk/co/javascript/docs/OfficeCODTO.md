# TseCloudCo.OfficeCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cap** | **String** | CG31_CAP - Cap | [optional] 
**citta** | **String** | CG31_CITTA - Citta | [optional] 
**codice** | **Number** | CG31_CODICE - Sede | 
**dittaCg18** | **Number** | CG31_DITTA_CG18 - Ditta | 
**idmediaCg99** | **Number** | CG31_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**indDimcentrocomm** | **Number** | CG31_INDDIMCENTROCOMM - Dimensione centro commerciale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Non centro commerciale&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Grande&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Media&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Piccola&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indIrizzo** | **String** | CG31_INDIRIZZO - Indirizzo | [optional] 
**numerorea** | **String** | CG31_NUMEROREA - Numero REA | [optional] 
**progRea** | **Number** | CG31_PROGREA -  Progressivo REA | [optional] 
**prov** | **String** | CG31_PROV - Provincia | [optional] 
**rowversion** | **Blob** | CG31_ROWVERSION - RowVersion | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndDimcentrocommEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)




