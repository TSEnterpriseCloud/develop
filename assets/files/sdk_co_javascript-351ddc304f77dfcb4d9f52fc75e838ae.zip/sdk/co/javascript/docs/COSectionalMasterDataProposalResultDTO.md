# TseCloudCo.COSectionalMasterDataProposalResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**executionResult** | **Boolean** |  | [optional] 
**sectionalData** | [**COSectionalMasterDataProposalInfoDTO**](COSectionalMasterDataProposalInfoDTO.md) |  | [optional] 
**selfInvoiceSectionalData** | [**COSectionalMasterDataProposalInfoDTO**](COSectionalMasterDataProposalInfoDTO.md) |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


