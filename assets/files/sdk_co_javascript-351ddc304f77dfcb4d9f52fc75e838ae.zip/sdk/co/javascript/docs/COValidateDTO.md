# TseCloudCo.COValidateDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**[COValidationResultDTO]**](COValidationResultDTO.md) |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


