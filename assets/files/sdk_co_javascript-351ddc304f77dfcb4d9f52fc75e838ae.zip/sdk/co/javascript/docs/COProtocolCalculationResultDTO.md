# TseCloudCo.COProtocolCalculationResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**executionResult** | **Boolean** |  | [optional] 
**numdoc** | **Number** |  | [optional] 
**tipodocrif** | **Number** |  | [optional] 
**datadoc** | **Date** |  | [optional] 
**numDocOrigData** | [**CONumDocOrigProposalDTO**](CONumDocOrigProposalDTO.md) |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


