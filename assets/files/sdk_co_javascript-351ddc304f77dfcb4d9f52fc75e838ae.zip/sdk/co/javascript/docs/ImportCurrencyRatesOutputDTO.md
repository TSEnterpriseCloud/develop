# TseCloudCo.ImportCurrencyRatesOutputDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**operationResult** | **Boolean** |  | [optional] 
**errorMessages** | **[String]** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


