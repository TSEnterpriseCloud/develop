# TseCloudCo.COCSCompanyBankCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cliforCg44** | **Number** | MG2H_CLIFOR_CG44 - Codice Cliente / Fornitore | 
**dittaCg18** | **Number** | MG2H_DITTA_CG18 - Ditta | 
**flgPref** | **Number** | MG2H_FLGPREF - Banca preferenziale | 
**id** | **Number** | MG2H_ID - ID (Required only in PUT/PATCH) | [optional] 
**progR** | **Number** | MG2H_PROGR - PROGR | 
**progREf08** | **Number** | MG2H_PROGR_EF08 - Codice banca aziendale | 
**rowversion** | **Blob** | MG2H_ROWVERSION - Rowversion | [optional] 
**tipocfCg44** | **Number** | MG2H_TIPOCF_CG44 - Tipo cliente fornitore | 
**companyBankCO** | [**COCompanyBankCODTO**](COCompanyBankCODTO.md) |  | 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


