# TseCloudCo.CSWithEffectivePaymentConditionParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idCliFor** | **Number** |  | [optional] 
**valuta** | **String** |  | [optional] 
**impTotale** | **Number** |  | [optional] 
**impTotaleVal** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


