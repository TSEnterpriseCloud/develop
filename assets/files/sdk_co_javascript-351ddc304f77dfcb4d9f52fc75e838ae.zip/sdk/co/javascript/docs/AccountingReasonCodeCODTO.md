# TseCloudCo.AccountingReasonCodeCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**caualias** | **String** | CG33_CAUALIAS - Alias per ricerca causale contabile | 
**causalecoll** | **String** | CG33_CAUSALECOLL - Causale collegata | [optional] 
**causalecolltype** | **Number** | CG33_CAUSALECOLLTYPE - Causalecolltype&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Iva&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Contabile&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Scadenze&lt;/li&gt;&lt;/ul&gt; | [optional] 
**causaleiva** | **String** | CG33_CAUSALEIVA - Causale IVA | [optional] 
**codice** | **String** | CG33_CODICE - Codice causale | 
**descr** | **String** | CG33_DESCR - Descrizione | [optional] 
**flgAcconto** | **Number** | CG33_FLGACCONTO - Causale acconto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgAgviag** | **Number** | CG33_FLGAGVIAG - Agenzie viaggio&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgAutofatt** | **Number** | CG33_FLGAUTOFATT - Autofattura&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgCaufissa** | **Number** | CG33_FLGCAUFISSA - Causale fissa&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgComp** | **Number** | CG33_FLGCOMP - Competenza esercizio precedente&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgDatiassegno** | **Number** | CG33_FLGDATIASSEGNO - Richiesta riferimenti assegno&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgEconto** | **Number** | CG33_FLGECONTO - Gest. E/Conto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgFattdiff** | **Number** | CG33_FLGFATTDIFF - Rich. data comp. IVA | [optional] 
**flgGestsez** | **Number** | CG33_FLGGESTSEZ - Protocolla movimento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgInsoluti** | **Number** | CG33_FLGINSOLUTI - Insoluti&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgIvaedit** | **Number** | CG33_FLGIVAEDIT - IVA editoria&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgPortaf** | **Number** | CG33_FLGPORTAF - Gest. portafoglio&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgProtsemp** | **Number** | CG33_FLGPROTSEMP - Nr. docum. semplificata | [optional] 
**flgSubforni** | **Number** | CG33_FLGSUBFORNI - Subfornitura&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**idCg0z** | **Number** | CG33_ID_CG0Z - IdCg0z | [optional] 
**idCgd1** | **Number** | CG33_ID_CGD1 - Classificazione causale | [optional] 
**idmediaCg99** | **Number** | CG33_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**idprov** | **Number** | CG33_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**indCaubenius** | **Number** | CG33_INDCAUBENIUS - Regime del margine&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Analitico&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Globale&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Forfetario&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Normale&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indDaav** | **Number** | CG33_INDDAAV - Segno&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Dare&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Avere&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indGestec** | **Number** | CG33_INDGESTEC - Gest. E/Conto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Apertura&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Chiusura&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Apertura/chiusura&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indGestfattproforma** | **Number** | CG33_INDGESTFATTPROFORMA - Gestione fatture proforma | [optional] 
**indMonofasersm** | **Number** | CG33_INDMONOFASERSM - Operazioni monofase RSM | [optional] 
**indProteo360** | **Number** | CG33_INDPROTEO360 - Aggancio alla procedura Proteo 360 | [optional] 
**indScadfattproforma** | **Number** | CG33_INDSCADFATTPROFORMA - Scadenze in fatture proforma | [optional] 
**indTipomov** | **Number** | CG33_INDTIPOMOV - Tipo operazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - criterio Gestionale      &lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - criterio di Cassa        &lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Gestionale/Cassa         &lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Gestionale/Cassa sospeso &lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Gestionale/Cassa speciale&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Gestionale/Cassa esteso  &lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTipooper** | **Number** | CG33_INDTIPOOPER - IndTipooper | [optional] 
**indTiporeg** | **Number** | CG33_INDTIPOREG - Tipo registro&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Acquisti&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Vendite&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Corrispettivi&lt;/li&gt;&lt;/ul&gt; | [optional] 
**rowversion** | **Blob** | CG33_ROWVERSION - RowVersion | [optional] 
**tipoeff** | **Number** | CG33_TIPOEFF - Tipo effetti&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Tutti&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Contanti&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Ricevuta bancaria&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Tratta&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Tratta accettata&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Cessione&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Cambiale&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Carta di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Bancomat&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Contrassegno&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Lettera di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - RID&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Leasing&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Rimessa diretta&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Bonifico&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - C/C postale&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - MAV&lt;/li&gt;&lt;/ul&gt; | [optional] 
**classification** | [**AccountingReasonCodeClassificationCODTO**](AccountingReasonCodeClassificationCODTO.md) |  | [optional] 
**vatCodeReason** | [**AccountingReasonCodeCODTO**](AccountingReasonCodeCODTO.md) |  | [optional] 
**vatCodeReasonConnect** | [**AccountingReasonCodeCODTO**](AccountingReasonCodeCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: CausalecolltypeEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: FlgAccontoEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgAgviagEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgAutofattEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgCaufissaEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgCompEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgDatiassegnoEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgEcontoEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgGestsezEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgInsolutiEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgIvaeditEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgPortafEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgSubforniEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndCaubeniusEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)





## Enum: IndDaavEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndGestecEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: IndTipomovEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)





## Enum: IndTiporegEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: TipoeffEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)

* `10` (value: `10`)

* `11` (value: `11`)

* `12` (value: `12`)

* `13` (value: `13`)

* `14` (value: `14`)

* `15` (value: `15`)

* `16` (value: `16`)




