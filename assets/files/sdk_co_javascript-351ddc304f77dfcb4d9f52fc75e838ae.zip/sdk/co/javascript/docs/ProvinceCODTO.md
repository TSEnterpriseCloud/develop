# TseCloudCo.ProvinceCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**acronym** | **String** | CP02_SIGLA - Sigla provincia | 
**idProvince** | **Number** | CP02_ID - Cod. Provincia | 
**idRegion** | **Number** | CP02_IDREGIONE_CP01 - Cod. Regione | 
**istatCapitalCityCode** | **String** | CP02_CODISTATCAPOLUOGO - Codice ISTAT capoluogo | 
**istatCode** | **String** | CP02_CODISTAT - Codici Istat | 
**name** | **String** | CP02_DENOMINAZIONE -  Provincia  | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


