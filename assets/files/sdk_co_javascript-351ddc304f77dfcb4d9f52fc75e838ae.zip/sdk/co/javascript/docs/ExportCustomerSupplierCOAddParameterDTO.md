# TseCloudCo.ExportCustomerSupplierCOAddParameterDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**selectionValidityGeneralMasterData** | **String** | Selection on validity General master data&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - 0 (All General master data)&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - 1 (Current valid General master data)&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - 2 (General master data valid on the date)&lt;/li&gt;&lt;/ul&gt; | [optional] [default to &#39;0&#39;]
**referenceValidDate** | **Date** | Reference valid date for General master data | [optional] 



## Enum: SelectionValidityGeneralMasterDataEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)

* `2` (value: `"2"`)




