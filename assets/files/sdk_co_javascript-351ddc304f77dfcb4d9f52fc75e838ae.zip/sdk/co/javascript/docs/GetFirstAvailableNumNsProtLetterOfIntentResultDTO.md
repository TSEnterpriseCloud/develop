# TseCloudCo.GetFirstAvailableNumNsProtLetterOfIntentResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numNsProt** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


