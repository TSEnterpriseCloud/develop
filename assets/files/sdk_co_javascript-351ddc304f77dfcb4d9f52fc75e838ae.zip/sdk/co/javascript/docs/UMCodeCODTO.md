# TseCloudCo.UMCodeCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descr** | **String** | CG0B_DESCR - Descrizione | [optional] 
**umsigla** | **String** | CG0B_UMSIGLA - Sigla UM | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


