# TseCloudCo.PaymentTermCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codPag** | **String** | CG62_CODPAG - Codice | 
**descPag** | **String** | CG62_DESCPAG - Descrizione | [optional] 
**desPagAnal** | **String** | CG62_DESPAGANAL - Descrizione analitica | [optional] 
**flgDesc** | **Number** | CG62_FLGDESC - Descriz. automatica  | [optional] 
**flgDisgg** | **Number** | CG62_FLGDISGG - Non applicare giorni fissi cliente/fornitore - slittamento generale e cliente/fornitore | [optional] 
**flgPrefatt** | **Number** | CG62_FLGPREFATT - Preferenziale ciclo attivo | [optional] 
**flgPrefpass** | **Number** | CG62_FLGPREFPASS - Preferenziale ciclo passivo | [optional] 
**flgStornoiva** | **Number** | CG62_FLGSTORNOIVA - Storno IVA | [optional] 
**id** | **Number** | CG62_ID - ID (Required only in PUT/PATCH) | [optional] 
**rowversion** | **Blob** | CG62_ROWVERSION - RowVersion | [optional] 
**scart26** | **Number** | CG62_SCART26 - Sconto Art.26 importo | [optional] 
**scpercart26** | **Number** | CG62_SCPERCART26 - Sconto Art.26 % | [optional] 
**scpercas** | **Number** | CG62_SCPERCAS - Sc. cassa | [optional] 
**scpermer1** | **Number** | CG62_SCPERMER1 - Sc. merce 1 | [optional] 
**scpermer2** | **Number** | CG62_SCPERMER2 - Sc. merce 2 | [optional] 
**idExtendedAttributeEntity** | **Number** |  | [optional] 
**idExtendedAttributeSubEntity** | **Number** |  | [optional] 
**paymentTermDetailCO** | [**[PaymentTermDetailCODTO]**](PaymentTermDetailCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


