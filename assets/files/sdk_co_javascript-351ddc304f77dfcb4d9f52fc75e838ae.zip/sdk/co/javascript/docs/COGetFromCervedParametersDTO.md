# TseCloudCo.COGetFromCervedParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subjectId** | **String** | ID dell&#39;anagrafica Cerved da importare o mappare in un&#39;entità di GeneralMasterDataCODTO | [optional] 
**createNew** | **Boolean** | Se TRUE, viene effettuata la creazione dell&#39;anagrafica | [optional] 
**subjectType** | **String** | Type of the Cerved master data to import or map in an entity of GeneralMasterDataCODTO | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


