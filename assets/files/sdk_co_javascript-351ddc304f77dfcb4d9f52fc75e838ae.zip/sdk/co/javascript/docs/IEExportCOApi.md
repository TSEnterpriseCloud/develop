# TseCloudCo.IEExportCOApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiV1EnvironmentCOIEExportCOCustomersupplierPost**](IEExportCOApi.md#apiV1EnvironmentCOIEExportCOCustomersupplierPost) | **POST** /api/v1/{environment}/CO/IEExportCO/customersupplier | Export Customers/Suppliers based on the required parameters



## apiV1EnvironmentCOIEExportCOCustomersupplierPost

> ImportExportResultDTO apiV1EnvironmentCOIEExportCOCustomersupplierPost(environment, authorizationScope, exportCustomerSupplierCOParameterDTO, opts)

Export Customers/Suppliers based on the required parameters

Export Customers/Suppliers based on the required parameters

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.IEExportCOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let exportCustomerSupplierCOParameterDTO = new TseCloudCo.ExportCustomerSupplierCOParameterDTO(); // ExportCustomerSupplierCOParameterDTO | Export Customers/Suppliers parameters
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOIEExportCOCustomersupplierPost(environment, authorizationScope, exportCustomerSupplierCOParameterDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **exportCustomerSupplierCOParameterDTO** | [**ExportCustomerSupplierCOParameterDTO**](ExportCustomerSupplierCOParameterDTO.md)| Export Customers/Suppliers parameters | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**ImportExportResultDTO**](ImportExportResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml

