# TseCloudCo.GetNewCodScaglCSPaymentRangeResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codScagl** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


