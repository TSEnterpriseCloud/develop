# TseCloudCo.ContactTypeCOApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiV1EnvironmentCOContactTypeCOGet**](ContactTypeCOApi.md#apiV1EnvironmentCOContactTypeCOGet) | **GET** /api/v1/{environment}/CO/ContactTypeCO | Get new
[**apiV1EnvironmentCOContactTypeCOIdDelete**](ContactTypeCOApi.md#apiV1EnvironmentCOContactTypeCOIdDelete) | **DELETE** /api/v1/{environment}/CO/ContactTypeCO/{id} | Delete
[**apiV1EnvironmentCOContactTypeCOIdGet**](ContactTypeCOApi.md#apiV1EnvironmentCOContactTypeCOIdGet) | **GET** /api/v1/{environment}/CO/ContactTypeCO/{id} | Get by ID
[**apiV1EnvironmentCOContactTypeCOIdPatch**](ContactTypeCOApi.md#apiV1EnvironmentCOContactTypeCOIdPatch) | **PATCH** /api/v1/{environment}/CO/ContactTypeCO/{id} | Update partial
[**apiV1EnvironmentCOContactTypeCOIdPut**](ContactTypeCOApi.md#apiV1EnvironmentCOContactTypeCOIdPut) | **PUT** /api/v1/{environment}/CO/ContactTypeCO/{id} | Update
[**apiV1EnvironmentCOContactTypeCOPost**](ContactTypeCOApi.md#apiV1EnvironmentCOContactTypeCOPost) | **POST** /api/v1/{environment}/CO/ContactTypeCO | Create
[**apiV1EnvironmentCOContactTypeCOReadPost**](ContactTypeCOApi.md#apiV1EnvironmentCOContactTypeCOReadPost) | **POST** /api/v1/{environment}/CO/ContactTypeCO/read | Read
[**apiV1EnvironmentCOContactTypeCOSearchPost**](ContactTypeCOApi.md#apiV1EnvironmentCOContactTypeCOSearchPost) | **POST** /api/v1/{environment}/CO/ContactTypeCO/search | Search
[**apiV1EnvironmentCOContactTypeCOValidatePost**](ContactTypeCOApi.md#apiV1EnvironmentCOContactTypeCOValidatePost) | **POST** /api/v1/{environment}/CO/ContactTypeCO/validate | Validate
[**apiV1EnvironmentCOContactTypeCOValidatePropertiesPost**](ContactTypeCOApi.md#apiV1EnvironmentCOContactTypeCOValidatePropertiesPost) | **POST** /api/v1/{environment}/CO/ContactTypeCO/validateProperties | Validation of one on more properties of Type



## apiV1EnvironmentCOContactTypeCOGet

> ContactTypeCODTO apiV1EnvironmentCOContactTypeCOGet(op, environment, authorizationScope, opts)

Get new

Get an empty object of type corresponding

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.ContactTypeCOApi();
let op = "op_example"; // String | The value must be 'new'
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOContactTypeCOGet(op, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **op** | **String**| The value must be &#39;new&#39; | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**ContactTypeCODTO**](ContactTypeCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOContactTypeCOIdDelete

> apiV1EnvironmentCOContactTypeCOIdDelete(id, environment, authorizationScope, opts)

Delete

Deleting object of type 

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.ContactTypeCOApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOContactTypeCOIdDelete(id, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOContactTypeCOIdGet

> ContactTypeCODTO apiV1EnvironmentCOContactTypeCOIdGet(id, environment, authorizationScope, opts)

Get by ID

Get an object of type corresponding the requested id

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.ContactTypeCOApi();
let id = "id_example"; // String | Id to get the object
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'dlevel': "dlevel_example", // String | Serialization level
  'dlevelkey': "dlevelkey_example", // String | Serialization level key
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOContactTypeCOIdGet(id, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Id to get the object | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **dlevel** | **String**| Serialization level | [optional] 
 **dlevelkey** | **String**| Serialization level key | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**ContactTypeCODTO**](ContactTypeCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOContactTypeCOIdPatch

> apiV1EnvironmentCOContactTypeCOIdPatch(id, environment, authorizationScope, body, opts)

Update partial

Patching an object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.ContactTypeCOApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let body = null; // Object | Object of type to patch
let opts = {
  'force': "force_example", // String | The warning/s code to bypass (separated by ‘,’) during the execution
  'op': "op_example", // String | Set 'reload', if you want the DTO updated in the response request
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOContactTypeCOIdPatch(id, environment, authorizationScope, body, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **body** | **Object**| Object of type to patch | 
 **force** | **String**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **String**| Set &#39;reload&#39;, if you want the DTO updated in the response request | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOContactTypeCOIdPut

> ContactTypeCODTO apiV1EnvironmentCOContactTypeCOIdPut(id, environment, authorizationScope, contactTypeCODTO, opts)

Update

Updating an object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.ContactTypeCOApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let contactTypeCODTO = new TseCloudCo.ContactTypeCODTO(); // ContactTypeCODTO | Object of type to update
let opts = {
  'force': "force_example", // String | The warning/s code to bypass (separated by ‘,’) during the execution
  'op': "op_example", // String | Set 'reload', if you want the DTO updated in the response request, otherwise will be returned null value
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOContactTypeCOIdPut(id, environment, authorizationScope, contactTypeCODTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **contactTypeCODTO** | [**ContactTypeCODTO**](ContactTypeCODTO.md)| Object of type to update | 
 **force** | **String**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **String**| Set &#39;reload&#39;, if you want the DTO updated in the response request, otherwise will be returned null value | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**ContactTypeCODTO**](ContactTypeCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOContactTypeCOPost

> ContactTypeCODTO apiV1EnvironmentCOContactTypeCOPost(environment, authorizationScope, contactTypeCODTO, opts)

Create

Creating new object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.ContactTypeCOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let contactTypeCODTO = new TseCloudCo.ContactTypeCODTO(); // ContactTypeCODTO | Object of type to create
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOContactTypeCOPost(environment, authorizationScope, contactTypeCODTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **contactTypeCODTO** | [**ContactTypeCODTO**](ContactTypeCODTO.md)| Object of type to create | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**ContactTypeCODTO**](ContactTypeCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOContactTypeCOReadPost

> ContactTypeCODTO apiV1EnvironmentCOContactTypeCOReadPost(environment, authorizationScope, searchElementDTO, opts)

Read

Read among object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.ContactTypeCOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let searchElementDTO = [new TseCloudCo.SearchElementDTO()]; // [SearchElementDTO] | Search criteria to apply
let opts = {
  'dlevel': "dlevel_example", // String | Serialization level
  'dlevelkey': "dlevelkey_example", // String | Serialization level key
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOContactTypeCOReadPost(environment, authorizationScope, searchElementDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **searchElementDTO** | [**[SearchElementDTO]**](SearchElementDTO.md)| Search criteria to apply | 
 **dlevel** | **String**| Serialization level | [optional] 
 **dlevelkey** | **String**| Serialization level key | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**ContactTypeCODTO**](ContactTypeCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOContactTypeCOSearchPost

> ContactTypeCODTO apiV1EnvironmentCOContactTypeCOSearchPost(environment, authorizationScope, searchDTO, opts)

Search

Search among object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.ContactTypeCOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let searchDTO = new TseCloudCo.SearchDTO(); // SearchDTO | Search criteria to apply
let opts = {
  'loadEntireDomain': "loadEntireDomain_example", // String | Specify 'loadEntireDomain=true' if you want all the aggregate
  'gettotalcount': "gettotalcount_example", // String | Specify 'gettotalcount=true' if you want the total number of elements
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOContactTypeCOSearchPost(environment, authorizationScope, searchDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **searchDTO** | [**SearchDTO**](SearchDTO.md)| Search criteria to apply | 
 **loadEntireDomain** | **String**| Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate | [optional] 
 **gettotalcount** | **String**| Specify &#39;gettotalcount&#x3D;true&#39; if you want the total number of elements | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**ContactTypeCODTO**](ContactTypeCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOContactTypeCOValidatePost

> apiV1EnvironmentCOContactTypeCOValidatePost(environment, authorizationScope, contactTypeCODTO, opts)

Validate

Validation of object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.ContactTypeCOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let contactTypeCODTO = new TseCloudCo.ContactTypeCODTO(); // ContactTypeCODTO | Object of type to validate
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOContactTypeCOValidatePost(environment, authorizationScope, contactTypeCODTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **contactTypeCODTO** | [**ContactTypeCODTO**](ContactTypeCODTO.md)| Object of type to validate | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOContactTypeCOValidatePropertiesPost

> ValidateDTO apiV1EnvironmentCOContactTypeCOValidatePropertiesPost(environment, authorizationScope, opts)

Validation of one on more properties of Type

Validation of object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.ContactTypeCOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'", // String | Example for multilanguage
  'body': null // String |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br>
};
apiInstance.apiV1EnvironmentCOContactTypeCOValidatePropertiesPost(environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]
 **body** | **String**|  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED&lt;br&gt; - The id of an existing object to validate properties, or &#39;&#39; if the object does not exist yet &lt;br&gt; | [optional] 

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json, application/xml

