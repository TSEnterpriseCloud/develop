# TseCloudCo.ImportExportRowResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**typeResult** | **Number** | Type Result | [optional] 
**typeResultDescription** | **String** | Type Result Description | [optional] 
**description** | **String** | Description | [optional] 
**isDone** | **Boolean** | Is Done | [optional] 
**isImportance** | **Boolean** | Is Importance | [optional] 
**isError** | **Boolean** | Is Error | [optional] 
**isWarning** | **Boolean** | Is Warning | [optional] 
**isInformation** | **Boolean** | Is Information | [optional] 
**isCreate** | **Boolean** | Is Create | [optional] 
**isUpdate** | **Boolean** | Is Update | [optional] 
**isDelete** | **Boolean** | Is Delete | [optional] 


