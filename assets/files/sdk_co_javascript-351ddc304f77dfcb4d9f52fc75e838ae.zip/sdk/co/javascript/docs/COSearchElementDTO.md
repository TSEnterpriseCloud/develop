# TseCloudCo.COSearchElementDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**propertyName** | **String** | Property on witch apply the filter | 
**comparer** | [**COSearchComparer**](COSearchComparer.md) |  | 
**value** | **Object** |  | 
**operator** | [**COSearchLogicalOperators**](COSearchLogicalOperators.md) |  | [optional] 


