# TseCloudCo.SearchDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**SearchGroupDTO**](SearchGroupDTO.md) |  | [optional] 
**parameters** | **{String: Object}** | List of key value filters that will be applied to the query | [optional] 
**orderingProperties** | **{String: Object}** | \&quot;Order by\&quot; properties list | [optional] 
**pageSize** | **Number** | Page number to retun | [optional] 
**pageNumber** | **Number** | Number of elements per page to return | [optional] 
**selectList** | **String** |  | [optional] 
**visibleColumns** | **String** |  | [optional] 
**idRow** | **String** |  | [optional] 


