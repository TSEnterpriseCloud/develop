# TseCloudCo.NumDocOrigProposalDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**updEnabled** | **Boolean** |  | [optional] 
**numDocOrig** | **String** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


