# TseCloudCo.COVerificaMovimentazioneProgressiviResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codice** | **String** |  | [optional] 
**result** | **Boolean** |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


