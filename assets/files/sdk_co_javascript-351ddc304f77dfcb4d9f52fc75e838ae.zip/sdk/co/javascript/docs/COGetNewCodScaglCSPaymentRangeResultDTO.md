# TseCloudCo.COGetNewCodScaglCSPaymentRangeResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codScagl** | **Number** |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


