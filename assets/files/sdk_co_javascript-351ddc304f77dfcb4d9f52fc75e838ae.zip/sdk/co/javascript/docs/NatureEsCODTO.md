# TseCloudCo.NatureEsCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codice** | **String** | CG2M_CODICE - Codice | 
**datafineval** | **Date** | CG2M_DATAFINEVAL - Datafineval | [optional] 
**datainival** | **Date** | CG2M_DATAINIVAL - Datainival | [optional] 
**descr** | **String** | CG2M_DESCR - Descrizione | 
**id** | **Number** | CG2M_ID - Codice | 
**rowversion** | **Blob** | CG2M_ROWVERSION - Rowversion | [optional] 
**natureAssCO** | [**[NatureAssCODTO]**](NatureAssCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


