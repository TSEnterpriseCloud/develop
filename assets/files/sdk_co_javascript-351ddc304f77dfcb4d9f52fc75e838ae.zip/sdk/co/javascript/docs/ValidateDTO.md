# TseCloudCo.ValidateDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**[ValidationResultDTO]**](ValidationResultDTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


