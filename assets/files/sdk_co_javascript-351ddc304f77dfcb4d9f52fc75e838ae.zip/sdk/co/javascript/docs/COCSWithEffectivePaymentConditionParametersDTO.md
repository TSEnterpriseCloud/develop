# TseCloudCo.COCSWithEffectivePaymentConditionParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idCliFor** | **Number** |  | [optional] 
**valuta** | **String** |  | [optional] 
**impTotale** | **Number** |  | [optional] 
**impTotaleVal** | **Number** |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


