# TseCloudCo.UpdateParametersCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mg28IdsToUpdate** | **[Number]** |  | [optional] 
**idIntermediario** | **Number** |  | [optional] 
**tipoPlafond** | **Number** |  | [optional] 
**flgDichivapres** | **Number** |  | [optional] 
**flgEsport** | **Number** |  | [optional] 
**flgCessintra** | **Number** |  | [optional] 
**flgCessanmarino** | **Number** |  | [optional] 
**flgOperassim** | **Number** |  | [optional] 
**flgOperstraord** | **Number** |  | [optional] 
**impeData** | **Date** |  | [optional] 
**mgflId** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


