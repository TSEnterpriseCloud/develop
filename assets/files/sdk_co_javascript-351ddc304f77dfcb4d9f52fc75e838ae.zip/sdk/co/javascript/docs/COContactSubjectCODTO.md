# TseCloudCo.COContactSubjectCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**altro1** | **String** | CO02_ALTRO1 - Altro Indirizzo 1 | [optional] 
**altro2** | **String** | CO02_ALTRO2 - Altro Indirizzo 2 | [optional] 
**cap** | **String** | CO02_CAP - Cap | [optional] 
**cell1** | **String** | CO02_CELL1 - Cellulare 1 | [optional] 
**cell2** | **String** | CO02_CELL2 - Cellulare 2 | [optional] 
**citta** | **String** | CO02_CITTA - Città | [optional] 
**cognomenome** | **String** | CO02_COGNOMENOME - Cognome - Nome | [optional] 
**email1** | **String** | CO02_EMAIL1 - Email 1 | [optional] 
**email2** | **String** | CO02_EMAIL2 - Email 2 | [optional] 
**fax** | **String** | CO02_FAX - Fax | [optional] 
**guid** | **String** | CO02_GUID - GUID | [optional] 
**id** | **Number** | CO02_ID - ID (Required only in PUT/PATCH) | [optional] 
**idmediaCg99** | **Number** | CO02_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**indirizzo** | **String** | CO02_INDIRIZZO -  Indirizzo | [optional] 
**indPrefstdoc** | **Number** | CO02_INDPREFSTDOC - Stampa pref. doc.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Stampa&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Fax&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Mail&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - PEC&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Pdf&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Nessuna preferenza&lt;/li&gt;&lt;/ul&gt; | [optional] 
**lastchange** | **Date** | CO02_LASTCHANGE - Data ultima variazione | [optional] 
**note** | **String** | CO02_NOTE - Note | [optional] 
**orariolav** | **String** | CO02_ORARIOLAV - Orario di lavoro | [optional] 
**pec** | **String** | CO02_PEC - PEC | [optional] 
**prov** | **String** | CO02_PROV - Prov | [optional] 
**rowversion** | **Blob** | CO02_ROWVERSION - RowVersion | [optional] 
**telcasa** | **String** | CO02_TELCASA - Telefono casa | [optional] 
**teldir1** | **String** | CO02_TELDIR1 - Telefono diretto 1 numero | [optional] 
**teldir2** | **String** | CO02_TELDIR2 - Telefono diretto 2 numero | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndPrefstdocEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `4` (value: `4`)

* `5` (value: `5`)

* `3` (value: `3`)




