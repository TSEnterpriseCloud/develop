# TseCloudCo.ImportAnnualAverageRatesInputDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**baseCurrencyIsoCode** | **[String]** |  | [optional] 
**referenceYear** | **Number** |  | [optional] 
**overwrite** | **Boolean** |  | [optional] 


