# TseCloudCo.AgencyCOApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiV1EnvironmentCOAgencyCOGet**](AgencyCOApi.md#apiV1EnvironmentCOAgencyCOGet) | **GET** /api/v1/{environment}/CO/AgencyCO | Get new
[**apiV1EnvironmentCOAgencyCOIdDelete**](AgencyCOApi.md#apiV1EnvironmentCOAgencyCOIdDelete) | **DELETE** /api/v1/{environment}/CO/AgencyCO/{id} | Delete
[**apiV1EnvironmentCOAgencyCOIdGet**](AgencyCOApi.md#apiV1EnvironmentCOAgencyCOIdGet) | **GET** /api/v1/{environment}/CO/AgencyCO/{id} | Get by ID
[**apiV1EnvironmentCOAgencyCOIdPatch**](AgencyCOApi.md#apiV1EnvironmentCOAgencyCOIdPatch) | **PATCH** /api/v1/{environment}/CO/AgencyCO/{id} | Update partial
[**apiV1EnvironmentCOAgencyCOIdPut**](AgencyCOApi.md#apiV1EnvironmentCOAgencyCOIdPut) | **PUT** /api/v1/{environment}/CO/AgencyCO/{id} | Update
[**apiV1EnvironmentCOAgencyCOPost**](AgencyCOApi.md#apiV1EnvironmentCOAgencyCOPost) | **POST** /api/v1/{environment}/CO/AgencyCO | Create
[**apiV1EnvironmentCOAgencyCOReadPost**](AgencyCOApi.md#apiV1EnvironmentCOAgencyCOReadPost) | **POST** /api/v1/{environment}/CO/AgencyCO/read | Read
[**apiV1EnvironmentCOAgencyCOSearchPost**](AgencyCOApi.md#apiV1EnvironmentCOAgencyCOSearchPost) | **POST** /api/v1/{environment}/CO/AgencyCO/search | Search
[**apiV1EnvironmentCOAgencyCOValidatePost**](AgencyCOApi.md#apiV1EnvironmentCOAgencyCOValidatePost) | **POST** /api/v1/{environment}/CO/AgencyCO/validate | Validate
[**apiV1EnvironmentCOAgencyCOValidatePropertiesPost**](AgencyCOApi.md#apiV1EnvironmentCOAgencyCOValidatePropertiesPost) | **POST** /api/v1/{environment}/CO/AgencyCO/validateProperties | Validation of one on more properties of Type



## apiV1EnvironmentCOAgencyCOGet

> AgencyCODTO apiV1EnvironmentCOAgencyCOGet(op, environment, authorizationScope, opts)

Get new

Get an empty object of type corresponding

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.AgencyCOApi();
let op = "op_example"; // String | The value must be 'new'
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOAgencyCOGet(op, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **op** | **String**| The value must be &#39;new&#39; | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**AgencyCODTO**](AgencyCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOAgencyCOIdDelete

> apiV1EnvironmentCOAgencyCOIdDelete(id, environment, codBanca, authorizationScope, opts)

Delete

Deleting object of type 

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.AgencyCOApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let codBanca = "codBanca_example"; // String | CodBanca Mandatory to execute current action
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOAgencyCOIdDelete(id, environment, codBanca, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **codBanca** | **String**| CodBanca Mandatory to execute current action | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOAgencyCOIdGet

> AgencyCODTO apiV1EnvironmentCOAgencyCOIdGet(id, environment, codBanca, authorizationScope, opts)

Get by ID

Get an object of type corresponding the requested id

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.AgencyCOApi();
let id = "id_example"; // String | Id to get the object
let environment = "environment_example"; // String | 
let codBanca = "codBanca_example"; // String | CodBanca Mandatory to execute current action
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'dlevel': "dlevel_example", // String | Serialization level
  'dlevelkey': "dlevelkey_example", // String | Serialization level key
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOAgencyCOIdGet(id, environment, codBanca, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Id to get the object | 
 **environment** | **String**|  | 
 **codBanca** | **String**| CodBanca Mandatory to execute current action | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **dlevel** | **String**| Serialization level | [optional] 
 **dlevelkey** | **String**| Serialization level key | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**AgencyCODTO**](AgencyCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOAgencyCOIdPatch

> apiV1EnvironmentCOAgencyCOIdPatch(id, environment, codBanca, authorizationScope, body, opts)

Update partial

Patching an object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.AgencyCOApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let codBanca = "codBanca_example"; // String | CodBanca Mandatory to execute current action
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let body = null; // Object | Object of type to patch
let opts = {
  'force': "force_example", // String | The warning/s code to bypass (separated by ‘,’) during the execution
  'op': "op_example", // String | Set 'reload', if you want the DTO updated in the response request
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOAgencyCOIdPatch(id, environment, codBanca, authorizationScope, body, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **codBanca** | **String**| CodBanca Mandatory to execute current action | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **body** | **Object**| Object of type to patch | 
 **force** | **String**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **String**| Set &#39;reload&#39;, if you want the DTO updated in the response request | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOAgencyCOIdPut

> AgencyCODTO apiV1EnvironmentCOAgencyCOIdPut(id, environment, codBanca, authorizationScope, agencyCODTO, opts)

Update

Updating an object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.AgencyCOApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let codBanca = "codBanca_example"; // String | CodBanca Mandatory to execute current action
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let agencyCODTO = new TseCloudCo.AgencyCODTO(); // AgencyCODTO | Object of type to update
let opts = {
  'force': "force_example", // String | The warning/s code to bypass (separated by ‘,’) during the execution
  'op': "op_example", // String | Set 'reload', if you want the DTO updated in the response request, otherwise will be returned null value
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOAgencyCOIdPut(id, environment, codBanca, authorizationScope, agencyCODTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **codBanca** | **String**| CodBanca Mandatory to execute current action | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **agencyCODTO** | [**AgencyCODTO**](AgencyCODTO.md)| Object of type to update | 
 **force** | **String**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **String**| Set &#39;reload&#39;, if you want the DTO updated in the response request, otherwise will be returned null value | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**AgencyCODTO**](AgencyCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOAgencyCOPost

> AgencyCODTO apiV1EnvironmentCOAgencyCOPost(environment, authorizationScope, agencyCODTO, opts)

Create

Creating new object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.AgencyCOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let agencyCODTO = new TseCloudCo.AgencyCODTO(); // AgencyCODTO | Object of type to create
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOAgencyCOPost(environment, authorizationScope, agencyCODTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **agencyCODTO** | [**AgencyCODTO**](AgencyCODTO.md)| Object of type to create | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**AgencyCODTO**](AgencyCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOAgencyCOReadPost

> AgencyCODTO apiV1EnvironmentCOAgencyCOReadPost(environment, codBanca, authorizationScope, searchElementDTO, opts)

Read

Read among object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.AgencyCOApi();
let environment = "environment_example"; // String | 
let codBanca = "codBanca_example"; // String | CodBanca Mandatory to execute current action
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let searchElementDTO = [new TseCloudCo.SearchElementDTO()]; // [SearchElementDTO] | Search criteria to apply
let opts = {
  'dlevel': "dlevel_example", // String | Serialization level
  'dlevelkey': "dlevelkey_example", // String | Serialization level key
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOAgencyCOReadPost(environment, codBanca, authorizationScope, searchElementDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **codBanca** | **String**| CodBanca Mandatory to execute current action | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **searchElementDTO** | [**[SearchElementDTO]**](SearchElementDTO.md)| Search criteria to apply | 
 **dlevel** | **String**| Serialization level | [optional] 
 **dlevelkey** | **String**| Serialization level key | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**AgencyCODTO**](AgencyCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOAgencyCOSearchPost

> AgencyCODTO apiV1EnvironmentCOAgencyCOSearchPost(environment, authorizationScope, searchDTO, opts)

Search

Search among object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.AgencyCOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let searchDTO = new TseCloudCo.SearchDTO(); // SearchDTO | Search criteria to apply
let opts = {
  'loadEntireDomain': "loadEntireDomain_example", // String | Specify 'loadEntireDomain=true' if you want all the aggregate
  'gettotalcount': "gettotalcount_example", // String | Specify 'gettotalcount=true' if you want the total number of elements
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOAgencyCOSearchPost(environment, authorizationScope, searchDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **searchDTO** | [**SearchDTO**](SearchDTO.md)| Search criteria to apply | 
 **loadEntireDomain** | **String**| Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate | [optional] 
 **gettotalcount** | **String**| Specify &#39;gettotalcount&#x3D;true&#39; if you want the total number of elements | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**AgencyCODTO**](AgencyCODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOAgencyCOValidatePost

> apiV1EnvironmentCOAgencyCOValidatePost(environment, authorizationScope, agencyCODTO, opts)

Validate

Validation of object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.AgencyCOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let agencyCODTO = new TseCloudCo.AgencyCODTO(); // AgencyCODTO | Object of type to validate
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOAgencyCOValidatePost(environment, authorizationScope, agencyCODTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **agencyCODTO** | [**AgencyCODTO**](AgencyCODTO.md)| Object of type to validate | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOAgencyCOValidatePropertiesPost

> ValidateDTO apiV1EnvironmentCOAgencyCOValidatePropertiesPost(environment, authorizationScope, opts)

Validation of one on more properties of Type

Validation of object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.AgencyCOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'", // String | Example for multilanguage
  'body': null // String |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br>
};
apiInstance.apiV1EnvironmentCOAgencyCOValidatePropertiesPost(environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]
 **body** | **String**|  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED&lt;br&gt; - The id of an existing object to validate properties, or &#39;&#39; if the object does not exist yet &lt;br&gt; | [optional] 

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json, application/xml

