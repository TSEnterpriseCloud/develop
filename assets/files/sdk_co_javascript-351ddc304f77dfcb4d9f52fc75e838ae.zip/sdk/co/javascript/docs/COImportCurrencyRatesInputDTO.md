# TseCloudCo.COImportCurrencyRatesInputDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**referenceDate** | **Date** |  | [optional] 
**numberOfPreviousDays** | **Number** |  | [optional] 
**overwrite** | **Boolean** |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


