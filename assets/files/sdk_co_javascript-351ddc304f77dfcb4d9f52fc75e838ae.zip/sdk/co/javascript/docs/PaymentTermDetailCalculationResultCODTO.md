# TseCloudCo.PaymentTermDetailCalculationResultCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sumImp** | **Number** |  | [optional] 
**sumIva** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


