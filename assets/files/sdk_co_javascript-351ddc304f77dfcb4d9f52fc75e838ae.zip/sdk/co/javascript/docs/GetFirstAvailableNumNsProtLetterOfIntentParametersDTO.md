# TseCloudCo.GetFirstAvailableNumNsProtLetterOfIntentParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tipoCS** | **Number** |  | [optional] 
**anno** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


