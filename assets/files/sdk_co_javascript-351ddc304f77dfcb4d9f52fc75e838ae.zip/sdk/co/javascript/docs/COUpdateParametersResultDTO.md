# TseCloudCo.COUpdateParametersResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**opResult** | **Boolean** |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


