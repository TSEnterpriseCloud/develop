# TseCloudCo.COImportExportResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**guidSession** | **String** | Guid Process | [optional] 
**stateProcess** | **String** | State Process | [optional] 
**idStateProcess** | **Number** | Id State Process | [optional] 
**headProcess** | [**COImportExportHeadResultDTO**](COImportExportHeadResultDTO.md) |  | [optional] 


