# TseCloudCo.ProtocolCalculationResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**executionResult** | **Boolean** |  | [optional] 
**numdoc** | **Number** |  | [optional] 
**tipodocrif** | **Number** |  | [optional] 
**datadoc** | **Date** |  | [optional] 
**numDocOrigData** | [**NumDocOrigProposalDTO**](NumDocOrigProposalDTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


