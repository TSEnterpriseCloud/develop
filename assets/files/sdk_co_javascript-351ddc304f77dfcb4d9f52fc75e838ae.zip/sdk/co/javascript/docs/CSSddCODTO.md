# TseCloudCo.CSSddCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bancaallineam** | **Number** | MG29_BANCAALLINEAM - Codice ABI Banca Allineamento | [optional] 
**causrich** | **Number** | MG29_CAUSRICH - Causale richiesta Azienda | [optional] 
**causrisp** | **Number** | MG29_CAUSRISP - Causale Banca Allineamento | [optional] 
**cfiscsottoscr** | **String** | MG29_CFISCSOTTOSCR - Codice fiscale sottoscrittore | [optional] 
**cliforCg44** | **Number** | MG29_CLIFOR_CG44 - Codice Cliente / Fornitore | 
**codAutoriz** | **String** | MG29_CODAUTORIZ - Codice autorizzazione (Acquisizione PagoBancomat) | [optional] 
**codBicswift** | **String** | MG29_CODBICSWIFT - Codice BIC SWIFT | [optional] 
**codClideb** | **String** | MG29_CODCLIDEB - Codice debitore | [optional] 
**codClidebprec** | **String** | MG29_CODCLIDEBPREC - Codice debitore precedente | [optional] 
**codIndiv** | **Number** | MG29_CODINDIV - Codice individuale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Utenza&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Matricola&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Codice fiscale&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Codice cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Codice fornitore&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Portafoglio commerciale&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Altro&lt;/li&gt;&lt;/ul&gt; | [optional] 
**codIndivprec** | **Number** | MG29_CODINDIVPREC - Codice individuale precedente | [optional] 
**codRif** | **String** | MG29_CODRIF - Codice riferimento | [optional] 
**contocorr** | **String** | MG29_CONTOCORR - Conto corrente | [optional] 
**contocorrprec** | **String** | MG29_CONTOCORRPREC - Conto corrente precedente | [optional] 
**datamandato** | **Date** | MG29_DATAMANDATO - Data mandato RID | [optional] 
**dataprimascad** | **Date** | MG29_DATAPRIMASCAD - Data prima scadenza | [optional] 
**datarich** | **Date** | MG29_DATARICH - Data richiesta | [optional] 
**datarisp** | **Date** | MG29_DATARISP - Data causale Banca Allineamento | [optional] 
**dataultimascad** | **Date** | MG29_DATAULTIMASCAD - Data ultima scadenza | [optional] 
**descrizione** | **String** | MG29_DESCRIZIONE - Descrizione | [optional] 
**diniego** | **Number** | MG29_DINIEGO - Diniego | [optional] 
**dittaCg18** | **Number** | MG29_DITTA_CG18 - Ditta | 
**flgAllineam** | **Number** | MG29_FLGALLINEAM - FlgAllineam | [optional] 
**flgDisattivato** | **Number** | MG29_FLGDISATTIVATO - Dati disattivati | [optional] 
**flgVariato** | **Number** | MG29_FLGVARIATO - Variato | 
**id** | **Number** | MG29_ID - ID (Required only in PUT/PATCH) | [optional] 
**idmediaCg99** | **Number** | MG29_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**impmaxrata** | **Number** | MG29_IMPMAXRATA - Importo massimo/prefissato | [optional] 
**indIrsottoscr** | **String** | MG29_INDIRSOTTOSCR - Indirizzo sottoscrittore | [optional] 
**indStorno** | **Number** | MG29_INDSTORNO - Facoltà di storno&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Facoltà di storno dopo la scadenza (D+5)&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Facoltà di storno alla scadenza&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Nessuna facoltà di storno per contestazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Nessuna facoltà di storno per la banca domiciliataria&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Esiste diritto al rimborso (D+8 settimane)&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Nessuna facoltà di storno per le caratteristiche del mandato&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indStornoprec** | **Number** | MG29_INDSTORNOPREC - Facoltà di storno precedente | [optional] 
**indTipoinc** | **Number** | MG29_INDTIPOINC - Sequenza&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - First&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Recurrent&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Final&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - One-Off&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTiposdd** | **Number** | MG29_INDTIPOSDD - Tipo SDD&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Core&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - B2B&lt;/li&gt;&lt;/ul&gt; | [optional] 
**locsottoscr** | **String** | MG29_LOCSOTTOSCR - Località sottoscrittore | [optional] 
**nrrate** | **Number** | MG29_NRRATE - Numero rate | [optional] 
**nuovabanca** | **Number** | MG29_NUOVABANCA - Nuovabanca | [optional] 
**progR** | **Number** | MG29_PROGR - Progr. | 
**ragsosottoscr** | **String** | MG29_RAGSOSOTTOSCR - Ragione sociale sottoscrittore | [optional] 
**ridabi** | **Number** | MG29_RIDABI - Codice ABI | [optional] 
**ridabiprec** | **Number** | MG29_RIDABIPREC - Codice ABI precedente | [optional] 
**ridcab** | **Number** | MG29_RIDCAB - Codice CAB | [optional] 
**ridcabprec** | **Number** | MG29_RIDCABPREC - Codice CAB precedente | [optional] 
**ridiban** | **String** | MG29_RIDIBAN - IBAN | [optional] 
**ridibanprec** | **String** | MG29_RIDIBANPREC - IBAN (International Bank Account Number) | [optional] 
**soggtitibanCg16** | **Number** | MG29_SOGGTITIBAN_CG16 - Soggetto titolare IBAN | [optional] 
**tipocfCg44** | **Number** | MG29_TIPOCF_CG44 - Tipo Cliente / Fornitore | 
**tipoinclocked** | **Number** | MG29_TIPOINCLOCKED - Tipo seq. incasso bloccato | [optional] 
**tipologia** | **Number** | MG29_TIPOLOGIA - Tipologia&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Consumatore&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Non Consumatore&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Microimpresa&lt;/li&gt;&lt;/ul&gt; | [optional] 
**tipologiaprec** | **Number** | MG29_TIPOLOGIAPREC - Tipologiaprec | [optional] 
**csHistorySddCO** | [**[CSHistorySddCODTO]**](CSHistorySddCODTO.md) |  | [optional] 
**nationCO** | [**NationCODTO**](NationCODTO.md) |  | [optional] 
**soggtitiban** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: CodIndivEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `9` (value: `9`)





## Enum: IndStornoEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `8` (value: `8`)

* `9` (value: `9`)





## Enum: IndTipoincEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: IndTiposddEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: TipologiaEnum


* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)




