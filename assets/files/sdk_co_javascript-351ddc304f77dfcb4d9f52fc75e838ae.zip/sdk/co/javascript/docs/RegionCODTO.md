# TseCloudCo.RegionCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idRegion** | **Number** | CP01_ID - Cod. Regione | 
**istatCapitalCityCode** | **String** | CP01_CODISTATCAPOLUOGO - Codice ISTAT capoluogo | 
**istatCode** | **String** | CP01_CODISTAT - Codice ISTAT | 
**name** | **String** | CP01_DENOMINAZIONE - Regione | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


