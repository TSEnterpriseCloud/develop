# TseCloudCo.SectionalMasterDataProposalInfoDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**causale** | **String** |  | [optional] 
**codSez** | **String** |  | [optional] 
**descSez** | **String** |  | [optional] 
**indTipologia** | **Number** |  | [optional] 
**protocolData** | [**ProtocolCalculationResultDTO**](ProtocolCalculationResultDTO.md) |  | [optional] 
**codAttivita** | **Number** |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


