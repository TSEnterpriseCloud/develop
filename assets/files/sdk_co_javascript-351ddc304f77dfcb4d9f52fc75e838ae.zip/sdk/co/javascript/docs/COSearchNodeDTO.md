# TseCloudCo.COSearchNodeDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**operator** | [**COSearchLogicalOperators**](COSearchLogicalOperators.md) |  | [optional] 


