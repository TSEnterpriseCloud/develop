# TseCloudCo.OfficePACOApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiV1EnvironmentCOOfficePACOGet**](OfficePACOApi.md#apiV1EnvironmentCOOfficePACOGet) | **GET** /api/v1/{environment}/CO/OfficePACO | Get new
[**apiV1EnvironmentCOOfficePACOIdDelete**](OfficePACOApi.md#apiV1EnvironmentCOOfficePACOIdDelete) | **DELETE** /api/v1/{environment}/CO/OfficePACO/{id} | Delete
[**apiV1EnvironmentCOOfficePACOIdGet**](OfficePACOApi.md#apiV1EnvironmentCOOfficePACOIdGet) | **GET** /api/v1/{environment}/CO/OfficePACO/{id} | Get by ID
[**apiV1EnvironmentCOOfficePACOIdPatch**](OfficePACOApi.md#apiV1EnvironmentCOOfficePACOIdPatch) | **PATCH** /api/v1/{environment}/CO/OfficePACO/{id} | Update partial
[**apiV1EnvironmentCOOfficePACOIdPut**](OfficePACOApi.md#apiV1EnvironmentCOOfficePACOIdPut) | **PUT** /api/v1/{environment}/CO/OfficePACO/{id} | Update
[**apiV1EnvironmentCOOfficePACOPost**](OfficePACOApi.md#apiV1EnvironmentCOOfficePACOPost) | **POST** /api/v1/{environment}/CO/OfficePACO | Create
[**apiV1EnvironmentCOOfficePACOReadPost**](OfficePACOApi.md#apiV1EnvironmentCOOfficePACOReadPost) | **POST** /api/v1/{environment}/CO/OfficePACO/read | Read
[**apiV1EnvironmentCOOfficePACOSearchPost**](OfficePACOApi.md#apiV1EnvironmentCOOfficePACOSearchPost) | **POST** /api/v1/{environment}/CO/OfficePACO/search | Search
[**apiV1EnvironmentCOOfficePACOValidatePost**](OfficePACOApi.md#apiV1EnvironmentCOOfficePACOValidatePost) | **POST** /api/v1/{environment}/CO/OfficePACO/validate | Validate
[**apiV1EnvironmentCOOfficePACOValidatePropertiesPost**](OfficePACOApi.md#apiV1EnvironmentCOOfficePACOValidatePropertiesPost) | **POST** /api/v1/{environment}/CO/OfficePACO/validateProperties | Validation of one on more properties of Type



## apiV1EnvironmentCOOfficePACOGet

> OfficePACODTO apiV1EnvironmentCOOfficePACOGet(op, environment, authorizationScope, opts)

Get new

Get an empty object of type corresponding

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.OfficePACOApi();
let op = "op_example"; // String | The value must be 'new'
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOOfficePACOGet(op, environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **op** | **String**| The value must be &#39;new&#39; | 
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**OfficePACODTO**](OfficePACODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOOfficePACOIdDelete

> apiV1EnvironmentCOOfficePACOIdDelete(id, environment, tipocfCg44, codiceCg16, codDestin, authorizationScope, opts)

Delete

Deleting object of type 

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.OfficePACOApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let tipocfCg44 = "tipocfCg44_example"; // String | TipocfCg44 Mandatory to execute current action
let codiceCg16 = "codiceCg16_example"; // String | CodiceCg16 Mandatory to execute current action
let codDestin = "codDestin_example"; // String | CodDestin Mandatory to execute current action
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOOfficePACOIdDelete(id, environment, tipocfCg44, codiceCg16, codDestin, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **tipocfCg44** | **String**| TipocfCg44 Mandatory to execute current action | 
 **codiceCg16** | **String**| CodiceCg16 Mandatory to execute current action | 
 **codDestin** | **String**| CodDestin Mandatory to execute current action | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOOfficePACOIdGet

> OfficePACODTO apiV1EnvironmentCOOfficePACOIdGet(id, environment, tipocfCg44, codiceCg16, codDestin, authorizationScope, opts)

Get by ID

Get an object of type corresponding the requested id

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.OfficePACOApi();
let id = "id_example"; // String | Id to get the object
let environment = "environment_example"; // String | 
let tipocfCg44 = "tipocfCg44_example"; // String | TipocfCg44 Mandatory to execute current action
let codiceCg16 = "codiceCg16_example"; // String | CodiceCg16 Mandatory to execute current action
let codDestin = "codDestin_example"; // String | CodDestin Mandatory to execute current action
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'dlevel': "dlevel_example", // String | Serialization level
  'dlevelkey': "dlevelkey_example", // String | Serialization level key
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOOfficePACOIdGet(id, environment, tipocfCg44, codiceCg16, codDestin, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Id to get the object | 
 **environment** | **String**|  | 
 **tipocfCg44** | **String**| TipocfCg44 Mandatory to execute current action | 
 **codiceCg16** | **String**| CodiceCg16 Mandatory to execute current action | 
 **codDestin** | **String**| CodDestin Mandatory to execute current action | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **dlevel** | **String**| Serialization level | [optional] 
 **dlevelkey** | **String**| Serialization level key | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**OfficePACODTO**](OfficePACODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOOfficePACOIdPatch

> apiV1EnvironmentCOOfficePACOIdPatch(id, environment, tipocfCg44, codiceCg16, codDestin, authorizationScope, body, opts)

Update partial

Patching an object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.OfficePACOApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let tipocfCg44 = "tipocfCg44_example"; // String | TipocfCg44 Mandatory to execute current action
let codiceCg16 = "codiceCg16_example"; // String | CodiceCg16 Mandatory to execute current action
let codDestin = "codDestin_example"; // String | CodDestin Mandatory to execute current action
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let body = null; // Object | Object of type to patch
let opts = {
  'force': "force_example", // String | The warning/s code to bypass (separated by ‘,’) during the execution
  'op': "op_example", // String | Set 'reload', if you want the DTO updated in the response request
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOOfficePACOIdPatch(id, environment, tipocfCg44, codiceCg16, codDestin, authorizationScope, body, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **tipocfCg44** | **String**| TipocfCg44 Mandatory to execute current action | 
 **codiceCg16** | **String**| CodiceCg16 Mandatory to execute current action | 
 **codDestin** | **String**| CodDestin Mandatory to execute current action | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **body** | **Object**| Object of type to patch | 
 **force** | **String**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **String**| Set &#39;reload&#39;, if you want the DTO updated in the response request | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOOfficePACOIdPut

> OfficePACODTO apiV1EnvironmentCOOfficePACOIdPut(id, environment, tipocfCg44, codiceCg16, codDestin, authorizationScope, officePACODTO, opts)

Update

Updating an object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.OfficePACOApi();
let id = "id_example"; // String | 
let environment = "environment_example"; // String | 
let tipocfCg44 = "tipocfCg44_example"; // String | TipocfCg44 Mandatory to execute current action
let codiceCg16 = "codiceCg16_example"; // String | CodiceCg16 Mandatory to execute current action
let codDestin = "codDestin_example"; // String | CodDestin Mandatory to execute current action
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let officePACODTO = new TseCloudCo.OfficePACODTO(); // OfficePACODTO | Object of type to update
let opts = {
  'force': "force_example", // String | The warning/s code to bypass (separated by ‘,’) during the execution
  'op': "op_example", // String | Set 'reload', if you want the DTO updated in the response request, otherwise will be returned null value
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOOfficePACOIdPut(id, environment, tipocfCg44, codiceCg16, codDestin, authorizationScope, officePACODTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **environment** | **String**|  | 
 **tipocfCg44** | **String**| TipocfCg44 Mandatory to execute current action | 
 **codiceCg16** | **String**| CodiceCg16 Mandatory to execute current action | 
 **codDestin** | **String**| CodDestin Mandatory to execute current action | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **officePACODTO** | [**OfficePACODTO**](OfficePACODTO.md)| Object of type to update | 
 **force** | **String**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **String**| Set &#39;reload&#39;, if you want the DTO updated in the response request, otherwise will be returned null value | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**OfficePACODTO**](OfficePACODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOOfficePACOPost

> OfficePACODTO apiV1EnvironmentCOOfficePACOPost(environment, authorizationScope, officePACODTO, opts)

Create

Creating new object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.OfficePACOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let officePACODTO = new TseCloudCo.OfficePACODTO(); // OfficePACODTO | Object of type to create
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOOfficePACOPost(environment, authorizationScope, officePACODTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **officePACODTO** | [**OfficePACODTO**](OfficePACODTO.md)| Object of type to create | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**OfficePACODTO**](OfficePACODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOOfficePACOReadPost

> OfficePACODTO apiV1EnvironmentCOOfficePACOReadPost(environment, tipocfCg44, codiceCg16, codDestin, authorizationScope, searchElementDTO, opts)

Read

Read among object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.OfficePACOApi();
let environment = "environment_example"; // String | 
let tipocfCg44 = "tipocfCg44_example"; // String | TipocfCg44 Mandatory to execute current action
let codiceCg16 = "codiceCg16_example"; // String | CodiceCg16 Mandatory to execute current action
let codDestin = "codDestin_example"; // String | CodDestin Mandatory to execute current action
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let searchElementDTO = [new TseCloudCo.SearchElementDTO()]; // [SearchElementDTO] | Search criteria to apply
let opts = {
  'dlevel': "dlevel_example", // String | Serialization level
  'dlevelkey': "dlevelkey_example", // String | Serialization level key
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOOfficePACOReadPost(environment, tipocfCg44, codiceCg16, codDestin, authorizationScope, searchElementDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **tipocfCg44** | **String**| TipocfCg44 Mandatory to execute current action | 
 **codiceCg16** | **String**| CodiceCg16 Mandatory to execute current action | 
 **codDestin** | **String**| CodDestin Mandatory to execute current action | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **searchElementDTO** | [**[SearchElementDTO]**](SearchElementDTO.md)| Search criteria to apply | 
 **dlevel** | **String**| Serialization level | [optional] 
 **dlevelkey** | **String**| Serialization level key | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**OfficePACODTO**](OfficePACODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOOfficePACOSearchPost

> OfficePACODTO apiV1EnvironmentCOOfficePACOSearchPost(environment, authorizationScope, searchDTO, opts)

Search

Search among object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.OfficePACOApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let searchDTO = new TseCloudCo.SearchDTO(); // SearchDTO | Search criteria to apply
let opts = {
  'loadEntireDomain': "loadEntireDomain_example", // String | Specify 'loadEntireDomain=true' if you want all the aggregate
  'gettotalcount': "gettotalcount_example", // String | Specify 'gettotalcount=true' if you want the total number of elements
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOOfficePACOSearchPost(environment, authorizationScope, searchDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **searchDTO** | [**SearchDTO**](SearchDTO.md)| Search criteria to apply | 
 **loadEntireDomain** | **String**| Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate | [optional] 
 **gettotalcount** | **String**| Specify &#39;gettotalcount&#x3D;true&#39; if you want the total number of elements | [optional] 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

[**OfficePACODTO**](OfficePACODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOOfficePACOValidatePost

> apiV1EnvironmentCOOfficePACOValidatePost(environment, tipocfCg44, codiceCg16, codDestin, authorizationScope, officePACODTO, opts)

Validate

Validation of object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.OfficePACOApi();
let environment = "environment_example"; // String | 
let tipocfCg44 = "tipocfCg44_example"; // String | TipocfCg44 Mandatory to execute current action
let codiceCg16 = "codiceCg16_example"; // String | CodiceCg16 Mandatory to execute current action
let codDestin = "codDestin_example"; // String | CodDestin Mandatory to execute current action
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let officePACODTO = new TseCloudCo.OfficePACODTO(); // OfficePACODTO | Object of type to validate
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentCOOfficePACOValidatePost(environment, tipocfCg44, codiceCg16, codDestin, authorizationScope, officePACODTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **tipocfCg44** | **String**| TipocfCg44 Mandatory to execute current action | 
 **codiceCg16** | **String**| CodiceCg16 Mandatory to execute current action | 
 **codDestin** | **String**| CodDestin Mandatory to execute current action | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **officePACODTO** | [**OfficePACODTO**](OfficePACODTO.md)| Object of type to validate | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentCOOfficePACOValidatePropertiesPost

> ValidateDTO apiV1EnvironmentCOOfficePACOValidatePropertiesPost(environment, tipocfCg44, codiceCg16, codDestin, authorizationScope, opts)

Validation of one on more properties of Type

Validation of object of type

### Example

```javascript
import TseCloudCo from 'tse_cloud_co';
let defaultClient = TseCloudCo.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudCo.OfficePACOApi();
let environment = "environment_example"; // String | 
let tipocfCg44 = "tipocfCg44_example"; // String | TipocfCg44 Mandatory to execute current action
let codiceCg16 = "codiceCg16_example"; // String | CodiceCg16 Mandatory to execute current action
let codDestin = "codDestin_example"; // String | CodDestin Mandatory to execute current action
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'", // String | Example for multilanguage
  'body': null // String |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br>
};
apiInstance.apiV1EnvironmentCOOfficePACOValidatePropertiesPost(environment, tipocfCg44, codiceCg16, codDestin, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **tipocfCg44** | **String**| TipocfCg44 Mandatory to execute current action | 
 **codiceCg16** | **String**| CodiceCg16 Mandatory to execute current action | 
 **codDestin** | **String**| CodDestin Mandatory to execute current action | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]
 **body** | **String**|  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED&lt;br&gt; - The id of an existing object to validate properties, or &#39;&#39; if the object does not exist yet &lt;br&gt; | [optional] 

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json, application/xml

