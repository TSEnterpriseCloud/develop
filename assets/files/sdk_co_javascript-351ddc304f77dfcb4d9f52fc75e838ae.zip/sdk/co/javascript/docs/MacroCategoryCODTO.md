# TseCloudCo.MacroCategoryCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descrmacrocat** | **String** | MG10_DESCRMACROCAT - Descrizione | [optional] 
**dittaCg18** | **Number** | MG10_DITTA_CG18 - Ditta | [optional] 
**macrocat** | **String** | MG10_MACROCAT - Macrocategoria | 
**tipocf** | **Number** | MG10_TIPOCF - Tipo Cli/For&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**categorie** | [**[CategoryCODTO]**](CategoryCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: TipocfEnum


* `0` (value: `0`)

* `1` (value: `1`)




