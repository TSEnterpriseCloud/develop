# TseCloudCo.IEStructureSubTypeCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codStructureSubType** | **Number** | IE37_SOTTOTIPO - Sottotipo struttura | 
**codStructureType** | **Number** | IE37_STRUTTURA_IE21 - Struttura | 
**description** | **String** | IE37_DESCRIZIONE - Descrizione Sottotipo | 
**structureType** | [**IEStructureTypeCODTO**](IEStructureTypeCODTO.md) |  | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


