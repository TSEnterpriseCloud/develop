# TseCloudCo.COForeignPaymentCodeCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codice** | **String** | CG6D_CODICE - Codice | 
**codIso** | **String** | CG6D_CODISO - Codice ISO | [optional] 
**descrpag** | **String** | CG6D_DESCRPAG - Descrizione | [optional] 
**flgIbanobbl** | **Number** | CG6D_FLGIBANOBBL - IBAN | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


