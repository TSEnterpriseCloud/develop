# TseCloudCo.COUnitOfMeasureCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descr** | **String** | CG0C_DESCR - Descrizione | [optional] 
**dittaCg18** | **Number** | CG0C_DITTA_CG18 - Ditta | 
**fattconv** | **Number** | CG0C_FATTCONV - Fattore di conversione | [optional] 
**indOperatore** | **Number** | CG0C_INDOPERATORE - Operatore di conversione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Moltiplicazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Divisione&lt;/li&gt;&lt;/ul&gt; | [optional] 
**umsigla** | **String** | CG0C_UMSIGLA - Sigla da visualizzare | 
**umsiglaCg0b** | **String** | CG0C_UMSIGLA_CG0B - UM del SI corrispondente | 
**sigla** | [**COUMCodeCODTO**](COUMCodeCODTO.md) |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndOperatoreEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)




