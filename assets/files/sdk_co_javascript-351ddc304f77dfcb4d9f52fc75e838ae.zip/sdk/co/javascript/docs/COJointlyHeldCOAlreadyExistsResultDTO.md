# TseCloudCo.COJointlyHeldCOAlreadyExistsResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alreadyExists** | **Boolean** |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


