# TseCloudCo.ImportExportHeadResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**guidResult** | **String** | Guid Result | [optional] 
**totRowImpExp** | **Number** | total rows processed | [optional] 
**impExpWithErrors** | **Boolean** | Import/Export with Error | [optional] 
**rowElab** | [**[ImportExportRowResultDTO]**](ImportExportRowResultDTO.md) | Information/Error rows | [optional] 


