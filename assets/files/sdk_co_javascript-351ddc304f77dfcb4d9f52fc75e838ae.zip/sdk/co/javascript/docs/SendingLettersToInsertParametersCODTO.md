# TseCloudCo.SendingLettersToInsertParametersCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sendingLettersToInsert** | [**[SendingLettersToInsertRowCODTO]**](SendingLettersToInsertRowCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


