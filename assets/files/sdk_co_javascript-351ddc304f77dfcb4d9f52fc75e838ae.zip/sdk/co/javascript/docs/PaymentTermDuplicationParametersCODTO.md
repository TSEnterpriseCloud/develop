# TseCloudCo.PaymentTermDuplicationParametersCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sourcePaymentTermId** | **Number** |  | [optional] 
**targetPaymentTermCode** | **String** |  | [optional] 
**targetPaymentTermCodeDescription** | **String** |  | [optional] 
**isDuplLangDescriptions** | **Boolean** |  | [optional] 
**isDuplExtendedAttribute** | **Boolean** |  | [optional] 


