# TseCloudCo.ImportTimeSeriesRatesInputDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startDate** | **Date** |  | [optional] 
**endDate** | **Date** |  | [optional] 
**baseCurrencyIsoCode** | **String** |  | [optional] 
**currencyIsoCode** | **String** |  | [optional] 
**overwrite** | **Boolean** |  | [optional] 


