# TseCloudCo.NatureAssCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codice** | **String** | CG2N_CODICE - Codice | 
**datafineval** | **Date** | CG2N_DATAFINEVAL - Datafineval | [optional] 
**datainival** | **Date** | CG2N_DATAINIVAL - Datainival | [optional] 
**descr** | **String** | CG2N_DESCR - Descrizione | 
**idassosw** | **Number** | CG2N_IDASSOSW - Idassosw | 
**idCg2m** | **Number** | CG2N_ID_CG2M - IdCg2m | 
**rowversion** | **Blob** | CG2N_ROWVERSION - Rowversion | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


