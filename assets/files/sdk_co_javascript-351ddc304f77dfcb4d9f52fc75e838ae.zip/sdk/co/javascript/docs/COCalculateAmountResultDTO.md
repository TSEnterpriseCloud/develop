# TseCloudCo.COCalculateAmountResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **Number** |  | [optional] 
**currencyExchange** | **Number** |  | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


