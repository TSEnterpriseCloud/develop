# TseCloudCo.COImportExportRowResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**typeResult** | **Number** | Type Result | [optional] 
**typeResultDescription** | **String** | Type Result Description | [optional] 
**description** | **String** | Description | [optional] 


