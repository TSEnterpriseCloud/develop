# TseCloudCo.COBankCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codBicswift** | **String** | CG12_CODBICSWIFT - Codice BIC SWIFT | [optional] 
**codiceBanca** | **Number** | CG12_BANCA - ABI-Banca | 
**descrizione** | **String** | CG12_DESCR - Descrizione | [optional] 
**extensionData** | [**[COStringObjectKeyValuePair]**](COStringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


