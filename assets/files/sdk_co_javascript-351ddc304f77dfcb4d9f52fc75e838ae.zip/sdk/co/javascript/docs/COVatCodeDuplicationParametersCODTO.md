# TseCloudCo.COVatCodeDuplicationParametersCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sourceVatCode** | **String** |  | [optional] 
**newVatCode** | **String** |  | [optional] 
**newVatCodeDescription** | **String** |  | [optional] 
**isDuplLangDescriptions** | **Boolean** |  | [optional] 
**isDuplExtendedAttribute** | **Boolean** |  | [optional] 


