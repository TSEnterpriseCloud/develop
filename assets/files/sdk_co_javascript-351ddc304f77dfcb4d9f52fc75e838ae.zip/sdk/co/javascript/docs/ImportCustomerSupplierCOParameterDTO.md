# TseCloudCo.ImportCustomerSupplierCOParameterDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**addParameters** | [**ImportCustomerSupplierCOAddParameterDTO**](ImportCustomerSupplierCOAddParameterDTO.md) |  | [optional] 
**isAsyncMode** | **Boolean** | Asynchronous processing | [optional] [default to false]
**codLayout** | **String** | Code Layout | 
**streamFileImport** | **String** | Stream File Import | 


