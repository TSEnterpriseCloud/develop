# TseCloudCo.IntegrativeDeclarationResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**opResult** | [**CSLetterOfIntentCODTO**](CSLetterOfIntentCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


