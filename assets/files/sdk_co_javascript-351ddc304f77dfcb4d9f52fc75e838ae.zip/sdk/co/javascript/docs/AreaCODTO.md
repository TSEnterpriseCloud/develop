# TseCloudCo.AreaCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codiceAreaMG** | **String** | MG08_AREA - Area | 
**descrarea** | **String** | MG08_DESCRAREA - Descrizione | [optional] 
**dittaCg18** | **Number** | MG08_DITTA_CG18 - Ditta | 
**idprov** | **Number** | MG08_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**macroareaMg07** | **String** | MG08_MACROAREA_MG07 - Macroarea | 
**tipocfMg07** | **Number** | MG08_TIPOCF_MG07 - Tipo Cliente / Fornitore&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**zone** | [**[ZoneCODTO]**](ZoneCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: TipocfMg07Enum


* `0` (value: `0`)

* `1` (value: `1`)




