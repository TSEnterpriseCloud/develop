# IO.Swagger.Model.FileListEditPathResultDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Files** | **List&lt;string&gt;** | List of files | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

