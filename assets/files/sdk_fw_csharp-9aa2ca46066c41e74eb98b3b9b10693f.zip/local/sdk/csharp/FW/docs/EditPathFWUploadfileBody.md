# IO.Swagger.Model.EditPathFWUploadfileBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**File** | **byte[]** | File to upload | 
**FixedPathType** | **string** | Fixed path type (only UserFileTemp value managed) | [default to "UserFileTemp"]
**RelativePath** | **string** | Relative path | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

