# IO.Swagger.Model.SearchGroupDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_Operator** | **SearchLogicalOperators** |  | [optional] 
**Items** | **List&lt;OneOfSearchGroupDTOItemsItems&gt;** | Items list to apply: any element can be a &#x27;SearchGroupDTO&#x27; or a &#x27;SearchElementDTO&#x27; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

