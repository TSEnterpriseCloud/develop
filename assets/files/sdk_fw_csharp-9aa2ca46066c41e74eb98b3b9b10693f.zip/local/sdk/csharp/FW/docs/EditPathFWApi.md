# IO.Swagger.Api.EditPathFWApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ApiV1EnvironmentFWEditPathFWGetfilePost**](EditPathFWApi.md#apiv1environmentfweditpathfwgetfilepost) | **POST** /api/v1/{environment}/FW/EditPathFW/getfile | Get a file from Edit Path
[**ApiV1EnvironmentFWEditPathFWGetfilelistPost**](EditPathFWApi.md#apiv1environmentfweditpathfwgetfilelistpost) | **POST** /api/v1/{environment}/FW/EditPathFW/getfilelist | Get file list from Edit Path
[**ApiV1EnvironmentFWEditPathFWRemovefilePost**](EditPathFWApi.md#apiv1environmentfweditpathfwremovefilepost) | **POST** /api/v1/{environment}/FW/EditPathFW/removefile | Remove a file Edit Path for error
[**ApiV1EnvironmentFWEditPathFWUploadfilePost**](EditPathFWApi.md#apiv1environmentfweditpathfwuploadfilepost) | **POST** /api/v1/{environment}/FW/EditPathFW/uploadfile | Upload a file to Edit Path

<a name="apiv1environmentfweditpathfwgetfilepost"></a>
# **ApiV1EnvironmentFWEditPathFWGetfilePost**
> void ApiV1EnvironmentFWEditPathFWGetfilePost (string authorizationScope, string environment, GetEditPathParamsDTO body = null, string acceptLanguage = null, string company = null, string user = null)

Get a file from Edit Path

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiV1EnvironmentFWEditPathFWGetfilePostExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: Basic
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new EditPathFWApi();
            var authorizationScope = authorizationScope_example;  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var environment = environment_example;  // string | 
            var body = new GetEditPathParamsDTO(); // GetEditPathParamsDTO |  (optional) 
            var acceptLanguage = acceptLanguage_example;  // string | Example for multilanguage (optional)  (default to it-IT)
            var company = company_example;  // string | Company code (optional) 
            var user = user_example;  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 

            try
            {
                // Get a file from Edit Path
                apiInstance.ApiV1EnvironmentFWEditPathFWGetfilePost(authorizationScope, environment, body, acceptLanguage, company, user);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EditPathFWApi.ApiV1EnvironmentFWEditPathFWGetfilePost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorizationScope** | **string**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **environment** | **string**|  | 
 **body** | [**GetEditPathParamsDTO**](GetEditPathParamsDTO.md)|  | [optional] 
 **acceptLanguage** | **string**| Example for multilanguage | [optional] [default to it-IT]
 **company** | **string**| Company code | [optional] 
 **user** | **string**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="apiv1environmentfweditpathfwgetfilelistpost"></a>
# **ApiV1EnvironmentFWEditPathFWGetfilelistPost**
> FileListEditPathResultDTO ApiV1EnvironmentFWEditPathFWGetfilelistPost (string authorizationScope, string environment, FileListEditPathParamsDTO body = null, string acceptLanguage = null, string company = null, string user = null)

Get file list from Edit Path

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiV1EnvironmentFWEditPathFWGetfilelistPostExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: Basic
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new EditPathFWApi();
            var authorizationScope = authorizationScope_example;  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var environment = environment_example;  // string | 
            var body = new FileListEditPathParamsDTO(); // FileListEditPathParamsDTO |  (optional) 
            var acceptLanguage = acceptLanguage_example;  // string | Example for multilanguage (optional)  (default to it-IT)
            var company = company_example;  // string | Company code (optional) 
            var user = user_example;  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 

            try
            {
                // Get file list from Edit Path
                FileListEditPathResultDTO result = apiInstance.ApiV1EnvironmentFWEditPathFWGetfilelistPost(authorizationScope, environment, body, acceptLanguage, company, user);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EditPathFWApi.ApiV1EnvironmentFWEditPathFWGetfilelistPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorizationScope** | **string**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **environment** | **string**|  | 
 **body** | [**FileListEditPathParamsDTO**](FileListEditPathParamsDTO.md)|  | [optional] 
 **acceptLanguage** | **string**| Example for multilanguage | [optional] [default to it-IT]
 **company** | **string**| Company code | [optional] 
 **user** | **string**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 

### Return type

[**FileListEditPathResultDTO**](FileListEditPathResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="apiv1environmentfweditpathfwremovefilepost"></a>
# **ApiV1EnvironmentFWEditPathFWRemovefilePost**
> void ApiV1EnvironmentFWEditPathFWRemovefilePost (FileEditPathParamsDTO body, string authorizationScope, string environment, string acceptLanguage = null, string company = null, string user = null)

Remove a file Edit Path for error

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiV1EnvironmentFWEditPathFWRemovefilePostExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: Basic
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new EditPathFWApi();
            var body = new FileEditPathParamsDTO(); // FileEditPathParamsDTO | Input parameters
            var authorizationScope = authorizationScope_example;  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var environment = environment_example;  // string | 
            var acceptLanguage = acceptLanguage_example;  // string | Example for multilanguage (optional)  (default to it-IT)
            var company = company_example;  // string | Company code (optional) 
            var user = user_example;  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 

            try
            {
                // Remove a file Edit Path for error
                apiInstance.ApiV1EnvironmentFWEditPathFWRemovefilePost(body, authorizationScope, environment, acceptLanguage, company, user);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EditPathFWApi.ApiV1EnvironmentFWEditPathFWRemovefilePost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FileEditPathParamsDTO**](FileEditPathParamsDTO.md)| Input parameters | 
 **authorizationScope** | **string**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **environment** | **string**|  | 
 **acceptLanguage** | **string**| Example for multilanguage | [optional] [default to it-IT]
 **company** | **string**| Company code | [optional] 
 **user** | **string**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="apiv1environmentfweditpathfwuploadfilepost"></a>
# **ApiV1EnvironmentFWEditPathFWUploadfilePost**
> void ApiV1EnvironmentFWEditPathFWUploadfilePost (string authorizationScope, string environment, byte[] file = null, string fixedPathType = null, string relativePath = null, string acceptLanguage = null, string company = null, string user = null)

Upload a file to Edit Path

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiV1EnvironmentFWEditPathFWUploadfilePostExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: Basic
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new EditPathFWApi();
            var authorizationScope = authorizationScope_example;  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var environment = environment_example;  // string | 
            var file = file_example;  // byte[] |  (optional) 
            var fixedPathType = fixedPathType_example;  // string |  (optional) 
            var relativePath = relativePath_example;  // string |  (optional) 
            var acceptLanguage = acceptLanguage_example;  // string | Example for multilanguage (optional)  (default to it-IT)
            var company = company_example;  // string | Company code (optional) 
            var user = user_example;  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 

            try
            {
                // Upload a file to Edit Path
                apiInstance.ApiV1EnvironmentFWEditPathFWUploadfilePost(authorizationScope, environment, file, fixedPathType, relativePath, acceptLanguage, company, user);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EditPathFWApi.ApiV1EnvironmentFWEditPathFWUploadfilePost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorizationScope** | **string**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **environment** | **string**|  | 
 **file** | **byte[]****byte[]**|  | [optional] 
 **fixedPathType** | **string**|  | [optional] 
 **relativePath** | **string**|  | [optional] 
 **acceptLanguage** | **string**| Example for multilanguage | [optional] [default to it-IT]
 **company** | **string**| Company code | [optional] 
 **user** | **string**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
