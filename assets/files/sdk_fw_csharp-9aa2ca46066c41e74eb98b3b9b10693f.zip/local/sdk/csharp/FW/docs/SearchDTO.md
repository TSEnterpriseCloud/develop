# IO.Swagger.Model.SearchDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Filters** | [**SearchGroupDTO**](SearchGroupDTO.md) |  | [optional] 
**Parameters** | **Dictionary&lt;string, Object&gt;** | List of key value filters that will be applied to the query | [optional] 
**OrderingProperties** | **Dictionary&lt;string, Object&gt;** | \&quot;Order by\&quot; properties list | [optional] 
**PageSize** | **int?** | Page number to retun | [optional] 
**PageNumber** | **int?** | Number of elements per page to return | [optional] 
**SelectList** | **string** |  | [optional] 
**VisibleColumns** | **string** |  | [optional] 
**IdRow** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

