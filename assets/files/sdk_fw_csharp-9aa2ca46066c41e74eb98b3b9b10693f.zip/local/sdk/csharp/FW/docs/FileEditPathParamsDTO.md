# IO.Swagger.Model.FileEditPathParamsDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Filename** | **string** | File name | 
**FixedPathType** | **string** | Fixed path type (only UserFileTemp value managed) | [optional] [default to "UserFileTemp"]
**RelativePath** | **string** | Relative path | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

