# IO.Swagger.Model.AsyncCatalogFWDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Assemblyname** | **string** | AssemblyName - Assemblyname | 
**Classname** | **string** | ClassName - Classname | 
**Descriptionid** | **long?** | DescriptionId - Descriptionid | [optional] 
**Detaillifehours** | **int?** | DetailLifeHours - Detaillifehours | [optional] [default to 0]
**Groupname** | **string** | GroupName - Groupname | 
**Idoperation** | **string** | IdOperation - Id operazione | 
**IsSchedulable** | **bool?** | IsSchedulable - IsSchedulable | 
**Rowversion** | **byte[]** | RowVersion - RowVersion | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

