# IO.Swagger.Model.SearchElementDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_Operator** | **SearchLogicalOperators** |  | [optional] 
**PropertyName** | **string** | Property on witch apply the filter | 
**Comparer** | [**SearchComparer**](SearchComparer.md) |  | 
**Value** | [**SearchNodeValueDTO**](SearchNodeValueDTO.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

