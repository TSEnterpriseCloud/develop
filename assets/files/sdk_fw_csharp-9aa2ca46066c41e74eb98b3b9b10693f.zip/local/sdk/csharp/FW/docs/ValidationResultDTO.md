# IO.Swagger.Model.ValidationResultDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Message** | **string** | Validation message | [optional] 
**WarningCode** | **long?** |  | [optional] 
**IsWarning** | **bool?** | It means the message is a warning | [optional] 
**IsError** | **bool?** | It means the message is an error | [optional] 
**DtoName** | **string** | the DTO name who the property belong | [optional] 
**DtoPropertyName** | **string** | The DTO invalid property name | [optional] 
**EntityPropertyPath** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

