# IO.Swagger.Model.GetEditPathParamsDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AsAttachment** | **bool?** | Download as attachment | [optional] 
**DeleteAfter** | **bool?** | Delete after download | [optional] 
**Filename** | **string** | File name | 
**FixedPathType** | **string** | Fixed path type (only UserFileTemp value managed) | [optional] [default to "UserFileTemp"]
**RelativePath** | **string** | Relative path | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

