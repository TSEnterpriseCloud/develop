# It.TSEnterprise.Sdk.Api.EditPathFWApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**ApiV1EnvironmentFWEditPathFWGetfilePost**](EditPathFWApi.md#apiv1environmentfweditpathfwgetfilepost) | **POST** /api/v1/{environment}/FW/EditPathFW/getfile | Get a file from Edit Path |
| [**ApiV1EnvironmentFWEditPathFWGetfilelistPost**](EditPathFWApi.md#apiv1environmentfweditpathfwgetfilelistpost) | **POST** /api/v1/{environment}/FW/EditPathFW/getfilelist | Get file list from Edit Path |
| [**ApiV1EnvironmentFWEditPathFWRemovefilePost**](EditPathFWApi.md#apiv1environmentfweditpathfwremovefilepost) | **POST** /api/v1/{environment}/FW/EditPathFW/removefile | Remove a file Edit Path for error |
| [**ApiV1EnvironmentFWEditPathFWUploadfilePost**](EditPathFWApi.md#apiv1environmentfweditpathfwuploadfilepost) | **POST** /api/v1/{environment}/FW/EditPathFW/uploadfile | Upload a file to Edit Path |

<a id="apiv1environmentfweditpathfwgetfilepost"></a>
# **ApiV1EnvironmentFWEditPathFWGetfilePost**
> void ApiV1EnvironmentFWEditPathFWGetfilePost (string environment, string authorizationScope, string company = null, string user = null, string acceptLanguage = null, GetEditPathParamsDTO getEditPathParamsDTO = null)

Get a file from Edit Path

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFWEditPathFWGetfilePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new EditPathFWApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)
            var getEditPathParamsDTO = new GetEditPathParamsDTO(); // GetEditPathParamsDTO |  (optional) 

            try
            {
                // Get a file from Edit Path
                apiInstance.ApiV1EnvironmentFWEditPathFWGetfilePost(environment, authorizationScope, company, user, acceptLanguage, getEditPathParamsDTO);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling EditPathFWApi.ApiV1EnvironmentFWEditPathFWGetfilePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFWEditPathFWGetfilePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get a file from Edit Path
    apiInstance.ApiV1EnvironmentFWEditPathFWGetfilePostWithHttpInfo(environment, authorizationScope, company, user, acceptLanguage, getEditPathParamsDTO);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling EditPathFWApi.ApiV1EnvironmentFWEditPathFWGetfilePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |
| **getEditPathParamsDTO** | [**GetEditPathParamsDTO**](GetEditPathParamsDTO.md) |  | [optional]  |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | Not Found |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentfweditpathfwgetfilelistpost"></a>
# **ApiV1EnvironmentFWEditPathFWGetfilelistPost**
> FileListEditPathResultDTO ApiV1EnvironmentFWEditPathFWGetfilelistPost (string environment, string authorizationScope, string company = null, string user = null, string acceptLanguage = null, FileListEditPathParamsDTO fileListEditPathParamsDTO = null)

Get file list from Edit Path

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFWEditPathFWGetfilelistPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new EditPathFWApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)
            var fileListEditPathParamsDTO = new FileListEditPathParamsDTO(); // FileListEditPathParamsDTO |  (optional) 

            try
            {
                // Get file list from Edit Path
                FileListEditPathResultDTO result = apiInstance.ApiV1EnvironmentFWEditPathFWGetfilelistPost(environment, authorizationScope, company, user, acceptLanguage, fileListEditPathParamsDTO);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling EditPathFWApi.ApiV1EnvironmentFWEditPathFWGetfilelistPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFWEditPathFWGetfilelistPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get file list from Edit Path
    ApiResponse<FileListEditPathResultDTO> response = apiInstance.ApiV1EnvironmentFWEditPathFWGetfilelistPostWithHttpInfo(environment, authorizationScope, company, user, acceptLanguage, fileListEditPathParamsDTO);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling EditPathFWApi.ApiV1EnvironmentFWEditPathFWGetfilelistPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |
| **fileListEditPathParamsDTO** | [**FileListEditPathParamsDTO**](FileListEditPathParamsDTO.md) |  | [optional]  |

### Return type

[**FileListEditPathResultDTO**](FileListEditPathResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Response of the request |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | Not Found |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentfweditpathfwremovefilepost"></a>
# **ApiV1EnvironmentFWEditPathFWRemovefilePost**
> void ApiV1EnvironmentFWEditPathFWRemovefilePost (string environment, string authorizationScope, FileEditPathParamsDTO fileEditPathParamsDTO, string company = null, string user = null, string acceptLanguage = null)

Remove a file Edit Path for error

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFWEditPathFWRemovefilePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new EditPathFWApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var fileEditPathParamsDTO = new FileEditPathParamsDTO(); // FileEditPathParamsDTO | Input parameters
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Remove a file Edit Path for error
                apiInstance.ApiV1EnvironmentFWEditPathFWRemovefilePost(environment, authorizationScope, fileEditPathParamsDTO, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling EditPathFWApi.ApiV1EnvironmentFWEditPathFWRemovefilePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFWEditPathFWRemovefilePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Remove a file Edit Path for error
    apiInstance.ApiV1EnvironmentFWEditPathFWRemovefilePostWithHttpInfo(environment, authorizationScope, fileEditPathParamsDTO, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling EditPathFWApi.ApiV1EnvironmentFWEditPathFWRemovefilePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **fileEditPathParamsDTO** | [**FileEditPathParamsDTO**](FileEditPathParamsDTO.md) | Input parameters |  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | Not Found |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentfweditpathfwuploadfilepost"></a>
# **ApiV1EnvironmentFWEditPathFWUploadfilePost**
> void ApiV1EnvironmentFWEditPathFWUploadfilePost (string environment, string authorizationScope, System.IO.Stream file, string fixedPathType, string company = null, string user = null, string acceptLanguage = null, string relativePath = null)

Upload a file to Edit Path

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFWEditPathFWUploadfilePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new EditPathFWApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var file = new System.IO.MemoryStream(System.IO.File.ReadAllBytes("/path/to/file.txt"));  // System.IO.Stream | File to upload
            var fixedPathType = "\"UserFileTemp\"";  // string | Fixed path type (only UserFileTemp value managed) (default to "UserFileTemp")
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)
            var relativePath = "relativePath_example";  // string | Relative path (optional) 

            try
            {
                // Upload a file to Edit Path
                apiInstance.ApiV1EnvironmentFWEditPathFWUploadfilePost(environment, authorizationScope, file, fixedPathType, company, user, acceptLanguage, relativePath);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling EditPathFWApi.ApiV1EnvironmentFWEditPathFWUploadfilePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFWEditPathFWUploadfilePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Upload a file to Edit Path
    apiInstance.ApiV1EnvironmentFWEditPathFWUploadfilePostWithHttpInfo(environment, authorizationScope, file, fixedPathType, company, user, acceptLanguage, relativePath);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling EditPathFWApi.ApiV1EnvironmentFWEditPathFWUploadfilePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **file** | **System.IO.Stream****System.IO.Stream** | File to upload |  |
| **fixedPathType** | **string** | Fixed path type (only UserFileTemp value managed) | [default to &quot;UserFileTemp&quot;] |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |
| **relativePath** | **string** | Relative path | [optional]  |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: Not defined


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **415** | Client Error |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

