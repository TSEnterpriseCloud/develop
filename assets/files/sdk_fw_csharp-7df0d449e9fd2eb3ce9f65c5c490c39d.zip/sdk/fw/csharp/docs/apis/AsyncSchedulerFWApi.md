# It.TSEnterprise.Sdk.Api.AsyncSchedulerFWApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**ApiV1EnvironmentFWAsyncSchedulerFWGet**](AsyncSchedulerFWApi.md#apiv1environmentfwasyncschedulerfwget) | **GET** /api/v1/{environment}/FW/AsyncSchedulerFW | Get new |
| [**ApiV1EnvironmentFWAsyncSchedulerFWIdDelete**](AsyncSchedulerFWApi.md#apiv1environmentfwasyncschedulerfwiddelete) | **DELETE** /api/v1/{environment}/FW/AsyncSchedulerFW/{id} | Delete |
| [**ApiV1EnvironmentFWAsyncSchedulerFWIdGet**](AsyncSchedulerFWApi.md#apiv1environmentfwasyncschedulerfwidget) | **GET** /api/v1/{environment}/FW/AsyncSchedulerFW/{id} | Get by ID |
| [**ApiV1EnvironmentFWAsyncSchedulerFWIdPatch**](AsyncSchedulerFWApi.md#apiv1environmentfwasyncschedulerfwidpatch) | **PATCH** /api/v1/{environment}/FW/AsyncSchedulerFW/{id} | Update partial |
| [**ApiV1EnvironmentFWAsyncSchedulerFWIdPut**](AsyncSchedulerFWApi.md#apiv1environmentfwasyncschedulerfwidput) | **PUT** /api/v1/{environment}/FW/AsyncSchedulerFW/{id} | Update |
| [**ApiV1EnvironmentFWAsyncSchedulerFWPost**](AsyncSchedulerFWApi.md#apiv1environmentfwasyncschedulerfwpost) | **POST** /api/v1/{environment}/FW/AsyncSchedulerFW | Create |
| [**ApiV1EnvironmentFWAsyncSchedulerFWReadPost**](AsyncSchedulerFWApi.md#apiv1environmentfwasyncschedulerfwreadpost) | **POST** /api/v1/{environment}/FW/AsyncSchedulerFW/read | Read |
| [**ApiV1EnvironmentFWAsyncSchedulerFWSearchPost**](AsyncSchedulerFWApi.md#apiv1environmentfwasyncschedulerfwsearchpost) | **POST** /api/v1/{environment}/FW/AsyncSchedulerFW/search | Search |
| [**ApiV1EnvironmentFWAsyncSchedulerFWValidatePost**](AsyncSchedulerFWApi.md#apiv1environmentfwasyncschedulerfwvalidatepost) | **POST** /api/v1/{environment}/FW/AsyncSchedulerFW/validate | Validate |
| [**ApiV1EnvironmentFWAsyncSchedulerFWValidatePropertiesPost**](AsyncSchedulerFWApi.md#apiv1environmentfwasyncschedulerfwvalidatepropertiespost) | **POST** /api/v1/{environment}/FW/AsyncSchedulerFW/validateProperties | Validation of one on more properties of Type |

<a id="apiv1environmentfwasyncschedulerfwget"></a>
# **ApiV1EnvironmentFWAsyncSchedulerFWGet**
> AsyncSchedulerFWDTO ApiV1EnvironmentFWAsyncSchedulerFWGet (string op, string environment, string authorizationScope, string company = null, string user = null, string acceptLanguage = null)

Get new

Get an empty object of type corresponding

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFWAsyncSchedulerFWGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new AsyncSchedulerFWApi(config);
            var op = "op_example";  // string | The value must be 'new'
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get new
                AsyncSchedulerFWDTO result = apiInstance.ApiV1EnvironmentFWAsyncSchedulerFWGet(op, environment, authorizationScope, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling AsyncSchedulerFWApi.ApiV1EnvironmentFWAsyncSchedulerFWGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFWAsyncSchedulerFWGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get new
    ApiResponse<AsyncSchedulerFWDTO> response = apiInstance.ApiV1EnvironmentFWAsyncSchedulerFWGetWithHttpInfo(op, environment, authorizationScope, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling AsyncSchedulerFWApi.ApiV1EnvironmentFWAsyncSchedulerFWGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **op** | **string** | The value must be &#39;new&#39; |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**AsyncSchedulerFWDTO**](AsyncSchedulerFWDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The empty object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentfwasyncschedulerfwiddelete"></a>
# **ApiV1EnvironmentFWAsyncSchedulerFWIdDelete**
> void ApiV1EnvironmentFWAsyncSchedulerFWIdDelete (string id, string environment, string authorizationScope, string company = null, string user = null, string acceptLanguage = null)

Delete

Deleting object of type 

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFWAsyncSchedulerFWIdDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new AsyncSchedulerFWApi(config);
            var id = "id_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Delete
                apiInstance.ApiV1EnvironmentFWAsyncSchedulerFWIdDelete(id, environment, authorizationScope, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling AsyncSchedulerFWApi.ApiV1EnvironmentFWAsyncSchedulerFWIdDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFWAsyncSchedulerFWIdDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete
    apiInstance.ApiV1EnvironmentFWAsyncSchedulerFWIdDeleteWithHttpInfo(id, environment, authorizationScope, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling AsyncSchedulerFWApi.ApiV1EnvironmentFWAsyncSchedulerFWIdDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object has been deleted |  -  |
| **400** | if object has not been deleted: the content response contains the validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |
| **409** | If object has not been deleted due to business rules violation: the content response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentfwasyncschedulerfwidget"></a>
# **ApiV1EnvironmentFWAsyncSchedulerFWIdGet**
> AsyncSchedulerFWDTO ApiV1EnvironmentFWAsyncSchedulerFWIdGet (string id, string environment, string authorizationScope, string dlevel = null, string dlevelkey = null, string company = null, string user = null, string acceptLanguage = null)

Get by ID

Get an object of type corresponding the requested id

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFWAsyncSchedulerFWIdGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new AsyncSchedulerFWApi(config);
            var id = "id_example";  // string | Id to get the object
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var dlevel = "dlevel_example";  // string | Serialization level (optional) 
            var dlevelkey = "dlevelkey_example";  // string | Serialization level key (optional) 
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get by ID
                AsyncSchedulerFWDTO result = apiInstance.ApiV1EnvironmentFWAsyncSchedulerFWIdGet(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling AsyncSchedulerFWApi.ApiV1EnvironmentFWAsyncSchedulerFWIdGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFWAsyncSchedulerFWIdGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get by ID
    ApiResponse<AsyncSchedulerFWDTO> response = apiInstance.ApiV1EnvironmentFWAsyncSchedulerFWIdGetWithHttpInfo(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling AsyncSchedulerFWApi.ApiV1EnvironmentFWAsyncSchedulerFWIdGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** | Id to get the object |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **dlevel** | **string** | Serialization level | [optional]  |
| **dlevelkey** | **string** | Serialization level key | [optional]  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**AsyncSchedulerFWDTO**](AsyncSchedulerFWDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentfwasyncschedulerfwidpatch"></a>
# **ApiV1EnvironmentFWAsyncSchedulerFWIdPatch**
> void ApiV1EnvironmentFWAsyncSchedulerFWIdPatch (string id, string environment, string authorizationScope, Object body, string force = null, string op = null, string company = null, string user = null, string acceptLanguage = null)

Update partial

Patching an object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFWAsyncSchedulerFWIdPatchExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new AsyncSchedulerFWApi(config);
            var id = "id_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var body = null;  // Object | Object of type to patch
            var force = "force_example";  // string | The warning/s code to bypass (separated by ‘,’) during the execution (optional) 
            var op = "op_example";  // string | Set 'reload', if you want the DTO updated in the response request (optional) 
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Update partial
                apiInstance.ApiV1EnvironmentFWAsyncSchedulerFWIdPatch(id, environment, authorizationScope, body, force, op, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling AsyncSchedulerFWApi.ApiV1EnvironmentFWAsyncSchedulerFWIdPatch: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFWAsyncSchedulerFWIdPatchWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update partial
    apiInstance.ApiV1EnvironmentFWAsyncSchedulerFWIdPatchWithHttpInfo(id, environment, authorizationScope, body, force, op, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling AsyncSchedulerFWApi.ApiV1EnvironmentFWAsyncSchedulerFWIdPatchWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **body** | **Object** | Object of type to patch |  |
| **force** | **string** | The warning/s code to bypass (separated by ‘,’) during the execution | [optional]  |
| **op** | **string** | Set &#39;reload&#39;, if you want the DTO updated in the response request | [optional]  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object has been updated |  -  |
| **400** | If the object has not been patched: the content response contains the validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |
| **409** | If object has not been patched due to business rules violation: the content response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentfwasyncschedulerfwidput"></a>
# **ApiV1EnvironmentFWAsyncSchedulerFWIdPut**
> AsyncSchedulerFWDTO ApiV1EnvironmentFWAsyncSchedulerFWIdPut (string id, string environment, string authorizationScope, AsyncSchedulerFWDTO asyncSchedulerFWDTO, string force = null, string op = null, string company = null, string user = null, string acceptLanguage = null)

Update

Updating an object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFWAsyncSchedulerFWIdPutExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new AsyncSchedulerFWApi(config);
            var id = "id_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var asyncSchedulerFWDTO = new AsyncSchedulerFWDTO(); // AsyncSchedulerFWDTO | Object of type to update
            var force = "force_example";  // string | The warning/s code to bypass (separated by ‘,’) during the execution (optional) 
            var op = "op_example";  // string | Set 'reload', if you want the DTO updated in the response request, otherwise will be returned null value (optional) 
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Update
                AsyncSchedulerFWDTO result = apiInstance.ApiV1EnvironmentFWAsyncSchedulerFWIdPut(id, environment, authorizationScope, asyncSchedulerFWDTO, force, op, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling AsyncSchedulerFWApi.ApiV1EnvironmentFWAsyncSchedulerFWIdPut: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFWAsyncSchedulerFWIdPutWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update
    ApiResponse<AsyncSchedulerFWDTO> response = apiInstance.ApiV1EnvironmentFWAsyncSchedulerFWIdPutWithHttpInfo(id, environment, authorizationScope, asyncSchedulerFWDTO, force, op, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling AsyncSchedulerFWApi.ApiV1EnvironmentFWAsyncSchedulerFWIdPutWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **asyncSchedulerFWDTO** | [**AsyncSchedulerFWDTO**](AsyncSchedulerFWDTO.md) | Object of type to update |  |
| **force** | **string** | The warning/s code to bypass (separated by ‘,’) during the execution | [optional]  |
| **op** | **string** | Set &#39;reload&#39;, if you want the DTO updated in the response request, otherwise will be returned null value | [optional]  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**AsyncSchedulerFWDTO**](AsyncSchedulerFWDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object has been updated |  -  |
| **400** | If the object has not been updated: the content response contains the validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |
| **409** | If object has not been updated due to business rules violation: the content response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentfwasyncschedulerfwpost"></a>
# **ApiV1EnvironmentFWAsyncSchedulerFWPost**
> AsyncSchedulerFWDTO ApiV1EnvironmentFWAsyncSchedulerFWPost (string environment, string authorizationScope, AsyncSchedulerFWDTO asyncSchedulerFWDTO, string company = null, string user = null, string acceptLanguage = null)

Create

Creating new object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFWAsyncSchedulerFWPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new AsyncSchedulerFWApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var asyncSchedulerFWDTO = new AsyncSchedulerFWDTO(); // AsyncSchedulerFWDTO | Object of type to create
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Create
                AsyncSchedulerFWDTO result = apiInstance.ApiV1EnvironmentFWAsyncSchedulerFWPost(environment, authorizationScope, asyncSchedulerFWDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling AsyncSchedulerFWApi.ApiV1EnvironmentFWAsyncSchedulerFWPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFWAsyncSchedulerFWPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Create
    ApiResponse<AsyncSchedulerFWDTO> response = apiInstance.ApiV1EnvironmentFWAsyncSchedulerFWPostWithHttpInfo(environment, authorizationScope, asyncSchedulerFWDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling AsyncSchedulerFWApi.ApiV1EnvironmentFWAsyncSchedulerFWPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **asyncSchedulerFWDTO** | [**AsyncSchedulerFWDTO**](AsyncSchedulerFWDTO.md) | Object of type to create |  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**AsyncSchedulerFWDTO**](AsyncSchedulerFWDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | If object has been created |  -  |
| **400** | If the object has not been created: the content response contains validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object has not been created due to business rules violation: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentfwasyncschedulerfwreadpost"></a>
# **ApiV1EnvironmentFWAsyncSchedulerFWReadPost**
> AsyncSchedulerFWDTO ApiV1EnvironmentFWAsyncSchedulerFWReadPost (string environment, string authorizationScope, List<SearchElementDTO> searchElementDTO, string dlevel = null, string dlevelkey = null, string company = null, string user = null, string acceptLanguage = null)

Read

Read among object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFWAsyncSchedulerFWReadPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new AsyncSchedulerFWApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var searchElementDTO = new List<SearchElementDTO>(); // List<SearchElementDTO> | Search criteria to apply
            var dlevel = "dlevel_example";  // string | Serialization level (optional) 
            var dlevelkey = "dlevelkey_example";  // string | Serialization level key (optional) 
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Read
                AsyncSchedulerFWDTO result = apiInstance.ApiV1EnvironmentFWAsyncSchedulerFWReadPost(environment, authorizationScope, searchElementDTO, dlevel, dlevelkey, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling AsyncSchedulerFWApi.ApiV1EnvironmentFWAsyncSchedulerFWReadPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFWAsyncSchedulerFWReadPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Read
    ApiResponse<AsyncSchedulerFWDTO> response = apiInstance.ApiV1EnvironmentFWAsyncSchedulerFWReadPostWithHttpInfo(environment, authorizationScope, searchElementDTO, dlevel, dlevelkey, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling AsyncSchedulerFWApi.ApiV1EnvironmentFWAsyncSchedulerFWReadPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **searchElementDTO** | [**List&lt;SearchElementDTO&gt;**](SearchElementDTO.md) | Search criteria to apply |  |
| **dlevel** | **string** | Serialization level | [optional]  |
| **dlevelkey** | **string** | Serialization level key | [optional]  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**AsyncSchedulerFWDTO**](AsyncSchedulerFWDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentfwasyncschedulerfwsearchpost"></a>
# **ApiV1EnvironmentFWAsyncSchedulerFWSearchPost**
> AsyncSchedulerFWDTO ApiV1EnvironmentFWAsyncSchedulerFWSearchPost (string environment, string authorizationScope, SearchDTO searchDTO, string loadEntireDomain = null, string gettotalcount = null, string company = null, string user = null, string acceptLanguage = null)

Search

Search among object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFWAsyncSchedulerFWSearchPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new AsyncSchedulerFWApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var searchDTO = new SearchDTO(); // SearchDTO | Search criteria to apply
            var loadEntireDomain = "loadEntireDomain_example";  // string | Specify 'loadEntireDomain=true' if you want all the aggregate (optional) 
            var gettotalcount = "gettotalcount_example";  // string | Specify 'gettotalcount=true' if you want the total number of elements (optional) 
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Search
                AsyncSchedulerFWDTO result = apiInstance.ApiV1EnvironmentFWAsyncSchedulerFWSearchPost(environment, authorizationScope, searchDTO, loadEntireDomain, gettotalcount, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling AsyncSchedulerFWApi.ApiV1EnvironmentFWAsyncSchedulerFWSearchPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFWAsyncSchedulerFWSearchPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Search
    ApiResponse<AsyncSchedulerFWDTO> response = apiInstance.ApiV1EnvironmentFWAsyncSchedulerFWSearchPostWithHttpInfo(environment, authorizationScope, searchDTO, loadEntireDomain, gettotalcount, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling AsyncSchedulerFWApi.ApiV1EnvironmentFWAsyncSchedulerFWSearchPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **searchDTO** | [**SearchDTO**](SearchDTO.md) | Search criteria to apply |  |
| **loadEntireDomain** | **string** | Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate | [optional]  |
| **gettotalcount** | **string** | Specify &#39;gettotalcount&#x3D;true&#39; if you want the total number of elements | [optional]  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**AsyncSchedulerFWDTO**](AsyncSchedulerFWDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The list of object of type as result of search |  -  |
| **400** | If the search criteria is not supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentfwasyncschedulerfwvalidatepost"></a>
# **ApiV1EnvironmentFWAsyncSchedulerFWValidatePost**
> void ApiV1EnvironmentFWAsyncSchedulerFWValidatePost (string environment, string authorizationScope, AsyncSchedulerFWDTO asyncSchedulerFWDTO, string company = null, string user = null, string acceptLanguage = null)

Validate

Validation of object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFWAsyncSchedulerFWValidatePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new AsyncSchedulerFWApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var asyncSchedulerFWDTO = new AsyncSchedulerFWDTO(); // AsyncSchedulerFWDTO | Object of type to validate
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Validate
                apiInstance.ApiV1EnvironmentFWAsyncSchedulerFWValidatePost(environment, authorizationScope, asyncSchedulerFWDTO, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling AsyncSchedulerFWApi.ApiV1EnvironmentFWAsyncSchedulerFWValidatePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFWAsyncSchedulerFWValidatePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Validate
    apiInstance.ApiV1EnvironmentFWAsyncSchedulerFWValidatePostWithHttpInfo(environment, authorizationScope, asyncSchedulerFWDTO, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling AsyncSchedulerFWApi.ApiV1EnvironmentFWAsyncSchedulerFWValidatePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **asyncSchedulerFWDTO** | [**AsyncSchedulerFWDTO**](AsyncSchedulerFWDTO.md) | Object of type to validate |  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object is VALID: the content response does NOT contain validation messages |  -  |
| **400** | If no object to validate was supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object is NOT VALID: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentfwasyncschedulerfwvalidatepropertiespost"></a>
# **ApiV1EnvironmentFWAsyncSchedulerFWValidatePropertiesPost**
> ValidateDTO ApiV1EnvironmentFWAsyncSchedulerFWValidatePropertiesPost (string environment, string authorizationScope, string company = null, string user = null, string acceptLanguage = null, string body = null)

Validation of one on more properties of Type

Validation of object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFWAsyncSchedulerFWValidatePropertiesPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new AsyncSchedulerFWApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)
            var body = null;  // string |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br> (optional) 

            try
            {
                // Validation of one on more properties of Type
                ValidateDTO result = apiInstance.ApiV1EnvironmentFWAsyncSchedulerFWValidatePropertiesPost(environment, authorizationScope, company, user, acceptLanguage, body);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling AsyncSchedulerFWApi.ApiV1EnvironmentFWAsyncSchedulerFWValidatePropertiesPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFWAsyncSchedulerFWValidatePropertiesPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Validation of one on more properties of Type
    ApiResponse<ValidateDTO> response = apiInstance.ApiV1EnvironmentFWAsyncSchedulerFWValidatePropertiesPostWithHttpInfo(environment, authorizationScope, company, user, acceptLanguage, body);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling AsyncSchedulerFWApi.ApiV1EnvironmentFWAsyncSchedulerFWValidatePropertiesPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |
| **body** | **string** |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED&lt;br&gt; - The id of an existing object to validate properties, or &#39;&#39; if the object does not exist yet &lt;br&gt; | [optional]  |

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object is VALID: the content response does NOT contain validation messages |  -  |
| **400** | If no object to validate was supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object is NOT VALID: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

