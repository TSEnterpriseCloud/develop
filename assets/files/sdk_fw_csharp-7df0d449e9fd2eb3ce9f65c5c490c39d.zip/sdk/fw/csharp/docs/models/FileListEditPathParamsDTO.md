# It.TSEnterprise.Sdk.Model.FileListEditPathParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FixedPathType** | **string** | Fixed path type (only UserFileTemp value managed) | [optional] [default to "UserFileTemp"]
**RelativePath** | **string** | Relative path | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

