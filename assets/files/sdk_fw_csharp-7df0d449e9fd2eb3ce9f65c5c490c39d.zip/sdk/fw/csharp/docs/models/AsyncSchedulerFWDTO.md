# It.TSEnterprise.Sdk.Model.AsyncSchedulerFWDTO
FW_ASYNC_SCHEDULER - Processi schedulati<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Cronexpr** | **string** | CronExpr - Frequenza | 
**Idoperation** | **string** | IdOperation - Id operazione | 
**Startdatetimeutc** | **DateTime** | StartDateTimeUtc - Data inizio | 
**AsyncCatalogFW** | [**AsyncCatalogFWDTO**](AsyncCatalogFWDTO.md) |  | 
**Additionalinfo** | **string** | AdditionalInfo - Informazioni aggiuntive | [optional] 
**Enddatetimeutc** | **DateTime** | EndDateTimeUtc - Data fine | [optional] 
**Id** | **int** | Id - Id processo (Required only in PUT/PATCH) | [optional] 
**IsDisabled** | **bool** | IsDisabled - Disabilitato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to false]
**Lastexecutionutc** | **DateTime** | LastExecutionUtc - Ultima esecuzione | [optional] 
**Nextexecutionutc** | **DateTime** | NextExecutionUtc - Prossima esecuzione | [optional] 
**SerializedParameter** | **string** | SerializedParameter - Parametri di elaborazione | [optional] 
**Withcompany** | **bool** | WithCompany - per azienda | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

