# It.TSEnterprise.Sdk.Model.AsyncCatalogFWDTO
FW_ASYNC_CATALOG - Operazioni (job) schedulabili<br>Proprietà chiave:<ul><li><b>Idoperation</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Assemblyname** | **string** | AssemblyName - Assemblyname | 
**Classname** | **string** | ClassName - Classname | 
**Groupname** | **string** | GroupName - Groupname | 
**Idoperation** | **string** | IdOperation - Id operazione | 
**IsSchedulable** | **bool** | IsSchedulable - IsSchedulable | 
**Descriptionid** | **long** | DescriptionId - Descriptionid | [optional] 
**Detaillifehours** | **int** | DetailLifeHours - Detaillifehours | [optional] [default to 0]
**Rowversion** | **byte[]** | RowVersion - RowVersion | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

