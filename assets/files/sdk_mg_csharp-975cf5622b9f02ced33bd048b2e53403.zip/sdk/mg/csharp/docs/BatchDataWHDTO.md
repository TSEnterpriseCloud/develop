# It.TSEnterprise.Sdk.Model.BatchDataWHDTO
MG4G_ANAGRLOTTI - Anagrafica lotto<br>Proprietà chiave:<ul><li><b>CodArtMg66</b></li><li><b>CodLotto</b></li><li><b>DittaCg18</b></li><li><b>OpzioneMg5e</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodArtMg66** | **string** | MG4G_CODART_MG66 - Codice Articolo | 
**CodLotto** | **string** | MG4G_CODLOTTO - Codice Lotto | 
**Datacre** | **DateTime?** | MG4G_DATACRE - Data creazione | [optional] 
**Datascad** | **DateTime?** | MG4G_DATASCAD - Data scadenza | [optional] 
**Desclotto** | **string** | MG4G_DESCLOTTO - Descrizione Lotto | [optional] 
**DittaCg18** | **double?** | MG4G_DITTA_CG18 - Ditta | [optional] 
**IdmediaCg99** | **double?** | MG4G_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**Lib1** | **double?** | MG4G_LIB1 - Lib1 | [optional] 
**Note** | **string** | MG4G_NOTE - Note | [optional] 
**OpzioneMg5e** | **string** | MG4G_OPZIONE_MG5E - Codice variante | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

