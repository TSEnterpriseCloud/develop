# It.TSEnterprise.Sdk.Model.DocumentoRigaLottoMGDTO
DO52_DOCCORPOLOT - Lotti riga<br>Proprietà chiave:<ul><li><b>DittaCg18</b></li><li><b>NumregCo99</b></li><li><b>Prog</b></li><li><b>ProgMg4f</b></li><li><b>ProgRiga</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CausmagMg51** | **double?** | DO52_CAUSMAG_MG51 - Causale magazzino | [optional] 
**CliforCg44** | **double?** | DO52_CLIFOR_CG44 - Codice Cliente / Fornitore | [optional] 
**CodArtMg66** | **string** | DO52_CODART_MG66 - Codice Articolo | [optional] 
**CodArtpfMg66** | **string** | DO52_CODARTPF_MG66 - Codice articolo prodotto finito | [optional] 
**CodBagnomat** | **string** | DO52_CODBAGNOMAT - Bagno materiali | [optional] 
**CodConfezMg96** | **string** | DO52_CODCONFEZ_MG96 - Codice confezione | [optional] 
**CodDepMg58** | **string** | DO52_CODDEP_MG58 - Deposito | [optional] 
**CodLottoMg4g** | **string** | DO52_CODLOTTO_MG4G - Codice Lotto | [optional] 
**CodLottopfMg4g** | **string** | DO52_CODLOTTOPF_MG4G - Cod. Lotto P.F. | [optional] 
**CodPallets** | **string** | DO52_CODPALLETS - Codice Pallets | [optional] 
**CodProgPd14** | **string** | DO52_CODPROG_PD14 - CodProgPd14 | [optional] 
**CodSscc** | **string** | DO52_CODSSCC - Codice SSCC | [optional] 
**DittaCg18** | **double?** | DO52_DITTA_CG18 - Ditta | [optional] 
**FlgNonpiuev** | **double?** | DO52_FLGNONPIUEV - Flag non più evadibile | [optional] 
**IdmediaCg99** | **double?** | DO52_IDMEDIA_CG99 - Hypermedia | [optional] 
**Note** | **string** | DO52_NOTE - Note | [optional] 
**NumregCo99** | **string** | DO52_NUMREG_CO99 - Numero registrazione | 
**NumregrifCo99** | **string** | DO52_NUMREGRIF_CO99 - Numero documento di riferimento | [optional] 
**OpzioneMg5e** | **string** | DO52_OPZIONE_MG5E - Variante | [optional] 
**OpzionepfMg5e** | **string** | DO52_OPZIONEPF_MG5E - Variante Prod. Finito | [optional] 
**Prog** | **double?** | DO52_PROG - Progressivo | [optional] 
**ProgMg4f** | **double** | DO52_PROG_MG4F - Configurazione Movimenti Lotti | 
**ProgRifDo52** | **double?** | DO52_PROGRIF_DO52 - Progrssivo riga lotti | [optional] 
**ProgRiga** | **double** | DO52_PROGRIGA - Progressivo Riga | 
**ProgRigarifDo30** | **double?** | DO52_PROGRIGARIF_DO30 - Progressivo di riga nel documento di riferimento | [optional] 
**Qta1** | **double?** | DO52_QTA1 -  Quantita&#39; 1 | [optional] 
**Qta1cons** | **double?** | DO52_QTA1CONS - Quantità 1 consegnata | [optional] 
**Qta2** | **double?** | DO52_QTA2 -  Quantita&#39; 2 | [optional] 
**Qta2cons** | **double?** | DO52_QTA2CONS - Quantità 2 consegnata | [optional] 
**Scadenza** | **DateTime?** | DO52_SCADENZA - Scadenza | [optional] 
**Sernum** | **string** | DO52_SERNUM - Serial Number | [optional] 
**SotprogPd14** | **double?** | DO52_SOTPROG_PD14 - SotprogPd14 | [optional] 
**TipocfCg44** | **double?** | DO52_TIPOCF_CG44 - Tipologia cliente/fornitore | [optional] 
**UbicazcollMg97** | **string** | DO52_UBICAZCOLL_MG97 - Ubicazione collegata | [optional] 
**UbicazMg97** | **string** | DO52_UBICAZ_MG97 - Ubicazione | [optional] 
**AnagraficaLotto** | [**BatchDataWHDTO**](BatchDataWHDTO.md) |  | [optional] 
**ParametroMovimentazioneLotto** | [**LotMovParameterWHDTO**](LotMovParameterWHDTO.md) |  | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

