# It.TSEnterprise.Sdk.Model.FiltroDispArticolo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Articolo** | **string** |  | [optional] 
**Opzione** | **string** |  | [optional] 
**Lotto** | **string** |  | [optional] 
**SerNum** | **string** |  | [optional] 
**Pallet** | **string** |  | [optional] 
**CodBagnoMat** | **string** |  | [optional] 
**CodProg** | **string** |  | [optional] 
**SotProg** | **int** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

