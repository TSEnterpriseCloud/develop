# It.TSEnterprise.Sdk.Model.StatoDTO
Anagrafica stato

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdStato** | **int** | Codice stato | 
**Seq** | **int** | Numero sequenziale di stato | 
**IndTipoStato** | **int** | Indicatore tipo stato: 0 - stato standard, 1 - stato decisionale, 2 - stato autorizzato, 3 -  stato non autorizzato | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

