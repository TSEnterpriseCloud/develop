# It.TSEnterprise.Sdk.Model.CustomerSupplierExtensionMGDTO
MG19_CLIFORVA - Classificazione Cliente/Fornitore<br>Proprietà chiave:<ul><li><b>CliforCg44</b></li><li><b>DittaCg18</b></li><li><b>TipocfCg44</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CliforCg44** | **double** | MG19_CLIFOR_CG44 - Codice cliente | 
**TipocfCg44** | **double** | MG19_TIPOCF_CG44 - Tipo Cliente/ Fornitore | 
**Art62txt** | **string** | MG19_ART62TXT - Estremi / dati del contratto | [optional] 
**Coddestprev** | **string** | MG19_CODDESTPREV - Codice destinatario prevalente per i documenti | [optional] 
**CoddocumMg3g** | **string** | MG19_CODDOCUM_MG3G - Codice documento prevalente | [optional] 
**Dataultcalsp** | **DateTime** | MG19_DATAULTCALSP - Data emissione ultimo calcolo bolli e spese incasso del cliente/fornitore | [optional] 
**Dataultdoc** | **DateTime** | MG19_DATAULTDOC - Data emissione ultimo documento non fattura | [optional] 
**Dataultfat** | **DateTime** | MG19_DATAULTFAT - Data emissione ultima fattura del cliente/fornitore | [optional] 
**Dataultord** | **DateTime** | MG19_DATAULTORD - Data emissione ultimo ordine del cliente/fornitore | [optional] 
**DittaCg18** | **double** | MG19_DITTA_CG18 - Ditta | [optional] 
**Flgart62ctr** | **int** | MG19_FLGART62CTR - Contratto stipulato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Flgdaticlfat** | **double** | MG19_FLGDATICLFAT - Util. dati cliente x fatturazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Flgesclspepor** | **double** | MG19_FLGESCLSPEPOR - Flag di esclusione delle spese indicate nel porto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Flgprzcamp** | **double** | MG19_FLGPRZCAMP - Listini campagna&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Nessuna&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Tutte&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Da elenco&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Flgqualita** | **double** | MG19_FLGQUALITA - Soggetto a controllo qualità&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Flgrottcig** | **double** | MG19_FLGROTTCIG - Flag rottura CIG (codice identificativo di gara)&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Flgrottsingdoc** | **double** | MG19_FLGROTTSINGDOC - Genera unico documento per ogni documento origine elaborato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Ggcons** | **double** | MG19_GGCONS - Giorni consegna | [optional] 
**Imparrotprec** | **double** | MG19_IMPARROTPREC - Importo arrotondamento precedente | [optional] 
**Impdaarrot** | **double** | MG19_IMPDAARROT - Importo da arrotondare | [optional] 
**Indarrinfat** | **double** | MG19_INDARRINFAT - Indicatore arrotondamento fatture&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessun arrotondamento&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Matematico&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Limite superiore&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Limite inferiore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Indarrl96** | **double** | MG19_INDARRL96 - Arrotondamento legge 96&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;li&gt;&lt;i&gt;99&lt;/i&gt; - Come personalizzazione azienda&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Indclifat** | **double** | MG19_INDCLIFAT - Tipo conversione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuna&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - In fatturazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - In fase di registrazione contabile&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Inddesdocest** | **double** | MG19_INDDESDOCEST - Stampa descrizione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Descrizione base&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Descrizione base in lingua&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Entrambe le descrizioni&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndFattper** | **double** | MG19_INDFATTPER - Periodicità di fatturazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Non definito&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Mensile&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Quindicinale&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Settimanale&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Indgiorni** | **double** | MG19_INDGIORNI - Modalità di gestione giorni di consegna&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Dato informativo&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Sostituiscono i giorni dell&#39;articolo&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Sommano ai giorni dell&#39;articolo&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Indprefstdoc** | **double** | MG19_INDPREFSTDOC - Stampa pref. documento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Stampa&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Fax&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Mail&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Nessuna preferenza&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - PEC&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Pdf&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Da param. generali&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Indstscadest** | **double** | MG19_INDSTSCADEST - Stampa scadenze | [optional] 
**Indtestof1** | **double** | MG19_INDTESTOF1 - Indicatore testo fisso 1&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Domanda se inserirlo&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - In automatico all&#39;inizio del corpo documenti&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - In automatico alla fine del corpo documenti&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - In testata dei documenti&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Nel piede dei documenti&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Indtestof2** | **string** | MG19_INDTESTOF2 - Indicatore testo fisso 2&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Domanda se inserirlo&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - In automatico all&#39;inizio del corpo documenti&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - In automatico alla fine del corpo documenti&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - In testata dei documenti&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Nel piede dei documenti&lt;/li&gt;&lt;/ul&gt; | [optional] [default to 0]
**Magimpcor** | **double** | MG19_MAGIMPCOR - Magg. importo | [optional] 
**Magpercor** | **double** | MG19_MAGPERCOR - Maggiorazione % | [optional] 
**Punlis99pre** | **double** | MG19_PUNLIS99PRE - Puntatore listino a 99 prezzi | [optional] 
**Sc1percor** | **double** | MG19_SC1PERCOR - Sconto % 1 | [optional] 
**Sc2percor** | **double** | MG19_SC2PERCOR - Sconto % 2 | [optional] 
**Sc3percor** | **double** | MG19_SC3PERCOR - Sconto % 3 | [optional] 
**Scimpcor** | **double** | MG19_SCIMPCOR - Sconto importo | [optional] 
**Scperpiede** | **double** | MG19_SCPERPIEDE - % Sconto piede | [optional] 
**Tipoclxdoc** | **double** | MG19_TIPOCLXDOC - Cl. x doc.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Italia&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Estero&lt;/li&gt;&lt;/ul&gt; | [optional] 
**BlockLevelCO** | [**BlockLevelCODTO**](BlockLevelCODTO.md) |  | [optional] 
**CliForFatturazione** | [**CustomerSupplierMGDTO**](CustomerSupplierMGDTO.md) |  | [optional] 
**FixedExp1** | [**SpesaVariaMGDTO**](SpesaVariaMGDTO.md) |  | [optional] 
**FixedExp2** | [**SpesaVariaMGDTO**](SpesaVariaMGDTO.md) |  | [optional] 
**FixedText1** | [**TestoFissoMGDTO**](TestoFissoMGDTO.md) |  | [optional] 
**FixedText2** | [**TestoFissoMGDTO**](TestoFissoMGDTO.md) |  | [optional] 
**Language** | [**LanguageCODTO**](LanguageCODTO.md) |  | [optional] 
**PriceListSalePurchase** | [**SalePurchasePriceListCodeMGDTO**](SalePurchasePriceListCodeMGDTO.md) |  | [optional] 
**PriceListWithMultipleItems** | [**PriceListWithMultipleItemsMGDTO**](PriceListWithMultipleItemsMGDTO.md) |  | [optional] 
**RaggruppamentoPrevalente** | [**RaggruppamentoCliForMGDTO**](RaggruppamentoCliForMGDTO.md) |  | [optional] 
**Rischio** | [**RiskMGDTO**](RiskMGDTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

