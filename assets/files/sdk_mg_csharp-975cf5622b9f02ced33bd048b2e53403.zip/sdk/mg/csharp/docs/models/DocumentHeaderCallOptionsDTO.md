# It.TSEnterprise.Sdk.Model.DocumentHeaderCallOptionsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FlgSpbolliForceZero** | **bool** | FlgSpbolliForceZero (default false): set to true if you want to force the value &#x3D; 0 of the tax stamps fees flag | [optional] [default to false]
**FlgSpincasForceZero** | **bool** | FlgSpincasForceZero (default false): set to true if you want to force the value &#x3D; 0 of the collection expenses flag | [optional] [default to false]
**FlgLockOnDocExist** | **bool** | FlgLockOnDocExist (default false): set to true to block the insertion of an already existing document | [optional] [default to false]
**EsclusioneAgentiMultipli** | **bool** | EsclusioneAgentiMultipli (default false): set to true to exclude the loading of multiple agents in the header | [optional] [default to false]
**EsclusioneIvaTestata** | **bool** | EsclusioneIvaTestata (default false): set to true to force the header VAT code of the document to Null. | [optional] [default to false]
**DisableLetterOfIntent** | **bool** | DisableLetterOfIntent (default false): set to true to disable letters of intent | [optional] [default to false]
**EsclusioneSpeseTestiCliFor** | **bool** | EsclusioneSpeseTestiCliFor (default false): set to true to exclude the proposal of Customer/Supplier expense rows and default fixed texts | [optional] [default to false]
**FlgDisableItemControl** | **bool** | DisableItemControl (default false): parameter to disable the existence control of articles to optimize times | [optional] [default to false]

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

