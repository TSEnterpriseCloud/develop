# It.TSEnterprise.Sdk.Model.SpesaVariaMGDTO
MG04_SPESE - Spese varie<br>Proprietà chiave:<ul><li><b>Codice</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codice** | **string** | MG04_CODICE - Codice spesa | 
**Descr** | **string** | MG04_DESCR - Descrizione | [optional] 
**FlgIvaincl** | **int** | MG04_FLGIVAINCL - Importo fisso IVA inclusa&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgOramin** | **double** | MG04_FLGORAMIN - Calcolo importo con quantità espressa in ore e minuti&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgRicfatriep** | **double** | MG04_FLGRICFATRIEP - Forza ricalcolo importo spesa in trasformazione documenti&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgVentamm** | **double** | MG04_FLGVENTAMM - Incrementa ammontare delle operazioni | [optional] 
**FlgVentstat** | **double** | MG04_FLGVENTSTAT - Incrementa valore statistico | [optional] 
**IdmediaCg99** | **double** | MG04_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**IndFatriep** | **double** | MG04_INDFATRIEP - Calc. in trasf. doc.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuna operazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Sommatoria singoli documenti (solo fatt.riep.)&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Unico importo ricalcolato (solo fatt.riep.)&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Sommatoria singoli documenti (tutti doc.)&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Unico importo ricalcolato (tutti doc.)&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Sommat. sing. doc. (tutti doc. tranne riep.)&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Unico imp. ricalc. (tutti doc. tranne riep.)&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndGesintra** | **double** | MG04_INDGESINTRA - Modalità di gestione INTRA&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Ventilazione sulla base dell&#39;ammontare operazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuna rilevazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Rilevazione come servizio&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndRotturacorpo** | **double** | MG04_INDROTTURACORPO - Modalità trasformazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Riporta su tutti i documenti&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Riporta solo sul primo documento&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTipoaliq** | **double** | MG04_INDTIPOALIQ - Tipo aliquota IVA&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Aliquota fissa&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Aliquota proporzionale&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Aliquota maggiore&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Aliquota prevalente&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTipoevas** | **double** | MG04_INDTIPOEVAS - Tipo trasf. documenti&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si trasformazione, solo la 1^ volta in automatico&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No trasformazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Si trasformazione, sempre in automatico&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Si trasformazione, solo la 1^ volta con conferma manuale&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Si trasformazione, sempre con conferma manuale&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Si trasformazione, se trasformata riga di riferimento&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTipospesa** | **double** | MG04_INDTIPOSPESA - Tipo calcolo spesa&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Ad importo fisso&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - A percentuale fissa&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Ad importo e percentuale fissa&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - A scaglione di importo, calcolo ad importo&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - A scaglione di importo, calcolo a percentuale&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - A scaglione di importo, calcolo ad importo e perc.&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTipotot** | **double** | MG04_INDTIPOTOT - Tipo calc. su totale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Netto merce&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Lordo merce&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Su conti merce&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Su totale fattura&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTotspese** | **double** | MG04_INDTOTSPESE - Tot.spese su docum.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Non totalizza&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Su totale spese 1&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Su totale spese 2&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Su totale spese 3&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Su totale spese 4&lt;/li&gt;&lt;/ul&gt; | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

