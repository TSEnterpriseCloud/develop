# It.TSEnterprise.Sdk.Model.DocumentoTestataPersonalizzataMGDTO
DO17_DOCTESTAPERS - Documento personalizzato<br>Proprietà chiave:<ul><li><b>DittaCg18</b></li><li><b>NumregCo99</b></li><li><b>Prog</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NumregCo99** | **string** | DO17_NUMREG_CO99 - Numero registrazione | 
**Alfpers1** | **string** | DO17_ALFPERS1 - Alfanumerico 1 applicazioni pers. | [optional] 
**Alfpers10** | **string** | DO17_ALFPERS10 - Alfanumerico 10 | [optional] 
**Alfpers11** | **string** | DO17_ALFPERS11 - Alfanumerico 11 | [optional] 
**Alfpers12** | **string** | DO17_ALFPERS12 - Alfanumerico 12 | [optional] 
**Alfpers2** | **string** | DO17_ALFPERS2 - Alfanumerico 2 applicazioni pers. | [optional] 
**Alfpers3** | **string** | DO17_ALFPERS3 - Alfanumerico 3 applicazioni pers. | [optional] 
**Alfpers4** | **string** | DO17_ALFPERS4 - Alfanumerico 4 applicazioni pers. | [optional] 
**Alfpers5** | **string** | DO17_ALFPERS5 - Alfanumerico 5 | [optional] 
**Alfpers6** | **string** | DO17_ALFPERS6 - Alfanumerico 6 | [optional] 
**Alfpers7** | **string** | DO17_ALFPERS7 - Alfanumerico 7 | [optional] 
**Alfpers8** | **string** | DO17_ALFPERS8 - Alfanumerico 8 | [optional] 
**Alfpers9** | **string** | DO17_ALFPERS9 - Alfanumerico 9 | [optional] 
**Datapers1** | **DateTime** | DO17_DATAPERS1 - Data personalizzabile 1 | [optional] 
**Datapers2** | **DateTime** | DO17_DATAPERS2 - Data personalizzabile 2 | [optional] 
**Datapers3** | **DateTime** | DO17_DATAPERS3 - Data 3 | [optional] 
**Datapers4** | **DateTime** | DO17_DATAPERS4 - Data 4 | [optional] 
**Datapers5** | **DateTime** | DO17_DATAPERS5 - Data 5 | [optional] 
**Datapers6** | **DateTime** | DO17_DATAPERS6 - Data 6 | [optional] 
**DittaCg18** | **double** | DO17_DITTA_CG18 - Ditta | [optional] 
**FlgPers1** | **double** | DO17_FLGPERS1 - Flag personalizzabile 1 | [optional] 
**FlgPers2** | **double** | DO17_FLGPERS2 - Flag personalizzabile 2 | [optional] 
**FlgPers3** | **double** | DO17_FLGPERS3 - Flag personalizzabile 3 | [optional] 
**FlgPers4** | **double** | DO17_FLGPERS4 - Flag personalizzabile 4 | [optional] 
**IdmediaCg99** | **double** | DO17_IDMEDIA_CG99 - Hypermedia | [optional] 
**IndPers1** | **double** | DO17_INDPERS1 - Indicatore 1 personalizzabile | [optional] 
**IndPers2** | **double** | DO17_INDPERS2 - Indicatore 2 personalizzabile | [optional] 
**Numpers1** | **double** | DO17_NUMPERS1 - Numero personalizzabile 1 | [optional] 
**Numpers10** | **double** | DO17_NUMPERS10 - Numerico 10 | [optional] 
**Numpers11** | **double** | DO17_NUMPERS11 - Numerico 11 | [optional] 
**Numpers12** | **double** | DO17_NUMPERS12 - Numerico 12 | [optional] 
**Numpers2** | **double** | DO17_NUMPERS2 - Num. pers.2 | [optional] 
**Numpers3** | **double** | DO17_NUMPERS3 - Num. pers. 3 | [optional] 
**Numpers4** | **double** | DO17_NUMPERS4 - Num. pers. 4 | [optional] 
**Numpers5** | **double** | DO17_NUMPERS5 - Numerico 5 | [optional] 
**Numpers6** | **double** | DO17_NUMPERS6 - Numerico 6 | [optional] 
**Numpers7** | **double** | DO17_NUMPERS7 - Numerico 7 | [optional] 
**Numpers8** | **double** | DO17_NUMPERS8 - Numerico 8 | [optional] 
**Numpers9** | **double** | DO17_NUMPERS9 - Numerico 9 | [optional] 
**Prog** | **double** | DO17_PROG - Progressivo | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

