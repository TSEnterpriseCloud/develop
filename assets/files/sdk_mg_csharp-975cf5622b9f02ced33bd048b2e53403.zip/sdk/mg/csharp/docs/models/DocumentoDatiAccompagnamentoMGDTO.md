# It.TSEnterprise.Sdk.Model.DocumentoDatiAccompagnamentoMGDTO
DO14_DOCDATIACC - Dati di accompagnamento<br>Proprietà chiave:<ul><li><b>DittaCg18</b></li><li><b>NumregCo99</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NumregCo99** | **string** | DO14_NUMREG_CO99 - Numero registrazione | 
**CodAspettoMg99** | **string** | DO14_CODASPETTO_MG99 - Codice aspetto dei beni | [optional] 
**CodCautraspMg13** | **string** | DO14_CODCAUTRASP_MG13 - Codice causale di trasporto | [optional] 
**CodImballoMg95** | **string** | DO14_CODIMBALLO_MG95 - Codice Imballo | [optional] 
**CodPortoMg91** | **string** | DO14_CODPORTO_MG91 - Codice Porto | [optional] 
**CodTipospedMg93** | **string** | DO14_CODTIPOSPED_MG93 - Codice tipo spedizione | [optional] 
**Datainiztrasp** | **DateTime** | DO14_DATAINIZTRASP - Data inizio trasporto | [optional] 
**Dataritvet1** | **DateTime** | DO14_DATARITVET1 - Data ritiro vettore 1 | [optional] 
**Dataritvet2** | **DateTime** | DO14_DATARITVET2 - Data ritiro vettore 2 | [optional] 
**Descaspetto** | **string** | DO14_DESCASPETTO - Descrizione Aspetto dei beni | [optional] 
**Descrlettint** | **string** | DO14_DESCRLETTINT - Descrizione lettera di intento | [optional] 
**DittaCg18** | **double** | DO14_DITTA_CG18 - Codice ditta | [optional] 
**Orainiziotrasp** | **double** | DO14_ORAINIZIOTRASP - Ora inizio trasporto | [optional] 
**Oraritvet1** | **double** | DO14_ORARITVET1 - Ora ritiro vettore 1 | [optional] 
**Oraritvet2** | **double** | DO14_ORARITVET2 - Ora ritiro vettore 2 | [optional] 
**Pesolordo** | **double** | DO14_PESOLORDO - Peso lordo totale | [optional] 
**Pesonetto** | **double** | DO14_PESONETTO - Peso netto totale | [optional] 
**SpedizMg15** | **string** | DO14_SPEDIZ_MG15 - Codice Spedizioniere | [optional] 
**Targarim1** | **string** | DO14_TARGARIM1 - Targa rimorchio vettore 1 | [optional] 
**Targarim2** | **string** | DO14_TARGARIM2 - Targa rimorchio vettore 2 | [optional] 
**Targavet1** | **string** | DO14_TARGAVET1 - Targa vettore 1 | [optional] 
**Targavet2** | **string** | DO14_TARGAVET2 - Targa vettore 2 | [optional] 
**Totcolli** | **double** | DO14_TOTCOLLI - Totale colli | [optional] 
**Umpeso** | **string** | DO14_UMPESO - UM Peso | [optional] 
**Umvolume** | **string** | DO14_UMVOLUME - UM Volume | [optional] 
**Vettore1Mg14** | **string** | DO14_VETTORE1_MG14 - Codice Vettore 1 | [optional] 
**Vettore2Mg14** | **string** | DO14_VETTORE2_MG14 - Codice Vettore 2 | [optional] 
**Volume** | **double** | DO14_VOLUME - Totale volume | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

