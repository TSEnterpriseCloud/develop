# It.TSEnterprise.Sdk.Model.DocumentoStatoEvasoMGDTO
VFW_DOCUMENTOSTATOEVASIONE - DocumentoStatoEvasoMG<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AnnoDoc** | **double** | VFW_ANNODOC_DO11 - AnnodocDo11 | 
**DataDoc** | **DateTime** | VFW_DATADOC_DO11 - DatadocDo11 | 
**DittaCg18** | **double** | VFW_DITTA_CG18 - DittaCg18 | 
**Id** | **long** | VFW_ID - Id | 
**IdDo11** | **long** | VFW_ID_DO11 - IdDo11 | 
**IndStatoriga** | **int** | VFW_INDSTATORIGA - IndStatoriga | 
**NumdocDo11** | **double** | VFW_NUMDOC_DO11 - NumdocDo11 | 
**NumregCo99** | **string** | VFW_NUMREG_CO99 - NumregCo99 | 
**NumregfatCo99** | **string** | VFW_NUMREGFAT_CO99 - NumregfatCo99 | 
**ProgRigaDo30** | **double** | VFW_PROGRIGA_DO30 - ProgRigaDo30 | 
**Collidoc** | **double** | VFW_COLLIDOC - Collidoc | [optional] 
**Collires** | **double** | VFW_COLLIRES - Collires | [optional] 
**Collitrasf** | **double** | VFW_COLLITRASF - Collitrasf | [optional] 
**FlgDaevadere** | **double** | VFW_FLGDAEVADERE - FlgDaevadere | [optional] 
**FlgEvaso** | **double** | VFW_FLGEVASO - FlgEvaso | [optional] 
**FlgEvasoparz** | **double** | VFW_FLGEVASOPARZ - FlgEvasoparz | [optional] 
**Qta1doc** | **double** | VFW_QTA1DOC - Qta1doc | [optional] 
**Qta1res** | **double** | VFW_QTA1RES - Qta1res | [optional] 
**Qta1trasf** | **double** | VFW_QTA1TRASF - Qta1trasf | [optional] 
**Qta2doc** | **double** | VFW_QTA2DOC - Qta2doc | [optional] 
**Qta2res** | **double** | VFW_QTA2RES - Qta2res | [optional] 
**Qta2trasf** | **double** | VFW_QTA2TRASF - Qta2trasf | [optional] 
**TipodocDo11** | **double** | VFW_TIPODOC_DO11 - TipodocDo11 | [optional] 
**Valoredoc** | **double** | VFW_VALOREDOC - Valoredoc | [optional] 
**Valoreres** | **double** | VFW_VALORERES - Valoreres | [optional] 
**Valoretrasf** | **double** | VFW_VALORETRASF - Valoretrasf | [optional] 
**DocumentoStatoEvasoCorpoRifMG** | [**List&lt;DocumentoStatoEvasoCorpoRifMGDTO&gt;**](DocumentoStatoEvasoCorpoRifMGDTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

