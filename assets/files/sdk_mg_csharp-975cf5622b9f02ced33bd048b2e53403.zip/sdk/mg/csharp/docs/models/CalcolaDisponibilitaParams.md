# It.TSEnterprise.Sdk.Model.CalcolaDisponibilitaParams

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Deposito** | **string** |  | [optional] 
**TipoQta** | **int** |  | [optional] 
**Filtro** | [**List&lt;FiltroDispArticolo&gt;**](FiltroDispArticolo.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

