# It.TSEnterprise.Sdk.Model.COAGroupCodeFIDTO
CG10_DESPDC - Gruppo piano dei conti<br>Proprietà chiave:<ul><li><b>Gruppo</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FlgPdclib** | **int** | CG10_FLGPDCLIB - PdC libero | 
**Gruppo** | **double** | CG10_GRUPPO - Piano dei conti | 
**Numlivelli** | **double** | CG10_NUMLIVELLI - Numero livelli | 
**Descr** | **string** | CG10_DESCR - Descrizione | [optional] 
**Maskedit** | **string** | CG10_MASKEDIT - Formato | [optional] 
**Numlivcons** | **double** | CG10_NUMLIVCONS - Livello per consolidamento | [optional] 
**Rowversion** | **byte[]** | CG10_ROWVERSION - RowVersion | [optional] 
**AccountProposals** | [**List&lt;COAAccountProposalFIDTO&gt;**](COAAccountProposalFIDTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

