# It.TSEnterprise.Sdk.Model.RaggruppamentoCliForMGDTO
MG24_CLIFORRAG - Raggr. prevalente<br>Proprietà chiave:<ul><li><b>CliforCg44</b></li><li><b>CodRag</b></li><li><b>DittaCg18</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CliforCg44** | **double** | MG24_CLIFOR_CG44 - Codice Cliente / Fornitore | 
**CodRag** | **string** | MG24_CODRAG - Codice raggruppamento | 
**Descragg** | **string** | MG24_DESCRAGG - Descrizione raggruppamento | 
**DittaCg18** | **double** | MG24_DITTA_CG18 - Ditta | [optional] 
**IdmediaCg99** | **double** | MG24_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

