# It.TSEnterprise.Sdk.Model.TestoFissoMGDTO
MG62_TESTIFIS - Testi fissi<br>Proprietà chiave:<ul><li><b>Codice</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codice** | **string** | MG62_CODICE - Codice testo fisso | 
**Datafineval** | **DateTime** | MG62_DATAFINEVAL - Data fine validità | [optional] 
**Datainizioval** | **DateTime** | MG62_DATAINIZIOVAL - Data inizio validità | [optional] 
**Descr** | **string** | MG62_DESCR - Descrizione | [optional] 
**IdmediaCg99** | **double** | MG62_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**Idprov** | **int** | MG62_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**IndTipoevas** | **double** | MG62_INDTIPOEVAS - Tipo trasf. doc.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si trasformazione, solo la 1^ volta in automatico&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No trasformazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Si trasformazione, sempre in automatico&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Si trasformazione, solo la 1^ volta con conferma manuale&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Si trasformazione, sempre con conferma manuale&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Si trasformazione, se trasformata riga di riferimento&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Testo** | **string** | MG62_TESTO - Testo | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

