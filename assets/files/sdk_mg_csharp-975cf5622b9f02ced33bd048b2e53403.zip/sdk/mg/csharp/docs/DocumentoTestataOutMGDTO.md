# It.TSEnterprise.Sdk.Model.DocumentoTestataOutMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**GuidSession** | **string** | Guid Session Result Elab | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

