# It.TSEnterprise.Sdk.Model.DocumentoRigaProvvigioniMGDTO
DO32_DOCCORPOPROV - Gestione provvigioni<br>Proprietà chiave:<ul><li><b>DittaCg18</b></li><li><b>IdagenteMg17</b></li><li><b>NumregCo99</b></li><li><b>ProgRiga</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodiceAgente** | **string** | Codice agente | [optional] 
**DittaCg18** | **double?** | DO32_DITTA_CG18 - Codice ditta | [optional] 
**FlgVarprov** | **double?** | DO32_FLGVARPROV - Flag provvigione variata manualmente&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IdagenteMg17** | **int** | DO32_IDAGENTE_MG17 - ID Agente | 
**Imponprov** | **double** | DO32_IMPONPROV - Imponibile provvigione | 
**ImponprovVal** | **double?** | DO32_IMPONPROV_VAL - Imponibile provvigione in valuta | [optional] 
**Imporprov** | **double** | DO32_IMPORPROV - Importo provvigione | 
**ImporprovVal** | **double?** | DO32_IMPORPROV_VAL - Importo provvigione in valuta | [optional] 
**IndRegprov** | **double?** | DO32_INDREGPROV - Indicatore regime provvigione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No calcolo provv.&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - % dall&#39;agente&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - % dal cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - % dall&#39;anagrafica articolo&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - % dall&#39;anagrafica articolo/agente&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - % da listino fisso&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - % da listino anag. su cli./for.&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - % da listino fisso e scagl. sc./magg.&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - % da listino utilizzato&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - % da listino utilizzato: solo gest. scagl. di sc./magg.&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - % da listino utilizzato: provv. list. + scagl. di sc./magg.&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - % da tabella composta a due livelli&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - % da tabella composta a tre livelli&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - % da scaglioni di fatturato&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - % da condizioni multiple&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - % da listini parametrici&lt;/li&gt;&lt;/ul&gt; | [optional] 
**NumregCo99** | **string** | DO32_NUMREG_CO99 - Numero registrazione | 
**Percprov** | **double** | DO32_PERCPROV - Percentuale provvigione | 
**ProgRiga** | **double** | DO32_PROGRIGA - Progressivo riga interna | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

