# It.TSEnterprise.Sdk.Model.CustomerSupplierMGDTO
CG44_CLIFOR - Cliente fornitore<br>Proprietà chiave:<ul><li><b>CliFor</b></li><li><b>DittaCg18</b></li><li><b>TipoCf</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Guid** | **Guid** |  | [optional] 
**CliFor** | **double** | CG44_CLIFOR - Codice | 
**Contratto** | **string** | CG44_CONTRATTO - Codice contratto | [optional] 
**Datavaliva** | **DateTime?** | CG44_DATAVALIVA - Fine validità codice IVA | [optional] 
**DittaCg18** | **double?** | CG44_DITTA_CG18 - Ditta | [optional] 
**Flgart62** | **int?** | CG44_FLGART62 - Flag Art. 62&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgAttivo** | **double?** | CG44_FLGATTIVO - Attivo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgCointestati** | **double?** | CG44_FLGCOINTESTATI - Cointestati&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgInterCompany** | **double?** | CG44_FLGINTERCOMPANY - Intercompany&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**GgScadFix** | **double?** | CG44_GGSCADFIX - GG scad. fix | [optional] 
**GruppoCg10** | **double?** | CG44_GRUPPO_CG10 - Gruppo piano dei conti | [optional] 
**IdCliFor** | **int?** | CG44_IDCLIFOR - ID cliente (Required only in PUT/PATCH) | [optional] 
**IdmediaCg99** | **double?** | CG44_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**IndElenchiMov3000** | **int?** | CG44_INDELENCHIMOV3000 - Ind. gestione elenchi mov. 3.000€&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;99&lt;/i&gt; - Come da anag. generale&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Contratto &gt;&#x3D; 3.000€&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Contratto corrisp. periodici&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Lastchange** | **DateTime?** | CG44_LASTCHANGE - Data ultima variazione | [optional] 
**ProgrEf08** | **double?** | CG44_PROGR_EF08 - Codice banca aziendale | [optional] 
**TipoCf** | **double?** | CG44_TIPOCF - Tipo Cliente / Fornitore&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**TipocfCg40** | **double?** | CG44_TIPOCF_CG40 - Tipo Cliente / Fornitore | [optional] 
**IdExtendedAttributeEntity** | **int** |  | [optional] 
**IdExtendedAttributeSubEntity** | **int** |  | [optional] 
**BlackListGeneralMasterData** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | [optional] 
**ClassificationData** | [**CustSuppClassificationMGDTO**](CustSuppClassificationMGDTO.md) |  | [optional] 
**CurrencyCO** | [**CurrencyCODTO**](CurrencyCODTO.md) |  | [optional] 
**DmsPublishedEntityFW** | [**DMSPublishedEntityFWDTO**](DMSPublishedEntityFWDTO.md) |  | 
**GeneralMasterDataCO** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | 
**Goods** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**OfficeCO** | [**OfficeCODTO**](OfficeCODTO.md) |  | [optional] 
**PaymentTermCO** | [**PaymentTermCODTO**](PaymentTermCODTO.md) |  | [optional] 
**Returns** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**StatoAttualeCO** | [**StatoAttualeDTO**](StatoAttualeDTO.md) |  | 
**VatCodeCO** | [**VatCodeCODTO**](VatCodeCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

