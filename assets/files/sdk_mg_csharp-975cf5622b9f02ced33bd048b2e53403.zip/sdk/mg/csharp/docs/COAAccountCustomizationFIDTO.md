# It.TSEnterprise.Sdk.Model.COAAccountCustomizationFIDTO
CG39_PRSDESPDC - Personalizzazione conti azienda<br>Proprietà chiave:<ul><li><b>Iddespcon</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ContoCg24** | **string** | CG39_CONTO_CG24 - Codice conto | 
**Descr** | **string** | CG39_DESCR - Descrizione | [optional] 
**DittaCg18** | **double** | CG39_DITTA_CG18 - Ditta | 
**GruppoCg10** | **double** | CG39_GRUPPO_CG10 - Piano dei conti | 
**IdCg24** | **long** | CG39_ID_CG24 - ID Conto | 
**Iddespcon** | **long?** | CG39_IDDESPCON - ID (Required only in PUT/PATCH) | [optional] 
**IdmediaCg99** | **double?** | CG39_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**Rowversion** | **byte[]** | CG39_ROWVERSION - RowVersion | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

