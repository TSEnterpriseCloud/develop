# It.TSEnterprise.Sdk.Api.CompanyDocumentMasterDataMGApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**ApiV1EnvironmentMGCompanyDocumentMasterDataMGGet**](CompanyDocumentMasterDataMGApi.md#apiv1environmentmgcompanydocumentmasterdatamgget) | **GET** /api/v1/{environment}/MG/CompanyDocumentMasterDataMG | Get new |
| [**ApiV1EnvironmentMGCompanyDocumentMasterDataMGIdGet**](CompanyDocumentMasterDataMGApi.md#apiv1environmentmgcompanydocumentmasterdatamgidget) | **GET** /api/v1/{environment}/MG/CompanyDocumentMasterDataMG/{id} | Get by ID |
| [**ApiV1EnvironmentMGCompanyDocumentMasterDataMGReadPost**](CompanyDocumentMasterDataMGApi.md#apiv1environmentmgcompanydocumentmasterdatamgreadpost) | **POST** /api/v1/{environment}/MG/CompanyDocumentMasterDataMG/read | Read |
| [**ApiV1EnvironmentMGCompanyDocumentMasterDataMGSearchPost**](CompanyDocumentMasterDataMGApi.md#apiv1environmentmgcompanydocumentmasterdatamgsearchpost) | **POST** /api/v1/{environment}/MG/CompanyDocumentMasterDataMG/search | Search |
| [**ApiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePost**](CompanyDocumentMasterDataMGApi.md#apiv1environmentmgcompanydocumentmasterdatamgvalidatepost) | **POST** /api/v1/{environment}/MG/CompanyDocumentMasterDataMG/validate | Validate |
| [**ApiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePropertiesPost**](CompanyDocumentMasterDataMGApi.md#apiv1environmentmgcompanydocumentmasterdatamgvalidatepropertiespost) | **POST** /api/v1/{environment}/MG/CompanyDocumentMasterDataMG/validateProperties | Validation of one on more properties of Type |

<a id="apiv1environmentmgcompanydocumentmasterdatamgget"></a>
# **ApiV1EnvironmentMGCompanyDocumentMasterDataMGGet**
> CompanyDocumentMasterDataMGDTO ApiV1EnvironmentMGCompanyDocumentMasterDataMGGet (string op, string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null)

Get new

Get an empty object of type corresponding

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentMGCompanyDocumentMasterDataMGGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new CompanyDocumentMasterDataMGApi(config);
            var op = "op_example";  // string | The value must be 'new'
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get new
                CompanyDocumentMasterDataMGDTO result = apiInstance.ApiV1EnvironmentMGCompanyDocumentMasterDataMGGet(op, environment, authorizationScope, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CompanyDocumentMasterDataMGApi.ApiV1EnvironmentMGCompanyDocumentMasterDataMGGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentMGCompanyDocumentMasterDataMGGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get new
    ApiResponse<CompanyDocumentMasterDataMGDTO> response = apiInstance.ApiV1EnvironmentMGCompanyDocumentMasterDataMGGetWithHttpInfo(op, environment, authorizationScope, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CompanyDocumentMasterDataMGApi.ApiV1EnvironmentMGCompanyDocumentMasterDataMGGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **op** | **string** | The value must be &#39;new&#39; |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**CompanyDocumentMasterDataMGDTO**](CompanyDocumentMasterDataMGDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The empty object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentmgcompanydocumentmasterdatamgidget"></a>
# **ApiV1EnvironmentMGCompanyDocumentMasterDataMGIdGet**
> CompanyDocumentMasterDataMGDTO ApiV1EnvironmentMGCompanyDocumentMasterDataMGIdGet (string id, string environment, string authorizationScope, string? dlevel = null, string? dlevelkey = null, string? company = null, string? user = null, string? acceptLanguage = null)

Get by ID

Get an object of type corresponding the requested id

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentMGCompanyDocumentMasterDataMGIdGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new CompanyDocumentMasterDataMGApi(config);
            var id = "id_example";  // string | Id to get the object
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var dlevel = "dlevel_example";  // string? | Serialization level (optional) 
            var dlevelkey = "dlevelkey_example";  // string? | Serialization level key (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get by ID
                CompanyDocumentMasterDataMGDTO result = apiInstance.ApiV1EnvironmentMGCompanyDocumentMasterDataMGIdGet(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CompanyDocumentMasterDataMGApi.ApiV1EnvironmentMGCompanyDocumentMasterDataMGIdGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentMGCompanyDocumentMasterDataMGIdGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get by ID
    ApiResponse<CompanyDocumentMasterDataMGDTO> response = apiInstance.ApiV1EnvironmentMGCompanyDocumentMasterDataMGIdGetWithHttpInfo(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CompanyDocumentMasterDataMGApi.ApiV1EnvironmentMGCompanyDocumentMasterDataMGIdGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** | Id to get the object |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **dlevel** | **string?** | Serialization level | [optional]  |
| **dlevelkey** | **string?** | Serialization level key | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**CompanyDocumentMasterDataMGDTO**](CompanyDocumentMasterDataMGDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentmgcompanydocumentmasterdatamgreadpost"></a>
# **ApiV1EnvironmentMGCompanyDocumentMasterDataMGReadPost**
> CompanyDocumentMasterDataMGDTO ApiV1EnvironmentMGCompanyDocumentMasterDataMGReadPost (string environment, string authorizationScope, List<SearchElementDTO> searchElementDTO, string? dlevel = null, string? dlevelkey = null, string? company = null, string? user = null, string? acceptLanguage = null)

Read

Read among object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentMGCompanyDocumentMasterDataMGReadPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new CompanyDocumentMasterDataMGApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var searchElementDTO = new List<SearchElementDTO>(); // List<SearchElementDTO> | Search criteria to apply
            var dlevel = "dlevel_example";  // string? | Serialization level (optional) 
            var dlevelkey = "dlevelkey_example";  // string? | Serialization level key (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Read
                CompanyDocumentMasterDataMGDTO result = apiInstance.ApiV1EnvironmentMGCompanyDocumentMasterDataMGReadPost(environment, authorizationScope, searchElementDTO, dlevel, dlevelkey, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CompanyDocumentMasterDataMGApi.ApiV1EnvironmentMGCompanyDocumentMasterDataMGReadPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentMGCompanyDocumentMasterDataMGReadPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Read
    ApiResponse<CompanyDocumentMasterDataMGDTO> response = apiInstance.ApiV1EnvironmentMGCompanyDocumentMasterDataMGReadPostWithHttpInfo(environment, authorizationScope, searchElementDTO, dlevel, dlevelkey, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CompanyDocumentMasterDataMGApi.ApiV1EnvironmentMGCompanyDocumentMasterDataMGReadPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **searchElementDTO** | [**List&lt;SearchElementDTO&gt;**](SearchElementDTO.md) | Search criteria to apply |  |
| **dlevel** | **string?** | Serialization level | [optional]  |
| **dlevelkey** | **string?** | Serialization level key | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**CompanyDocumentMasterDataMGDTO**](CompanyDocumentMasterDataMGDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The object of type requested |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentmgcompanydocumentmasterdatamgsearchpost"></a>
# **ApiV1EnvironmentMGCompanyDocumentMasterDataMGSearchPost**
> CompanyDocumentMasterDataMGDTO ApiV1EnvironmentMGCompanyDocumentMasterDataMGSearchPost (string environment, string authorizationScope, SearchDTO searchDTO, string? loadEntireDomain = null, string? gettotalcount = null, string? company = null, string? user = null, string? acceptLanguage = null)

Search

Search among object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentMGCompanyDocumentMasterDataMGSearchPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new CompanyDocumentMasterDataMGApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var searchDTO = new SearchDTO(); // SearchDTO | Search criteria to apply
            var loadEntireDomain = "loadEntireDomain_example";  // string? | Specify 'loadEntireDomain=true' if you want all the aggregate (optional) 
            var gettotalcount = "gettotalcount_example";  // string? | Specify 'gettotalcount=true' if you want the total number of elements (optional) 
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Search
                CompanyDocumentMasterDataMGDTO result = apiInstance.ApiV1EnvironmentMGCompanyDocumentMasterDataMGSearchPost(environment, authorizationScope, searchDTO, loadEntireDomain, gettotalcount, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CompanyDocumentMasterDataMGApi.ApiV1EnvironmentMGCompanyDocumentMasterDataMGSearchPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentMGCompanyDocumentMasterDataMGSearchPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Search
    ApiResponse<CompanyDocumentMasterDataMGDTO> response = apiInstance.ApiV1EnvironmentMGCompanyDocumentMasterDataMGSearchPostWithHttpInfo(environment, authorizationScope, searchDTO, loadEntireDomain, gettotalcount, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CompanyDocumentMasterDataMGApi.ApiV1EnvironmentMGCompanyDocumentMasterDataMGSearchPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **searchDTO** | [**SearchDTO**](SearchDTO.md) | Search criteria to apply |  |
| **loadEntireDomain** | **string?** | Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate | [optional]  |
| **gettotalcount** | **string?** | Specify &#39;gettotalcount&#x3D;true&#39; if you want the total number of elements | [optional]  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**CompanyDocumentMasterDataMGDTO**](CompanyDocumentMasterDataMGDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The list of object of type as result of search |  -  |
| **400** | If the search criteria is not supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentmgcompanydocumentmasterdatamgvalidatepost"></a>
# **ApiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePost**
> void ApiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePost (string environment, string authorizationScope, CompanyDocumentMasterDataMGDTO companyDocumentMasterDataMGDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Validate

Validation of object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new CompanyDocumentMasterDataMGApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var companyDocumentMasterDataMGDTO = new CompanyDocumentMasterDataMGDTO(); // CompanyDocumentMasterDataMGDTO | Object of type to validate
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Validate
                apiInstance.ApiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePost(environment, authorizationScope, companyDocumentMasterDataMGDTO, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CompanyDocumentMasterDataMGApi.ApiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Validate
    apiInstance.ApiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePostWithHttpInfo(environment, authorizationScope, companyDocumentMasterDataMGDTO, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CompanyDocumentMasterDataMGApi.ApiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **companyDocumentMasterDataMGDTO** | [**CompanyDocumentMasterDataMGDTO**](CompanyDocumentMasterDataMGDTO.md) | Object of type to validate |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object is VALID: the content response does NOT contain validation messages |  -  |
| **400** | If no object to validate was supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object is NOT VALID: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentmgcompanydocumentmasterdatamgvalidatepropertiespost"></a>
# **ApiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePropertiesPost**
> ValidateDTO ApiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePropertiesPost (string environment, string authorizationScope, string? company = null, string? user = null, string? acceptLanguage = null, string? body = null)

Validation of one on more properties of Type

Validation of object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePropertiesPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new CompanyDocumentMasterDataMGApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)
            var body = null;  // string? |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br> (optional) 

            try
            {
                // Validation of one on more properties of Type
                ValidateDTO result = apiInstance.ApiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePropertiesPost(environment, authorizationScope, company, user, acceptLanguage, body);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CompanyDocumentMasterDataMGApi.ApiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePropertiesPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePropertiesPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Validation of one on more properties of Type
    ApiResponse<ValidateDTO> response = apiInstance.ApiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePropertiesPostWithHttpInfo(environment, authorizationScope, company, user, acceptLanguage, body);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CompanyDocumentMasterDataMGApi.ApiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePropertiesPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |
| **body** | **string?** |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED&lt;br&gt; - The id of an existing object to validate properties, or &#39;&#39; if the object does not exist yet &lt;br&gt; | [optional]  |

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object is VALID: the content response does NOT contain validation messages |  -  |
| **400** | If no object to validate was supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object is NOT VALID: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

