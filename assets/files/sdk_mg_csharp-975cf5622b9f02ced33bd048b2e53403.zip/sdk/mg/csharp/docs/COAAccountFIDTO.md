# It.TSEnterprise.Sdk.Model.COAAccountFIDTO
CG24_TABPDC - Conto contabile<br>Proprietà chiave:<ul><li><b>Idconto</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccountType** | **int?** | Tipo conto | [optional] 
**Alias** | **string** | CG24_ALIAS - Alias | [optional] 
**Codeformatted** | **string** | Codice | 
**CodiceCg22** | **double?** | CG24_CODICE_CG22 - Cod.imm. | [optional] 
**CodiceCgc0** | **double?** | CG24_CODICE_CGC0 - Codice intercompany | [optional] 
**CogeprogeAbil** | **int?** | CG24_COGEPROGE_ABIL - Abilitato alla correlazione progetti/commesse | [optional] 
**CogeprogeAttivita** | **int?** | CG24_COGEPROGE_ATTIVITA - Correla attività | [optional] 
**CogeprogeMateriali** | **int?** | CG24_COGEPROGE_MATERIALI - Correla materiali | [optional] 
**CogeprogeNodo** | **int?** | CG24_COGEPROGE_NODO - Correla nodo | [optional] 
**CogeprogeSpese** | **int?** | CG24_COGEPROGE_SPESE - Correla spese | [optional] 
**Conto** | **string** | CG24_CONTO - Codice conto | 
**Contoape** | **string** | CG24_CONTOAPE - Conto apertura | [optional] 
**Contochiu** | **string** | CG24_CONTOCHIU - Conto chiusura | [optional] 
**Contocrsosp** | **string** | CG24_CONTOCRSOSP - Conto specifico | [optional] 
**Contoratatt** | **string** | CG24_CONTORATATT - Conto rateo att. | [optional] 
**Contoratpass** | **string** | CG24_CONTORATPASS - Conto rateo pass. | [optional] 
**Contorisatt** | **string** | CG24_CONTORISATT - Conto risc. att. | [optional] 
**Contorispass** | **string** | CG24_CONTORISPASS - Conto risc. pass. | [optional] 
**Descr** | **string** | CG24_DESCR - Descrizione | [optional] 
**FlgAggfatt** | **int?** | CG24_FLGAGGFATT - Agg.fatt.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgAnalit** | **int?** | CG24_FLGANALIT - Conto analitico&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgBilconsattpassdist** | **int?** | CG24_FLGBILCONSATTPASSDIST - Non utilizzato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgContoimm** | **int?** | CG24_FLGCONTOIMM - Imm.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgGesec** | **int?** | CG24_FLGGESEC - Gest.EC&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgGespor** | **int?** | CG24_FLGGESPOR - Gest.port.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgIntercompany** | **int?** | CG24_FLGINTERCOMPANY - Gestione Intercompany&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgOpnonfin** | **double?** | CG24_FLGOPNONFIN - Cont.per cassa&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgRaganal** | **int?** | CG24_FLGRAGANAL - Raggr.anal.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgRarp** | **int?** | CG24_FLGRARP - Base imp.rit.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgSaldog** | **int?** | CG24_FLGSALDOG - Saldo data reg.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgValutaest** | **int?** | CG24_FLGVALUTAEST - Valuta est.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**GruppoCg10** | **double** | CG24_GRUPPO_CG10 - Piano dei conti | 
**Idconto** | **long?** | CG24_IDCONTO - ID Conto (Required only in PUT/PATCH) | [optional] 
**IdcontoapeCg24** | **long?** | CG24_IDCONTOAPE_CG24 - Conto riapertura | [optional] 
**IdcontochiuCg24** | **long?** | CG24_IDCONTOCHIU_CG24 - Conto chiusura | [optional] 
**IdcontoratattCg24** | **long?** | CG24_IDCONTORATATT_CG24 - Conto rateo att. | [optional] 
**IdcontoratpassCg24** | **long?** | CG24_IDCONTORATPASS_CG24 - Conto rateo pass. | [optional] 
**IdcontorisattCg24** | **long?** | CG24_IDCONTORISATT_CG24 - Conto risc. att. | [optional] 
**IdcontorispassCg24** | **long?** | CG24_IDCONTORISPASS_CG24 - Conto risc. pass. | [optional] 
**Idparent** | **long** | CG24_IDPARENT - Id conto padre | 
**Idreverse** | **int?** | CG24_IDREVERSE - Tipo reverse charge | [optional] 
**IdRifPdC80** | **long?** | CG24_IDRIFPDC80 - Conto correlazione AI P.d.C 80 | [optional] 
**IndAttpasspor** | **int?** | CG24_INDATTPASSPOR - Natura&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Attivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Passivo&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndContoricav** | **int?** | CG24_INDCONTORICAV - Tipo conto econ.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Ricavo&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Costo&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndCosvend** | **int?** | CG24_INDCOSVEND - Costo venduto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Ricavi inerenti attivita&#39;&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Ricavi diversi&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Costi merci e mat. suss.&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Altri costi&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Retribuzioni&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Consumi carb. e lubrif.&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Consumi energia&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Altri consumi&lt;/li&gt;&lt;li&gt;&lt;i&gt;98&lt;/i&gt; - Rimanenze iniziali&lt;/li&gt;&lt;li&gt;&lt;i&gt;99&lt;/i&gt; - Rimanenze finali&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndDaav** | **int?** | CG24_INDDAAV - Segno esp.bilancio&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Dare&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Avere&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndDaavec** | **int?** | CG24_INDDAAVEC - Segno&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Dare&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Avere&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndLivchius** | **int?** | CG24_INDLIVCHIUS - Livello di chiusura | [optional] 
**IndMastroCliFor** | **double?** | CG24_INDMASTROCLIFOR - Indicatore mastro clienti/fornitori&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;99&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Mastro clienti&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Mastro fornitori&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndTipoconto** | **int?** | CG24_INDTIPOCONTO - Natura conto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Conto d&#39;ordine&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Patrimoniale&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Economico&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Da non stampare&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Percindeduc** | **double?** | CG24_PERCINDEDUC - % IRAP | [optional] 
**Percindetra** | **double?** | CG24_PERCINDETRA - % IRES/IRPEF | [optional] 
**Suddconti** | **double?** | CG24_SUDDCONTI - Informazioni riguardanti la compilazione quadro A modello IVA 11 | [optional] 
**CoaAccountCustomizationFI** | [**List&lt;COAAccountCustomizationFIDTO&gt;**](COAAccountCustomizationFIDTO.md) |  | [optional] 
**CoaAccountFIApe** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**CoaAccountFIChiu** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**CoaAccountFIParent** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**CoaAccountFIRatatt** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**CoaAccountFIRatpass** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**CoaAccountFIRisatt** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**CoaAccountFIRispass** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**CoaAccountStateFI** | [**List&lt;COAAccountStateFIDTO&gt;**](COAAccountStateFIDTO.md) |  | [optional] 
**CoaGroupCodeFI** | [**COAGroupCodeFIDTO**](COAGroupCodeFIDTO.md) |  | 
**CoaInternationalCustomizationFI** | [**List&lt;COAInternationalCustomizationFIDTO&gt;**](COAInternationalCustomizationFIDTO.md) |  | [optional] 
**IntragroupStructureCO** | [**IntragroupStructureCODTO**](IntragroupStructureCODTO.md) |  | [optional] 
**ReverseTypeFI** | [**GLReverseTypeFIDTO**](GLReverseTypeFIDTO.md) |  | [optional] 
**VatTypeFI** | [**VATTypeFIDTO**](VATTypeFIDTO.md) |  | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

