# It.TSEnterprise.Sdk.Model.DocumentMasterCODTO
CO99_MASTERDOC - Master documento<br>Proprietà chiave:<ul><li><b>DittaCg18</b></li><li><b>Numreg</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Datacre** | **DateTime?** | CO99_DATACRE - Data creazione | [optional] 
**Datavar** | **DateTime?** | CO99_DATAVAR - Data ultima variazione | [optional] 
**Descnote1** | **string** | CO99_DESCNOTE1 - Note | [optional] 
**DittaCg18** | **double?** | CO99_DITTA_CG18 - Ditta | [optional] 
**Gruppocre** | **string** | CO99_GRUPPOCRE - Gruppo utente creazione | [optional] 
**Gruppovar** | **string** | CO99_GRUPPOVAR - Gruppo variazione | [optional] 
**IndTipoop** | **double?** | CO99_INDTIPOOP - Indicatore tipo operazione | [optional] 
**Numreg** | **string** | CO99_NUMREG - Numero registrazione | 
**Utentecre** | **string** | CO99_UTENTECRE - Utente creazione | [optional] 
**Utentevar** | **string** | CO99_UTENTEVAR - Utente variazione | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

