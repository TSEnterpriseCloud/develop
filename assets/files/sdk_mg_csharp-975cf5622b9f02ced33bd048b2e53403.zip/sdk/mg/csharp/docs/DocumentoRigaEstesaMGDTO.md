# It.TSEnterprise.Sdk.Model.DocumentoRigaEstesaMGDTO
DO36_DOCCORPOEST - Campi estesi corpo<br>Proprietà chiave:<ul><li><b>DittaCg18</b></li><li><b>NumregCo99</b></li><li><b>Prog</b></li><li><b>ProgRiga</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Alfst1** | **string** | DO36_ALFST1 - Alfanumerico 1 | [optional] 
**Alfst10** | **string** | DO36_ALFST10 - Alfanumerico 10 | [optional] 
**Alfst11** | **string** | DO36_ALFST11 - Alfanumerico 11 | [optional] 
**Alfst12** | **string** | DO36_ALFST12 - Alfanumerico 12 | [optional] 
**Alfst2** | **string** | DO36_ALFST2 - Alfanumerico 2 | [optional] 
**Alfst3** | **string** | DO36_ALFST3 - Alfanumerico 3 | [optional] 
**Alfst4** | **string** | DO36_ALFST4 - Alfanumerico 4 | [optional] 
**Alfst5** | **string** | DO36_ALFST5 - Alfanumerico 5 | [optional] 
**Alfst6** | **string** | DO36_ALFST6 - Alfanumerico 6 | [optional] 
**Alfst7** | **string** | DO36_ALFST7 - Alfanumerico 7 | [optional] 
**Alfst8** | **string** | DO36_ALFST8 - Alfanumerico 8 | [optional] 
**Alfst9** | **string** | DO36_ALFST9 - Alfanumerico 9 | [optional] 
**Datast1** | **DateTime?** | DO36_DATAST1 - Data 1 | [optional] 
**Datast2** | **DateTime?** | DO36_DATAST2 - Data 2 | [optional] 
**Datast3** | **DateTime?** | DO36_DATAST3 - Data 3 | [optional] 
**Datast4** | **DateTime?** | DO36_DATAST4 - Data 4 | [optional] 
**Datast5** | **DateTime?** | DO36_DATAST5 - Data 5 | [optional] 
**Datast6** | **DateTime?** | DO36_DATAST6 - Data 6 | [optional] 
**DittaCg18** | **double?** | DO36_DITTA_CG18 - Ditta | [optional] 
**FlgSt1** | **double?** | DO36_FLGST1 - Flag 1 | [optional] 
**FlgSt2** | **double?** | DO36_FLGST2 - Flag 2 | [optional] 
**FlgSt3** | **double?** | DO36_FLGST3 - Flag 3 | [optional] 
**FlgSt4** | **double?** | DO36_FLGST4 - Flag 4 | [optional] 
**IdmediaCg99** | **double?** | DO36_IDMEDIA_CG99 - Hypermedia | [optional] 
**IndSt1** | **double?** | DO36_INDST1 - Indicatore 1 | [optional] 
**IndSt2** | **double?** | DO36_INDST2 - Indicatore 2 | [optional] 
**NumregCo99** | **string** | DO36_NUMREG_CO99 - Numero registrazione | 
**Numst1** | **double?** | DO36_NUMST1 - Numerico 1 | [optional] 
**Numst10** | **double?** | DO36_NUMST10 - Numerico 10 | [optional] 
**Numst11** | **double?** | DO36_NUMST11 - Numerico 11 | [optional] 
**Numst12** | **double?** | DO36_NUMST12 - Numerico 12 | [optional] 
**Numst2** | **double?** | DO36_NUMST2 - Numerico 2 | [optional] 
**Numst3** | **double?** | DO36_NUMST3 - Numerico 3 | [optional] 
**Numst4** | **double?** | DO36_NUMST4 - Numerico 4 | [optional] 
**Numst5** | **double?** | DO36_NUMST5 - Numerico 5 | [optional] 
**Numst6** | **double?** | DO36_NUMST6 - Numerico 6 | [optional] 
**Numst7** | **double?** | DO36_NUMST7 - Numerico 7 | [optional] 
**Numst8** | **double?** | DO36_NUMST8 - Numerico 8 | [optional] 
**Numst9** | **double?** | DO36_NUMST9 - Numerico 9 | [optional] 
**Prog** | **double?** | DO36_PROG - Progressivo | [optional] 
**ProgRiga** | **double** | DO36_PROGRIGA - Progressivo Riga | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

