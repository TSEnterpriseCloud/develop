# It.TSEnterprise.Sdk.Model.PriceListWithMultipleItemsMGDTO
LI26_ANAGLISPIUART - Codice listino a più articoli<br>Proprietà chiave:<ul><li><b>Codice</b></li><li><b>DittaCg18</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codice** | **string** | LI26_CODICE - Codice listino con più articoli | 
**Descr** | **string** | LI26_DESCR - Descrizione | [optional] 
**DittaCg18** | **double?** | LI26_DITTA_CG18 - Ditta | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

