# It.TSEnterprise.Sdk.Api.GiacenzaMGApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**ApiV1EnvironmentMGGiacenzaMGDisponibilitaPost**](GiacenzaMGApi.md#apiv1environmentmggiacenzamgdisponibilitapost) | **POST** /api/v1/{environment}/MG/GiacenzaMG/disponibilita | Calculate stock availability based on the required parameters |
| [**ApiV1EnvironmentMGGiacenzaMGRicalcologiacenzaPost**](GiacenzaMGApi.md#apiv1environmentmggiacenzamgricalcologiacenzapost) | **POST** /api/v1/{environment}/MG/GiacenzaMG/ricalcologiacenza | Recalculate the stock based on the required parameters |
| [**ApiV1EnvironmentMGGiacenzaMGValidatePost**](GiacenzaMGApi.md#apiv1environmentmggiacenzamgvalidatepost) | **POST** /api/v1/{environment}/MG/GiacenzaMG/validate | Validate |

<a id="apiv1environmentmggiacenzamgdisponibilitapost"></a>
# **ApiV1EnvironmentMGGiacenzaMGDisponibilitaPost**
> void ApiV1EnvironmentMGGiacenzaMGDisponibilitaPost (string environment, string authorizationScope, CalcolaDisponibilitaParams calcolaDisponibilitaParams, string? company = null, string? user = null, string? acceptLanguage = null)

Calculate stock availability based on the required parameters

Calculate stock availability based on the required parameters

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentMGGiacenzaMGDisponibilitaPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GiacenzaMGApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var calcolaDisponibilitaParams = new CalcolaDisponibilitaParams(); // CalcolaDisponibilitaParams | Object that contains all the parameters that can affect the stock availability recalculation
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Calculate stock availability based on the required parameters
                apiInstance.ApiV1EnvironmentMGGiacenzaMGDisponibilitaPost(environment, authorizationScope, calcolaDisponibilitaParams, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GiacenzaMGApi.ApiV1EnvironmentMGGiacenzaMGDisponibilitaPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentMGGiacenzaMGDisponibilitaPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Calculate stock availability based on the required parameters
    apiInstance.ApiV1EnvironmentMGGiacenzaMGDisponibilitaPostWithHttpInfo(environment, authorizationScope, calcolaDisponibilitaParams, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GiacenzaMGApi.ApiV1EnvironmentMGGiacenzaMGDisponibilitaPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **calcolaDisponibilitaParams** | [**CalcolaDisponibilitaParams**](CalcolaDisponibilitaParams.md) | Object that contains all the parameters that can affect the stock availability recalculation |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Calculation result |  -  |
| **400** | In case of errors in the business logic: the content of the response contains the validation messages produced |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentmggiacenzamgricalcologiacenzapost"></a>
# **ApiV1EnvironmentMGGiacenzaMGRicalcologiacenzaPost**
> void ApiV1EnvironmentMGGiacenzaMGRicalcologiacenzaPost (string environment, string authorizationScope, RicalcoloGiacenzaParams ricalcoloGiacenzaParams, string? company = null, string? user = null, string? acceptLanguage = null)

Recalculate the stock based on the required parameters

Recalculate the stock based on the required parameters

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentMGGiacenzaMGRicalcologiacenzaPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GiacenzaMGApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var ricalcoloGiacenzaParams = new RicalcoloGiacenzaParams(); // RicalcoloGiacenzaParams | Object that contains all the parameters that can affect the stock recalculation
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Recalculate the stock based on the required parameters
                apiInstance.ApiV1EnvironmentMGGiacenzaMGRicalcologiacenzaPost(environment, authorizationScope, ricalcoloGiacenzaParams, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GiacenzaMGApi.ApiV1EnvironmentMGGiacenzaMGRicalcologiacenzaPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentMGGiacenzaMGRicalcologiacenzaPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Recalculate the stock based on the required parameters
    apiInstance.ApiV1EnvironmentMGGiacenzaMGRicalcologiacenzaPostWithHttpInfo(environment, authorizationScope, ricalcoloGiacenzaParams, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GiacenzaMGApi.ApiV1EnvironmentMGGiacenzaMGRicalcologiacenzaPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **ricalcoloGiacenzaParams** | [**RicalcoloGiacenzaParams**](RicalcoloGiacenzaParams.md) | Object that contains all the parameters that can affect the stock recalculation |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Calculation result |  -  |
| **400** | In case of errors in the business logic: the content of the response contains the validation messages produced |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="apiv1environmentmggiacenzamgvalidatepost"></a>
# **ApiV1EnvironmentMGGiacenzaMGValidatePost**
> void ApiV1EnvironmentMGGiacenzaMGValidatePost (string environment, string authorizationScope, GiacenzaMGDTO giacenzaMGDTO, string? company = null, string? user = null, string? acceptLanguage = null)

Validate

Validation of object of type

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentMGGiacenzaMGValidatePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new GiacenzaMGApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var giacenzaMGDTO = new GiacenzaMGDTO(); // GiacenzaMGDTO | Object of type to validate
            var company = "company_example";  // string? | Company code (optional) 
            var user = "user_example";  // string? | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string? | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Validate
                apiInstance.ApiV1EnvironmentMGGiacenzaMGValidatePost(environment, authorizationScope, giacenzaMGDTO, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling GiacenzaMGApi.ApiV1EnvironmentMGGiacenzaMGValidatePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentMGGiacenzaMGValidatePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Validate
    apiInstance.ApiV1EnvironmentMGGiacenzaMGValidatePostWithHttpInfo(environment, authorizationScope, giacenzaMGDTO, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling GiacenzaMGApi.ApiV1EnvironmentMGGiacenzaMGValidatePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **giacenzaMGDTO** | [**GiacenzaMGDTO**](GiacenzaMGDTO.md) | Object of type to validate |  |
| **company** | **string?** | Company code | [optional]  |
| **user** | **string?** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string?** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object is VALID: the content response does NOT contain validation messages |  -  |
| **400** | If no object to validate was supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **409** | If object is NOT VALID: the content response contains validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

