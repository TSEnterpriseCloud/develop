# It.TSEnterprise.Sdk.Model.BlockLevelCODTO
MG25_LIVBLOCCO - Livelli di blocco<br>Proprietà chiave:<ul><li><b>CodBlocco</b></li><li><b>DittaCg18</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodBlocco** | **string** | MG25_CODBLOCCO - Codice Blocco | 
**Descrblocco** | **string** | MG25_DESCRBLOCCO - Descrizione | [optional] 
**DittaCg18** | **double?** | MG25_DITTA_CG18 - Ditta | [optional] 
**IdmediaCg99** | **double?** | MG25_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**IndPayline** | **double?** | MG25_INDPAYLINE - Status Payline&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno Status Payline&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Status Bloccato Payline&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Status A Legale Payline&lt;/li&gt;&lt;/ul&gt; | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

