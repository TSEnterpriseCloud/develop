# It.TSEnterprise.Sdk.Model.DocumentTransformationPartialEvadContainerGeneralDataDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NumRegOrigin** | **string** | NumRegOrigin - Num Reg Origin | 
**DocumentTransformationGeneralData** | [**List&lt;DocumentTransformationGeneralDataDTO&gt;**](DocumentTransformationGeneralDataDTO.md) | DocumentTransformationGeneralDataDTO - Container For partial rows | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

