# It.TSEnterprise.Sdk.Model.StatoAttualeDTO
Stato attuale di un'entità.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StatoCorrente** | [**StatoDTO**](StatoDTO.md) |  | 
**StatiDisponibili** | [**List&lt;StatoDTO&gt;**](StatoDTO.md) | Lista di stati disponibili raggiungibili dallo stato corrente. | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

