# Org.OpenAPITools.Model.DocumentoRigaRiferimentoMGDTO
DO33_DOCCORPORIF - Corpo documenti di riferimento<br>Proprietà chiave:<ul><li><b>DittaCg18</b></li><li><b>NumregCo99</b></li><li><b>ProgRif</b></li><li><b>ProgRiga</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NumregCo99** | **string** | DO33_NUMREG_CO99 - Numero registrazione | 
**ProgRif** | **double** | DO33_PROGRIF - Progressivo di rif. | 
**ProgRiga** | **double** | DO33_PROGRIGA - Progressivo Riga | 
**Collimov** | **double** | DO33_COLLIMOV - Colli movimentati | [optional] 
**Datansconf** | **DateTime** | DO33_DATANSCONF - Data nostra conferma | [optional] 
**Datansdoc** | **DateTime** | DO33_DATANSDOC - Data nostro documento | [optional] 
**Datavsconf** | **DateTime** | DO33_DATAVSCONF - Data vostra conferma | [optional] 
**Datavsdoc** | **DateTime** | DO33_DATAVSDOC - Data vostro documento | [optional] 
**DittaCg18** | **double** | DO33_DITTA_CG18 - Ditta | [optional] [default to 0D]
**FasePd12** | **double** | DO33_FASE_PD12 - Fase di lavorazione | [optional] 
**FlgAggprescvar** | **double** | DO33_FLGAGGPRESCVAR - Aggiornamento prezzi e sconti variati su doc. origine&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgAggqtatrasf** | **int** | DO33_FLGAGGQTATRASF - Aggiornamento quantità evasa/trasformata su documento origine&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgNonpiuevpdc** | **double** | DO33_FLGNONPIUEVPDC - FlgNonpiuevpdc&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgNsdocbis** | **double** | DO33_FLGNSDOCBIS - Flag bis ns documento | [optional] 
**FlgStornoqtaval** | **int** | DO33_FLGSTORNOQTAVAL - Storno le quantità evase/trasformate con la causale del documento origine&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndAggdocorigine** | **double** | DO33_INDAGGDOCORIGINE - Modalità di aggiornamento documento di origine | [optional] [default to 0D]
**IndQtaordres** | **int** | DO33_INDQTAORDRES - IndQtaordres | [optional] 
**IndStipodoc** | **int** | DO33_INDSTIPODOC - Indicatore sottotipo documento di riferimento | [optional] [default to 0]
**IndTipodoc** | **int** | DO33_INDTIPODOC - Indicatore tipo documento di riferimento | [optional] [default to 0]
**Notensdoc** | **string** | DO33_NOTENSDOC - Note nostro documento | [optional] 
**Notevsdoc** | **string** | DO33_NOTEVSDOC - Note vostro documento | [optional] 
**Numnsdoc** | **double** | DO33_NUMNSDOC - Numero nostro documento | [optional] 
**NumregpadreCo99** | **string** | DO33_NUMREGPADRE_CO99 - Documento origine/riga padre | [optional] 
**NumregrifCo99** | **string** | DO33_NUMREGRIF_CO99 - Num. doc. rif. | [optional] 
**Numvsdoc** | **string** | DO33_NUMVSDOC - Numero vostro documento | [optional] 
**ProgPdcDo65** | **double** | DO33_PROGPDC_DO65 - Gestione progressivo righe ordini aperti | [optional] 
**ProgPdcrifDo65** | **double** | DO33_PROGPDCRIF_DO65 - Gestione progr.righe ordini aperti | [optional] 
**ProgRigapadreDo30** | **double** | DO33_PROGRIGAPADRE_DO30 - Documento origine/riga padre | [optional] 
**ProgRigarifDo30** | **double** | DO33_PROGRIGARIF_DO30 - Progressivo di riga nel documento di riferimento | [optional] 
**Qta1mov** | **double** | DO33_QTA1MOV - Quantità 1 movimentata | [optional] 
**Qta2mov** | **double** | DO33_QTA2MOV - Quantità 2 movimentata | [optional] 
**Rifnsdoc** | **string** | DO33_RIFNSDOC - Riferimento nostro documento | [optional] 
**Rifvsdoc** | **string** | DO33_RIFVSDOC - Riferimento vostro documento | [optional] 
**Seqfase** | **double** | DO33_SEQFASE - Sequenza fase | [optional] 
**Seznsdoc** | **string** | DO33_SEZNSDOC - Sezionale nostro documento | [optional] 
**Valoremov** | **double** | DO33_VALOREMOV - Valore movimentato | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

