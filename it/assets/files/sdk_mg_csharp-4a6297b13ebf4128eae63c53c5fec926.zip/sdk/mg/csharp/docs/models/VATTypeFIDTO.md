# Org.OpenAPITools.Model.VATTypeFIDTO
CG0T_TIPOIVA - VATTypeFI<br>Proprietà chiave:<ul><li><b>Codice</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Agviaggio** | **int** | CG0T_AGVIAGGIO - Agviaggio | 
**Codice** | **double** | CG0T_CODICE - Codice | 
**IndAutofattura** | **int** | CG0T_INDAUTOFATTURA - IndAutofattura | 
**CodiceCg0d** | **double** | CG0T_CODICE_CG0D - CodiceCg0d | [optional] 
**Descr** | **string** | CG0T_DESCR - Descr | [optional] 
**IndTipo** | **double** | CG0T_INDTIPO - IndTipo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Ordinario&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Rep. San Marino&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Agenzia viaggi&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Agricoltura&lt;/li&gt;&lt;li&gt;&lt;i&gt;99&lt;/i&gt; - Obsoleti&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Localizzazione** | **int** | CG0T_LOCALIZZAZIONE - Localizzazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuna&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - FRANCIA&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Stati Uniti&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Spagna&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Regno Unito&lt;/li&gt;&lt;/ul&gt; | [optional] [default to LocalizzazioneEnum.NUMBER_0]
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

