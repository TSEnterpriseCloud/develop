# Org.OpenAPITools.Api.DocumentServiceApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**ApiV1EnvironmentMGDocumentServiceDocprocessingstatusPost**](DocumentServiceApi.md#apiv1environmentmgdocumentservicedocprocessingstatuspost) | **POST** /api/v1/{environment}/MG/DocumentService/docprocessingstatus | Return Document processing status |
| [**ApiV1EnvironmentMGDocumentServiceMultiplecreatePost**](DocumentServiceApi.md#apiv1environmentmgdocumentservicemultiplecreatepost) | **POST** /api/v1/{environment}/MG/DocumentService/multiplecreate | Insert Multiple Documents for async process |
| [**ApiV1EnvironmentMGDocumentServiceMultiplecreatehistoryIdDelete**](DocumentServiceApi.md#apiv1environmentmgdocumentservicemultiplecreatehistoryiddelete) | **DELETE** /api/v1/{environment}/MG/DocumentService/multiplecreatehistory/{id} | Delete records for multiple insert documents by guid |
| [**ApiV1EnvironmentMGDocumentServiceMultiplecreatereprocessGuidPost**](DocumentServiceApi.md#apiv1environmentmgdocumentservicemultiplecreatereprocessguidpost) | **POST** /api/v1/{environment}/MG/DocumentService/multiplecreatereprocess/{guid} | Multiple Documents reprocess operations for async insert by guid |
| [**ApiV1EnvironmentMGDocumentServiceOrderavailabilityIdDelete**](DocumentServiceApi.md#apiv1environmentmgdocumentserviceorderavailabilityiddelete) | **DELETE** /api/v1/{environment}/MG/DocumentService/orderavailability/{id} | Delete record for async process portfolio orders |
| [**ApiV1EnvironmentMGDocumentServiceOrderavailabilityPost**](DocumentServiceApi.md#apiv1environmentmgdocumentserviceorderavailabilitypost) | **POST** /api/v1/{environment}/MG/DocumentService/orderavailability | Return Documents Order Portfolio |
| [**ApiV1EnvironmentMGDocumentServiceTransformPost**](DocumentServiceApi.md#apiv1environmentmgdocumentservicetransformpost) | **POST** /api/v1/{environment}/MG/DocumentService/transform | Document transformation based on the required parameters |

<a id="apiv1environmentmgdocumentservicedocprocessingstatuspost"></a>
# **ApiV1EnvironmentMGDocumentServiceDocprocessingstatusPost**
> DocumentoStatoEvasoMGDTO ApiV1EnvironmentMGDocumentServiceDocprocessingstatusPost (string loadEntireDomain, string environment, string authorizationScope, SearchDTO searchDTO, string getTotalCount = null, string company = null, string user = null, string acceptLanguage = null)

Return Document processing status

Document processing status

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ApiV1EnvironmentMGDocumentServiceDocprocessingstatusPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new DocumentServiceApi(config);
            var loadEntireDomain = "loadEntireDomain_example";  // string | Specify 'loadEntireDomain=true' if you want all the aggregate
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var searchDTO = new SearchDTO(); // SearchDTO | Search criteria to apply
            var getTotalCount = "getTotalCount_example";  // string | Specify 'getTotalCount=true' if you want the total number of elements (optional) 
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Return Document processing status
                DocumentoStatoEvasoMGDTO result = apiInstance.ApiV1EnvironmentMGDocumentServiceDocprocessingstatusPost(loadEntireDomain, environment, authorizationScope, searchDTO, getTotalCount, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling DocumentServiceApi.ApiV1EnvironmentMGDocumentServiceDocprocessingstatusPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentMGDocumentServiceDocprocessingstatusPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Return Document processing status
    ApiResponse<DocumentoStatoEvasoMGDTO> response = apiInstance.ApiV1EnvironmentMGDocumentServiceDocprocessingstatusPostWithHttpInfo(loadEntireDomain, environment, authorizationScope, searchDTO, getTotalCount, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling DocumentServiceApi.ApiV1EnvironmentMGDocumentServiceDocprocessingstatusPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **loadEntireDomain** | **string** | Specify &#39;loadEntireDomain&#x3D;true&#39; if you want all the aggregate |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **searchDTO** | [**SearchDTO**](SearchDTO.md) | Search criteria to apply |  |
| **getTotalCount** | **string** | Specify &#39;getTotalCount&#x3D;true&#39; if you want the total number of elements | [optional]  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**DocumentoStatoEvasoMGDTO**](DocumentoStatoEvasoMGDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The list of object of type as result of search |  -  |
| **400** | If the search criteria is not supplied |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentmgdocumentservicemultiplecreatepost"></a>
# **ApiV1EnvironmentMGDocumentServiceMultiplecreatePost**
> DocumentoTestataOutMGDTO ApiV1EnvironmentMGDocumentServiceMultiplecreatePost (string environment, string authorizationScope, List<GroupDocumentoTestataMGDTO> groupDocumentoTestataMGDTO, string force = null, bool withvalidpreconditions = null, string company = null, string user = null, string acceptLanguage = null)

Insert Multiple Documents for async process

Document async multiple process

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ApiV1EnvironmentMGDocumentServiceMultiplecreatePostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new DocumentServiceApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var groupDocumentoTestataMGDTO = new List<GroupDocumentoTestataMGDTO>(); // List<GroupDocumentoTestataMGDTO> | Object of type to create
            var force = "force_example";  // string | Force values (optional) 
            var withvalidpreconditions = true;  // bool | Validate Preconditions (optional) 
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Insert Multiple Documents for async process
                DocumentoTestataOutMGDTO result = apiInstance.ApiV1EnvironmentMGDocumentServiceMultiplecreatePost(environment, authorizationScope, groupDocumentoTestataMGDTO, force, withvalidpreconditions, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling DocumentServiceApi.ApiV1EnvironmentMGDocumentServiceMultiplecreatePost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentMGDocumentServiceMultiplecreatePostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Insert Multiple Documents for async process
    ApiResponse<DocumentoTestataOutMGDTO> response = apiInstance.ApiV1EnvironmentMGDocumentServiceMultiplecreatePostWithHttpInfo(environment, authorizationScope, groupDocumentoTestataMGDTO, force, withvalidpreconditions, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling DocumentServiceApi.ApiV1EnvironmentMGDocumentServiceMultiplecreatePostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **groupDocumentoTestataMGDTO** | [**List&lt;GroupDocumentoTestataMGDTO&gt;**](GroupDocumentoTestataMGDTO.md) | Object of type to create |  |
| **force** | **string** | Force values | [optional]  |
| **withvalidpreconditions** | **bool** | Validate Preconditions | [optional]  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**DocumentoTestataOutMGDTO**](DocumentoTestataOutMGDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **202** | Multiple Insert Accepted |  -  |
| **400** | In case of errors in the business logic: the content of the response contains the validation messages produced |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentmgdocumentservicemultiplecreatehistoryiddelete"></a>
# **ApiV1EnvironmentMGDocumentServiceMultiplecreatehistoryIdDelete**
> void ApiV1EnvironmentMGDocumentServiceMultiplecreatehistoryIdDelete (string id, string environment, string authorizationScope, string progress = null, string company = null, string user = null, string acceptLanguage = null)

Delete records for multiple insert documents by guid

Deleting object of type 

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ApiV1EnvironmentMGDocumentServiceMultiplecreatehistoryIdDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new DocumentServiceApi(config);
            var id = "id_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var progress = "progress_example";  // string | Force values (optional) 
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Delete records for multiple insert documents by guid
                apiInstance.ApiV1EnvironmentMGDocumentServiceMultiplecreatehistoryIdDelete(id, environment, authorizationScope, progress, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling DocumentServiceApi.ApiV1EnvironmentMGDocumentServiceMultiplecreatehistoryIdDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentMGDocumentServiceMultiplecreatehistoryIdDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete records for multiple insert documents by guid
    apiInstance.ApiV1EnvironmentMGDocumentServiceMultiplecreatehistoryIdDeleteWithHttpInfo(id, environment, authorizationScope, progress, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling DocumentServiceApi.ApiV1EnvironmentMGDocumentServiceMultiplecreatehistoryIdDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **progress** | **string** | Force values | [optional]  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object has been deleted |  -  |
| **400** | if object has not been deleted: the content response contains the validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |
| **409** | If object has not been deleted due to business rules violation: the content response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentmgdocumentservicemultiplecreatereprocessguidpost"></a>
# **ApiV1EnvironmentMGDocumentServiceMultiplecreatereprocessGuidPost**
> DocumentoTestataOutMGDTO ApiV1EnvironmentMGDocumentServiceMultiplecreatereprocessGuidPost (string guid, string environment, string authorizationScope, List<GroupDocumentoTestataMGDTO> groupDocumentoTestataMGDTO, string force = null, bool withvalidpreconditions = null, string company = null, string user = null, string acceptLanguage = null)

Multiple Documents reprocess operations for async insert by guid

Document async multiple reprocess

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ApiV1EnvironmentMGDocumentServiceMultiplecreatereprocessGuidPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new DocumentServiceApi(config);
            var guid = "guid_example";  // string | That's Guid Session MixMatch documents insert value
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var groupDocumentoTestataMGDTO = new List<GroupDocumentoTestataMGDTO>(); // List<GroupDocumentoTestataMGDTO> | Object of type to update
            var force = "force_example";  // string | Force values (optional) 
            var withvalidpreconditions = true;  // bool | Validate Preconditions (optional) 
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Multiple Documents reprocess operations for async insert by guid
                DocumentoTestataOutMGDTO result = apiInstance.ApiV1EnvironmentMGDocumentServiceMultiplecreatereprocessGuidPost(guid, environment, authorizationScope, groupDocumentoTestataMGDTO, force, withvalidpreconditions, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling DocumentServiceApi.ApiV1EnvironmentMGDocumentServiceMultiplecreatereprocessGuidPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentMGDocumentServiceMultiplecreatereprocessGuidPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Multiple Documents reprocess operations for async insert by guid
    ApiResponse<DocumentoTestataOutMGDTO> response = apiInstance.ApiV1EnvironmentMGDocumentServiceMultiplecreatereprocessGuidPostWithHttpInfo(guid, environment, authorizationScope, groupDocumentoTestataMGDTO, force, withvalidpreconditions, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling DocumentServiceApi.ApiV1EnvironmentMGDocumentServiceMultiplecreatereprocessGuidPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **guid** | **string** | That&#39;s Guid Session MixMatch documents insert value |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **groupDocumentoTestataMGDTO** | [**List&lt;GroupDocumentoTestataMGDTO&gt;**](GroupDocumentoTestataMGDTO.md) | Object of type to update |  |
| **force** | **string** | Force values | [optional]  |
| **withvalidpreconditions** | **bool** | Validate Preconditions | [optional]  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**DocumentoTestataOutMGDTO**](DocumentoTestataOutMGDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **202** | Multiple Documents Reprocess Accepted |  -  |
| **400** | In case of errors in the business logic: the content of the response contains the validation messages produced |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentmgdocumentserviceorderavailabilityiddelete"></a>
# **ApiV1EnvironmentMGDocumentServiceOrderavailabilityIdDelete**
> void ApiV1EnvironmentMGDocumentServiceOrderavailabilityIdDelete (string id, string environment, string authorizationScope, string company = null, string user = null, string acceptLanguage = null)

Delete record for async process portfolio orders

Deleting object of type 

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ApiV1EnvironmentMGDocumentServiceOrderavailabilityIdDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new DocumentServiceApi(config);
            var id = "id_example";  // string | 
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Delete record for async process portfolio orders
                apiInstance.ApiV1EnvironmentMGDocumentServiceOrderavailabilityIdDelete(id, environment, authorizationScope, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling DocumentServiceApi.ApiV1EnvironmentMGDocumentServiceOrderavailabilityIdDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentMGDocumentServiceOrderavailabilityIdDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete record for async process portfolio orders
    apiInstance.ApiV1EnvironmentMGDocumentServiceOrderavailabilityIdDeleteWithHttpInfo(id, environment, authorizationScope, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling DocumentServiceApi.ApiV1EnvironmentMGDocumentServiceOrderavailabilityIdDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **string** |  |  |
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If object has been deleted |  -  |
| **400** | if object has not been deleted: the content response contains the validation messages |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | If object not found |  -  |
| **409** | If object has not been deleted due to business rules violation: the content response contains the validation messages |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentmgdocumentserviceorderavailabilitypost"></a>
# **ApiV1EnvironmentMGDocumentServiceOrderavailabilityPost**
> DocumentoPortfolioEvadOrdineOutMGSetDTO ApiV1EnvironmentMGDocumentServiceOrderavailabilityPost (string environment, string authorizationScope, DocumentoPortfolioEvadInMGDTO documentoPortfolioEvadInMGDTO, string force = null, string company = null, string user = null, string acceptLanguage = null)

Return Documents Order Portfolio

Document processing status

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ApiV1EnvironmentMGDocumentServiceOrderavailabilityPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new DocumentServiceApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var documentoPortfolioEvadInMGDTO = new DocumentoPortfolioEvadInMGDTO(); // DocumentoPortfolioEvadInMGDTO | Object of type to validate
            var force = "force_example";  // string | Force values (optional) 
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Return Documents Order Portfolio
                DocumentoPortfolioEvadOrdineOutMGSetDTO result = apiInstance.ApiV1EnvironmentMGDocumentServiceOrderavailabilityPost(environment, authorizationScope, documentoPortfolioEvadInMGDTO, force, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling DocumentServiceApi.ApiV1EnvironmentMGDocumentServiceOrderavailabilityPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentMGDocumentServiceOrderavailabilityPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Return Documents Order Portfolio
    ApiResponse<DocumentoPortfolioEvadOrdineOutMGSetDTO> response = apiInstance.ApiV1EnvironmentMGDocumentServiceOrderavailabilityPostWithHttpInfo(environment, authorizationScope, documentoPortfolioEvadInMGDTO, force, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling DocumentServiceApi.ApiV1EnvironmentMGDocumentServiceOrderavailabilityPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **documentoPortfolioEvadInMGDTO** | [**DocumentoPortfolioEvadInMGDTO**](DocumentoPortfolioEvadInMGDTO.md) | Object of type to validate |  |
| **force** | **string** | Force values | [optional]  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**DocumentoPortfolioEvadOrdineOutMGSetDTO**](DocumentoPortfolioEvadOrdineOutMGSetDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Portfolio Resultset Data |  -  |
| **400** | In case of errors in the business logic: the content of the response contains the validation messages produced |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentmgdocumentservicetransformpost"></a>
# **ApiV1EnvironmentMGDocumentServiceTransformPost**
> DocumentTransformationParameterDTO ApiV1EnvironmentMGDocumentServiceTransformPost (string environment, string authorizationScope, DocumentTransformationParameterDTO documentTransformationParameterDTO, string force = null, string company = null, string user = null, string acceptLanguage = null)

Document transformation based on the required parameters

Document transformation based on the required parameters

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ApiV1EnvironmentMGDocumentServiceTransformPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new DocumentServiceApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var documentTransformationParameterDTO = new DocumentTransformationParameterDTO(); // DocumentTransformationParameterDTO | Document transformation parameters
            var force = "force_example";  // string | Force values (optional) 
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Document transformation based on the required parameters
                DocumentTransformationParameterDTO result = apiInstance.ApiV1EnvironmentMGDocumentServiceTransformPost(environment, authorizationScope, documentTransformationParameterDTO, force, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling DocumentServiceApi.ApiV1EnvironmentMGDocumentServiceTransformPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentMGDocumentServiceTransformPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Document transformation based on the required parameters
    ApiResponse<DocumentTransformationParameterDTO> response = apiInstance.ApiV1EnvironmentMGDocumentServiceTransformPostWithHttpInfo(environment, authorizationScope, documentTransformationParameterDTO, force, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling DocumentServiceApi.ApiV1EnvironmentMGDocumentServiceTransformPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **documentTransformationParameterDTO** | [**DocumentTransformationParameterDTO**](DocumentTransformationParameterDTO.md) | Document transformation parameters |  |
| **force** | **string** | Force values | [optional]  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

[**DocumentTransformationParameterDTO**](DocumentTransformationParameterDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Document transformation result |  -  |
| **400** | In case of errors in the business logic: the content of the response contains the validation messages produced |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

