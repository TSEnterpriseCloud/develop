# Org.OpenAPITools.Model.DocumentoTestataProvvigioniMGDTO
DO21_DOCTESTAPROV - Documento e provvigione generata da gestione documenti o altro<br>Proprietà chiave:<ul><li><b>DittaCg18</b></li><li><b>IdagenteMg17</b></li><li><b>NumregCo99</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdagenteMg17** | **int** | DO21_IDAGENTE_MG17 - ID Agente | 
**Imponprov** | **double** | DO21_IMPONPROV - Imponibile provvigione | 
**Imporprov** | **double** | DO21_IMPORPROV - Importo provvigione | 
**NumregCo99** | **string** | DO21_NUMREG_CO99 - Numero registrazione | 
**Provmedia** | **double** | DO21_PROVMEDIA - Percentuale provvigione media | 
**AnnoPa23** | **double** | DO21_ANNO_PA23 - Anno distinta trimestrale ENASARCO | [optional] 
**CodiceAgente** | **string** | Codice agente | [optional] 
**DittaCg18** | **double** | DO21_DITTA_CG18 - Codice ditta | [optional] [default to 0D]
**FlgPers** | **double** | DO21_FLGPERS - FlgPers | [optional] 
**FlgProvsosp** | **double** | DO21_FLGPROVSOSP - Flag provvigione sospesa&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgProvvar** | **double** | DO21_FLGPROVVAR - Flag provvigione variata manualmente&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgSt** | **double** | DO21_FLGST - FlgSt | [optional] 
**FlgStarcred** | **double** | DO21_FLGSTARCRED - Flag movimento di provvigione soggetta allo star del credere&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgStenas** | **double** | DO21_FLGSTENAS - Flag stampata distinta enasarco&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IdmediaCg99** | **double** | DO21_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**ImponprovVal** | **double** | DO21_IMPONPROV_VAL - Imponibile provvigione in valuta | [optional] [default to 0D]
**ImporprovVal** | **double** | DO21_IMPORPROV_VAL - Importo provvigione in valuta | [optional] [default to 0D]
**IndPers** | **double** | DO21_INDPERS - IndPers | [optional] 
**IndSt** | **double** | DO21_INDST - IndSt | [optional] 
**IndTipomov** | **double** | DO21_INDTIPOMOV - Movim.gen.da | [optional] [default to 0D]
**Noteprov** | **string** | DO21_NOTEPROV - Note provvigioni | [optional] 
**TrimestrePa23** | **double** | DO21_TRIMESTRE_PA23 - Trimestre distinta | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

