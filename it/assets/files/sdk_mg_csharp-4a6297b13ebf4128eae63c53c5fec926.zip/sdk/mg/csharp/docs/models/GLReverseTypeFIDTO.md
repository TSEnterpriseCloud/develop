# Org.OpenAPITools.Model.GLReverseTypeFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ReverseTypeCode** | **int** |  | [optional] 
**ReverseTypeDescription** | **string** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

