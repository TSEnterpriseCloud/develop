# Org.OpenAPITools.Model.DMSPublishedEntityFWDTO
Stato attuale di un'entità.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Guid** | **Guid** | Guid entità. | [optional] 
**TipoarchHm30** | **int** | Tipologia entità. | [optional] 
**Idknos** | **int** | Id Knos. | [optional] 
**DittaCg18** | **double** | Azienda | [optional] 
**Protocollo** | **string** | Prtocollo | [optional] 
**FlgInvalid** | **int** | Flag invalido | [optional] 
**Percorso** | **string** | Path | [optional] 
**Nome** | **string** | File name | [optional] 
**Datapub** | **DateTime** | Data pubblicazione | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

