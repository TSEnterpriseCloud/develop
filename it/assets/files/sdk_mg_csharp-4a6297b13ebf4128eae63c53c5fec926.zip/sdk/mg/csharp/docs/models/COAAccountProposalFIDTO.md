# Org.OpenAPITools.Model.COAAccountProposalFIDTO
CG36_PRSPDC - Proposta conti CoGe<br>Proprietà chiave:<ul><li><b>Codice</b></li><li><b>GruppoCg10</b></li><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codice** | **double** | CG36_CODICE - Codice proposta conti | 
**ContoCg24** | **string** | CG36_CONTO_CG24 - Codice conto | 
**GruppoCg10** | **double** | CG36_GRUPPO_CG10 - Piano dei conti | 
**IdCg24** | **long** | CG36_ID_CG24 - ID Conto | 
**CoaAccountFI** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | 
**Id** | **long** | CG36_ID - ID (Required only in PUT/PATCH) | [optional] 
**Rowversion** | **byte[]** | CG36_ROWVERSION - RowVersion | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

