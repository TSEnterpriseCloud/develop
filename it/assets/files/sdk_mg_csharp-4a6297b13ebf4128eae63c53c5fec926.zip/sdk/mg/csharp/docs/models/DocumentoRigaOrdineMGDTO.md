# Org.OpenAPITools.Model.DocumentoRigaOrdineMGDTO
DO31_DOCCORPOORD - Corpo dati ordini<br>Proprietà chiave:<ul><li><b>DittaCg18</b></li><li><b>NumregCo99</b></li><li><b>ProgRiga</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NumregCo99** | **string** | DO31_NUMREG_CO99 - Numero registrazione | 
**ProgRiga** | **double** | DO31_PROGRIGA - Progressivo Riga | 
**CodPiano** | **string** | DO31_CODPIANO - Codice piano | [optional] 
**CodTraclegdb** | **string** | DO31_CODTRACLEGDB - Codice tracciabilità legame distinta | [optional] 
**CodTraclegwbs** | **string** | DO31_CODTRACLEGWBS - Codice tracciabilità legame WBS | [optional] 
**Collicons** | **double** | DO31_COLLICONS - Colli consegnati | [optional] [default to 0D]
**Collitrasfddtcl** | **double** | DO31_COLLITRASFDDTCL - Colli trasf. conto lavoro | [optional] 
**Collitrasfp** | **double** | DO31_COLLITRASFP - Colli trasf.p. | [optional] 
**ContpcarPd79** | **double** | DO31_CONTPCAR_PD79 - Piano carico | [optional] 
**Datacons** | **DateTime** | DO31_DATACONS - Data consegna | [optional] 
**Dataconsint** | **DateTime** | DO31_DATACONSINT - Data consegna interna | [optional] 
**Dataconsorig** | **DateTime** | DO31_DATACONSORIG - Data consegna origine corpo | [optional] 
**Datafineoap** | **DateTime** | DO31_DATAFINEOAP - Data fine validità ordine aperto | [optional] 
**Datainizlav** | **DateTime** | DO31_DATAINIZLAV - Data inizio lavorazione | [optional] 
**Datainizoap** | **DateTime** | DO31_DATAINIZOAP - Data inizio validità ordine aperto | [optional] 
**Datalancio** | **DateTime** | DO31_DATALANCIO - Data lancio | [optional] 
**Datapianif** | **DateTime** | DO31_DATAPIANIF - Data pianificazione | [optional] 
**DittaCg18** | **double** | DO31_DITTA_CG18 - Ditta | [optional] [default to 0D]
**FlgConsconf** | **int** | DO31_FLGCONSCONF - Flag consegna confermata&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgNoevasparz** | **int** | DO31_FLGNOEVASPARZ - Flag no evasione parziale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgNonpiuev** | **int** | DO31_FLGNONPIUEV - Riga non piu evadibile&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgNosugg** | **int** | DO31_FLGNOSUGG - Flag no suggerimento in MRP&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgRicpreev** | **int** | DO31_FLGRICPREEV - Flag ricalcolo prezzi in evasione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgSospriga** | **int** | DO31_FLGSOSPRIGA - Flag riga sospesa&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Ggtollercons** | **double** | DO31_GGTOLLERCONS - Giorni di tolleranza consegna | [optional] 
**IndEvasdescsp** | **int** | DO31_INDEVASDESCSP - Indicatore evasione descrizioni e spese | [optional] [default to 0]
**IndStatocons** | **int** | DO31_INDSTATOCONS - Indicatore stato consegnato | [optional] [default to 0]
**IndStatodescsp** | **int** | DO31_INDSTATODESCSP - Indicatore stato trasf. descrizioni e spese | [optional] [default to 0]
**Numpiano** | **double** | DO31_NUMPIANO - Numero piano | [optional] 
**NumpropPd39** | **double** | DO31_NUMPROP_PD39 - Numero proposta | [optional] 
**ProgRigpiaPd80** | **double** | DO31_PROGRIGPIA_PD80 - Progressivo riga piano consegna | [optional] 
**Qta1cons** | **double** | DO31_QTA1CONS - Quantità consegnata | [optional] [default to 0D]
**Qta1lanc** | **double** | DO31_QTA1LANC - Quantità consegnata alla data lancio | [optional] [default to 0D]
**Qta1prel** | **double** | DO31_QTA1PREL - Quantità 1 prelevata | [optional] [default to 0D]
**Qta1trasfddtcl** | **double** | DO31_QTA1TRASFDDTCL - Quantità 1 trasf. conto lavoro | [optional] 
**Qta1trasfp** | **double** | DO31_QTA1TRASFP - Qta 1 trasf.p. | [optional] 
**Qta2cons** | **double** | DO31_QTA2CONS - Quantità consegnata 2 | [optional] [default to 0D]
**Qta2lanc** | **double** | DO31_QTA2LANC - Quantità consegnata alla data lancio | [optional] [default to 0D]
**Qta2prel** | **double** | DO31_QTA2PREL - Quantità 2 prelevata | [optional] [default to 0D]
**Qta2trasfddtcl** | **double** | DO31_QTA2TRASFDDTCL - Quantità 2 trasf. conto lavoro | [optional] 
**Qta2trasfp** | **double** | DO31_QTA2TRASFP - Qta 2 trasf.p. | [optional] 
**Valorecons** | **double** | DO31_VALORECONS - Valore cons. | [optional] [default to 0D]
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

