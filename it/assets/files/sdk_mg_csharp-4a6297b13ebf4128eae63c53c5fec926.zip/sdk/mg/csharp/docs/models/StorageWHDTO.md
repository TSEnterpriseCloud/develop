# Org.OpenAPITools.Model.StorageWHDTO
MG58_DEPOSITI - Deposito<br>Proprietà chiave:<ul><li><b>CodDep</b></li><li><b>DittaCg18</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodDep** | **string** | MG58_CODDEP - Codice deposito | 
**Dataatt** | **DateTime** | MG58_DATAATT - Data attivazione | 
**Capdep** | **string** | MG58_CAPDEP - Cap | [optional] 
**Datacess** | **DateTime** | MG58_DATACESS - Data cessazione | [optional] 
**Descrdep** | **string** | MG58_DESCRDEP - Descrizione | [optional] 
**DittaCg18** | **double** | MG58_DITTA_CG18 - Ditta | [optional] [default to 0D]
**Faxnumdep** | **string** | MG58_FAXNUMDEP - Fax | [optional] 
**FlgDepprinc** | **double** | MG58_FLGDEPPRINC - Deposito principale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to 0D]
**IndEmail** | **string** | MG58_INDEMAIL - Email | [optional] 
**IndIdep** | **string** | MG58_INDIDEP - Indirizzo deposito | [optional] 
**IndInterest** | **double** | MG58_INDINTEREST - Tipo deposito&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Interno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Esterno&lt;/li&gt;&lt;/ul&gt; | [optional] [default to 0D]
**Locdep** | **string** | MG58_LOCDEP - Località | [optional] 
**Provdep** | **string** | MG58_PROVDEP - Prov. | [optional] 
**Respdep** | **string** | MG58_RESPDEP - Responsabile | [optional] 
**Telnumdep** | **string** | MG58_TELNUMDEP - Telefono | [optional] 
**LocationWH** | [**List&lt;LocationWHDTO&gt;**](LocationWHDTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

