# Org.OpenAPITools.Model.IntragroupStructureCODTO
CGC0_STRUTINFRAGRUPPO - IntragroupStructureCO<br>Proprietà chiave:<ul><li><b>Codice</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codice** | **double** | CGC0_CODICE - Codice | 
**CodAnagGen** | **int** | Codice anagrafica | [optional] 
**CodIntercompany** | **int** | Codice intercompany | [optional] 
**Descr** | **string** | CGC0_DESCR - Descrizione | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

