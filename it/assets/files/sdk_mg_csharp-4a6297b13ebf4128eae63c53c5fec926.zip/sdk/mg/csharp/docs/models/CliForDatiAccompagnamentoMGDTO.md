# Org.OpenAPITools.Model.CliForDatiAccompagnamentoMGDTO
MG27_CLIFORACC - Dati di accompagnamento<br>Proprietà chiave:<ul><li><b>CliforCg44</b></li><li><b>DittaCg18</b></li><li><b>TipocfCg44</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CliforCg44** | **double** | MG27_CLIFOR_CG44 - Codice Cliente / Fornitore | 
**TipocfCg44** | **double** | MG27_TIPOCF_CG44 - Tipo Cliente / Fornitore | 
**AspettoMg99** | **string** | MG27_ASPETTO_MG99 - Aspetto dei beni | [optional] 
**DittaCg18** | **double** | MG27_DITTA_CG18 - Ditta | [optional] [default to 0D]
**IdmediaCg99** | **double** | MG27_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**ImballoMg95** | **string** | MG27_IMBALLO_MG95 - Codice Imballo | [optional] 
**PortoMg91** | **string** | MG27_PORTO_MG91 - Codice Porto | [optional] 
**SpedizMg15** | **string** | MG27_SPEDIZ_MG15 - Codice Spedizioniere | [optional] 
**TipospedMg93** | **string** | MG27_TIPOSPED_MG93 - Codice tipo spedizione | [optional] 
**Vett1Mg14** | **string** | MG27_VETT1_MG14 - Codice Vettore 1 | [optional] 
**Vett2Mg14** | **string** | MG27_VETT2_MG14 - Codice Vettore 2 | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

