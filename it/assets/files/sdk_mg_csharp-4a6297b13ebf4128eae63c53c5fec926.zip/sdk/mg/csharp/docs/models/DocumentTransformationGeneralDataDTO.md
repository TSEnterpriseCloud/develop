# Org.OpenAPITools.Model.DocumentTransformationGeneralDataDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**QtaTransf** | **double** | QTATRANSF - Transformation Qta  | 
**ProgrRiga** | **double** | ProgrRiga - Progr. Row | [optional] 
**Indtiporiga** | **int** | INDTIPORIGA - Indicatore tipo riga&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Warehouse item&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Manual article management of all fields&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Descriptive&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Expense&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Multiple tab&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Fixed text&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Letter of intent&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Phase&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Deposits&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Article + phase&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - Node&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - Activity&lt;/li&gt;&lt;li&gt;&lt;i&gt;17&lt;/i&gt; - Project expense&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Descart** | **string** | DESCART - Row Description | [optional] 
**CodartMg66** | **string** | CODART_MG66 - CodartMg66 | [optional] 
**Price1** | **double** | Price1 - Price1 in transformation | [optional] 
**Price2** | **double** | Price2 - Price2 in transformation | [optional] 
**Scper1** | **double** | Scper1 - Discount 1 in % | [optional] 
**Scper2** | **double** | Scper2 - Discount 2 in % | [optional] 
**ScImp** | **double** | SctImp - Discount in value | [optional] 
**Increase1** | **double** | Increase1 - Increase 1 in % | [optional] 
**Increase2** | **double** | Increase2 - Increase 2 in % | [optional] 
**IncreaseImp** | **double** | IncreaseImp - Taxable increase in % | [optional] 
**RowNotEvad** | **bool** | RowNotEvad - Row will be not evadible | [optional] [default to false]

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

