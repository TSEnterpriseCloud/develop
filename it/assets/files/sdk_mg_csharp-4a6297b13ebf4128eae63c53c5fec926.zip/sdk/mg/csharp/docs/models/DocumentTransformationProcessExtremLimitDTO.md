# Org.OpenAPITools.Model.DocumentTransformationProcessExtremLimitDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AcceptDocMode** | **int** | AcceptDocMode (Combo filter criteria)&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Initial request only&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Initial request and proposal before generation&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Only request before generation&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Source document numbering replication&lt;/li&gt;&lt;/ul&gt; | [optional] 
**DestinationDocParams** | [**DocumentTransfomationDocDestParamsDTO**](DocumentTransfomationDocDestParamsDTO.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

