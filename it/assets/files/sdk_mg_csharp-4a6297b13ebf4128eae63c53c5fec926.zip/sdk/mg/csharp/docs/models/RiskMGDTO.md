# Org.OpenAPITools.Model.RiskMGDTO
MG2A_RISCHIO - Controllo rischio<br>Proprietà chiave:<ul><li><b>Codice</b></li><li><b>DittaCg18</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codice** | **string** | MG2A_CODICE - Codice rischio | 
**Descrizione** | **string** | MG2A_DESCRIZIONE - Descrizione | [optional] 
**DittaCg18** | **double** | MG2A_DITTA_CG18 - Ditta | [optional] [default to 0D]
**FlgAttivo** | **double** | MG2A_FLGATTIVO - Condizione attiva&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgCalceffcons** | **double** | MG2A_FLGCALCEFFCONS - Elaborazione scadenze consolidate&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgCalceffdacons** | **double** | MG2A_FLGCALCEFFDACONS - Includi scadenze da consolidare&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgCalceffprev** | **double** | MG2A_FLGCALCEFFPREV - Includi scadenze previsionali&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgCalcmovcons** | **double** | MG2A_FLGCALCMOVCONS - Includi movimenti consolidati nel calcolo del saldo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgCalcmovdacons** | **double** | MG2A_FLGCALCMOVDACONS - Includi movimenti da consolidare nel calcolo del saldo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgCalcmovprev** | **double** | MG2A_FLGCALCMOVPREV - Includi movimenti previsionali nel calcolo del saldo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgEffettiscaduti** | **double** | MG2A_FLGEFFETTISCADUTI - Includi effetti  da liberalizzare nel valore del fido&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgOrdini** | **double** | MG2A_FLGORDINI - Includi ordini non evasi nel valore del fido&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgSaldocon** | **double** | MG2A_FLGSALDOCON - Includi saldo contabile nel valore del fido&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgScadereins** | **double** | MG2A_FLGSCADEREINS - Includi effetti a scadere insoluti nel valore del fido&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgScaderenoins** | **double** | MG2A_FLGSCADERENOINS - Includi effetti a scadere non insoluti nel valore del fido&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgScadutoins** | **double** | MG2A_FLGSCADUTOINS - Includi effetti scaduti insoluti nel valore del fido&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgScadutonoins** | **double** | MG2A_FLGSCADUTONOINS - Includi effetti scaduti non insoluti nel valore del fido&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgSelclifortrasf** | **double** | MG2A_FLGSELCLIFORTRASF - Blocco selezione clienti/fornitori in trasformazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgSolobusinesriskattivo** | **double** | MG2A_FLGSOLOBUSINESRISKATTIVO - FlgSolobusinesriskattivo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndAttivatrasf** | **double** | MG2A_INDATTIVATRASF - Modalità di attivazione su trasformazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Tutti selezionati&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Tutti,con fuori fido deselezionati&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Solo fuori fido selezionati&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Solo fuori fido deselezionati&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Escludi fuori fido in automatico&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndElabscadinsol** | **double** | MG2A_INDELABSCADINSOL - Tipo elaborazione scadenze insolute&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Tutte le scadenze&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Solo scadenze aperte&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Solo scadenze chiuse&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndProvenienzafido** | **double** | MG2A_INDPROVENIENZAFIDO - Indicatore provenienza fido&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Fido cliente/Fido ass.credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Fido ass.credito/Fido cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Fido cliente + Fido ass.rischio&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndSegnalazionecorpo** | **double** | MG2A_INDSEGNALAZIONECORPO - Modalità segnalazione fuori fido su corpo documento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Segnalazione semplice&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Segnalazione con valori&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Segnalazione completa&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Mesiricdocdafatt** | **double** | MG2A_MESIRICDOCDAFATT - Mesi retroattivi recupero doc. da fatturare | [optional] 
**Mesiricordini** | **double** | MG2A_MESIRICORDINI - Mesi retroattivi recupero doc. da evadere | [optional] 
**Mesiricscadenze** | **double** | MG2A_MESIRICSCADENZE - Mesi retroattivi recupero scadenze da recuperare | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

