# Org.OpenAPITools.Model.SearchLogicalOperators
Logical operator: And = 1, Or = 2, Not = 3

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

