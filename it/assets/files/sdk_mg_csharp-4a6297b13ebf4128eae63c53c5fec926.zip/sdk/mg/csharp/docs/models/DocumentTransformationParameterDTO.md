# Org.OpenAPITools.Model.DocumentTransformationParameterDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NumRegOrigin** | **List&lt;string&gt;** | NumRegOrigin | 
**CodModelTransfDoc** | **string** | CodModelTransfDoc | 
**ProcessExtremLimits** | [**DocumentTransformationProcessExtremLimitDTO**](DocumentTransformationProcessExtremLimitDTO.md) |  | [optional] 
**RowSearchTransformationCriteria** | [**SearchDTO**](SearchDTO.md) |  | [optional] 
**DocumentTransformationPartialEvadContainerGeneralData** | [**List&lt;DocumentTransformationPartialEvadContainerGeneralDataDTO&gt;**](DocumentTransformationPartialEvadContainerGeneralDataDTO.md) | Additional Document Body General Data for partial Data Evad. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

