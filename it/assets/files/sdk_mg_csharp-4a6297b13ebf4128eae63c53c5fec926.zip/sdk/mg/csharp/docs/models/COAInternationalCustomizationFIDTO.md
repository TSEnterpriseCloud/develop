# Org.OpenAPITools.Model.COAInternationalCustomizationFIDTO
CG2D_PDCLOCALIZ - Localizzazione conto<br>Proprietà chiave:<ul><li><b>Id</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ContoCg24** | **string** | CG2D_CONTO_CG24 - Codice conto | 
**GruppoCg10** | **double** | CG2D_GRUPPO_CG10 - Piano dei conti | 
**IdCg24** | **long** | CG2D_ID_CG24 - ID Conto | 
**Iso3166A2** | **string** | CG2D_ISO3166_A2 - Localizzazione | 
**Categoria** | **int** | CG2D_CATEGORIA - Categoria conto | [optional] 
**EsModulo347** | **int** | CG2D_ES_MODULO347 - Escludi mod.347 | [optional] 
**GbDeferralcode** | **string** | CG2D_GB_DEFERRALCODE - Deferral code | [optional] 
**Id** | **long** | CG2D_ID - ID (Required only in PUT/PATCH) | [optional] 
**Rowversion** | **byte[]** | CG2D_ROWVERSION - RowVersion | [optional] 
**Subcategoria** | **int** | CG2D_SUBCATEGORIA - Sottocategoria | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

