# Org.OpenAPITools.Model.DocumentoRigaProgettiMGDTO
DO41_DOCCORPOPROGE - Dati progetto<br>Proprietà chiave:<ul><li><b>DittaCg18</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AttivitaPd0d** | **string** | DO41_ATTIVITA_PD0D - Codice Attività | [optional] 
**CodCommessa** | **string** | DO41_CODCOMMESSA - Codice commessa | [optional] 
**CodDipPd06** | **string** | DO41_CODDIP_PD06 - Codice dipendente | [optional] 
**CodProgcol** | **string** | DO41_CODPROGCOL - Codice progetto collegato | [optional] 
**CodProgetto** | **string** | DO41_CODPROGETTO - Codice progetto | [optional] 
**CodScommessa** | **double** | DO41_CODSCOMMESSA - Codice sottocommessa | [optional] 
**CodSprogcol** | **double** | DO41_CODSPROGCOL - Codice sottoprogetto collegato | [optional] 
**CodSprogetto** | **double** | DO41_CODSPROGETTO - Codice sottoprogetto | [optional] 
**DittaCg18** | **double** | DO41_DITTA_CG18 - Codice ditta | [optional] [default to 0D]
**IdartepuVc02** | **int** | DO41_IDARTEPU_VC02 - Articolo EPU | [optional] 
**IdattrezzaturaVc02** | **int** | DO41_IDATTREZZATURA_VC02 - IDAttrezzatura | [optional] 
**Idmedia** | **double** | DO41_IDMEDIA - ID HyperMedia | [optional] 
**NodoPd0c** | **string** | DO41_NODO_PD0C - Codice Nodo | [optional] 
**NodorifcolPd0c** | **string** | DO41_NODORIFCOL_PD0C - Codice nodo di riferimento collegato | [optional] 
**NodorifPd0c** | **string** | DO41_NODORIF_PD0C - Codice Nodo di riferimento | [optional] 
**SpesaPd64** | **string** | DO41_SPESA_PD64 - Codice spese accessorie | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

