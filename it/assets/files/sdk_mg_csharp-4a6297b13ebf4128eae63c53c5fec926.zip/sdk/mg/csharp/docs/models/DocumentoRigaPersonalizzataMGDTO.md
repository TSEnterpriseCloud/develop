# Org.OpenAPITools.Model.DocumentoRigaPersonalizzataMGDTO
DO35_DOCCORPOPERS - Dati personalizzati di riga<br>Proprietà chiave:<ul><li><b>DittaCg18</b></li><li><b>NumregCo99</b></li><li><b>Prog</b></li><li><b>ProgRiga</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NumregCo99** | **string** | DO35_NUMREG_CO99 - Numero registrazione | 
**ProgRiga** | **double** | DO35_PROGRIGA - Progressivo Riga | 
**Alfpers1** | **string** | DO35_ALFPERS1 - Alfanumerico 1 applicazioni pers. | [optional] 
**Alfpers10** | **string** | DO35_ALFPERS10 - Alfanumerico 10 | [optional] 
**Alfpers11** | **string** | DO35_ALFPERS11 - Alfanumerico 11 | [optional] 
**Alfpers12** | **string** | DO35_ALFPERS12 - Alfanumerico 12 | [optional] 
**Alfpers2** | **string** | DO35_ALFPERS2 - Alfanumerico 2 applicazioni pers. | [optional] 
**Alfpers3** | **string** | DO35_ALFPERS3 - Alfanumerico 3 applicazioni pers. | [optional] 
**Alfpers4** | **string** | DO35_ALFPERS4 - Alfanumerico 4 applicazioni pers. | [optional] 
**Alfpers5** | **string** | DO35_ALFPERS5 - Alfanumerico 5 | [optional] 
**Alfpers6** | **string** | DO35_ALFPERS6 - Alfanumerico 6 | [optional] 
**Alfpers7** | **string** | DO35_ALFPERS7 - Alfanumerico 7 | [optional] 
**Alfpers8** | **string** | DO35_ALFPERS8 - Alfanumerico 8 | [optional] 
**Alfpers9** | **string** | DO35_ALFPERS9 - Alfanumerico 9 | [optional] 
**Datapers1** | **DateTime** | DO35_DATAPERS1 - Data personalizzabile 1 | [optional] 
**Datapers2** | **DateTime** | DO35_DATAPERS2 - Data personalizzabile 2 | [optional] 
**Datapers3** | **DateTime** | DO35_DATAPERS3 - Data 3 | [optional] 
**Datapers4** | **DateTime** | DO35_DATAPERS4 - Data 4 | [optional] 
**Datapers5** | **DateTime** | DO35_DATAPERS5 - Data 5 | [optional] 
**Datapers6** | **DateTime** | DO35_DATAPERS6 - Data 6 | [optional] 
**DittaCg18** | **double** | DO35_DITTA_CG18 - Ditta | [optional] [default to 0D]
**FlgPers1** | **double** | DO35_FLGPERS1 - Flag personalizzabile 1 | [optional] 
**FlgPers2** | **double** | DO35_FLGPERS2 - Flag personalizzabile 2 | [optional] 
**FlgPers3** | **double** | DO35_FLGPERS3 - Flag personalizzabile 3 | [optional] 
**FlgPers4** | **double** | DO35_FLGPERS4 - Flag personalizzabile 4 | [optional] 
**IdmediaCg99** | **double** | DO35_IDMEDIA_CG99 - Hypermedia | [optional] 
**IndPers1** | **double** | DO35_INDPERS1 - Indicatore 1 personalizzabile | [optional] 
**IndPers2** | **double** | DO35_INDPERS2 - Indicatore 2 personalizzabile | [optional] 
**Numpers1** | **double** | DO35_NUMPERS1 - Numerico 1 applicazioni pers. | [optional] 
**Numpers10** | **double** | DO35_NUMPERS10 - Numerico 10 | [optional] 
**Numpers11** | **double** | DO35_NUMPERS11 - Numerico 11 | [optional] 
**Numpers12** | **double** | DO35_NUMPERS12 - Numerico 12 | [optional] 
**Numpers2** | **double** | DO35_NUMPERS2 - Numerico 2 applicazioni pers. | [optional] 
**Numpers3** | **double** | DO35_NUMPERS3 - Numerico 3 applicazioni pers. | [optional] 
**Numpers4** | **double** | DO35_NUMPERS4 - Numerico 4 applicazioni pers. | [optional] 
**Numpers5** | **double** | DO35_NUMPERS5 - Numerico 5 | [optional] 
**Numpers6** | **double** | DO35_NUMPERS6 - Numerico 6 | [optional] 
**Numpers7** | **double** | DO35_NUMPERS7 - Numerico 7 | [optional] 
**Numpers8** | **double** | DO35_NUMPERS8 - Numerico 8 | [optional] 
**Numpers9** | **double** | DO35_NUMPERS9 - Numerico 9 | [optional] 
**Prog** | **double** | DO35_PROG - Progressivo | [optional] [default to 1D]
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

