# Org.OpenAPITools.Model.DocumentTransfomationDocDestParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DataReg** | **DateTime** | DataReg (In compile: Registration Data) | [optional] 
**DataDoc** | **DateTime** | DataDoc (In compile: Document Data) | [optional] 
**DataCompVatMan** | **DateTime** | DataCompVatMan (In compile: Manual Vat compilation Data) | [optional] 
**Sezdoc** | **string** | SezDoc - In compile: (In compile: Sez. for Document) | [optional] 
**NumDoc** | **double** | NumDoc (In compile: Document number) | [optional] 
**NumDocOrig** | **double** | NumDocOrig (In compile: Document orig. number) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

