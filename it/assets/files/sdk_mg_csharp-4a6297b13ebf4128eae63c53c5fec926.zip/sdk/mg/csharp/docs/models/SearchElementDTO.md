# Org.OpenAPITools.Model.SearchElementDTO
DTO that identifies a search criteria

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PropertyName** | **string** | Property on witch apply the filter | 
**Comparer** | **SearchComparer** |  | 
**Value** | **Object** |  | 
**Operator** | **SearchLogicalOperators** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

