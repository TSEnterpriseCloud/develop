# TseCloudFw.PgmExecDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idTaskScheduled** | **String** | Id for Scheduled Task | [optional] 
**timeoutSeconds** | **Number** | Timeout in seconds for Scheduled Task | [optional] 
**skipIfRunning** | **Boolean** | Skip if a task with same id is running | [optional] 


