# TseCloudFi.AgentCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agente** | **String** | MG17_AGENTE - Agente | 
**anagenCg16** | **Number** | MG17_ANAGEN_CG16 - Codice anagrafica generale | 
**datafineman** | **Date** | MG17_DATAFINEMAN - Data fine mandato | [optional] 
**datainman** | **Date** | MG17_DATAINMAN - Data inizio mandato | [optional] 
**datainrapp** | **Date** | MG17_DATAINRAPP - Data inizio rapporto | [optional] 
**dittaCg18** | **Number** | MG17_DITTA_CG18 - Ditta | 
**flgAdegdelta** | **Number** | MG17_FLGADEGDELTA - Adeguamento provvigioni in funzione del delta della riga documento | [optional] 
**flgAdeguamscmag** | **Number** | MG17_FLGADEGUAMSCMAG - Adeguamento provvigioni per sconti/maggiorazioni | [optional] 
**flgRegimeart** | **Number** | MG17_FLGREGIMEART - Reg. provv. dell&#39;articolo | [optional] [default to 0]
**flgRegimecl** | **Number** | MG17_FLGREGIMECL - Reg. provv. del cliente | [optional] [default to 0]
**guid** | **String** | MG17_GUID - GUID | [optional] 
**idagente** | **Number** | MG17_IDAGENTE - ID (Required only in PUT/PATCH) | [optional] 
**idcapoareaMg17** | **Number** | MG17_IDCAPOAREA_MG17 - Capo area dell&#39;agente | [optional] 
**idcapozonaMg17** | **Number** | MG17_IDCAPOZONA_MG17 - Capo zona dell&#39;agente | [optional] 
**idmediaCg99** | **Number** | MG17_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**indBaseimpmag** | **Number** | MG17_INDBASEIMPMAG - Base impon. provv. mag.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Imponibile provvigione&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Imponib. provv. - Importo provv. gia&#39; calcolato&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Diff. pr. determinato per il calcolo dello sconto&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Impor. provv. calcolato prima dell&#39;adeguamento&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indBaseimpsc** | **Number** | MG17_INDBASEIMPSC - Base impon. provv. sc.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Imponibile provvigione&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Imponib. provv. - Importo provv. gia&#39; calcolato&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Diff. pr. determinato per il calcolo dello sconto&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Impor. provv. calcolato prima dell&#39;adeguamento&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indCalcscmag** | **Number** | MG17_INDCALCSCMAG - Calcolo sconto/magg.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Pr. ven./acq. calcolato da priorita&#39; prezzi-Pr. doc.&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Pr. di list. anag. art. indicato sul cli./for-Pr. doc.&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Sconti o magg. effettivi indicati sul documento&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indPrefstdoc** | **Number** | MG17_INDPREFSTDOC - Stampa pref. documento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Stampa&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Fax&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Mail&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - PEC&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Pdf&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Nessuna preferenza&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndPrefstdocEnum.0]
**indStdistenas** | **Number** | MG17_INDSTDISTENAS - Flag stampata distinta enasarco&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Si stampa distinta&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - No stampa distinta&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTipoage** | **Number** | MG17_INDTIPOAGE - Tipo agente&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Agente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Capo zona&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Capo area&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndTipoageEnum.0]
**indTipoliq** | **Number** | MG17_INDTIPOLIQ - Tipo liquidazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuna scelta&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Per importo&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Per scaduto&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Per pagato&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndTipoliqEnum.0]
**perprov** | **Number** | MG17_PERPROV - % Provvigioni | [optional] [default to 0]
**regimeprov** | **Number** | MG17_REGIMEPROV - Regime&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No calcolo provvigioni&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - % dall&#39;agente&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - % dal cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - % dall&#39;anagrafica articolo&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - % dall&#39;anagrafica articolo/agente&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - % da listino fisso&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - % da listino anag. su cli./for.&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - % da listino fisso e scagl. sc./magg.&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - % da listino utilizzato&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - % da listino utilizzato: solo gest. scagl. di sc./magg.&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - % da listino utilizzato: provv. list. + scagl. di sc./magg.&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - % da tabella composta a due livelli&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - % da tabella composta a tre livelli&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - % da scaglioni di fatturato&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - % da condizioni multiple&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - % da listini parametrici&lt;/li&gt;&lt;/ul&gt; | [optional] [default to RegimeprovEnum.0]
**tipomand** | **Number** | MG17_TIPOMAND - Tipo mandato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Monomandatario&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Plurimandatario&lt;/li&gt;&lt;/ul&gt; | [optional] [default to TipomandEnum.0]
**tiporappor** | **Number** | MG17_TIPORAPPOR - Tipo rapporto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Procacciatore&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Generale&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Ispettore&lt;/li&gt;&lt;/ul&gt; | [optional] [default to TiporapporEnum.1]
**tiposoc** | **Number** | MG17_TIPOSOC - Tipo di società&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Persona fisica&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Società di capitale&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Società di persona&lt;/li&gt;&lt;/ul&gt; | [optional] 
**idExtendedAttributeEntity** | **Number** |  | [optional] 
**idExtendedAttributeSubEntity** | **Number** |  | [optional] 
**dmsPublishedEntityFW** | [**DMSPublishedEntityFWDTO**](DMSPublishedEntityFWDTO.md) |  | 
**generalMasterDataCO** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndBaseimpmagEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: IndBaseimpscEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: IndCalcscmagEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndPrefstdocEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `4` (value: `4`)

* `5` (value: `5`)

* `3` (value: `3`)





## Enum: IndStdistenasEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndTipoageEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndTipoliqEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: RegimeprovEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)

* `10` (value: `10`)

* `11` (value: `11`)

* `12` (value: `12`)

* `13` (value: `13`)

* `14` (value: `14`)

* `15` (value: `15`)





## Enum: TipomandEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: TiporapporEnum


* `1` (value: `1`)

* `0` (value: `0`)

* `2` (value: `2`)





## Enum: TiposocEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)




