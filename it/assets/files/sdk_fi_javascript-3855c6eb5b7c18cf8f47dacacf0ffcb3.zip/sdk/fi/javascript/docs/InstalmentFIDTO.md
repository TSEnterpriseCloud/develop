# TseCloudFi.InstalmentFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accettazione** | **Number** | EF01_ACCETTAZIONE - Accettazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Non applicabile  &lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Accettato&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Non accettato&lt;/li&gt;&lt;/ul&gt; | [optional] [default to AccettazioneEnum.0]
**agenappCg13** | **Number** | EF01_AGENAPP_CG13 - Agenzia d&#39;appoggio | [optional] 
**agenpreScg13** | **Number** | EF01_AGENPRE_SCG13 - Agenzia di presentazione | [optional] 
**annopart** | **Number** | EF01_ANNOPART - Anno partita | 
**bancaappCg12** | **Number** | EF01_BANCAAPP_CG12 - Banca d&#39;appoggio | [optional] 
**bancapreScg12** | **Number** | EF01_BANCAPRE_SCG12 - Banca di presentazione | [optional] 
**bolli** | **Number** | EF01_BOLLI - Importo bolli in EURO | [optional] [default to 0]
**bollival** | **Number** | EF01_BOLLIVAL - Importo bolli in valuta | [optional] 
**cambio** | **Number** | EF01_CAMBIO - Valore del cambio | [optional] 
**cambioadcontoS** | **Number** | EF01_CAMBIOADCONTO_S - Valore cambio movimento adeguamento su conto | [optional] 
**causaleCg33** | **String** | EF01_CAUSALE_CG33 - Codice causale | [optional] 
**causmgoMgfo** | **Number** | EF01_CAUSMGO_MGFO - Causale MGO | [optional] 
**cig** | **String** | EF01_CIG - Codice Identificativo Gara | [optional] 
**codCcred** | **String** | EF01_CODCCRED - Codice carta di credito | [optional] 
**contrfinanz** | **String** | EF01_CONTRFINANZ - Numero contratto di finanziamento | [optional] 
**cup** | **String** | EF01_CUP - Codice Unico di Progetto | [optional] 
**datacambio** | **Date** | EF01_DATACAMBIO - Data cambio | [optional] 
**datacambioadcontoS** | **Date** | EF01_DATACAMBIOADCONTO_S - Data cambio dell&#39;adeguamento su conto | [optional] 
**datadecorr** | **Date** | EF01_DATADECORR - Data decorrenza per calcolo scadenza | [optional] 
**datadoc** | **Date** | EF01_DATADOC - Data documento | 
**datareg** | **Date** | EF01_DATAREG - Data registrazione effetto | 
**descausale** | **String** | EF01_DESCAUSALE - Descrizione causale | [optional] 
**descragg** | **String** | EF01_DESCRAGG - Descrizione aggiuntiva | [optional] 
**dittaCg18** | **Number** | EF01_DITTA_CG18 - Codice azienda | 
**flgAcconto** | **Number** | EF01_FLGACCONTO - Acconto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgAccontoEnum.0]
**flgDocbis** | **Number** | EF01_FLGDOCBIS - Bis&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgDocbisEnum.0]
**flgEffvar** | **Number** | EF01_FLGEFFVAR - Variato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgEffvarEnum.0]
**flgEstraz** | **Number** | EF01_FLGESTRAZ - Estratto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgEstrazEnum.0]
**flgGendarag** | **Number** | EF01_FLGGENDARAG - Da raggr.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgGendaragEnum.0]
**flgGiratoS** | **Number** | EF01_FLGGIRATO_S - Girato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgGiratoSEnum.0]
**flgIncassobfS** | **Number** | EF01_FLGINCASSOBF_S - Incasso buon fine&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgIncassobfSEnum.0]
**flgPartbis** | **Number** | EF01_FLGPARTBIS - Bis&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgPartbisEnum.0]
**flgRicevutoS** | **Number** | EF01_FLGRICEVUTO_S - Ricevuto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgRicevutoSEnum.0]
**flgSospeso** | **Number** | EF01_FLGSOSPESO - Rata sospesa&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgSospesoEnum.0]
**flgSteffS** | **Number** | EF01_FLGSTEFF_S - Stampato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgSteffSEnum.0]
**id** | **Number** | EF01_ID - Id Scadenza (Required only in PUT/PATCH) | [optional] 
**idagenteMg17** | **Number** | EF01_IDAGENTE_MG17 - ID Agente | [optional] 
**idCo1h** | **Number** | EF01_ID_CO1H - IdCo1h | [optional] 
**idEf08** | **Number** | EF01_ID_EF08 - Banca aziendale | [optional] 
**idLinkEf01** | **Number** | EF01_IDLINK_EF01 - IdLinkEf01 | [optional] 
**idmediaCg99** | **Number** | EF01_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**impadegcambioS** | **Number** | EF01_IMPADEGCAMBIO_S - Importo adeguamento cambio su conto | [optional] 
**impeffiva** | **Number** | EF01_IMPEFFIVA - Importo IVA originario in EURO | 
**impeffivaVal** | **Number** | EF01_IMPEFFIVA_VAL - Importo IVA originario in valuta | [optional] 
**impeffnetprevS** | **Number** | EF01_IMPEFFNETPREV_S - Importo effetto al netto dei mov. previsionali in EURO | 
**impeffnetprevvalS** | **Number** | EF01_IMPEFFNETPREVVAL_S - Importo effetto al netto dei mov. previsionali in valuta | [optional] 
**impefforig** | **Number** | EF01_IMPEFFORIG - Importo rata | 
**impefforigval** | **Number** | EF01_IMPEFFORIGVAL - Importo rata | [optional] 
**impeffS** | **Number** | EF01_IMPEFF_S - Importo residuo | 
**impeffvalS** | **Number** | EF01_IMPEFFVAL_S - Importo residuo | [optional] 
**impritacc** | **Number** | EF01_IMPRITACC - Importo ritenute | [optional] 
**impritaccorig** | **Number** | EF01_IMPRITACCORIG - Importo origine della ritenuta di acconto in EURO | [optional] 
**impritaccorigval** | **Number** | EF01_IMPRITACCORIGVAL - Importo origine della ritenuta di acconto in valuta | [optional] 
**impritaccval** | **Number** | EF01_IMPRITACCVAL - Importo ritenute | [optional] 
**indConto** | **Number** | EF01_INDCONTO - Tipo conto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Attivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Passivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Conto attivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Conto passivo&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndContoEnum.0]
**indExp** | **Number** | EF01_INDEXP - Esportato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndExpEnum.0]
**indGenstatoS** | **Number** | EF01_INDGENSTATO_S - Operazione che ha determinato lo stato dell&#39;effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Creazione iniziale&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Pagamento/Riscossione&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Chiusura effetti&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  Insoluto&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; -  Raggruppato&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; -  Riemissione&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; -  Richiamato&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndGenstatoSEnum.0]
**indLiqprov** | **Number** | EF01_INDLIQPROV - Liquidazione provvigioni&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Liquidabile&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Liquidabile se tot. incassato&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Sospesa&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndLiqprovEnum.0]
**indMerceart62** | **Number** | EF01_INDMERCEART62 - Tipo merce in riferimento all&#39;Art. 62&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Non soggetta&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Deperibile&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Non deperibile&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndMerceart62Enum.0]
**indPresS** | **Number** | EF01_INDPRES_S - Presentazione dell&#39;effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Non soggetto&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  In portafoglio&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  S.b.f. ordinario&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  S.b.f. a maturazione valuta&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; -  S.b.f. anticipato&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; -  Dopo incasso&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; -  Allo sconto&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; -  Altre presentazioni&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; -  Sconto fatture&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; -  Cessione a factoring&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndPresSEnum.0]
**indSperitS** | **Number** | EF01_INDSPERIT_S - Modalità di gestione delle spese di ritorno&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Nessun addebito&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Solo annotate&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Sommate&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  Nuovo effetto&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndSperitSEnum.0]
**indStatoS** | **Number** | EF01_INDSTATO_S - Stato effetto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Aperto&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Chiuso&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndStatoSEnum.0]
**indTipomov** | **Number** | EF01_INDTIPOMOV - Tipo movimento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Consolidato&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Da consolidare&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Previsionale&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  Previsionale per simulaz.&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; -  Previsionale per cash flow&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndTipomovEnum.0]
**lastchange** | **Date** | EF01_LASTCHANGE - Data ultima variazione | [optional] 
**nravvisomav** | **String** | EF01_NRAVVISOMAV - Numero avviso MAV | [optional] 
**numdoc** | **Number** | EF01_NUMDOC - Nr documento/Protocollo | 
**numdocorig** | **String** | EF01_NUMDOCORIG - Numero documento originario | [optional] 
**numeff** | **Number** | EF01_NUMEFF - Numero scadenza | 
**numeffaccor** | **String** | EF01_NUMEFFACCOR - Numero accorpamento | [optional] 
**numpart** | **Number** | EF01_NUMPART - Numero partita | 
**numrata** | **Number** | EF01_NUMRATA - Numero rata | [optional] 
**numregCo99** | **String** | EF01_NUMREG_CO99 - Numero di registrazione | 
**numriemisS** | **Number** | EF01_NUMRIEMIS_S - Numero di riemissione | [optional] 
**numsteffS** | **Number** | EF01_NUMSTEFF_S - Numero stampa effetto | [optional] 
**progEcEc01** | **Number** | EF01_PROGEC_EC01 - Progressivo estratto conto | [optional] [default to 0]
**progEff** | **Number** | EF01_PROGEFF - Progressivo effetti | 
**rigacontCg42** | **Number** | EF01_RIGACONT_CG42 - Riga contabile | 
**rowversion** | **Blob** | EF01_ROWVERSION - RowVersion | [optional] 
**scadeorig** | **Date** | EF01_SCADEORIG - Scadenza | 
**scadeS** | **Date** | EF01_SCADE_S - Data scadenza | 
**sezdoc** | **String** | EF01_SEZDOC - Sezionale documento | 
**sezpart** | **String** | EF01_SEZPART - Sezionale partita | 
**speseritbanS** | **Number** | EF01_SPESERITBAN_S - Spese di ritorno addebitate dalla banca | [optional] 
**speseritS** | **Number** | EF01_SPESERIT_S - Spese di ritorno | [optional] 
**spinc** | **Number** | EF01_SPINC - Spese incasso in EURO | [optional] [default to 0]
**spincval** | **Number** | EF01_SPINCVAL - Spese incasso in valuta | [optional] 
**stipoeff** | **Number** | EF01_STIPOEFF - Sottotipo | [optional] 
**tipoeff** | **Number** | EF01_TIPOEFF - Tipo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Contanti&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Ricevuta bancaria&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Tratta&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Tratta accettata&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Cessione&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Cambiale&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Carta di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Bancomat&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Contrassegno&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Lettera di credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - SDD&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Leasing&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Rimessa diretta&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Bonifico Bancario&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - C/C postale&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - MAV&lt;/li&gt;&lt;/ul&gt; | [optional] [default to TipoeffEnum.1]
**totdoc** | **Number** | EF01_TOTDOC - Totale documento in EURO | 
**totdocval** | **Number** | EF01_TOTDOCVAL - Totale documento in valuta | [optional] 
**totrate** | **Number** | EF01_TOTRATE - Totale rate | [optional] 
**idExtendedAttributeEntity** | **Number** |  | [optional] 
**idExtendedAttributeSubEntity** | **Number** |  | [optional] 
**coaAccountFI** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | 
**companyBankFI** | [**CompanyBankFIDTO**](CompanyBankFIDTO.md) |  | [optional] 
**companyBankPresFI** | [**CompanyBankFIDTO**](CompanyBankFIDTO.md) |  | [optional] 
**csBankCO** | [**CSBankCODTO**](CSBankCODTO.md) |  | [optional] 
**csSddCO** | [**CSSddCODTO**](CSSddCODTO.md) |  | [optional] 
**currencyCO** | [**CurrencyCODTO**](CurrencyCODTO.md) |  | 
**customerSupplierCO** | [**CustomerSupplierCODTO**](CustomerSupplierCODTO.md) |  | [optional] 
**instalmentCreditFI** | [**InstalmentCreditFIDTO**](InstalmentCreditFIDTO.md) |  | [optional] 
**instalmentHistoryFI** | [**[InstalmentHistoryFIDTO]**](InstalmentHistoryFIDTO.md) |  | [optional] 
**instalmentNoteFI** | [**InstalmentNoteFIDTO**](InstalmentNoteFIDTO.md) |  | [optional] 
**instalmentReminderFI** | [**[InstalmentReminderFIDTO]**](InstalmentReminderFIDTO.md) |  | [optional] 
**paymentTermCO** | [**PaymentTermCODTO**](PaymentTermCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: AccettazioneEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: FlgAccontoEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgDocbisEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgEffvarEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgEstrazEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgGendaragEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgGiratoSEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgIncassobfSEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgPartbisEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgRicevutoSEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgSospesoEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgSteffSEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndContoEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: IndExpEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndGenstatoSEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)





## Enum: IndLiqprovEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndMerceart62Enum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndPresSEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)





## Enum: IndSperitSEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: IndStatoSEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndTipomovEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)





## Enum: TipoeffEnum


* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)

* `10` (value: `10`)

* `11` (value: `11`)

* `12` (value: `12`)

* `13` (value: `13`)

* `14` (value: `14`)

* `15` (value: `15`)

* `16` (value: `16`)




