# TseCloudFi.Grouping1CODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codRaggrcf1** | **String** | MG31_CODRAGGRCF1 - Raggruppamento 1 | 
**descraggrcf1** | **String** | MG31_DESCRAGGRCF1 - Descrizione | [optional] 
**dittaCg18** | **Number** | MG31_DITTA_CG18 - Ditta | [optional] [default to 0]
**idmediaCg99** | **Number** | MG31_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**idprov** | **Number** | MG31_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**tipocf** | **Number** | MG31_TIPOCF - Tipo Cli/For&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] [default to TipocfEnum.0]
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: TipocfEnum


* `0` (value: `0`)

* `1` (value: `1`)




