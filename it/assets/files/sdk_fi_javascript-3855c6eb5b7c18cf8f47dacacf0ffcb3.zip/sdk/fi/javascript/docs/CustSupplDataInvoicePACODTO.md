# TseCloudFi.CustSupplDataInvoicePACODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codiceCg16** | **Number** | CG1O_CODICE_CG16 - Codice anagrafica generale | 
**emailcortesia** | **String** | CG1O_EMAILCORTESIA - E-mail | [optional] 
**flgAsw** | **Number** | CG1O_FLGASW - FlgAsw&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgAswEnum.0]
**indTypeb2b** | **Number** | CG1O_INDTYPEB2B - Instradamento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;99&lt;/i&gt; - Non attivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - FEPA&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - FEPR&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndTypeb2bEnum.99]
**tipocfCg44** | **Number** | CG1O_TIPOCF_CG44 - Tipo Cliente / Fornitore&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] [default to TipocfCg44Enum.0]
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgAswEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndTypeb2bEnum


* `99` (value: `99`)

* `1` (value: `1`)

* `6` (value: `6`)





## Enum: TipocfCg44Enum


* `0` (value: `0`)

* `1` (value: `1`)




