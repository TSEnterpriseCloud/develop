# TseCloudFi.GLEntryFIMultipleDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rifpadre** | **String** |  | [optional] 
**stageGuid** | **String** |  | [optional] 
**canUpdate** | **Boolean** |  | [optional] 
**cambio** | **Number** | CG41_CAMBIO - Cambio | [optional] 
**causcollnumreg** | **String** | CG41_CAUSCOLLNUMREG - Causcollnumreg | [optional] 
**codiceCg33** | **String** | CG41_CODICE_CG33 - Causale contabile | 
**datacambio** | **Date** | CG41_DATACAMBIO - Data cambio | [optional] 
**datacomp** | **Date** | CG41_DATACOMP - Data Plafond | [optional] 
**datacons** | **Date** | CG41_DATACONS - Data consolidamento | [optional] 
**datadoc** | **Date** | CG41_DATADOC - Data documento | [optional] 
**datadocrifnotevar** | **Date** | CG41_DATADOCRIFNOTEVAR - Data documento nota di variazione | [optional] 
**dataprecons** | **Date** | CG41_DATAPRECONS - Data pre-consolidamento | [optional] 
**datarateo** | **Date** | CG41_DATARATEO - Data rateo | [optional] 
**datarateop** | **Date** | CG41_DATARATEOP - Data rateo esercizio precedente | [optional] 
**datareg** | **Date** | CG41_DATAREG - Data registrazione | 
**dataregiva** | **Date** | CG41_DATAREGIVA - Data competenza IVA | [optional] 
**descausale** | **String** | CG41_DESCAUSALE - Descrizione causale | [optional] 
**descragg** | **String** | CG41_DESCRAGG - Descrizione aggiuntiva | [optional] 
**dittaCg18** | **Number** | CG41_DITTA_CG18 - Azienda | 
**flgDelete** | **Number** | CG41_FLGDELETE - Eliminazione | [optional] [default to 0]
**flgDocbis** | **Number** | CG41_FLGDOCBIS -  Bis&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgDocbisEnum.0]
**flgDocriep** | **Number** | CG41_FLGDOCRIEP - Documento riepilogativo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgDocriepEnum.0]
**flgDocsemplif** | **Number** | CG41_FLGDOCSEMPLIF - Documento semplificato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgDocsemplifEnum.0]
**flgIntra** | **Number** | CG41_FLGINTRA - Intra&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgMentry** | **Number** | CG41_FLGMENTRY - FlgMentry | [optional] [default to 0]
**flgSegnoiva** | **Number** | CG41_FLGSEGNOIVA - Segno&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Fattura&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Nota di credito / decremento&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgSegnoivaEnum.0]
**flgStpgior** | **Number** | CG41_FLGSTPGIOR - Stampato su libro giornale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgStpgiorEnum.0]
**flgStpiva** | **Number** | CG41_FLGSTPIVA - Stampato sul registro IVA&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgStpivaEnum.0]
**flgStptotiva** | **Number** | CG41_FLGSTPTOTIVA - Stampa totali IVA | [optional] [default to 0]
**flgTurismo** | **Number** | CG41_FLGTURISMO - Operazioni legate al turismo | [optional] [default to 0]
**hubid** | **String** | CG41_HUBID - Hub Id | [optional] 
**id** | **Number** | CG41_ID - ID | 
**idCo1a** | **Number** | CG41_ID_CO1A - ID divisione | [optional] 
**idMg28** | **String** | CG41_ID_MG28 - Lettera d&#39;intento | [optional] 
**idsdi** | **String** | CG41_IDSDI - Identificativo SDI | [optional] 
**imparrot** | **Number** | CG41_IMPARROT - Imparrot | [optional] 
**imparrotval** | **Number** | CG41_IMPARROTVAL - Imparrotval | [optional] 
**imparrotval2** | **Number** | CG41_IMPARROTVAL2 - Imparrotval2 | [optional] 
**imptotale** | **Number** | CG41_IMPTOTALE - Importo | [optional] 
**imptotaleval** | **Number** | CG41_IMPTOTALEVAL - Importo    in valuta | [optional] 
**imptotaleval2** | **Number** | CG41_IMPTOTALEVAL2 - Importo    in valuta | [optional] 
**indElenchimov3000** | **Number** | CG41_INDELENCHIMOV3000 - Includi negli invii telematici&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - NonIncludere&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Includi&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - DaValutare&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - DaValutarePerAnno&lt;/li&gt;&lt;li&gt;&lt;i&gt;99&lt;/i&gt; - NonDefinito&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndElenchimov3000Enum.0]
**indExp** | **Number** | CG41_INDEXP - IndExp | [optional] [default to 0]
**indModdiffcambio** | **Number** | CG41_INDMODDIFFCAMBIO - Differenza cambio&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - ContoClienteFornitore&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - ContoApposito&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - ContiContropartiteOrig&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndModdiffcambioEnum.0]
**indModpn** | **Number** | CG41_INDMODPN - IndModpn | [optional] [default to 0]
**indMovgruppo** | **Number** | CG41_INDMOVGRUPPO - Raggruppamento movimenti per Cli/For di riferimento | [optional] [default to 0]
**indNollis** | **Number** | CG41_INDNOLLIS - Tipo noleggio&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - A-Autovettura&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - B-Caravan&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - C-Altri veicoli&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - D-Unità da diporto&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - E-Aeromobili&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndNollisEnum.0]
**indProvreg** | **Number** | CG41_INDPROVREG - Provenienza&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Prima nota&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Procedura esterna&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Importazione dati&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Documenti&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Cespiti&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Digital invoice&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Digital banklink&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Scadenze&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Ratei e risconti&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Adeguamento cambi&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Chiusura/apertura conti&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - Disposizioni bancarie: Generazione file&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Liquidazione IVA&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Rettifiche pro-rata di fine anno&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Iva per cassa vendite&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - Iva per cassa acquisti&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - Incassa Subito&lt;/li&gt;&lt;li&gt;&lt;i&gt;17&lt;/i&gt; - Movimenti CBI&lt;/li&gt;&lt;li&gt;&lt;i&gt;18&lt;/i&gt; - F24&lt;/li&gt;&lt;li&gt;&lt;i&gt;19&lt;/i&gt; - Credito d&#39;imposta&lt;/li&gt;&lt;li&gt;&lt;i&gt;20&lt;/i&gt; - DocFinance&lt;/li&gt;&lt;li&gt;&lt;i&gt;21&lt;/i&gt; - Documenti da modulo esterno&lt;/li&gt;&lt;li&gt;&lt;i&gt;22&lt;/i&gt; - Corrispettivi mensili&lt;/li&gt;&lt;li&gt;&lt;i&gt;23&lt;/i&gt; - TS Pay&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndProvregEnum.0]
**indTipodoc** | **Number** | CG41_INDTIPODOC - Tipo documento transfrontaliere&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Automatico&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - TD01_Fattura&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - TD04_NotaCredito&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - TD05_NotaDebito&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - TD07_FatturaSemplificata&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - TD08_NotaCreditoSemplificata&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - TD10_FatturaAcquistoIntraBeni&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - TD11_FatturaAcquistoIntraServizi&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - TD12_DocumentoRiepilogativo&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndTipodocEnum.0]
**indTipoifrs** | **Number** | CG41_INDTIPOIFRS - IFRS | [optional] [default to 0]
**indTipomov** | **Number** | CG41_INDTIPOMOV - Tipo movimento | 
**indTiporeg** | **Number** | CG41_INDTIPOREG - Tipo registro&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Acquisti&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Vendite&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Corrispettivi&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndTiporegEnum.0]
**lastchange** | **Date** | CG41_LASTCHANGE - Data ultima variazione | [optional] 
**numdoc** | **Number** | CG41_NUMDOC - Protocollo | [optional] [default to 0]
**numdocorig** | **String** | CG41_NUMDOCORIG - Numero documento | [optional] 
**numpart** | **Number** | CG41_NUMPART - Numero partita | [optional] 
**numreg** | **String** | CG41_NUMREG - Numero registrazione | 
**parentCodiceCgc0** | **Number** | CG41_CODEHOLDING_CGC0 - Capogruppo Intercompany | [optional] 
**progEserCg19** | **Number** | CG41_PROGESER_CG19 - Progressivo esercizio | 
**selfInvoiceProtocol** | **Number** | CG41_SELFPROTOCOL - Numero autofattura | [optional] 
**selfInvoiceSectional** | **String** | CG41_SELFSECTIONAL - Sezionale autofattura | [optional] 
**sezionale** | **String** | CG41_SEZIONALE - Sezionale | 
**tipodoc** | **Number** | CG41_TIPODOC - Tipo documento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - TipoDocumentoNessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;32&lt;/i&gt; - TipoDocumento_Autobolla&lt;/li&gt;&lt;li&gt;&lt;i&gt;48&lt;/i&gt; - TipoDocumento_AvanzamentoDiProduzione&lt;/li&gt;&lt;li&gt;&lt;i&gt;24&lt;/i&gt; - TipoDocumento_BollaDiUscita&lt;/li&gt;&lt;li&gt;&lt;i&gt;25&lt;/i&gt; - TipoDocumento_BollaResoDaClienti&lt;/li&gt;&lt;li&gt;&lt;i&gt;26&lt;/i&gt; - TipoDocumento_BollaRientroMerceCLavClienti&lt;/li&gt;&lt;li&gt;&lt;i&gt;27&lt;/i&gt; - TipoDocumento_BollaRientroMerceCLavFornitori&lt;/li&gt;&lt;li&gt;&lt;i&gt;29&lt;/i&gt; - TipoDocumento_BollaRientroMerceClientiCRiparazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;28&lt;/i&gt; - TipoDocumento_BollaRientroMerceClientiCVisione&lt;/li&gt;&lt;li&gt;&lt;i&gt;31&lt;/i&gt; - TipoDocumento_BollaRientroMerceFornitoriCRiparazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;30&lt;/i&gt; - TipoDocumento_BollaRientroMerceFornitoriCVisione&lt;/li&gt;&lt;li&gt;&lt;i&gt;931&lt;/i&gt; - TipoDocumento_BonificoFornitori&lt;/li&gt;&lt;li&gt;&lt;i&gt;933&lt;/i&gt; - TipoDocumento_BonificoImposte&lt;/li&gt;&lt;li&gt;&lt;i&gt;932&lt;/i&gt; - TipoDocumento_BonificoStipendi&lt;/li&gt;&lt;li&gt;&lt;i&gt;35&lt;/i&gt; - TipoDocumento_BuonoConsegna&lt;/li&gt;&lt;li&gt;&lt;i&gt;36&lt;/i&gt; - TipoDocumento_BuonoInterno&lt;/li&gt;&lt;li&gt;&lt;i&gt;47&lt;/i&gt; - TipoDocumento_CaricoDaProduzione&lt;/li&gt;&lt;li&gt;&lt;i&gt;50&lt;/i&gt; - TipoDocumento_CaricoMaterialiRecuperati&lt;/li&gt;&lt;li&gt;&lt;i&gt;72&lt;/i&gt; - TipoDocumento_CertificatoAEC&lt;/li&gt;&lt;li&gt;&lt;i&gt;901&lt;/i&gt; - TipoDocumento_CodiceCliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;902&lt;/i&gt; - TipoDocumento_CodiceFornitore&lt;/li&gt;&lt;li&gt;&lt;i&gt;55&lt;/i&gt; - TipoDocumento_ContrattoAssistenza&lt;/li&gt;&lt;li&gt;&lt;i&gt;53&lt;/i&gt; - TipoDocumento_ContrattoClienti&lt;/li&gt;&lt;li&gt;&lt;i&gt;54&lt;/i&gt; - TipoDocumento_ContrattoFornitori&lt;/li&gt;&lt;li&gt;&lt;i&gt;982&lt;/i&gt; - TipoDocumento_ContrattoVigilanza&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - TipoDocumento_Corrispettivi&lt;/li&gt;&lt;li&gt;&lt;i&gt;61&lt;/i&gt; - TipoDocumento_DistintaCaricoMerce&lt;/li&gt;&lt;li&gt;&lt;i&gt;60&lt;/i&gt; - TipoDocumento_DocumentoBanco&lt;/li&gt;&lt;li&gt;&lt;i&gt;66&lt;/i&gt; - TipoDocumento_DocumentoCoInd&lt;/li&gt;&lt;li&gt;&lt;i&gt;69&lt;/i&gt; - TipoDocumento_DocumentoContrattoVigilanza&lt;/li&gt;&lt;li&gt;&lt;i&gt;62&lt;/i&gt; - TipoDocumento_DocumentoDASAlcole&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - TipoDocumento_DocumentoDiTrasDiUscita&lt;/li&gt;&lt;li&gt;&lt;i&gt;23&lt;/i&gt; - TipoDocumento_DocumentoDiTraspRientroMerceFornCRip&lt;/li&gt;&lt;li&gt;&lt;i&gt;17&lt;/i&gt; - TipoDocumento_DocumentoDiTrasResoDaClienti&lt;/li&gt;&lt;li&gt;&lt;i&gt;18&lt;/i&gt; - TipoDocumento_DocumentoDiTrasRientroMerceCLavClienti&lt;/li&gt;&lt;li&gt;&lt;i&gt;19&lt;/i&gt; - TipoDocumento_DocumentoDiTrasRientroMerceCLavFornitori&lt;/li&gt;&lt;li&gt;&lt;i&gt;21&lt;/i&gt; - TipoDocumento_DocumentoDiTrasRientroMerceCliCRip&lt;/li&gt;&lt;li&gt;&lt;i&gt;20&lt;/i&gt; - TipoDocumento_DocumentoDiTrasRientroMerceCliCVisione&lt;/li&gt;&lt;li&gt;&lt;i&gt;22&lt;/i&gt; - TipoDocumento_DocumentoDiTrasRientroMerceFornCVisione&lt;/li&gt;&lt;li&gt;&lt;i&gt;56&lt;/i&gt; - TipoDocumento_DocumentoGenerico1Entrata&lt;/li&gt;&lt;li&gt;&lt;i&gt;58&lt;/i&gt; - TipoDocumento_DocumentoGenerico1Uscita&lt;/li&gt;&lt;li&gt;&lt;i&gt;57&lt;/i&gt; - TipoDocumento_DocumentoGenerico2Entrata&lt;/li&gt;&lt;li&gt;&lt;i&gt;59&lt;/i&gt; - TipoDocumento_DocumentoGenerico2Uscita&lt;/li&gt;&lt;li&gt;&lt;i&gt;63&lt;/i&gt; - TipoDocumento_DocumentoPackingList&lt;/li&gt;&lt;li&gt;&lt;i&gt;70&lt;/i&gt; - TipoDocumento_DocumentoRDA&lt;/li&gt;&lt;li&gt;&lt;i&gt;71&lt;/i&gt; - TipoDocumento_DocumentoRDO&lt;/li&gt;&lt;li&gt;&lt;i&gt;67&lt;/i&gt; - TipoDocumento_DocumentoVuoti&lt;/li&gt;&lt;li&gt;&lt;i&gt;921&lt;/i&gt; - TipoDocumento_EffettoAttivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;922&lt;/i&gt; - TipoDocumento_EffettoPassivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - TipoDocumento_FatturaAcquisto&lt;/li&gt;&lt;li&gt;&lt;i&gt;33&lt;/i&gt; - TipoDocumento_FatturaProforma&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - TipoDocumento_FatturaRicevutaFiscaleCliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - TipoDocumento_FatturaRicevutaFiscaleFornitore&lt;/li&gt;&lt;li&gt;&lt;i&gt;951&lt;/i&gt; - TipoDocumento_LiquidazioneProvvigioni&lt;/li&gt;&lt;li&gt;&lt;i&gt;34&lt;/i&gt; - TipoDocumento_ListaPrelievo&lt;/li&gt;&lt;li&gt;&lt;i&gt;941&lt;/i&gt; - TipoDocumento_MandatiDiPagamento&lt;/li&gt;&lt;li&gt;&lt;i&gt;68&lt;/i&gt; - TipoDocumento_MovimentiContabili&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - TipoDocumento_NotaDebitoCliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - TipoDocumento_NotaVariazioneFornitore&lt;/li&gt;&lt;li&gt;&lt;i&gt;961&lt;/i&gt; - TipoDocumento_NumeratoreCommesse&lt;/li&gt;&lt;li&gt;&lt;i&gt;962&lt;/i&gt; - TipoDocumento_NumeratoreProgetto&lt;/li&gt;&lt;li&gt;&lt;i&gt;65&lt;/i&gt; - TipoDocumento_NumeroPartitaRaggruppamentoEffetti&lt;/li&gt;&lt;li&gt;&lt;i&gt;51&lt;/i&gt; - TipoDocumento_OrdineCLavoroAttivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;52&lt;/i&gt; - TipoDocumento_OrdineCLavoroPassivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;39&lt;/i&gt; - TipoDocumento_OrdineCliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;934&lt;/i&gt; - TipoDocumento_OrdineDiPagamento&lt;/li&gt;&lt;li&gt;&lt;i&gt;40&lt;/i&gt; - TipoDocumento_OrdineFornitore&lt;/li&gt;&lt;li&gt;&lt;i&gt;45&lt;/i&gt; - TipoDocumento_OrdineProduzione&lt;/li&gt;&lt;li&gt;&lt;i&gt;43&lt;/i&gt; - TipoDocumento_PrenotazioneMerce&lt;/li&gt;&lt;li&gt;&lt;i&gt;41&lt;/i&gt; - TipoDocumento_PreordineCliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;42&lt;/i&gt; - TipoDocumento_PreordineFornitore&lt;/li&gt;&lt;li&gt;&lt;i&gt;37&lt;/i&gt; - TipoDocumento_PreventivoCliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;38&lt;/i&gt; - TipoDocumento_PreventivoFornitore&lt;/li&gt;&lt;li&gt;&lt;i&gt;911&lt;/i&gt; - TipoDocumento_ProgressivoCespite&lt;/li&gt;&lt;li&gt;&lt;i&gt;910&lt;/i&gt; - TipoDocumento_ProgressivoContoBanca&lt;/li&gt;&lt;li&gt;&lt;i&gt;945&lt;/i&gt; - TipoDocumento_ProgressivoDistintaIncassi&lt;/li&gt;&lt;li&gt;&lt;i&gt;946&lt;/i&gt; - TipoDocumento_ProgressivoDistintaPagamenti&lt;/li&gt;&lt;li&gt;&lt;i&gt;64&lt;/i&gt; - TipoDocumento_ProgressivoElencoINTRA&lt;/li&gt;&lt;li&gt;&lt;i&gt;972&lt;/i&gt; - TipoDocumento_ProgressivoRettificheSaldiCoInd&lt;/li&gt;&lt;li&gt;&lt;i&gt;971&lt;/i&gt; - TipoDocumento_ProgressivoRibaltamentiCoInd&lt;/li&gt;&lt;li&gt;&lt;i&gt;981&lt;/i&gt; - TipoDocumento_ProgressivoSerialShippingContainerCode&lt;/li&gt;&lt;li&gt;&lt;i&gt;928&lt;/i&gt; - TipoDocumento_ProgressivoStampaDistintaCessioneFactoring&lt;/li&gt;&lt;li&gt;&lt;i&gt;926&lt;/i&gt; - TipoDocumento_ProgressivoStampaDistintaMav&lt;/li&gt;&lt;li&gt;&lt;i&gt;924&lt;/i&gt; - TipoDocumento_ProgressivoStampaDistintaRiBaElettronica&lt;/li&gt;&lt;li&gt;&lt;i&gt;929&lt;/i&gt; - TipoDocumento_ProgressivoStampaDistintaRiBaTratteCessCamb&lt;/li&gt;&lt;li&gt;&lt;i&gt;925&lt;/i&gt; - TipoDocumento_ProgressivoStampaDistintaRid&lt;/li&gt;&lt;li&gt;&lt;i&gt;927&lt;/i&gt; - TipoDocumento_ProgressivoStampaDistintaScontoFatture&lt;/li&gt;&lt;li&gt;&lt;i&gt;923&lt;/i&gt; - TipoDocumento_ProgressivoStampaEffetti&lt;/li&gt;&lt;li&gt;&lt;i&gt;44&lt;/i&gt; - TipoDocumento_PropostaOrdineDiAcquisto&lt;/li&gt;&lt;li&gt;&lt;i&gt;906&lt;/i&gt; - TipoDocumento_ProtocolloLettereDiIntentoEmesse&lt;/li&gt;&lt;li&gt;&lt;i&gt;905&lt;/i&gt; - TipoDocumento_ProtocolloLettereDiIntentoRicevute&lt;/li&gt;&lt;li&gt;&lt;i&gt;999&lt;/i&gt; - TipoDocumento_RegistrazioneMasterDocumento&lt;/li&gt;&lt;li&gt;&lt;i&gt;942&lt;/i&gt; - TipoDocumento_ReversaliDiIncasso&lt;/li&gt;&lt;li&gt;&lt;i&gt;49&lt;/i&gt; - TipoDocumento_ScaricoAProduzione&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - TipoDocumento_ScontrinoFiscale&lt;/li&gt;&lt;li&gt;&lt;i&gt;46&lt;/i&gt; - TipoDocumento_TrasferimentoInterno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - TipoDocumentoTD01_Fattura&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - TipoDocumentoTD04_NotaCredito&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - TipoDocumentoTD05_NotaDebito&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - TipoDocumentoTD07_FatturaSemplificata&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - TipoDocumentoTD08_NotaCreditoSemplificata&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - TipoDocumentoTD10_FatturaAcquistoIntraBeni&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - TipoDocumentoTD11_FatturaAcquistoIntraServizi&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - TipoDocumentoTD12_DocumentoRiepilogativo&lt;/li&gt;&lt;/ul&gt; | [optional] 
**tipodocfe** | **String** | CG41_TIPODOCFE - Tipo documento SDI | [optional] 
**idExtendedAttributeEntity** | **Number** |  | [optional] 
**idExtendedAttributeSubEntity** | **Number** |  | [optional] 
**accountingYearCO** | [**AccountingYearCODTO**](AccountingYearCODTO.md) |  | 
**currencyCO** | [**CurrencyCODTO**](CurrencyCODTO.md) |  | [optional] 
**customerSupplierCO** | [**CustomerSupplierCODTO**](CustomerSupplierCODTO.md) |  | [optional] 
**dmsPublishedEntityFW** | [**DMSPublishedEntityFWDTO**](DMSPublishedEntityFWDTO.md) |  | 
**estabilshedOrganization** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | [optional] 
**fiscalRepresentative** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | [optional] 
**generalMasterDataCOBlackList** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | [optional] 
**generalMasterDataCODirectID** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | [optional] 
**glEntryDetailFI** | [**[GLEntryDetailFIDTO]**](GLEntryDetailFIDTO.md) |  | [optional] 
**glvatDetailFI** | [**[GLVATDetailFIDTO]**](GLVATDetailFIDTO.md) |  | [optional] 
**intragroupStructureCO** | [**IntragroupStructureCODTO**](IntragroupStructureCODTO.md) |  | [optional] 
**movementTypeCO** | [**MovementTypeCODTO**](MovementTypeCODTO.md) |  | 
**officeCO** | [**OfficeCODTO**](OfficeCODTO.md) |  | [optional] 
**sectionalMasterDataCO** | [**SectionalMasterDataCODTO**](SectionalMasterDataCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgDocbisEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgDocriepEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgDocsemplifEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgIntraEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgSegnoivaEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgStpgiorEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgStpivaEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndElenchimov3000Enum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `99` (value: `99`)





## Enum: IndModdiffcambioEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndNollisEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)





## Enum: IndProvregEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)

* `10` (value: `10`)

* `11` (value: `11`)

* `12` (value: `12`)

* `13` (value: `13`)

* `14` (value: `14`)

* `15` (value: `15`)

* `16` (value: `16`)

* `17` (value: `17`)

* `18` (value: `18`)

* `19` (value: `19`)

* `20` (value: `20`)

* `21` (value: `21`)

* `22` (value: `22`)

* `23` (value: `23`)





## Enum: IndTipodocEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `4` (value: `4`)

* `5` (value: `5`)

* `7` (value: `7`)

* `8` (value: `8`)

* `10` (value: `10`)

* `11` (value: `11`)

* `12` (value: `12`)





## Enum: IndTiporegEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: TipodocEnum


* `0` (value: `0`)

* `32` (value: `32`)

* `48` (value: `48`)

* `24` (value: `24`)

* `25` (value: `25`)

* `26` (value: `26`)

* `27` (value: `27`)

* `29` (value: `29`)

* `28` (value: `28`)

* `31` (value: `31`)

* `30` (value: `30`)

* `931` (value: `931`)

* `933` (value: `933`)

* `932` (value: `932`)

* `35` (value: `35`)

* `36` (value: `36`)

* `47` (value: `47`)

* `50` (value: `50`)

* `72` (value: `72`)

* `901` (value: `901`)

* `902` (value: `902`)

* `55` (value: `55`)

* `53` (value: `53`)

* `54` (value: `54`)

* `982` (value: `982`)

* `3` (value: `3`)

* `61` (value: `61`)

* `60` (value: `60`)

* `66` (value: `66`)

* `69` (value: `69`)

* `62` (value: `62`)

* `16` (value: `16`)

* `23` (value: `23`)

* `17` (value: `17`)

* `18` (value: `18`)

* `19` (value: `19`)

* `21` (value: `21`)

* `20` (value: `20`)

* `22` (value: `22`)

* `56` (value: `56`)

* `58` (value: `58`)

* `57` (value: `57`)

* `59` (value: `59`)

* `63` (value: `63`)

* `70` (value: `70`)

* `71` (value: `71`)

* `67` (value: `67`)

* `921` (value: `921`)

* `922` (value: `922`)

* `2` (value: `2`)

* `33` (value: `33`)

* `13` (value: `13`)

* `14` (value: `14`)

* `951` (value: `951`)

* `34` (value: `34`)

* `941` (value: `941`)

* `68` (value: `68`)

* `6` (value: `6`)

* `9` (value: `9`)

* `961` (value: `961`)

* `962` (value: `962`)

* `65` (value: `65`)

* `51` (value: `51`)

* `52` (value: `52`)

* `39` (value: `39`)

* `934` (value: `934`)

* `40` (value: `40`)

* `45` (value: `45`)

* `43` (value: `43`)

* `41` (value: `41`)

* `42` (value: `42`)

* `37` (value: `37`)

* `38` (value: `38`)

* `911` (value: `911`)

* `910` (value: `910`)

* `945` (value: `945`)

* `946` (value: `946`)

* `64` (value: `64`)

* `972` (value: `972`)

* `971` (value: `971`)

* `981` (value: `981`)

* `928` (value: `928`)

* `926` (value: `926`)

* `924` (value: `924`)

* `929` (value: `929`)

* `925` (value: `925`)

* `927` (value: `927`)

* `923` (value: `923`)

* `44` (value: `44`)

* `906` (value: `906`)

* `905` (value: `905`)

* `999` (value: `999`)

* `942` (value: `942`)

* `49` (value: `49`)

* `15` (value: `15`)

* `46` (value: `46`)

* `1` (value: `1`)

* `4` (value: `4`)

* `5` (value: `5`)

* `7` (value: `7`)

* `8` (value: `8`)

* `10` (value: `10`)

* `11` (value: `11`)

* `12` (value: `12`)




