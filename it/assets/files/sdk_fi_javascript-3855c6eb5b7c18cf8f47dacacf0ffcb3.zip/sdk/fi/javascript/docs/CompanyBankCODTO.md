# TseCloudFi.CompanyBankCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aprogressmav** | **Number** | EF08_APROGRESSMAV - A progressivo | [optional] 
**bancaCg12** | **Number** | EF08_BANCA_CG12 - Banca | [optional] 
**bbananticipi** | **String** | EF08_BBANANTICIPI - Bbananticipi | [optional] 
**bbanconto** | **String** | EF08_BBANCONTO - BBAN | [optional] 
**bbaneffpresef** | **String** | EF08_BBANEFFPRESEF - Bbaneffpresef | [optional] 
**bbanordpbonif** | **String** | EF08_BBANORDPBONIF - Bbanordpbonif | [optional] 
**bicbanca** | **String** | EF08_BICBANCA - BIC | [optional] 
**cabbonifCg13** | **Number** | EF08_CABBONIF_CG13 - CabbonifCg13 | [optional] 
**cabcontoCg13** | **Number** | EF08_CABCONTO_CG13 - CAB agenzia | [optional] 
**cabmavCg13** | **Number** | EF08_CABMAV_CG13 - CabmavCg13 | [optional] 
**cabribaCg13** | **Number** | EF08_CABRIBA_CG13 - CabribaCg13 | [optional] 
**cabridCg13** | **Number** | EF08_CABRID_CG13 - CabridCg13 | [optional] 
**ccanticipi** | **String** | EF08_CCANTICIPI - Ccanticipi | [optional] 
**ccconto** | **String** | EF08_CCCONTO - C/C | [optional] 
**cceffpresef** | **String** | EF08_CCEFFPRESEF - Cceffpresef | [optional] 
**ccordpbonif** | **String** | EF08_CCORDPBONIF - Ccordpbonif | [optional] 
**codAzienda** | **String** | EF08_CODAZIENDA - Codice azienda | [optional] 
**codiceCg07** | **Number** | EF08_CODICE_CG07 - Nazione | [optional] 
**codicecuc** | **String** | EF08_CODICECUC - Codice univoco CBI | [optional] 
**codRappopor** | **String** | EF08_CODRAPPOPOR - ID Rapporto di Portafoglio | [optional] 
**codSia** | **String** | EF08_CODSIA - SIA/Mittente | [optional] 
**creditidentifier** | **String** | EF08_CREDITIDENTIFIER - Creditor Identifier | [optional] 
**daprogressmav** | **Number** | EF08_DAPROGRESSMAV - Da progressivo | [optional] 
**descr** | **String** | EF08_DESCR - Descrizione | [optional] 
**dittaCg18** | **Number** | EF08_DITTA_CG18 - Ditta | 
**flgAutattribnrmav** | **Number** | EF08_FLGAUTATTRIBNRMAV - Gestione stampa bollettini MAV | [optional] 
**flgCambiali** | **Number** | EF08_FLGCAMBIALI - FlgCambiali&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgCambialiEnum.0]
**flgCessioni** | **Number** | EF08_FLGCESSIONI - FlgCessioni&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgCessioniEnum.0]
**flgMav** | **Number** | EF08_FLGMAV - MAV&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgMavEnum.0]
**flgPref** | **Number** | EF08_FLGPREF - Preferenziale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgPrefEnum.0]
**flgRiba** | **Number** | EF08_FLGRIBA - Ri.Ba.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgRibaEnum.0]
**flgRibacamb** | **Number** | EF08_FLGRIBACAMB - FlgRibacamb | [optional] 
**flgRibacess** | **Number** | EF08_FLGRIBACESS - FlgRibacess | [optional] 
**flgRibaricba** | **Number** | EF08_FLGRIBARICBA - FlgRibaricba | [optional] 
**flgRibatratac** | **Number** | EF08_FLGRIBATRATAC - FlgRibatratac | [optional] 
**flgRibatratte** | **Number** | EF08_FLGRIBATRATTE - FlgRibatratte | [optional] 
**flgRidsdd** | **Number** | EF08_FLGRIDSDD - RID SDD&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgRidsddEnum.0]
**flgRidsddraggr** | **Number** | EF08_FLGRIDSDDRAGGR - Modalità creazione RID SDD&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Analitica&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Raggruppata&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgScfatt** | **Number** | EF08_FLGSCFATT - Sconto fattura&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgScfattEnum.0]
**flgTratte** | **Number** | EF08_FLGTRATTE - FlgTratte&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgTratteEnum.0]
**ggvalcambalt** | **Number** | EF08_GGVALCAMBALT - Giorni di valuta cambiali e cessioni domiciliati altre banche | [optional] 
**ggvalcambfil** | **Number** | EF08_GGVALCAMBFIL - Giorni di valuta cambiali e cessioni domiciliati su stesse filiali banca di presentazione | [optional] 
**ggvalmavincalt** | **Number** | EF08_GGVALMAVINCALT - Giorni di valuta Mav assunti al dopo incasso domiciliati su altre banche | [optional] 
**ggvalmavincfil** | **Number** | EF08_GGVALMAVINCFIL - Giorni di valuta Mav assunti al dopo incasso domiciliati su stesse filiali banca di presentazione | [optional] 
**ggvalmavincpos** | **Number** | EF08_GGVALMAVINCPOS - Giorni di valuta Mav assunti al dopo incasso domiciliati su uffici postali | [optional] 
**ggvalmavsbf** | **Number** | EF08_GGVALMAVSBF - Giorni di valuta Mav presentati a s.b.f. | [optional] 
**ggvalribaalt** | **Number** | EF08_GGVALRIBAALT - Giorni di valuta Ri.Ba. domiciliati altre banche | [optional] 
**ggvalribafil** | **Number** | EF08_GGVALRIBAFIL - Giorni di valuta Ri.Ba. domiciliati su stesse filiali banca di presentazione | [optional] 
**ggvalridalt** | **Number** | EF08_GGVALRIDALT - Giorni di valuta Rid domiciliati su altre banche | [optional] 
**ggvalridfil** | **Number** | EF08_GGVALRIDFIL - Giorni di valuta Rid domiciliati su stesse filiali banca di presentazione | [optional] 
**ggvalscfattalt** | **Number** | EF08_GGVALSCFATTALT - Giorni di valuta Sconto fatture domiciliate altre banche | [optional] 
**ggvalscfattfil** | **Number** | EF08_GGVALSCFATTFIL - Giorni di valuta Sc. fatt. domiciliate su stesse filiali banca di presentazione | [optional] 
**ggvaltratalt** | **Number** | EF08_GGVALTRATALT - Giorni di valuta tratte e tratte accettate domiciliati altre banche | [optional] 
**ggvaltratfil** | **Number** | EF08_GGVALTRATFIL - Giorni di valuta tratte e tratte accettate domiciliati su stesse filiali banca di presentazione | [optional] 
**ibananticipi** | **String** | EF08_IBANANTICIPI - IBAN anticipi | [optional] 
**ibanconto** | **String** | EF08_IBANCONTO - IBAN | [optional] 
**ibaneffpresef** | **String** | EF08_IBANEFFPRESEF - Ibaneffpresef | [optional] 
**ibanordpbonif** | **String** | EF08_IBANORDPBONIF - IBAN Bonifici e Ordini di Pagamento | [optional] 
**id** | **Number** | EF08_ID - ID (Required only in PUT/PATCH) | [optional] 
**idbancaestera** | **String** | EF08_IDBANCAESTERA - Idbancaestera | [optional] 
**idcontratto** | **String** | EF08_IDCONTRATTO - Id Contratto | [optional] 
**idmediaCg99** | **Number** | EF08_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**idsuccursale** | **Number** | EF08_IDSUCCURSALE - ID Succursale | [optional] 
**impcastel** | **Number** | EF08_IMPCASTEL - Importo castelletto | [optional] 
**impfido** | **Number** | EF08_IMPFIDO - Importo fido | [optional] 
**indCheckpivacf** | **Number** | EF08_INDCHECKPIVACF - Controllo presenza CF e P.IVA&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndCheckpivacfEnum.0]
**indCompind** | **Number** | EF08_INDCOMPIND - IndCompind&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Su unico tag XML&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Tag XML strutturato&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indContpmtinf** | **Number** | EF08_INDCONTPMTINF - Numerazione Rid SDD su file&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Progressiva per distinta&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Relativa per raggruppo&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indPresmav** | **Number** | EF08_INDPRESMAV - Tipo presentazione MAV&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Sbf a maturazione valuta&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Sbf ordinario&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Sbf anticipato&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - All&#39;incasso&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Allo sconto&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indPresriba** | **Number** | EF08_INDPRESRIBA - Tipo presentazione Ri.Ba.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Sbf a maturazione valuta&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Sbf ordinario&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Sbf anticipato&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - All&#39;incasso&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Allo sconto&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indPresrid** | **Number** | EF08_INDPRESRID - Tipo presentazione Rid&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Sbf a maturazione valuta&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Sbf ordinario&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Sbf anticipato&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - All&#39;incasso&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Allo sconto&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTipolib** | **Number** | EF08_INDTIPOLIB - Tipo liberalizzazione del castelletto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Data scadenza + gg. valuta (calendario)&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - 1°gg succ. decade scad.+gg.val (calendario)&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - 1°gg succ. decade scad.+gg.val (lavorativi)&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Data scadenza + gg. valuta (lavorativi)&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indTipopres** | **Number** | EF08_INDTIPOPRES - Tipo presentazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Tutte&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  S.b.f. ordinario&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; -  S.b.f. a maturazione valuta&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; -  S.b.f. anticipato&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Incasso&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Sconto&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndTipopresEnum.0]
**locbancaestera** | **String** | EF08_LOCBANCAESTERA - Locbancaestera | [optional] 
**maxgginsoluti** | **Number** | EF08_MAXGGINSOLUTI - Max gg. insoluti | [optional] 
**prefissoattribmav** | **Number** | EF08_PREFISSOATTRIBMAV - Prefisso banca | [optional] 
**progR** | **Number** | EF08_PROGR - Progr. | 
**rowversion** | **Blob** | EF08_ROWVERSION - RowVersion | [optional] 
**scfindbasecalc** | **Number** | EF08_SCFINDBASECALC - Importo base calcolo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Totale documento&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Totale imponibile&lt;/li&gt;&lt;/ul&gt; | [optional] 
**scfnsdocrif** | **String** | EF08_SCFNSDOCRIF - Estremi ns. doc. riferim. | [optional] 
**scfpercpres** | **Number** | EF08_SCFPERCPRES - % di presentazione | [optional] 
**scfperctasso** | **Number** | EF08_SCFPERCTASSO - % tasso interesse | [optional] 
**scfvsdocrif** | **String** | EF08_SCFVSDOCRIF - Estremi vs. doc. riferim. | [optional] 
**spcommbonalt** | **Number** | EF08_SPCOMMBONALT - Spese commissioni su bonifici bancari di altre banche | [optional] 
**spcommbonfil** | **Number** | EF08_SPCOMMBONFIL - Spese commissioni su bonifici bancari di filiali della stessa banca di presentazione | [optional] 
**spcommordpalt** | **Number** | EF08_SPCOMMORDPALT - Spese commissioni su ordini pagamento di altre banche | [optional] 
**spcommordpfil** | **Number** | EF08_SPCOMMORDPFIL - Spese commissioni su ordini pagamento di filiali della stessa banca di presentazione | [optional] 
**spinccambalt** | **Number** | EF08_SPINCCAMBALT - Spese incasso cambiali/cessioni domiciliati su altre banche | [optional] 
**spinccambfil** | **Number** | EF08_SPINCCAMBFIL - Spese incasso cambiali/cessioni domiciliati su filiali della stessa banca di presentazione | [optional] 
**spinccoralt** | **Number** | EF08_SPINCCORALT - Spese incasso conferme d&#39;ordine domiciliati su altre banche | [optional] 
**spinccorfil** | **Number** | EF08_SPINCCORFIL - Spese incasso conferme d&#39;ordine domiciliati su filiali della stessa banca di presentazione | [optional] 
**spincesitopag** | **Number** | EF08_SPINCESITOPAG - Esito di pagamento | [optional] 
**spincmavincalt** | **Number** | EF08_SPINCMAVINCALT - Spese incasso Mav assunti al dopo incasso domiciliati su altre banche | [optional] 
**spincmavincfil** | **Number** | EF08_SPINCMAVINCFIL - Spese incasso Mav assunti al dopo incasso domiciliati su filiali della stessa banca di presentazione | [optional] 
**spincmavincpos** | **Number** | EF08_SPINCMAVINCPOS - Spese incasso Mav assunti al dopo incasso domiciliati su uffici postali | [optional] 
**spincmavsbf** | **Number** | EF08_SPINCMAVSBF - Spese incasso Mav assunti a s.b.f. | [optional] 
**spincribaalt** | **Number** | EF08_SPINCRIBAALT - Spese incasso Ri.Ba. domiciliati su altre banche | [optional] 
**spincribafil** | **Number** | EF08_SPINCRIBAFIL - Spese incasso Ri.Ba. domiciliati su filiali della stessa banca di presentazione | [optional] 
**spincridalt** | **Number** | EF08_SPINCRIDALT - Spese incasso Rid domiciliati su altre banche | [optional] 
**spincridfil** | **Number** | EF08_SPINCRIDFIL - Spese incasso Rid domiciliati su filiali della stessa banca di presentazione | [optional] 
**spinctraalt** | **Number** | EF08_SPINCTRAALT - Spese incasso tratte domiciliati su altre banche | [optional] 
**spinctrafil** | **Number** | EF08_SPINCTRAFIL - Spese incasso tratte domiciliati su filiali della stessa banca di presentazione | [optional] 
**sppresdistinta** | **Number** | EF08_SPPRESDISTINTA - Presentazione distinta | [optional] 
**spritcamb** | **Number** | EF08_SPRITCAMB - Spese di ritorno effettive per cambiali e cessioni | [optional] 
**spritcambcl** | **Number** | EF08_SPRITCAMBCL - Spese di ritorno da addebitare al cliente per cambiali e cessioni | [optional] 
**spritmavincas** | **Number** | EF08_SPRITMAVINCAS - Spese di ritorno effettive per MAV all&#39;incasso | [optional] 
**spritmavincascl** | **Number** | EF08_SPRITMAVINCASCL - Spese di ritorno da addebitare al cliente per MAV all&#39;incasso | [optional] 
**spritmavsbf** | **Number** | EF08_SPRITMAVSBF - Spese di ritorno effettive per MAV Sbf | [optional] 
**spritmavsbfcl** | **Number** | EF08_SPRITMAVSBFCL - Spese di ritorno da addebitare al cliente per MAV Sbf | [optional] 
**spritriba** | **Number** | EF08_SPRITRIBA - Spese di ritorno effettive Ri.Ba. e conferme d&#39;ordine | [optional] 
**spritribacl** | **Number** | EF08_SPRITRIBACL - Spese di ritorno da addebitare al cliente per Ri.Ba. e conferme d&#39;ordine | [optional] 
**spritrid** | **Number** | EF08_SPRITRID - Spese di ritorno effettive per Rid | [optional] 
**spritridcl** | **Number** | EF08_SPRITRIDCL - Spese di ritorno da addebitare al cliente per Rid | [optional] 
**sprittratte** | **Number** | EF08_SPRITTRATTE - Spese di ritorno effettive tratte e tratte accettate | [optional] 
**sprittrattecl** | **Number** | EF08_SPRITTRATTECL - Spese di ritorno da addebitare al cliente per tratte e tratte accettate | [optional] 
**tipobanca** | **Number** | EF08_TIPOBANCA - Tipo banca&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Internazionale&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Domestico&lt;/li&gt;&lt;/ul&gt; | [optional] 
**ultprogressmav** | **Number** | EF08_ULTPROGRESSMAV - Ultimo progressivo | [optional] 
**bankCO** | [**BankCODTO**](BankCODTO.md) |  | [optional] 
**nationCO** | [**NationCODTO**](NationCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgCambialiEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgCessioniEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgMavEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgPrefEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgRibaEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgRidsddEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgRidsddraggrEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgScfattEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgTratteEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndCheckpivacfEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndCompindEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndContpmtinfEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndPresmavEnum


* `1` (value: `1`)

* `0` (value: `0`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)





## Enum: IndPresribaEnum


* `1` (value: `1`)

* `0` (value: `0`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)





## Enum: IndPresridEnum


* `1` (value: `1`)

* `0` (value: `0`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)





## Enum: IndTipolibEnum


* `1` (value: `1`)

* `0` (value: `0`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: IndTipopresEnum


* `0` (value: `0`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)





## Enum: ScfindbasecalcEnum


* `1` (value: `1`)

* `0` (value: `0`)





## Enum: TipobancaEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)




