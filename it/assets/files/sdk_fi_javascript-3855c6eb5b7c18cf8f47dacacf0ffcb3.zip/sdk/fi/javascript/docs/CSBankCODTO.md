# TseCloudFi.CSBankCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bban** | **String** | MG35_BBAN - BBAN | [optional] 
**bicbancaestera** | **String** | MG35_BICBANCAESTERA - BIC | [optional] 
**ccaddetto** | **String** | MG35_CCADDETTO - Addetto | [optional] 
**ccdesagenz** | **String** | MG35_CCDESAGENZ - Descrizione agenzia | [optional] 
**ccforn** | **String** | MG35_CCFORN - Conto corrente | [optional] 
**ccfornfactor** | **Number** | MG35_CCFORNFACTOR - Fornitore per factoring | [optional] 
**ccfornfactoridCg44** | **Number** | MG35_CCFORNFACTORID_CG44 - CcfornfactoridCg44 | [optional] 
**ccggval** | **Number** | MG35_CCGGVAL - Giorni di valuta | [optional] [default to 0]
**cliforCg44** | **Number** | MG35_CLIFOR_CG44 - Codice Cliente / Fornitore | 
**codiceCg07** | **Number** | MG35_CODICE_CG07 - Nazione | [optional] 
**dittaCg18** | **Number** | MG35_DITTA_CG18 - Ditta | 
**flgPref** | **Number** | MG35_FLGPREF - Preferenziale pagamenti&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgPrefEnum.0]
**flgPrefIncassi** | **Number** | MG35_FLGPREF_INCASSI - Preferenziale incassi&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgPrefIncassiEnum.0]
**iban** | **String** | MG35_IBAN - IBAN | [optional] 
**id** | **Number** | MG35_ID - ID (Required only in PUT/PATCH) | [optional] 
**idbancaestera** | **String** | MG35_IDBANCAESTERA - ID Banca estera | [optional] 
**idcontratto** | **String** | MG35_IDCONTRATTO - ID Contratto/Rapporto | [optional] 
**idsuccursale** | **Number** | MG35_IDSUCCURSALE - ID Succursale | [optional] 
**indTipoop** | **Number** | MG35_INDTIPOOP - Tipo operazione | [optional] [default to 2]
**locbancaestera** | **String** | MG35_LOCBANCAESTERA - Località Banca estera | [optional] 
**nomebancaestera** | **String** | MG35_NOMEBANCAESTERA - Nome banca | [optional] 
**progR** | **Number** | MG35_PROGR - Progr. | 
**tipobanca** | **Number** | MG35_TIPOBANCA - Tipo banca&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Internazionale&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Domestico&lt;/li&gt;&lt;/ul&gt; | [optional] 
**tipocfCg44** | **Number** | MG35_TIPOCF_CG44 - Tipo Cliente / Fornitore | 
**agencyCO** | [**AgencyCODTO**](AgencyCODTO.md) |  | [optional] 
**customerSupplierCO** | [**CustomerSupplierCODTO**](CustomerSupplierCODTO.md) |  | [optional] 
**nationCO** | [**NationCODTO**](NationCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgPrefEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgPrefIncassiEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: TipobancaEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)




