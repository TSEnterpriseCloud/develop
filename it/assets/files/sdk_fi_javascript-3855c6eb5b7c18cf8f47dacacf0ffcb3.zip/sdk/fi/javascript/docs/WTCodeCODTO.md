# TseCloudFi.WTCodeCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**causdd1** | **String** | CG15_CAUSDD1 - Causale | [optional] 
**codFiscPrev** | **String** | CG15_CODFISCPREV - Codice fiscale ente previdenziale | [optional] 
**codice** | **String** | CG15_CODICE - Codice | 
**codNonsog** | **Number** | CG15_CODNONSOG - Codice reddito non soggetto CU | [optional] 
**codPrev** | **String** | CG15_CODPREV - Cod. ente previdenziale CU | [optional] 
**codTribrp** | **String** | CG15_CODTRIBRP - Trib.RP | [optional] 
**codTributo** | **String** | CG15_CODTRIBUTO - Trib.RA | [optional] 
**descr** | **String** | CG15_DESCR - Descrizione | [optional] 
**flgGlad** | **Number** | CG15_FLGGLAD - GLA/D&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgGladEnum.0]
**flgMinimi** | **Number** | CG15_FLGMINIMI - FlgMinimi&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgMinimiEnum.0]
**flgPignTerzi** | **Number** | CG15_FLGPIGNTERZI - Pignoramento presso terzi | [optional] 
**flgProteo360** | **Number** | CG15_FLGPROTEO360 - FlgProteo360&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgProteo360Enum.0]
**flgRegagevo** | **Number** | CG15_FLGREGAGEVO - R.Ag.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgRegagevoEnum.0]
**flgRitImposta** | **Number** | CG15_FLGRITIMPOSTA - Ritenuta a titolo d&#39;imposta | [optional] 
**flgSosprit** | **Number** | CG15_FLGSOSPRIT - FlgSosprit&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgSospritEnum.0]
**gcprev** | **Number** | CG15_GCPREV - g/c contributi previdenziali&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Data documento&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Data pagamento&lt;/li&gt;&lt;/ul&gt; | [optional] [default to GcprevEnum.0]
**idmediaCg99** | **Number** | CG15_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**idprov** | **Number** | CG15_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**indCodattglad** | **Number** | CG15_INDCODATTGLAD - Attività modello GLA/D&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Amministratore, revisore, liquidatore&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Amministratore di condominio&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Archiviazione, traduzioni, servizi amm. e contabili&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Assistenza tecnica macchinari, impianti&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Collaborazione giornali, riviste, enciclopedie&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Consulenze aziendali, fiscali, amministr.&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Estetica, igiene in genere&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Formazione, istruzione, addestramento&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Intermediazioni, recup. crediti, notifica atti&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Moda, arte, sport, spettacolo&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - Partecipanti a collegi e commissioni&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Salute, assistenza&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Sondaggi di opinione, marketing, pubblicita&#39;&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Trasporti e spedizioni&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - Turismo, animazione, intrattenimento&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - Vendite a domicilio&lt;/li&gt;&lt;li&gt;&lt;i&gt;17&lt;/i&gt; - Altre&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndCodattgladEnum.0]
**indTipocassa** | **Number** | CG15_INDTIPOCASSA - Tipo cassa&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  &lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Cassa nazionale previdenza e assistenza avvocati e procuratori legali&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Cassa previdenza dottori commercialisti&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Cassa previdenza e assistenza geometri&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Cassa nazionale previdenza e assistenza ingegneri e architetti liberi professionisti&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Cassa nazionale del notariato&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Cassa nazionale previdenza e assistenza ragionieri e periti commerciali&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Ente nazionale assistenza agenti e rappresentanti di commercio (ENASARCO)&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Ente nazionale previdenza e assistenza consulenti del lavoro (ENPACL)&lt;/li&gt;&lt;li&gt;&lt;i&gt;9&lt;/i&gt; - Ente nazionale previdenza e assistenza medici (ENPAM)&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Ente nazionale previdenza e assistenza farmacisti (ENPAF)&lt;/li&gt;&lt;li&gt;&lt;i&gt;11&lt;/i&gt; - Ente nazionale previdenza e assistenza veterinari (ENPAV)&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Ente nazionale previdenza e assistenza impiegati dell&#39;agricoltura (ENPAIA)&lt;/li&gt;&lt;li&gt;&lt;i&gt;13&lt;/i&gt; - Fondo previdenza impiegati imprese di spedizione e agenzie marittime&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Istituto nazionale previdenza giornalisti italiani (INPGI)&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - Opera nazionale assistenza orfani sanitari italiani (ONAOSI)&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - Cassa autonoma assistenza integrativa giornalisti italiani (CASAGIT)&lt;/li&gt;&lt;li&gt;&lt;i&gt;17&lt;/i&gt; - Ente previdenza periti industriali e periti industriali laureati (EPPI)&lt;/li&gt;&lt;li&gt;&lt;i&gt;18&lt;/i&gt; - Ente previdenza e assistenza pluricategoriale (EPAP)&lt;/li&gt;&lt;li&gt;&lt;i&gt;19&lt;/i&gt; - Ente nazionale previdenza e assistenza biologi (ENPAB)&lt;/li&gt;&lt;li&gt;&lt;i&gt;20&lt;/i&gt; - Ente nazionale previdenza e assistenza professione infermieristica (ENPAPI)&lt;/li&gt;&lt;li&gt;&lt;i&gt;21&lt;/i&gt; - Ente nazionale previdenza e assistenza psicologi (ENPAP)&lt;/li&gt;&lt;li&gt;&lt;i&gt;22&lt;/i&gt; - INPS&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndTipocassaEnum.0]
**inpsivs** | **Number** | CG15_INPSIVS - % R.P. | [optional] 
**percbaseimp** | **Number** | CG15_PERCBASEIMP - % B.imp. | [optional] 
**percci** | **Number** | CG15_PERCCI - % C.I. | [optional] 
**percra** | **Number** | CG15_PERCRA - % R.A. | [optional] 
**percripaz** | **Number** | CG15_PERCRIPAZ - % Az. | [optional] 
**percRipPerc** | **Number** | % Perc. | [optional] 
**rowversion** | **Blob** | CG15_ROWVERSION - Rowversion | [optional] 
**tiporapporto** | **String** | CG15_TIPORAPPPREV - Tipo rapporto | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgGladEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgMinimiEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgProteo360Enum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgRegagevoEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgSospritEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: GcprevEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndCodattgladEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)

* `10` (value: `10`)

* `11` (value: `11`)

* `12` (value: `12`)

* `13` (value: `13`)

* `14` (value: `14`)

* `15` (value: `15`)

* `16` (value: `16`)

* `17` (value: `17`)





## Enum: IndTipocassaEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `9` (value: `9`)

* `10` (value: `10`)

* `11` (value: `11`)

* `12` (value: `12`)

* `13` (value: `13`)

* `14` (value: `14`)

* `15` (value: `15`)

* `16` (value: `16`)

* `17` (value: `17`)

* `18` (value: `18`)

* `19` (value: `19`)

* `20` (value: `20`)

* `21` (value: `21`)

* `22` (value: `22`)




