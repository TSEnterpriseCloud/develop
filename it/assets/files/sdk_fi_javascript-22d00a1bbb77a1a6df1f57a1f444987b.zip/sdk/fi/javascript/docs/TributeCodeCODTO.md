# TseCloudFi.TributeCodeCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codMatricolaCg0e** | **String** | CG0F_CODMATRICOLA_CG0E - Codice matricola | 
**codPeriodo1** | **String** | CG0F_CODPERIODO1 - Codice 1° periodo | [optional] 
**codPeriodo2** | **String** | CG0F_CODPERIODO2 - Codice 2° periodo | [optional] 
**codTributo** | **String** | CG0F_CODTRIBUTO - Tributo | 
**descr** | **String** | CG0F_DESCR - Descrizione ridotta | [optional] 
**descrext** | **String** | CG0F_DESCREXT - Descrizione | [optional] 
**flgCodenteloc** | **Number** | CG0F_FLGCODENTELOC - Ind. cod. ente loc.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgCodregione** | **Number** | CG0F_FLGCODREGIONE - Ind.cod.regione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgCredcompens** | **Number** | CG0F_FLGCREDCOMPENS - Cred. compens.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgDebnoncompens** | **Number** | CG0F_FLGDEBNONCOMPENS - Deb. non compens.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgDisattivato** | **Number** | CG0F_FLGDISATTIVATO - FlgDisattivato | [optional] 
**flgIcicomuni** | **Number** | CG0F_FLGICICOMUNI - Ind. ICI o comuni&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgMeserif** | **Number** | CG0F_FLGMESERIF - Ind. mese rif.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgNumrate** | **Number** | CG0F_FLGNUMRATE - Ind. num. rate&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgRichcodatto** | **Number** | CG0F_FLGRICHCODATTO - Rich. cod. atto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgRichcoduff** | **Number** | CG0F_FLGRICHCODUFF - Rich. cod. ufficio&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgStpprov** | **Number** | CG0F_FLGSTPPROV - Ind. sigla prov.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**impdetrazioneici** | **Number** | CG0F_IMPDETRAZIONEICI - Detrazione ICI | 
**indSezione** | **Number** | CG0F_INDSEZIONE - Sezione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - 1-Erario&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - 2 - INPS&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - 3-Regione&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - 4-ICI e comuni&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - 5-INAIL&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - 6 - Altri&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  &lt;/li&gt;&lt;/ul&gt; | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgCodentelocEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgCodregioneEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgCredcompensEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgDebnoncompensEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgIcicomuniEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgMeserifEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgNumrateEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgRichcodattoEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgRichcoduffEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgStpprovEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndSezioneEnum


* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `0` (value: `0`)




