# It.TSEnterprise.Sdk.Model.DocumentoRigaRateiMGDTO
DO42_DOCCORPORATEI - Dati ratei corpo<br>Proprietà chiave:<ul><li><b>DittaCg18</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Adatacomp** | **DateTime** | DO42_ADATACOMP - A data competenza | [optional] 
**CodBeneusato** | **double** | DO42_CODBENEUSATO - Codice bene usato | [optional] 
**ContoparCg24** | **string** | DO42_CONTOPAR_CG24 - Conto contropartita | [optional] 
**Dadatacomp** | **DateTime** | DO42_DADATACOMP - Da data competenza | [optional] 
**Dataregesinc** | **DateTime** | DO42_DATAREGESINC - Data registrazione rateo esercizio corrente | [optional] 
**Dataregesprec** | **DateTime** | DO42_DATAREGESPREC - Data registrazione rateo esercizio precedente | [optional] 
**DittaCg18** | **double** | DO42_DITTA_CG18 - Codice ditta | [optional] [default to 0D]
**FlgDaav** | **double** | DO42_FLGDAAV - Indicatore Dare/Avere | [optional] [default to 0D]
**FlgDisatcoge** | **double** | DO42_FLGDISATCOGE - FlgDisatcoge | [optional] [default to 0D]
**Importo** | **double** | DO42_IMPORTO - Importo | [optional] 
**Imprettcostobu** | **double** | DO42_IMPRETTCOSTOBU - Imprettcostobu | [optional] 
**ImprettcostobuVal** | **double** | DO42_IMPRETTCOSTOBU_VAL - ImprettcostobuVal | [optional] 
**IndTipocomp** | **double** | DO42_INDTIPOCOMP - Importo | [optional] [default to 0D]
**IndTipomovbu** | **double** | DO42_INDTIPOMOVBU - IndTipomovbu | [optional] [default to 0D]
**Percforf** | **double** | DO42_PERCFORF - Percforf | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

