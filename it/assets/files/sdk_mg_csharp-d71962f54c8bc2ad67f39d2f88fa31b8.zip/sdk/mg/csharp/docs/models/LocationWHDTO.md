# It.TSEnterprise.Sdk.Model.LocationWHDTO
MG97_UBICAZ - Ubicazione<br>Proprietà chiave:<ul><li><b>CodDepMg58</b></li><li><b>DittaCg18</b></li><li><b>Ubicaz</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodDepMg58** | **string** | MG97_CODDEP_MG58 - Codice deposito | 
**Descubicaz** | **string** | MG97_DESCUBICAZ - Descrizione ubicazione | 
**Ubicaz** | **string** | MG97_UBICAZ - Codice ubicazione | 
**Altezza** | **double** | MG97_ALTEZZA - Altezza | [optional] 
**CodClassestoc** | **double** | MG97_CODCLASSESTOC - Classe stoccaggio | [optional] 
**CodPriorriemp** | **double** | MG97_CODPRIORRIEMP - Priorità di riempimento | [optional] 
**Coordin1** | **string** | MG97_COORDIN1 - Coordinata 1 | [optional] 
**Coordin2** | **string** | MG97_COORDIN2 - Coordinata 2 | [optional] 
**Coordin3** | **string** | MG97_COORDIN3 - Coordinata 3 | [optional] 
**DittaCg18** | **double** | MG97_DITTA_CG18 - Codice ditta | [optional] [default to 0D]
**IndTipoubicaz** | **double** | MG97_INDTIPOUBICAZ - Tipo ubicazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Di prelevamento&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Di scorta&lt;/li&gt;&lt;/ul&gt; | [optional] [default to 0D]
**Larghezza** | **double** | MG97_LARGHEZZA - Larghezza | [optional] 
**Maxpeso** | **double** | MG97_MAXPESO - Massimo peso | [optional] 
**Profondita** | **double** | MG97_PROFONDITA - Profondità | [optional] 
**Umdimens** | **string** | MG97_UMDIMENS - UM dimensione | [optional] 
**Umpeso** | **string** | MG97_UMPESO - UM Peso | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

