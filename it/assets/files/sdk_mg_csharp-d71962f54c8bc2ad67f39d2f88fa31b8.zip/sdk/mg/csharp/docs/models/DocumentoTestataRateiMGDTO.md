# It.TSEnterprise.Sdk.Model.DocumentoTestataRateiMGDTO
DO23_DOCTESTARATEI - Dati ratei testata<br>Proprietà chiave:<ul><li><b>DittaCg18</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Adatacomp** | **DateTime** | DO23_ADATACOMP - A data competenza | [optional] 
**Contopar** | **string** | DO23_CONTOPAR - Conto contropartita | [optional] 
**Dadatacomp** | **DateTime** | DO23_DADATACOMP - Da data competenza | [optional] 
**Datacompivaman** | **DateTime** | DO23_DATACOMPIVAMAN - Data competenza IVA manuale | [optional] 
**Dataregesinc** | **DateTime** | DO23_DATAREGESINC - Data registrazione rateo esercizio corrente | [optional] 
**Dataregesprec** | **DateTime** | DO23_DATAREGESPREC - Data registrazione rateo esercizio precedente | [optional] 
**DittaCg18** | **double** | DO23_DITTA_CG18 - Codice ditta | [optional] [default to 0D]
**FlgDaav** | **double** | DO23_FLGDAAV - Indicatore Dare/Avere | [optional] [default to 0D]
**FlgDisatcoge** | **double** | DO23_FLGDISATCOGE - FlgDisatcoge | [optional] [default to 0D]
**IndTipocomp** | **double** | DO23_INDTIPOCOMP - Indicatore tipo competenza | [optional] [default to 0D]
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

