# It.TSEnterprise.Sdk.Model.DocumentoRigaCOINMGDTO
DO53_DOCCORPOCOIN - Correlazione conti CoIn/Magazzino<br>Proprietà chiave:<ul><li><b>DittaCg18</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ContodestPc03** | **string** | DO53_CONTODEST_PC03 - Conto destinazione | [optional] 
**ContoorigPc03** | **string** | DO53_CONTOORIG_PC03 - Conto origine | [optional] 
**DittaCg18** | **double** | DO53_DITTA_CG18 - Codice ditta | [optional] [default to 0D]
**FlgEsclriga** | **double** | DO53_FLGESCLRIGA - Escludi&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IdmediaCg99** | **double** | DO53_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**PdcdestPc01** | **double** | DO53_PDCDEST_PC01 - Codice piano dei conti contabilità analitica | [optional] 
**PdcorigPc01** | **double** | DO53_PDCORIG_PC01 - Codice piano dei conti origine | [optional] 
**PdcvdsdestPc01** | **double** | DO53_PDCVDSDEST_PC01 - Codice piano dei conti V.d.S. destinazione | [optional] 
**PdcvdsorigPc01** | **double** | DO53_PDCVDSORIG_PC01 - codice piano dei conti Vds | [optional] 
**VdsdestPc03** | **string** | DO53_VDSDEST_PC03 - Conto VDS destinazione | [optional] 
**VdsorigPc03** | **string** | DO53_VDSORIG_PC03 - Conto VDS origine | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

