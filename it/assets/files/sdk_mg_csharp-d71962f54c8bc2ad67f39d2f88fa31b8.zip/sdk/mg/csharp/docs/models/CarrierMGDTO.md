# It.TSEnterprise.Sdk.Model.CarrierMGDTO
MG14_VETTORI - Vettore<br>Proprietà chiave:<ul><li><b>Codice</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codice** | **string** | MG14_CODICE - Codice | 
**CodiceCg16** | **int** | MG14_CODICE_CG16 - Codice anagrafica generale | 
**GeneralMasterDataCO** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | 
**FlgSchetra** | **double** | MG14_FLGSCHETRA - Soggetto a stampa scheda di trasporto | [optional] [default to 0D]
**IdmediaCg99** | **double** | MG14_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**IndPrefstdoc** | **double** | MG14_INDPREFSTDOC - Stampa pref. documenti&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Stampa&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Fax&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Mail&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - PEC&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Pdf&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Nessuna preferenza&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Nralbotra** | **string** | MG14_NRALBOTRA - Nr. iscrizione albo autotrasportatori | [optional] 
**Targa** | **string** | MG14_TARGA - Targa | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

