# It.TSEnterprise.Sdk.Model.OfficeCODTO
CG31_ANADITTASEDI - Sedi azienda<br>Proprietà chiave:<ul><li><b>Codice</b></li><li><b>DittaCg18</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codice** | **double** | CG31_CODICE - Sede | 
**DittaCg18** | **double** | CG31_DITTA_CG18 - Ditta | 
**Cap** | **string** | CG31_CAP - Cap | [optional] 
**Citta** | **string** | CG31_CITTA - Citta | [optional] 
**IdmediaCg99** | **double** | CG31_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**IndDimcentrocomm** | **double** | CG31_INDDIMCENTROCOMM - Dimensione centro commerciale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Non centro commerciale&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Grande&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Media&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Piccola&lt;/li&gt;&lt;/ul&gt; | [optional] [default to 0D]
**IndIrizzo** | **string** | CG31_INDIRIZZO - Indirizzo | [optional] 
**Numerorea** | **string** | CG31_NUMEROREA - Numero REA | [optional] 
**ProgRea** | **double** | CG31_PROGREA -  Progressivo REA | [optional] 
**Prov** | **string** | CG31_PROV - Provincia | [optional] 
**Rowversion** | **byte[]** | CG31_ROWVERSION - RowVersion | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

