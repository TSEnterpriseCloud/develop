# It.TSEnterprise.Sdk.Model.HeadingReferenceDocumentMGDTO
DO12_DOCTESTARIF - Documenti di riferimento testata<br>Proprietà chiave:<ul><li><b>DittaCg18</b></li><li><b>IndStipodoc</b></li><li><b>IndTipodoc</b></li><li><b>NumregCo99</b></li><li><b>ProgRif</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NumregCo99** | **string** | DO12_NUMREG_CO99 - Numero registrazione | 
**ProgRif** | **double** | DO12_PROGRIF - Progressivo di rif. | 
**Datansconf** | **DateTime** | DO12_DATANSCONF - Data nostra conferma | [optional] 
**Datansdoc** | **DateTime** | DO12_DATANSDOC - Data nostro documento | [optional] 
**Datavsconf** | **DateTime** | DO12_DATAVSCONF - Data vostra conferma | [optional] 
**Datavsdoc** | **DateTime** | DO12_DATAVSDOC - Data vostro documento | [optional] 
**DittaCg18** | **double** | DO12_DITTA_CG18 - Ditta | [optional] [default to 0D]
**Fedatadoc** | **DateTime** | DO12_FEDATADOC - Fedatadoc | [optional] 
**Feiddoc** | **string** | DO12_FEIDDOC - Feiddoc | [optional] 
**Feidsoggetto** | **string** | DO12_FEIDSOGGETTO - Feidsoggetto | [optional] 
**FlgNsdocbis** | **double** | DO12_FLGNSDOCBIS - Flag bis ns documento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndStipodoc** | **double** | DO12_INDSTIPODOC - Indicatore sottotipo documento di riferimento | [optional] [default to 0D]
**IndTipodoc** | **double** | DO12_INDTIPODOC - Indicatore tipo documento di riferimento | [optional] [default to 0D]
**Notensdoc** | **string** | DO12_NOTENSDOC - Note nostro documento | [optional] 
**Notevsdoc** | **string** | DO12_NOTEVSDOC - Note vostro documento | [optional] 
**Numnsdoc** | **double** | DO12_NUMNSDOC - Numero nostro documento | [optional] 
**Numvsdoc** | **string** | DO12_NUMVSDOC - Numero vostro documento | [optional] 
**Rifnsdoc** | **string** | DO12_RIFNSDOC - Riferimento nostro documento | [optional] 
**Rifvsdoc** | **string** | DO12_RIFVSDOC - Riferimento vostro documento | [optional] 
**Seznsdoc** | **string** | DO12_SEZNSDOC - Sezionale nostro documento | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

