# It.TSEnterprise.Sdk.Model.DocumentoTestataMGDTO
DO11_DOCTESTATA - Documento<br>Proprietà chiave:<ul><li><b>Ditta</b></li><li><b>NumReg</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Datadoc** | **DateTime** | DO11_DATADOC - Data docum. | 
**Datareg** | **DateTime** | DO11_DATAREG - Data registrazione documento | 
**Numdoc** | **double** | DO11_NUMDOC - Numero documento | 
**Sezdoc** | **string** | DO11_SEZDOC - Sezionale documento | 
**AnagraficaDocumentoDitta** | [**CompanyDocumentMasterDataMGDTO**](CompanyDocumentMasterDataMGDTO.md) |  | 
**StatoAttuale** | [**StatoAttualeDTO**](StatoAttualeDTO.md) |  | 
**StorageWH** | [**StorageWHDTO**](StorageWHDTO.md) |  | 
**Guid** | **Guid** | DO11_GUID - GUID for current states and extended attributes | [optional] 
**EsclusioneAgentiMultipli** | **int** | Deprecated: use callOptions.EsclusioneAgentiMultipli | [optional] 
**EsclusioneIvaTestata** | **int** | Deprecated: use callOptions.EsclusioneIvaTestata | [optional] 
**FlgLockOnDocExist** | **bool** | Deprecated: use callOptions.FlgLockOnDocExist | [optional] 
**Acconto** | **double** | DO13_ACCONTO - Acconto | [optional] 
**Abbuono** | **double** | DO13_ABBUONO - Abbuono | [optional] 
**CallOptions** | [**DocumentHeaderCallOptionsDTO**](DocumentHeaderCallOptionsDTO.md) |  | [optional] 
**BancaCg12** | **double** | DO11_BANCA_CG12 - Codice banca di appoggio | [optional] 
**Cambio** | **double** | DO11_CAMBIO - Cambio valuta | [optional] 
**CauprestCg15** | **string** | DO11_CAUPREST_CG15 - Codice causale prestazione | [optional] 
**CausmagMg51** | **double** | DO11_CAUSMAG_MG51 - Codice causale magazzino | [optional] 
**Cig** | **string** | DO11_CIG - CIG | [optional] 
**CliForDest** | **string** | DO11_CLIFORDEST - Codice destinatario | [optional] 
**Cliforfatt** | **double** | DO11_CLIFORFATT - Codice cliente/fornitore per fatturazione | [optional] 
**CodbloccoMg25** | **string** | DO11_CODBLOCCO_MG25 - Codice di blocco documento | [optional] 
**CodcabCg13** | **double** | DO11_CODCAB_CG13 - Codice agenzia di appoggio | [optional] 
**CodpagCg62** | **string** | DO11_CODPAG_CG62 - Codice Pagamento | [optional] 
**Cup** | **string** | DO11_CUP - CUP | [optional] 
**Datacambio** | **DateTime** | DO11_DATACAMBIO - Data cambio | [optional] 
**Datainiziopag** | **DateTime** | DO11_DATAINIZIOPAG - Data decorrenza pagamento manuale | [optional] 
**Dataplafond** | **DateTime** | DO11_DATAPLAFOND - Data Plafond | [optional] 
**Descraggcont** | **string** | DO11_DESCRAGGCONT - Descrizione aggiuntiva della registrazione in contabilità | [optional] 
**Ditta** | **double** | DO11_DITTA_CG18 - Ditta | [optional] [default to 0D]
**FlgClifat** | **int** | DO11_FLGCLIFAT - Flag cliente/fornitore per fatturazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgDocstamp** | **int** | DO11_FLGDOCSTAMP - Flag documento stampato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgSpbolli** | **int** | DO11_FLGSPBOLLI - Flag spese bolli&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgSpincas** | **int** | DO11_FLGSPINCAS - Flag spese di incasso&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IdcontCo02** | **double** | DO11_IDCONT_CO02 - Codice Contatto/Rif. Azienda | [optional] 
**IdmediaCg99** | **double** | DO11_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**Indconvclifat** | **int** | DO11_INDCONVCLIFAT - Conversione cliente per fatturazione | [optional] 
**Indfattpa** | **int** | DO11_INDFATTPA - Tipo fatt. PA | [optional] [default to 0]
**Lastchange** | **DateTime** | DO11_LASTCHANGE - Data ultima modifica | [optional] 
**LineaFa05** | **string** | DO11_LINEA_FA05 - Linea fashion | [optional] 
**Listmag** | **double** | DO11_LISTMAG - Listmag | [optional] 
**Notedocum** | **string** | DO11_NOTEDOCUM - Note documento | [optional] 
**Numautof** | **double** | DO11_NUMAUTOF - Numero autofattura | [optional] 
**Numdocorig** | **string** | DO11_NUMDOCORIG - Numero documento originale | [optional] 
**NumReg** | **string** | DO11_NUMREG_CO99 - Numero registrazione | [optional] [default to "000000000000"]
**ProgrEf08** | **double** | DO11_PROGR_EF08 - Codice banca aziendale | [optional] 
**Sezautof** | **string** | DO11_SEZAUTOF - Sezionale autofattura | [optional] 
**StagioneMg5t** | **int** | DO11_STAGIONE_MG5T - Codice stagione | [optional] 
**Stipodoc** | **double** | DO11_STIPODOC - Sottotipo documento | [optional] 
**Testoletint** | **string** | DO11_TESTOLETINT - Descrizione lettera di intento | [optional] 
**Tipodoc** | **double** | DO11_TIPODOC - Tipo documento | [optional] 
**Tipodocnumeraz** | **double** | DO11_TIPODOCNUMERAZ - Indicatore tipo documento di riferimento numerazione | [optional] 
**Tiponumautof** | **double** | DO11_TIPONUMAUTOF - Tipo registro autofatture | [optional] 
**ValutaCg08** | **string** | DO11_VALUTA_CG08 - Codice valuta | [optional] 
**IdExtendedAttributeEntity** | **int** |  | [optional] 
**IdExtendedAttributeSubEntity** | **int** |  | [optional] 
**CodIva** | [**VatCodeCODTO**](VatCodeCODTO.md) |  | [optional] 
**CustomerSupplierMG** | [**CustomerSupplierMGDTO**](CustomerSupplierMGDTO.md) |  | [optional] 
**DocumentMaster** | [**DocumentMasterCODTO**](DocumentMasterCODTO.md) |  | [optional] 
**DocumentoDatiAccompagnamentoMG** | [**DocumentoDatiAccompagnamentoMGDTO**](DocumentoDatiAccompagnamentoMGDTO.md) |  | [optional] 
**DocumentoTestataAgentiMG** | [**List&lt;DocumentoTestataAgentiMGDTO&gt;**](DocumentoTestataAgentiMGDTO.md) |  | [optional] 
**DocumentoTestataProgettiMG** | [**DocumentoTestataProgettiMGDTO**](DocumentoTestataProgettiMGDTO.md) |  | [optional] 
**DocumentoTestataProvvigioniMG** | [**List&lt;DocumentoTestataProvvigioniMGDTO&gt;**](DocumentoTestataProvvigioniMGDTO.md) |  | [optional] 
**DocumentoTestataRateiMG** | [**DocumentoTestataRateiMGDTO**](DocumentoTestataRateiMGDTO.md) |  | [optional] 
**HeadingReferenceDocumentMG** | [**List&lt;HeadingReferenceDocumentMGDTO&gt;**](HeadingReferenceDocumentMGDTO.md) |  | [optional] 
**OfficeCO** | [**OfficeCODTO**](OfficeCODTO.md) |  | [optional] 
**Righe** | [**List&lt;DocumentoRigaMGDTO&gt;**](DocumentoRigaMGDTO.md) |  | [optional] 
**StorageWHCollegato** | [**StorageWHDTO**](StorageWHDTO.md) |  | [optional] 
**TestataEstesa** | [**List&lt;DocumentoTestataEstesaMGDTO&gt;**](DocumentoTestataEstesaMGDTO.md) |  | [optional] 
**TestataOrdine** | [**DocumentoTestataOrdiniMGDTO**](DocumentoTestataOrdiniMGDTO.md) |  | [optional] 
**TestataPersonalizzata** | [**List&lt;DocumentoTestataPersonalizzataMGDTO&gt;**](DocumentoTestataPersonalizzataMGDTO.md) |  | [optional] 
**TotaliDocumento** | [**TotaleDocumentoMGDTO**](TotaleDocumentoMGDTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

