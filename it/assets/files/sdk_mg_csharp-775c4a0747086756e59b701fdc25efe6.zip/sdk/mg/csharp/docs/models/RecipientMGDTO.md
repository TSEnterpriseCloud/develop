# It.TSEnterprise.Sdk.Model.RecipientMGDTO
MG22_CLIFORDEST - Destinatario<br>Proprietà chiave:<ul><li><b>CliforCg44</b></li><li><b>CodDestin</b></li><li><b>DittaCg18</b></li><li><b>TipocfCg44</b></li></ul>

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CliforCg44** | **double** | MG22_CLIFOR_CG44 - Codice cliente fornitore | 
**CodDestin** | **string** | MG22_CODDESTIN - Codice destinatario | 
**TipocfCg44** | **double** | MG22_TIPOCF_CG44 - Tipo Cliente/Fornitore | 
**AreaMGMg08** | **string** | MG22_AREA_MG08 - Area | [optional] 
**CodAlf** | **string** | MG22_CODALF - Cod. alfanumerico | [optional] 
**Datavaliva** | **DateTime** | MG22_DATAVALIVA - Data fine validità | [optional] 
**Destcap** | **double** | MG22_DESTCAP - Cap | [optional] 
**Destcapchar** | **string** | MG22_DESTCAPCHAR - Cap | [optional] 
**Destcell** | **string** | MG22_DESTCELL - Cellulare | [optional] 
**Destcitta** | **string** | MG22_DESTCITTA - Città | [optional] 
**Destemail** | **string** | MG22_DESTEMAIL - Email | [optional] 
**Destfax** | **string** | MG22_DESTFAX - Fax | [optional] 
**Destind** | **string** | MG22_DESTIND - Indirizzo | [optional] 
**Destindex** | **string** | MG22_DESTINDEX - Indirizzo esteso | [optional] 
**Destnote** | **string** | MG22_DESTNOTE - Note | [optional] 
**Destpec** | **string** | MG22_DESTPEC - PEC | [optional] 
**Destprov** | **string** | MG22_DESTPROV - Provincia | [optional] 
**Destragsoc** | **string** | MG22_DESTRAGSOC - Ragione sociale | [optional] 
**Destragsocex** | **string** | MG22_DESTRAGSOCEX - Ragione sociale estesa | [optional] 
**Desttel** | **string** | MG22_DESTTEL - Numero di telefono | [optional] 
**DittaCg18** | **double** | MG22_DITTA_CG18 - Ditta | [optional] [default to 0D]
**FlgAppiva** | **int** | MG22_FLGAPPIVA - FlgAppiva&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgAppivaEnum.NUMBER_0]
**FlgApptaxdata** | **int** | MG22_FLGAPPTAXDATA - FlgApptaxdata&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgStetic** | **double** | MG22_FLGSTETIC - Stampa etichette | [optional] [default to 1D]
**FlgTaxliable** | **int** | MG22_FLGTAXLIABLE - FlgTaxliable&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**IndPrefstdoc** | **double** | MG22_INDPREFSTDOC - Stampa pref. documento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Stampa&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Fax&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Mail&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - PEC&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Pdf&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Nessuna preferenza&lt;/li&gt;&lt;/ul&gt; | [optional] 
**MacroareaMg07** | **string** | MG22_MACROAREA_MG07 - Macroarea | [optional] 
**Taxexemptionno** | **string** | MG22_TAXEXEMPTIONNO - Taxexemptionno | [optional] 
**Tipodestxdoc** | **double** | MG22_TIPODESTXDOC - Dest. x doc.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Predef. Cli.&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Italia&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Estero&lt;/li&gt;&lt;/ul&gt; | [optional] 
**ZonaMg09** | **string** | MG22_ZONA_MG09 -  Zona | [optional] 
**GeneralMasterDataCO** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | [optional] 
**NationCO** | [**NationCODTO**](NationCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

