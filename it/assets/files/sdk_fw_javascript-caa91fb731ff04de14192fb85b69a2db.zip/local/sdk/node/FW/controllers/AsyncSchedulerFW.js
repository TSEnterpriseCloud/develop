'use strict';

var utils = require('../utils/writer.js');
var AsyncSchedulerFW = require('../service/AsyncSchedulerFWService');

module.exports.apiV1EnvironmentFWAsyncSchedulerFWGET = function apiV1EnvironmentFWAsyncSchedulerFWGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  AsyncSchedulerFW.apiV1EnvironmentFWAsyncSchedulerFWGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWAsyncSchedulerFWIdDELETE = function apiV1EnvironmentFWAsyncSchedulerFWIdDELETE (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  AsyncSchedulerFW.apiV1EnvironmentFWAsyncSchedulerFWIdDELETE(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWAsyncSchedulerFWIdGET = function apiV1EnvironmentFWAsyncSchedulerFWIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  AsyncSchedulerFW.apiV1EnvironmentFWAsyncSchedulerFWIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWAsyncSchedulerFWIdPATCH = function apiV1EnvironmentFWAsyncSchedulerFWIdPATCH (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  AsyncSchedulerFW.apiV1EnvironmentFWAsyncSchedulerFWIdPATCH(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWAsyncSchedulerFWIdPUT = function apiV1EnvironmentFWAsyncSchedulerFWIdPUT (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  AsyncSchedulerFW.apiV1EnvironmentFWAsyncSchedulerFWIdPUT(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWAsyncSchedulerFWPOST = function apiV1EnvironmentFWAsyncSchedulerFWPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  AsyncSchedulerFW.apiV1EnvironmentFWAsyncSchedulerFWPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWAsyncSchedulerFWReadPOST = function apiV1EnvironmentFWAsyncSchedulerFWReadPOST (req, res, next, body, dlevel, dlevelkey, company, user, environment, authorizationScope, acceptLanguage) {
  AsyncSchedulerFW.apiV1EnvironmentFWAsyncSchedulerFWReadPOST(body, dlevel, dlevelkey, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWAsyncSchedulerFWSearchPOST = function apiV1EnvironmentFWAsyncSchedulerFWSearchPOST (req, res, next, body, loadEntireDomain, gettotalcount, company, user, environment, authorizationScope, acceptLanguage) {
  AsyncSchedulerFW.apiV1EnvironmentFWAsyncSchedulerFWSearchPOST(body, loadEntireDomain, gettotalcount, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWAsyncSchedulerFWValidatePOST = function apiV1EnvironmentFWAsyncSchedulerFWValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  AsyncSchedulerFW.apiV1EnvironmentFWAsyncSchedulerFWValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWAsyncSchedulerFWValidatePropertiesPOST = function apiV1EnvironmentFWAsyncSchedulerFWValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  AsyncSchedulerFW.apiV1EnvironmentFWAsyncSchedulerFWValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
