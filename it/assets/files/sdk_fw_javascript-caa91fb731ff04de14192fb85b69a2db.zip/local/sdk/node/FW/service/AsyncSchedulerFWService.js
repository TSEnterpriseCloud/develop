'use strict';


/**
 * Get new
 * Get an empty object of type corresponding
 *
 * _op String The value must be 'new'
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * acceptLanguage String Example for multilanguage (optional)
 * returns AsyncSchedulerFWDTO
 **/
exports.apiV1EnvironmentFWAsyncSchedulerFWGET = function(_op,environment,authorizationScope,company,user,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "cronexpr" : "cronexpr",
  "startdatetimeutc" : "2000-01-23T04:56:07.000+00:00",
  "serializedParameter" : "serializedParameter",
  "lastexecutionutc" : "2000-01-23T04:56:07.000+00:00",
  "withcompany" : true,
  "enddatetimeutc" : "2000-01-23T04:56:07.000+00:00",
  "additionalinfo" : "additionalinfo",
  "extensionData" : [ {
    "value" : "",
    "key" : "key"
  }, {
    "value" : "",
    "key" : "key"
  } ],
  "asyncCatalogFW" : {
    "descriptionid" : 0,
    "classname" : "classname",
    "idoperation" : "idoperation",
    "assemblyname" : "assemblyname",
    "detaillifehours" : 6,
    "additionalData" : {
      "key" : ""
    },
    "groupname" : "groupname",
    "extensionData" : [ {
      "value" : "",
      "key" : "key"
    }, {
      "value" : "",
      "key" : "key"
    } ],
    "isSchedulable" : true,
    "rowversion" : ""
  },
  "idoperation" : "idoperation",
  "nextexecutionutc" : "2000-01-23T04:56:07.000+00:00",
  "id" : 0,
  "isDisabled" : false,
  "additionalData" : {
    "key" : ""
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete
 * Deleting object of type 
 *
 * id String 
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * acceptLanguage String Example for multilanguage (optional)
 * no response value expected for this operation
 **/
exports.apiV1EnvironmentFWAsyncSchedulerFWIdDELETE = function(id,environment,authorizationScope,company,user,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get by ID
 * Get an object of type corresponding the requested id
 *
 * id String Id to get the object
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * dlevel String Serialization level (optional)
 * dlevelkey String Serialization level key (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * acceptLanguage String Example for multilanguage (optional)
 * returns AsyncSchedulerFWDTO
 **/
exports.apiV1EnvironmentFWAsyncSchedulerFWIdGET = function(id,environment,authorizationScope,dlevel,dlevelkey,company,user,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "cronexpr" : "cronexpr",
  "startdatetimeutc" : "2000-01-23T04:56:07.000+00:00",
  "serializedParameter" : "serializedParameter",
  "lastexecutionutc" : "2000-01-23T04:56:07.000+00:00",
  "withcompany" : true,
  "enddatetimeutc" : "2000-01-23T04:56:07.000+00:00",
  "additionalinfo" : "additionalinfo",
  "extensionData" : [ {
    "value" : "",
    "key" : "key"
  }, {
    "value" : "",
    "key" : "key"
  } ],
  "asyncCatalogFW" : {
    "descriptionid" : 0,
    "classname" : "classname",
    "idoperation" : "idoperation",
    "assemblyname" : "assemblyname",
    "detaillifehours" : 6,
    "additionalData" : {
      "key" : ""
    },
    "groupname" : "groupname",
    "extensionData" : [ {
      "value" : "",
      "key" : "key"
    }, {
      "value" : "",
      "key" : "key"
    } ],
    "isSchedulable" : true,
    "rowversion" : ""
  },
  "idoperation" : "idoperation",
  "nextexecutionutc" : "2000-01-23T04:56:07.000+00:00",
  "id" : 0,
  "isDisabled" : false,
  "additionalData" : {
    "key" : ""
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update partial
 * Patching an object of type
 *
 * body  Object of type to patch
 * force String The warning/s code to bypass (separated by ‘,’) during the execution (optional)
 * _op String Set 'reload', if you want the DTO updated in the response request (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * id String 
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * no response value expected for this operation
 **/
exports.apiV1EnvironmentFWAsyncSchedulerFWIdPATCH = function(body,force,_op,company,user,id,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Update
 * Updating an object of type
 *
 * body AsyncSchedulerFWDTO Object of type to update
 * force String The warning/s code to bypass (separated by ‘,’) during the execution (optional)
 * _op String Set 'reload', if you want the DTO updated in the response request, otherwise will be returned null value (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * id String 
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns AsyncSchedulerFWDTO
 **/
exports.apiV1EnvironmentFWAsyncSchedulerFWIdPUT = function(body,force,_op,company,user,id,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "cronexpr" : "cronexpr",
  "startdatetimeutc" : "2000-01-23T04:56:07.000+00:00",
  "serializedParameter" : "serializedParameter",
  "lastexecutionutc" : "2000-01-23T04:56:07.000+00:00",
  "withcompany" : true,
  "enddatetimeutc" : "2000-01-23T04:56:07.000+00:00",
  "additionalinfo" : "additionalinfo",
  "extensionData" : [ {
    "value" : "",
    "key" : "key"
  }, {
    "value" : "",
    "key" : "key"
  } ],
  "asyncCatalogFW" : {
    "descriptionid" : 0,
    "classname" : "classname",
    "idoperation" : "idoperation",
    "assemblyname" : "assemblyname",
    "detaillifehours" : 6,
    "additionalData" : {
      "key" : ""
    },
    "groupname" : "groupname",
    "extensionData" : [ {
      "value" : "",
      "key" : "key"
    }, {
      "value" : "",
      "key" : "key"
    } ],
    "isSchedulable" : true,
    "rowversion" : ""
  },
  "idoperation" : "idoperation",
  "nextexecutionutc" : "2000-01-23T04:56:07.000+00:00",
  "id" : 0,
  "isDisabled" : false,
  "additionalData" : {
    "key" : ""
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Create
 * Creating new object of type
 *
 * body AsyncSchedulerFWDTO Object of type to create
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns AsyncSchedulerFWDTO
 **/
exports.apiV1EnvironmentFWAsyncSchedulerFWPOST = function(body,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "cronexpr" : "cronexpr",
  "startdatetimeutc" : "2000-01-23T04:56:07.000+00:00",
  "serializedParameter" : "serializedParameter",
  "lastexecutionutc" : "2000-01-23T04:56:07.000+00:00",
  "withcompany" : true,
  "enddatetimeutc" : "2000-01-23T04:56:07.000+00:00",
  "additionalinfo" : "additionalinfo",
  "extensionData" : [ {
    "value" : "",
    "key" : "key"
  }, {
    "value" : "",
    "key" : "key"
  } ],
  "asyncCatalogFW" : {
    "descriptionid" : 0,
    "classname" : "classname",
    "idoperation" : "idoperation",
    "assemblyname" : "assemblyname",
    "detaillifehours" : 6,
    "additionalData" : {
      "key" : ""
    },
    "groupname" : "groupname",
    "extensionData" : [ {
      "value" : "",
      "key" : "key"
    }, {
      "value" : "",
      "key" : "key"
    } ],
    "isSchedulable" : true,
    "rowversion" : ""
  },
  "idoperation" : "idoperation",
  "nextexecutionutc" : "2000-01-23T04:56:07.000+00:00",
  "id" : 0,
  "isDisabled" : false,
  "additionalData" : {
    "key" : ""
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Read
 * Read among object of type
 *
 * body List Search criteria to apply
 * dlevel String Serialization level (optional)
 * dlevelkey String Serialization level key (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns AsyncSchedulerFWDTO
 **/
exports.apiV1EnvironmentFWAsyncSchedulerFWReadPOST = function(body,dlevel,dlevelkey,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "cronexpr" : "cronexpr",
  "startdatetimeutc" : "2000-01-23T04:56:07.000+00:00",
  "serializedParameter" : "serializedParameter",
  "lastexecutionutc" : "2000-01-23T04:56:07.000+00:00",
  "withcompany" : true,
  "enddatetimeutc" : "2000-01-23T04:56:07.000+00:00",
  "additionalinfo" : "additionalinfo",
  "extensionData" : [ {
    "value" : "",
    "key" : "key"
  }, {
    "value" : "",
    "key" : "key"
  } ],
  "asyncCatalogFW" : {
    "descriptionid" : 0,
    "classname" : "classname",
    "idoperation" : "idoperation",
    "assemblyname" : "assemblyname",
    "detaillifehours" : 6,
    "additionalData" : {
      "key" : ""
    },
    "groupname" : "groupname",
    "extensionData" : [ {
      "value" : "",
      "key" : "key"
    }, {
      "value" : "",
      "key" : "key"
    } ],
    "isSchedulable" : true,
    "rowversion" : ""
  },
  "idoperation" : "idoperation",
  "nextexecutionutc" : "2000-01-23T04:56:07.000+00:00",
  "id" : 0,
  "isDisabled" : false,
  "additionalData" : {
    "key" : ""
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Search
 * Search among object of type
 *
 * body SearchDTO Search criteria to apply
 * loadEntireDomain String Specify 'loadEntireDomain=true' if you want all the aggregate (optional)
 * gettotalcount String Specify 'gettotalcount=true' if you want the total number of elements (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns AsyncSchedulerFWDTO
 **/
exports.apiV1EnvironmentFWAsyncSchedulerFWSearchPOST = function(body,loadEntireDomain,gettotalcount,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "cronexpr" : "cronexpr",
  "startdatetimeutc" : "2000-01-23T04:56:07.000+00:00",
  "serializedParameter" : "serializedParameter",
  "lastexecutionutc" : "2000-01-23T04:56:07.000+00:00",
  "withcompany" : true,
  "enddatetimeutc" : "2000-01-23T04:56:07.000+00:00",
  "additionalinfo" : "additionalinfo",
  "extensionData" : [ {
    "value" : "",
    "key" : "key"
  }, {
    "value" : "",
    "key" : "key"
  } ],
  "asyncCatalogFW" : {
    "descriptionid" : 0,
    "classname" : "classname",
    "idoperation" : "idoperation",
    "assemblyname" : "assemblyname",
    "detaillifehours" : 6,
    "additionalData" : {
      "key" : ""
    },
    "groupname" : "groupname",
    "extensionData" : [ {
      "value" : "",
      "key" : "key"
    }, {
      "value" : "",
      "key" : "key"
    } ],
    "isSchedulable" : true,
    "rowversion" : ""
  },
  "idoperation" : "idoperation",
  "nextexecutionutc" : "2000-01-23T04:56:07.000+00:00",
  "id" : 0,
  "isDisabled" : false,
  "additionalData" : {
    "key" : ""
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Validate
 * Validation of object of type
 *
 * body AsyncSchedulerFWDTO Object of type to validate
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * no response value expected for this operation
 **/
exports.apiV1EnvironmentFWAsyncSchedulerFWValidatePOST = function(body,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Validation of one on more properties of Type
 * Validation of object of type
 *
 * body String  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br> (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns ValidateDTO
 **/
exports.apiV1EnvironmentFWAsyncSchedulerFWValidatePropertiesPOST = function(body,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "additionalData" : {
    "key" : ""
  },
  "items" : [ {
    "isError" : true,
    "isWarning" : true,
    "warningCode" : 0,
    "dtoName" : "dtoName",
    "dtoPropertyName" : "dtoPropertyName",
    "message" : "message",
    "entityPropertyPath" : "entityPropertyPath"
  }, {
    "isError" : true,
    "isWarning" : true,
    "warningCode" : 0,
    "dtoName" : "dtoName",
    "dtoPropertyName" : "dtoPropertyName",
    "message" : "message",
    "entityPropertyPath" : "entityPropertyPath"
  } ],
  "extensionData" : [ {
    "value" : "",
    "key" : "key"
  }, {
    "value" : "",
    "key" : "key"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

