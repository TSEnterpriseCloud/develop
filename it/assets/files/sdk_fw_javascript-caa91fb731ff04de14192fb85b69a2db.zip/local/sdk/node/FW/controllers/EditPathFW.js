'use strict';

var utils = require('../utils/writer.js');
var EditPathFW = require('../service/EditPathFWService');

module.exports.apiV1EnvironmentFWEditPathFWGetfilePOST = function apiV1EnvironmentFWEditPathFWGetfilePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  EditPathFW.apiV1EnvironmentFWEditPathFWGetfilePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWEditPathFWGetfilelistPOST = function apiV1EnvironmentFWEditPathFWGetfilelistPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  EditPathFW.apiV1EnvironmentFWEditPathFWGetfilelistPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWEditPathFWRemovefilePOST = function apiV1EnvironmentFWEditPathFWRemovefilePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  EditPathFW.apiV1EnvironmentFWEditPathFWRemovefilePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWEditPathFWUploadfilePOST = function apiV1EnvironmentFWEditPathFWUploadfilePOST (req, res, next, company, user, environment, authorizationScope, acceptLanguage) {
  EditPathFW.apiV1EnvironmentFWEditPathFWUploadfilePOST(company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
