'use strict';

var utils = require('../utils/writer.js');
var AsyncCatalogFW = require('../service/AsyncCatalogFWService');

module.exports.apiV1EnvironmentFWAsyncCatalogFWGET = function apiV1EnvironmentFWAsyncCatalogFWGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  AsyncCatalogFW.apiV1EnvironmentFWAsyncCatalogFWGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWAsyncCatalogFWIdDELETE = function apiV1EnvironmentFWAsyncCatalogFWIdDELETE (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  AsyncCatalogFW.apiV1EnvironmentFWAsyncCatalogFWIdDELETE(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWAsyncCatalogFWIdGET = function apiV1EnvironmentFWAsyncCatalogFWIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  AsyncCatalogFW.apiV1EnvironmentFWAsyncCatalogFWIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWAsyncCatalogFWIdPATCH = function apiV1EnvironmentFWAsyncCatalogFWIdPATCH (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  AsyncCatalogFW.apiV1EnvironmentFWAsyncCatalogFWIdPATCH(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWAsyncCatalogFWIdPUT = function apiV1EnvironmentFWAsyncCatalogFWIdPUT (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  AsyncCatalogFW.apiV1EnvironmentFWAsyncCatalogFWIdPUT(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWAsyncCatalogFWPOST = function apiV1EnvironmentFWAsyncCatalogFWPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  AsyncCatalogFW.apiV1EnvironmentFWAsyncCatalogFWPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWAsyncCatalogFWReadPOST = function apiV1EnvironmentFWAsyncCatalogFWReadPOST (req, res, next, body, dlevel, dlevelkey, company, user, environment, authorizationScope, acceptLanguage) {
  AsyncCatalogFW.apiV1EnvironmentFWAsyncCatalogFWReadPOST(body, dlevel, dlevelkey, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWAsyncCatalogFWSearchPOST = function apiV1EnvironmentFWAsyncCatalogFWSearchPOST (req, res, next, body, loadEntireDomain, gettotalcount, company, user, environment, authorizationScope, acceptLanguage) {
  AsyncCatalogFW.apiV1EnvironmentFWAsyncCatalogFWSearchPOST(body, loadEntireDomain, gettotalcount, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWAsyncCatalogFWValidatePOST = function apiV1EnvironmentFWAsyncCatalogFWValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  AsyncCatalogFW.apiV1EnvironmentFWAsyncCatalogFWValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentFWAsyncCatalogFWValidatePropertiesPOST = function apiV1EnvironmentFWAsyncCatalogFWValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  AsyncCatalogFW.apiV1EnvironmentFWAsyncCatalogFWValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
