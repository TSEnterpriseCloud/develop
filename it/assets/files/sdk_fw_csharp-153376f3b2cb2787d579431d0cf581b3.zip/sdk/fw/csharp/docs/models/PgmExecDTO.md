# It.TSEnterprise.Sdk.Model.PgmExecDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdTaskScheduled** | **string** | Id for Scheduled Task | [optional] 
**TimeoutSeconds** | **int** | Timeout in seconds for Scheduled Task | [optional] 
**SkipIfRunning** | **bool** | Skip if a task with same id is running | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

