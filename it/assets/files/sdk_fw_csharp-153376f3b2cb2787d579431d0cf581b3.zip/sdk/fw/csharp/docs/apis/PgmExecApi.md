# It.TSEnterprise.Sdk.Api.PgmExecApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**ApiV1EnvironmentFWPgmExecGetscheduledjobsGet**](PgmExecApi.md#apiv1environmentfwpgmexecgetscheduledjobsget) | **GET** /api/v1/{environment}/FW/PgmExec/getscheduledjobs | Get all scheduled jobs |
| [**ApiV1EnvironmentFWPgmExecPgmexecschedulerasyncPost**](PgmExecApi.md#apiv1environmentfwpgmexecpgmexecschedulerasyncpost) | **POST** /api/v1/{environment}/FW/PgmExec/pgmexecschedulerasync | Schedule and Execute program |

<a id="apiv1environmentfwpgmexecgetscheduledjobsget"></a>
# **ApiV1EnvironmentFWPgmExecGetscheduledjobsGet**
> void ApiV1EnvironmentFWPgmExecGetscheduledjobsGet (string environment, string authorizationScope, string company = null, string user = null, string acceptLanguage = null)

Get all scheduled jobs

Get all scheduled jobs

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFWPgmExecGetscheduledjobsGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new PgmExecApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get all scheduled jobs
                apiInstance.ApiV1EnvironmentFWPgmExecGetscheduledjobsGet(environment, authorizationScope, company, user, acceptLanguage);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling PgmExecApi.ApiV1EnvironmentFWPgmExecGetscheduledjobsGet: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFWPgmExecGetscheduledjobsGetWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get all scheduled jobs
    apiInstance.ApiV1EnvironmentFWPgmExecGetscheduledjobsGetWithHttpInfo(environment, authorizationScope, company, user, acceptLanguage);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling PgmExecApi.ApiV1EnvironmentFWPgmExecGetscheduledjobsGetWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If execution is ok |  -  |
| **400** | Bad Request |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | Not found |  -  |
| **409** | Request with conflict |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="apiv1environmentfwpgmexecpgmexecschedulerasyncpost"></a>
# **ApiV1EnvironmentFWPgmExecPgmexecschedulerasyncPost**
> Object ApiV1EnvironmentFWPgmExecPgmexecschedulerasyncPost (string environment, string authorizationScope, PgmExecDTO pgmExecDTO, string company = null, string user = null, string acceptLanguage = null)

Schedule and Execute program

Schedule and Execute program exe

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using It.TSEnterprise.Sdk.Api;
using It.TSEnterprise.Sdk.Client;
using It.TSEnterprise.Sdk.Model;

namespace Example
{
    public class ApiV1EnvironmentFWPgmExecPgmexecschedulerasyncPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://apicsdemo.teamsystem.io";
            // Configure HTTP basic authorization: Basic
            config.Username = "YOUR_USERNAME";
            config.Password = "YOUR_PASSWORD";
            // Configure Bearer token for authorization: Bearer
            config.AccessToken = "YOUR_BEARER_TOKEN";

            var apiInstance = new PgmExecApi(config);
            var environment = "environment_example";  // string | 
            var authorizationScope = "authorizationScope_example";  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var pgmExecDTO = new PgmExecDTO(); // PgmExecDTO | Arguments Array List
            var company = "company_example";  // string | Company code (optional) 
            var user = "user_example";  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = "it-IT";  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Schedule and Execute program
                Object result = apiInstance.ApiV1EnvironmentFWPgmExecPgmexecschedulerasyncPost(environment, authorizationScope, pgmExecDTO, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling PgmExecApi.ApiV1EnvironmentFWPgmExecPgmexecschedulerasyncPost: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ApiV1EnvironmentFWPgmExecPgmexecschedulerasyncPostWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Schedule and Execute program
    ApiResponse<Object> response = apiInstance.ApiV1EnvironmentFWPgmExecPgmexecschedulerasyncPostWithHttpInfo(environment, authorizationScope, pgmExecDTO, company, user, acceptLanguage);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling PgmExecApi.ApiV1EnvironmentFWPgmExecPgmexecschedulerasyncPostWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **environment** | **string** |  |  |
| **authorizationScope** | **string** | The environment where this operation will be executed. This must match with the environment in the url. |  |
| **pgmExecDTO** | [**PgmExecDTO**](PgmExecDTO.md) | Arguments Array List |  |
| **company** | **string** | Company code | [optional]  |
| **user** | **string** | Application user (mandatory if the WebApi user does not have any mapped application user) | [optional]  |
| **acceptLanguage** | **string** | Example for multilanguage | [optional] [default to it-IT] |

### Return type

**Object**

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | If execution is ok |  -  |
| **400** | Bad Request |  -  |
| **401** | Unauthorized access |  -  |
| **403** | Forbidden access |  -  |
| **404** | Not found |  -  |
| **409** | Request with conflict |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

