# TseCloudMg.DocumentoRigaEstesaMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alfst1** | **String** | DO36_ALFST1 - Alfanumerico 1 | [optional] 
**alfst10** | **String** | DO36_ALFST10 - Alfanumerico 10 | [optional] 
**alfst11** | **String** | DO36_ALFST11 - Alfanumerico 11 | [optional] 
**alfst12** | **String** | DO36_ALFST12 - Alfanumerico 12 | [optional] 
**alfst2** | **String** | DO36_ALFST2 - Alfanumerico 2 | [optional] 
**alfst3** | **String** | DO36_ALFST3 - Alfanumerico 3 | [optional] 
**alfst4** | **String** | DO36_ALFST4 - Alfanumerico 4 | [optional] 
**alfst5** | **String** | DO36_ALFST5 - Alfanumerico 5 | [optional] 
**alfst6** | **String** | DO36_ALFST6 - Alfanumerico 6 | [optional] 
**alfst7** | **String** | DO36_ALFST7 - Alfanumerico 7 | [optional] 
**alfst8** | **String** | DO36_ALFST8 - Alfanumerico 8 | [optional] 
**alfst9** | **String** | DO36_ALFST9 - Alfanumerico 9 | [optional] 
**datast1** | **Date** | DO36_DATAST1 - Data 1 | [optional] 
**datast2** | **Date** | DO36_DATAST2 - Data 2 | [optional] 
**datast3** | **Date** | DO36_DATAST3 - Data 3 | [optional] 
**datast4** | **Date** | DO36_DATAST4 - Data 4 | [optional] 
**datast5** | **Date** | DO36_DATAST5 - Data 5 | [optional] 
**datast6** | **Date** | DO36_DATAST6 - Data 6 | [optional] 
**dittaCg18** | **Number** | DO36_DITTA_CG18 - Ditta | [optional] [default to 0]
**flgSt1** | **Number** | DO36_FLGST1 - Flag 1 | [optional] 
**flgSt2** | **Number** | DO36_FLGST2 - Flag 2 | [optional] 
**flgSt3** | **Number** | DO36_FLGST3 - Flag 3 | [optional] 
**flgSt4** | **Number** | DO36_FLGST4 - Flag 4 | [optional] 
**idmediaCg99** | **Number** | DO36_IDMEDIA_CG99 - Hypermedia | [optional] 
**indSt1** | **Number** | DO36_INDST1 - Indicatore 1 | [optional] 
**indSt2** | **Number** | DO36_INDST2 - Indicatore 2 | [optional] 
**numregCo99** | **String** | DO36_NUMREG_CO99 - Numero registrazione | 
**numst1** | **Number** | DO36_NUMST1 - Numerico 1 | [optional] 
**numst10** | **Number** | DO36_NUMST10 - Numerico 10 | [optional] 
**numst11** | **Number** | DO36_NUMST11 - Numerico 11 | [optional] 
**numst12** | **Number** | DO36_NUMST12 - Numerico 12 | [optional] 
**numst2** | **Number** | DO36_NUMST2 - Numerico 2 | [optional] 
**numst3** | **Number** | DO36_NUMST3 - Numerico 3 | [optional] 
**numst4** | **Number** | DO36_NUMST4 - Numerico 4 | [optional] 
**numst5** | **Number** | DO36_NUMST5 - Numerico 5 | [optional] 
**numst6** | **Number** | DO36_NUMST6 - Numerico 6 | [optional] 
**numst7** | **Number** | DO36_NUMST7 - Numerico 7 | [optional] 
**numst8** | **Number** | DO36_NUMST8 - Numerico 8 | [optional] 
**numst9** | **Number** | DO36_NUMST9 - Numerico 9 | [optional] 
**prog** | **Number** | DO36_PROG - Progressivo | [optional] [default to 1]
**progRiga** | **Number** | DO36_PROGRIGA - Progressivo Riga | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


