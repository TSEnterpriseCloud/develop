# TseCloudMg.DocumentoRigaRateiMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**adatacomp** | **Date** | DO42_ADATACOMP - A data competenza | [optional] 
**codBeneusato** | **Number** | DO42_CODBENEUSATO - Codice bene usato | [optional] 
**contoparCg24** | **String** | DO42_CONTOPAR_CG24 - Conto contropartita | [optional] 
**dadatacomp** | **Date** | DO42_DADATACOMP - Da data competenza | [optional] 
**dataregesinc** | **Date** | DO42_DATAREGESINC - Data registrazione rateo esercizio corrente | [optional] 
**dataregesprec** | **Date** | DO42_DATAREGESPREC - Data registrazione rateo esercizio precedente | [optional] 
**dittaCg18** | **Number** | DO42_DITTA_CG18 - Codice ditta | [optional] [default to 0]
**flgDaav** | **Number** | DO42_FLGDAAV - Indicatore Dare/Avere | [optional] [default to 0]
**flgDisatcoge** | **Number** | DO42_FLGDISATCOGE - FlgDisatcoge | [optional] [default to 0]
**importo** | **Number** | DO42_IMPORTO - Importo | [optional] 
**imprettcostobu** | **Number** | DO42_IMPRETTCOSTOBU - Imprettcostobu | [optional] 
**imprettcostobuVal** | **Number** | DO42_IMPRETTCOSTOBU_VAL - ImprettcostobuVal | [optional] 
**indTipocomp** | **Number** | DO42_INDTIPOCOMP - Importo | [optional] [default to 0]
**indTipomovbu** | **Number** | DO42_INDTIPOMOVBU - IndTipomovbu | [optional] [default to 0]
**percforf** | **Number** | DO42_PERCFORF - Percforf | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


