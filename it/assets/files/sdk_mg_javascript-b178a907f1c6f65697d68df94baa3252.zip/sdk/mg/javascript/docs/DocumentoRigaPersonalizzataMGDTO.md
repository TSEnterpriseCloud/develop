# TseCloudMg.DocumentoRigaPersonalizzataMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alfpers1** | **String** | DO35_ALFPERS1 - Alfanumerico 1 applicazioni pers. | [optional] 
**alfpers10** | **String** | DO35_ALFPERS10 - Alfanumerico 10 | [optional] 
**alfpers11** | **String** | DO35_ALFPERS11 - Alfanumerico 11 | [optional] 
**alfpers12** | **String** | DO35_ALFPERS12 - Alfanumerico 12 | [optional] 
**alfpers2** | **String** | DO35_ALFPERS2 - Alfanumerico 2 applicazioni pers. | [optional] 
**alfpers3** | **String** | DO35_ALFPERS3 - Alfanumerico 3 applicazioni pers. | [optional] 
**alfpers4** | **String** | DO35_ALFPERS4 - Alfanumerico 4 applicazioni pers. | [optional] 
**alfpers5** | **String** | DO35_ALFPERS5 - Alfanumerico 5 | [optional] 
**alfpers6** | **String** | DO35_ALFPERS6 - Alfanumerico 6 | [optional] 
**alfpers7** | **String** | DO35_ALFPERS7 - Alfanumerico 7 | [optional] 
**alfpers8** | **String** | DO35_ALFPERS8 - Alfanumerico 8 | [optional] 
**alfpers9** | **String** | DO35_ALFPERS9 - Alfanumerico 9 | [optional] 
**datapers1** | **Date** | DO35_DATAPERS1 - Data personalizzabile 1 | [optional] 
**datapers2** | **Date** | DO35_DATAPERS2 - Data personalizzabile 2 | [optional] 
**datapers3** | **Date** | DO35_DATAPERS3 - Data 3 | [optional] 
**datapers4** | **Date** | DO35_DATAPERS4 - Data 4 | [optional] 
**datapers5** | **Date** | DO35_DATAPERS5 - Data 5 | [optional] 
**datapers6** | **Date** | DO35_DATAPERS6 - Data 6 | [optional] 
**dittaCg18** | **Number** | DO35_DITTA_CG18 - Ditta | [optional] [default to 0]
**flgPers1** | **Number** | DO35_FLGPERS1 - Flag personalizzabile 1 | [optional] 
**flgPers2** | **Number** | DO35_FLGPERS2 - Flag personalizzabile 2 | [optional] 
**flgPers3** | **Number** | DO35_FLGPERS3 - Flag personalizzabile 3 | [optional] 
**flgPers4** | **Number** | DO35_FLGPERS4 - Flag personalizzabile 4 | [optional] 
**idmediaCg99** | **Number** | DO35_IDMEDIA_CG99 - Hypermedia | [optional] 
**indPers1** | **Number** | DO35_INDPERS1 - Indicatore 1 personalizzabile | [optional] 
**indPers2** | **Number** | DO35_INDPERS2 - Indicatore 2 personalizzabile | [optional] 
**numpers1** | **Number** | DO35_NUMPERS1 - Numerico 1 applicazioni pers. | [optional] 
**numpers10** | **Number** | DO35_NUMPERS10 - Numerico 10 | [optional] 
**numpers11** | **Number** | DO35_NUMPERS11 - Numerico 11 | [optional] 
**numpers12** | **Number** | DO35_NUMPERS12 - Numerico 12 | [optional] 
**numpers2** | **Number** | DO35_NUMPERS2 - Numerico 2 applicazioni pers. | [optional] 
**numpers3** | **Number** | DO35_NUMPERS3 - Numerico 3 applicazioni pers. | [optional] 
**numpers4** | **Number** | DO35_NUMPERS4 - Numerico 4 applicazioni pers. | [optional] 
**numpers5** | **Number** | DO35_NUMPERS5 - Numerico 5 | [optional] 
**numpers6** | **Number** | DO35_NUMPERS6 - Numerico 6 | [optional] 
**numpers7** | **Number** | DO35_NUMPERS7 - Numerico 7 | [optional] 
**numpers8** | **Number** | DO35_NUMPERS8 - Numerico 8 | [optional] 
**numpers9** | **Number** | DO35_NUMPERS9 - Numerico 9 | [optional] 
**numregCo99** | **String** | DO35_NUMREG_CO99 - Numero registrazione | 
**prog** | **Number** | DO35_PROG - Progressivo | [optional] [default to 1]
**progRiga** | **Number** | DO35_PROGRIGA - Progressivo Riga | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


