# TseCloudMg.RiskMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codice** | **String** | MG2A_CODICE - Codice rischio | 
**descrizione** | **String** | MG2A_DESCRIZIONE - Descrizione | [optional] 
**dittaCg18** | **Number** | MG2A_DITTA_CG18 - Ditta | [optional] [default to 0]
**flgAttivo** | **Number** | MG2A_FLGATTIVO - Condizione attiva&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgCalceffcons** | **Number** | MG2A_FLGCALCEFFCONS - Elaborazione scadenze consolidate&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgCalceffdacons** | **Number** | MG2A_FLGCALCEFFDACONS - Includi scadenze da consolidare&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgCalceffprev** | **Number** | MG2A_FLGCALCEFFPREV - Includi scadenze previsionali&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgCalcmovcons** | **Number** | MG2A_FLGCALCMOVCONS - Includi movimenti consolidati nel calcolo del saldo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgCalcmovdacons** | **Number** | MG2A_FLGCALCMOVDACONS - Includi movimenti da consolidare nel calcolo del saldo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgCalcmovprev** | **Number** | MG2A_FLGCALCMOVPREV - Includi movimenti previsionali nel calcolo del saldo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgEffettiscaduti** | **Number** | MG2A_FLGEFFETTISCADUTI - Includi effetti  da liberalizzare nel valore del fido&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgOrdini** | **Number** | MG2A_FLGORDINI - Includi ordini non evasi nel valore del fido&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgSaldocon** | **Number** | MG2A_FLGSALDOCON - Includi saldo contabile nel valore del fido&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgScadereins** | **Number** | MG2A_FLGSCADEREINS - Includi effetti a scadere insoluti nel valore del fido&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgScaderenoins** | **Number** | MG2A_FLGSCADERENOINS - Includi effetti a scadere non insoluti nel valore del fido&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgScadutoins** | **Number** | MG2A_FLGSCADUTOINS - Includi effetti scaduti insoluti nel valore del fido&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgScadutonoins** | **Number** | MG2A_FLGSCADUTONOINS - Includi effetti scaduti non insoluti nel valore del fido&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgSelclifortrasf** | **Number** | MG2A_FLGSELCLIFORTRASF - Blocco selezione clienti/fornitori in trasformazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgSolobusinesriskattivo** | **Number** | MG2A_FLGSOLOBUSINESRISKATTIVO - FlgSolobusinesriskattivo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indAttivatrasf** | **Number** | MG2A_INDATTIVATRASF - Modalità di attivazione su trasformazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Tutti selezionati&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Tutti,con fuori fido deselezionati&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Solo fuori fido selezionati&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Solo fuori fido deselezionati&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Escludi fuori fido in automatico&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indElabscadinsol** | **Number** | MG2A_INDELABSCADINSOL - Tipo elaborazione scadenze insolute&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Tutte le scadenze&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Solo scadenze aperte&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Solo scadenze chiuse&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indProvenienzafido** | **Number** | MG2A_INDPROVENIENZAFIDO - Indicatore provenienza fido&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Fido cliente/Fido ass.credito&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Fido ass.credito/Fido cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Fido cliente + Fido ass.rischio&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indSegnalazionecorpo** | **Number** | MG2A_INDSEGNALAZIONECORPO - Modalità segnalazione fuori fido su corpo documento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Segnalazione semplice&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Segnalazione con valori&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Segnalazione completa&lt;/li&gt;&lt;/ul&gt; | [optional] 
**mesiricdocdafatt** | **Number** | MG2A_MESIRICDOCDAFATT - Mesi retroattivi recupero doc. da fatturare | [optional] 
**mesiricordini** | **Number** | MG2A_MESIRICORDINI - Mesi retroattivi recupero doc. da evadere | [optional] 
**mesiricscadenze** | **Number** | MG2A_MESIRICSCADENZE - Mesi retroattivi recupero scadenze da recuperare | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgAttivoEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgCalceffconsEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgCalceffdaconsEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgCalceffprevEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgCalcmovconsEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgCalcmovdaconsEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgCalcmovprevEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgEffettiscadutiEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgOrdiniEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgSaldoconEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgScadereinsEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgScaderenoinsEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgScadutoinsEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgScadutonoinsEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgSelclifortrasfEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgSolobusinesriskattivoEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndAttivatrasfEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)





## Enum: IndElabscadinsolEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: IndProvenienzafidoEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndSegnalazionecorpoEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)




