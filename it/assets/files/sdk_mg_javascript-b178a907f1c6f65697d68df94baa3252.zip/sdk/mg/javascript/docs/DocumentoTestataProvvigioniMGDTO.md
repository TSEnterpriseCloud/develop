# TseCloudMg.DocumentoTestataProvvigioniMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**annoPa23** | **Number** | DO21_ANNO_PA23 - Anno distinta trimestrale ENASARCO | [optional] 
**codiceAgente** | **String** | Codice agente | [optional] 
**dittaCg18** | **Number** | DO21_DITTA_CG18 - Codice ditta | [optional] [default to 0]
**flgPers** | **Number** | DO21_FLGPERS - FlgPers | [optional] 
**flgProvsosp** | **Number** | DO21_FLGPROVSOSP - Flag provvigione sospesa&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgProvvar** | **Number** | DO21_FLGPROVVAR - Flag provvigione variata manualmente&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgSt** | **Number** | DO21_FLGST - FlgSt | [optional] 
**flgStarcred** | **Number** | DO21_FLGSTARCRED - Flag movimento di provvigione soggetta allo star del credere&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgStenas** | **Number** | DO21_FLGSTENAS - Flag stampata distinta enasarco&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**idagenteMg17** | **Number** | DO21_IDAGENTE_MG17 - ID Agente | 
**idmediaCg99** | **Number** | DO21_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**imponprov** | **Number** | DO21_IMPONPROV - Imponibile provvigione | 
**imponprovVal** | **Number** | DO21_IMPONPROV_VAL - Imponibile provvigione in valuta | [optional] [default to 0]
**imporprov** | **Number** | DO21_IMPORPROV - Importo provvigione | 
**imporprovVal** | **Number** | DO21_IMPORPROV_VAL - Importo provvigione in valuta | [optional] [default to 0]
**indPers** | **Number** | DO21_INDPERS - IndPers | [optional] 
**indSt** | **Number** | DO21_INDST - IndSt | [optional] 
**indTipomov** | **Number** | DO21_INDTIPOMOV - Movim.gen.da | [optional] [default to 0]
**noteprov** | **String** | DO21_NOTEPROV - Note provvigioni | [optional] 
**numregCo99** | **String** | DO21_NUMREG_CO99 - Numero registrazione | 
**provmedia** | **Number** | DO21_PROVMEDIA - Percentuale provvigione media | 
**trimestrePa23** | **Number** | DO21_TRIMESTRE_PA23 - Trimestre distinta | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgProvsospEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgProvvarEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgStarcredEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgStenasEnum


* `0` (value: `0`)

* `1` (value: `1`)




