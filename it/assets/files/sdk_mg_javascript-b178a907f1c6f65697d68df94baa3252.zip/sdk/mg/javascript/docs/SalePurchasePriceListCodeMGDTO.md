# TseCloudMg.SalePurchasePriceListCodeMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**desclist** | **String** | MG44_DESCLIST - Descrizione listino | 
**dittaCg18** | **Number** | MG44_DITTA_CG18 - Ditta | [optional] [default to 0]
**flgVenacq** | **Number** | MG44_FLGVENACQ - Vendita / Acquisto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Listino di vendita&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Listino di acquisto&lt;/li&gt;&lt;/ul&gt; | [optional] 
**numlist** | **Number** | MG44_NUMLIST - Numero listino | 
**valutaCg08** | **String** | MG44_VALUTA_CG08 - Codice valuta | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgVenacqEnum


* `0` (value: `0`)

* `1` (value: `1`)




