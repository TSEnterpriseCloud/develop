# TseCloudMg.COAAccountFIDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountType** | **Number** | Tipo conto | [optional] 
**alias** | **String** | CG24_ALIAS - Alias | [optional] 
**codeformatted** | **String** | Codice | 
**codiceCg22** | **Number** | CG24_CODICE_CG22 - Cod.imm. | [optional] 
**codiceCgc0** | **Number** | CG24_CODICE_CGC0 - Codice intercompany | [optional] 
**cogeprogeAbil** | **Number** | CG24_COGEPROGE_ABIL - Abilitato alla correlazione progetti/commesse | [optional] [default to 0]
**cogeprogeAttivita** | **Number** | CG24_COGEPROGE_ATTIVITA - Correla attività | [optional] [default to 0]
**cogeprogeMateriali** | **Number** | CG24_COGEPROGE_MATERIALI - Correla materiali | [optional] [default to 0]
**cogeprogeNodo** | **Number** | CG24_COGEPROGE_NODO - Correla nodo | [optional] [default to 0]
**cogeprogeSpese** | **Number** | CG24_COGEPROGE_SPESE - Correla spese | [optional] [default to 0]
**conto** | **String** | CG24_CONTO - Codice conto | 
**contoape** | **String** | CG24_CONTOAPE - Conto apertura | [optional] 
**contochiu** | **String** | CG24_CONTOCHIU - Conto chiusura | [optional] 
**contocrsosp** | **String** | CG24_CONTOCRSOSP - Conto specifico | [optional] 
**contoratatt** | **String** | CG24_CONTORATATT - Conto rateo att. | [optional] 
**contoratpass** | **String** | CG24_CONTORATPASS - Conto rateo pass. | [optional] 
**contorisatt** | **String** | CG24_CONTORISATT - Conto risc. att. | [optional] 
**contorispass** | **String** | CG24_CONTORISPASS - Conto risc. pass. | [optional] 
**descr** | **String** | CG24_DESCR - Descrizione | [optional] 
**flgAggfatt** | **Number** | CG24_FLGAGGFATT - Agg.fatt.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgAggfattEnum.0]
**flgAnalit** | **Number** | CG24_FLGANALIT - Conto analitico&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgAnalitEnum.1]
**flgBilconsattpassdist** | **Number** | CG24_FLGBILCONSATTPASSDIST - Non utilizzato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgBilconsattpassdistEnum.0]
**flgContoimm** | **Number** | CG24_FLGCONTOIMM - Imm.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgContoimmEnum.0]
**flgGesec** | **Number** | CG24_FLGGESEC - Gest.EC&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgGesecEnum.0]
**flgGespor** | **Number** | CG24_FLGGESPOR - Gest.port.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgGesporEnum.0]
**flgIntercompany** | **Number** | CG24_FLGINTERCOMPANY - Gestione Intercompany&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgIntercompanyEnum.0]
**flgOpnonfin** | **Number** | CG24_FLGOPNONFIN - Cont.per cassa&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgOpnonfinEnum.0]
**flgRaganal** | **Number** | CG24_FLGRAGANAL - Raggr.anal.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgRaganalEnum.0]
**flgRarp** | **Number** | CG24_FLGRARP - Base imp.rit.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgRarpEnum.0]
**flgSaldog** | **Number** | CG24_FLGSALDOG - Saldo data reg.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgSaldogEnum.0]
**flgValutaest** | **Number** | CG24_FLGVALUTAEST - Valuta est.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgValutaestEnum.0]
**gruppoCg10** | **Number** | CG24_GRUPPO_CG10 - Piano dei conti | 
**idconto** | **Number** | CG24_IDCONTO - ID Conto (Required only in PUT/PATCH) | [optional] 
**idcontoapeCg24** | **Number** | CG24_IDCONTOAPE_CG24 - Conto riapertura | [optional] 
**idcontochiuCg24** | **Number** | CG24_IDCONTOCHIU_CG24 - Conto chiusura | [optional] 
**idcontoratattCg24** | **Number** | CG24_IDCONTORATATT_CG24 - Conto rateo att. | [optional] 
**idcontoratpassCg24** | **Number** | CG24_IDCONTORATPASS_CG24 - Conto rateo pass. | [optional] 
**idcontorisattCg24** | **Number** | CG24_IDCONTORISATT_CG24 - Conto risc. att. | [optional] 
**idcontorispassCg24** | **Number** | CG24_IDCONTORISPASS_CG24 - Conto risc. pass. | [optional] 
**idparent** | **Number** | CG24_IDPARENT - Id conto padre | 
**idreverse** | **Number** | CG24_IDREVERSE - Tipo reverse charge | [optional] 
**idRifPdC80** | **Number** | CG24_IDRIFPDC80 - Conto correlazione AI P.d.C 80 | [optional] 
**indAttpasspor** | **Number** | CG24_INDATTPASSPOR - Natura&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Attivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Passivo&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndAttpassporEnum.0]
**indContoricav** | **Number** | CG24_INDCONTORICAV - Tipo conto econ.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Ricavo&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Costo&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndContoricavEnum.0]
**indCosvend** | **Number** | CG24_INDCOSVEND - Costo venduto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Ricavi inerenti attivita&#39;&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Ricavi diversi&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Costi merci e mat. suss.&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Altri costi&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Retribuzioni&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Consumi carb. e lubrif.&lt;/li&gt;&lt;li&gt;&lt;i&gt;7&lt;/i&gt; - Consumi energia&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Altri consumi&lt;/li&gt;&lt;li&gt;&lt;i&gt;98&lt;/i&gt; - Rimanenze iniziali&lt;/li&gt;&lt;li&gt;&lt;i&gt;99&lt;/i&gt; - Rimanenze finali&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndCosvendEnum.0]
**indDaav** | **Number** | CG24_INDDAAV - Segno esp.bilancio&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Dare&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Avere&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndDaavEnum.0]
**indDaavec** | **Number** | CG24_INDDAAVEC - Segno&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Dare&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Avere&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndDaavecEnum.0]
**indLivchius** | **Number** | CG24_INDLIVCHIUS - Livello di chiusura | [optional] [default to 0]
**indMastroCliFor** | **Number** | CG24_INDMASTROCLIFOR - Indicatore mastro clienti/fornitori&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;99&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Mastro clienti&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Mastro fornitori&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndMastroCliForEnum.99]
**indTipoconto** | **Number** | CG24_INDTIPOCONTO - Natura conto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Conto d&#39;ordine&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Patrimoniale&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Economico&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Da non stampare&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndTipocontoEnum.0]
**percindeduc** | **Number** | CG24_PERCINDEDUC - % IRAP | [optional] 
**percindetra** | **Number** | CG24_PERCINDETRA - % IRES/IRPEF | [optional] 
**suddconti** | **Number** | CG24_SUDDCONTI - Informazioni riguardanti la compilazione quadro A modello IVA 11 | [optional] [default to 0]
**coaAccountCustomizationFI** | [**[COAAccountCustomizationFIDTO]**](COAAccountCustomizationFIDTO.md) |  | [optional] 
**coaAccountFIApe** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**coaAccountFIChiu** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**coaAccountFIParent** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**coaAccountFIRatatt** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**coaAccountFIRatpass** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**coaAccountFIRisatt** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**coaAccountFIRispass** | [**COAAccountFIDTO**](COAAccountFIDTO.md) |  | [optional] 
**coaAccountStateFI** | [**[COAAccountStateFIDTO]**](COAAccountStateFIDTO.md) |  | [optional] 
**coaGroupCodeFI** | [**COAGroupCodeFIDTO**](COAGroupCodeFIDTO.md) |  | 
**coaInternationalCustomizationFI** | [**[COAInternationalCustomizationFIDTO]**](COAInternationalCustomizationFIDTO.md) |  | [optional] 
**intragroupStructureCO** | [**IntragroupStructureCODTO**](IntragroupStructureCODTO.md) |  | [optional] 
**reverseTypeFI** | [**GLReverseTypeFIDTO**](GLReverseTypeFIDTO.md) |  | [optional] 
**vatTypeFI** | [**VATTypeFIDTO**](VATTypeFIDTO.md) |  | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgAggfattEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgAnalitEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgBilconsattpassdistEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgContoimmEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgGesecEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgGesporEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgIntercompanyEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgOpnonfinEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgRaganalEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgRarpEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgSaldogEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgValutaestEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndAttpassporEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndContoricavEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndCosvendEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `7` (value: `7`)

* `8` (value: `8`)

* `98` (value: `98`)

* `99` (value: `99`)





## Enum: IndDaavEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndDaavecEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndMastroCliForEnum


* `99` (value: `99`)

* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndTipocontoEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)




