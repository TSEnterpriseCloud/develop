# TseCloudMg.PriceListWithMultipleItemsMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codice** | **String** | LI26_CODICE - Codice listino con più articoli | 
**descr** | **String** | LI26_DESCR - Descrizione | [optional] 
**dittaCg18** | **Number** | LI26_DITTA_CG18 - Ditta | [optional] [default to 0]
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


