# TseCloudMg.TotaleDocumentoMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totdocumento** | **Number** | DO13_TOTDOCUMENTO - Totale documento - This parameter is for Read Only use !! (Cannot set any value) | 
**totimponibile** | **Number** | DO13_TOTIMPONIBILE - Totale imponibile - This parameter is for Read Only use !! (Cannot set any value) | 
**totiva** | **Number** | DO13_TOTIVA - Totale IVA - This parameter is for Read Only use !! (Cannot set any value) | 
**abbuono** | **Number** | DO13_ABBUONO - Abbuono | [optional] [default to 0]
**acconto** | **Number** | DO13_ACCONTO - Acconto | [optional] [default to 0]
**imponibomag** | **Number** | DO13_IMPONIBOMAG - Imponibile omaggi | [optional] [default to 0]
**ivaomag** | **Number** | DO13_IVAOMAG - Importo IVA omaggi | [optional] [default to 0]
**marginedocumento** | **Number** | DO13_MARGINEDOCUMENTO - Importo margine totale | 
**scimpcassa** | **Number** | DO13_SCIMPCASSA - Sconto cassa ad importo | [optional] [default to 0]
**scimpmerce** | **Number** | DO13_SCIMPMERCE - Sconto merce ad importo | [optional] [default to 0]
**scpercassa1** | **Number** | DO13_SCPERCASSA1 - Sconto 1 cassa in percentuale | [optional] [default to 0]
**scpercassa2** | **Number** | DO13_SCPERCASSA2 - Sconto 2 cassa in percentuale | [optional] [default to 0]
**scpermerce1** | **Number** | DO13_SCPERMERCE1 - Sconto 1 merce in percentuale | [optional] [default to 0]
**scpermerce2** | **Number** | DO13_SCPERMERCE2 - Sconto 2 merce in percentuale | [optional] [default to 0]
**scpermerce3** | **Number** | DO13_SCPERMERCE3 - Sconto 3 merce in percentuale | [optional] [default to 0]
**totaleCosto** | **Number** | DO13_TOTCOSTO - Totale costo | [optional] [default to 0]
**totalePagare** | **Number** | DO13_TOTAPAGARE - Totale a pagare | 
**totspbolli** | **Number** | DO13_TOTSPBOLLI - Totale spese bolli | [optional] [default to 0]
**totspinc** | **Number** | DO13_TOTSPINC - Totale spese incasso | [optional] [default to 0]
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


