# TseCloudMg.DocumentoRigaMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**guid** | **String** | DO30_GUID - GUID for current states | [optional] 
**alivacompCg28** | **String** | DO30_ALIVACOMP_CG28 - Codice aliquota IVA di compensazione | [optional] 
**altezza** | **Number** | DO30_ALTEZZA - Altezza | [optional] 
**base** | **Number** | DO30_BASE - Base | [optional] 
**capacita** | **Number** | DO30_CAPACITA - Capacità | [optional] 
**causmagMg51** | **Number** | DO30_CAUSMAG_MG51 - Codice causale di magazzino | [optional] 
**cig** | **String** | DO30_CIG - Codice CIG riga | [optional] 
**codartcli** | **String** | DO30_CODARTCLI -  Codice articolo cliente | [optional] 
**codartfor** | **String** | DO30_CODARTFOR -  Codice articolo fornitore | [optional] 
**codartMg66** | **String** | DO30_CODART_MG66 - Codice Articolo | [optional] 
**coddepcolMg58** | **String** | DO30_CODDEPCOL_MG58 - Codice deposito collegato | [optional] 
**coddepMg58** | **String** | DO30_CODDEP_MG58 - Codice deposito | [optional] 
**codschedaMg42** | **String** | DO30_CODSCHEDA_MG42 - Scheda multipla | [optional] 
**colli** | **Number** | DO30_COLLI - Colli | [optional] [default to 0]
**costotot** | **Number** | DO30_COSTOTOT - Costo riga | [optional] [default to 0]
**cpmerceCg24** | **String** | DO30_CPMERCE_CG24 - Conto merce | [optional] 
**cup** | **String** | DO30_CUP - Codice CUP riga | [optional] 
**descart** | **String** | DO30_DESCART - Descrizione riga | [optional] 
**ditta** | **Number** | DO30_DITTA_CG18 - Codice ditta | [optional] [default to 0]
**estdescart** | **String** | DO30_ESTDESCART - Descrizione estensione | [optional] 
**fatconv** | **Number** | DO30_FATCONV - Fattore di conversione | [optional] 
**fatconvcf** | **Number** | DO30_FATCONVCF - Fattore di conversione cliente/fornitore | [optional] 
**flgContribinteg** | **Number** | DO30_FLGCONTRIBINTEG - Flag soggetto a contributo integrativo&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgContribprev** | **Number** | DO30_FLGCONTRIBPREV - Flag soggetto a contributo previdenziale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgPriceDiscForce** | **Boolean** | FlgPriceDiscForce | [optional] 
**flgRitacc** | **Number** | DO30_FLGRITACC - Flag soggetto a ritenuta d&#39;acconto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgRitenas** | **Number** | DO30_FLGRITENAS - Flag soggetto a ritenuta Enasarco&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**importo** | **Number** | DO30_IMPORTO - Importo riga | 
**indlisacqven** | **Number** | DO30_INDLISACQVEN - Tipo listino | [optional] [default to 0]
**indlisfisso** | **Number** | DO30_INDLISFISSO - Listino fisso | [optional] 
**indlisprior** | **Number** | DO30_INDLISPRIOR - Listino priorità prezzi e sconti | [optional] 
**indtipoomag** | **Number** | DO30_INDTIPOOMAG - Indicatore tipo omaggio&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Omaggio con rivalsa&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Omaggio senza rivalsa&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Omaggio con sconto in merce&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndtipoomagEnum.0]
**indtiporiga** | **Number** | DO30_INDTIPORIGA - Indicatore tipo riga&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Articolo magazz.&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Articolo manuale gestione di tutti i campi&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Descrittiva&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Spesa&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Scheda multipla&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - Testo  fisso&lt;/li&gt;&lt;li&gt;&lt;i&gt;8&lt;/i&gt; - Lettera di intento&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Fase&lt;/li&gt;&lt;li&gt;&lt;i&gt;12&lt;/i&gt; - Cauzioni&lt;/li&gt;&lt;li&gt;&lt;i&gt;14&lt;/i&gt; - Articolo + fase&lt;/li&gt;&lt;li&gt;&lt;i&gt;15&lt;/i&gt; - Nodo&lt;/li&gt;&lt;li&gt;&lt;i&gt;16&lt;/i&gt; - Attività&lt;/li&gt;&lt;li&gt;&lt;i&gt;17&lt;/i&gt; - Spesa di progetto&lt;/li&gt;&lt;/ul&gt; | [optional] 
**lineaFa05** | **String** | DO30_LINEA_FA05 - Linea fashion | [optional] 
**magimp** | **Number** | DO30_MAGIMP - Maggiorazione importo | [optional] [default to 0]
**magper1** | **Number** | DO30_MAGPER1 - Maggiorazione 1 percentuale | [optional] [default to 0]
**magper2** | **Number** | DO30_MAGPER2 - Maggiorazione 2 percentuale | [optional] [default to 0]
**numReg** | **String** | DO30_NUMREG_CO99 - Numero registrazione | 
**opzioneMg5e** | **String** | DO30_OPZIONE_MG5E - Variante | [optional] 
**pesol** | **Number** | DO30_PESOL - Peso lordo | [optional] 
**peson** | **Number** | DO30_PESON - Peso netto | [optional] 
**prezzo1** | **Number** | DO30_PREZZO1 - Prezzo lordo 1 | [optional] [default to 0]
**prezzo1iva** | **Number** | DO30_PREZZO1IVA - Prezzo lordo 1 IVA compresa | [optional] [default to 0]
**prezzo2** | **Number** | DO30_PREZZO2 - Prezzo lordo 2 | [optional] [default to 0]
**prezzo2iva** | **Number** | DO30_PREZZO2IVA - Prezzo lordo 2 IVA compresa | [optional] [default to 0]
**profondita** | **Number** | DO30_PROFONDITA - Profondità | [optional] 
**progPadre** | **Number** | DO30_PROGPADRE - Progressivo Riga Padre | [optional] 
**progrRiga** | **Number** | DO30_PROGRIGA - Progressivo riga interna | 
**progvisuasta** | **Number** | DO30_PROGVISUASTA - Progressivo visualizzazione e stampa | [optional] 
**pzconf** | **Number** | DO30_PZCONF - Pezzi per confezione | [optional] 
**qta1** | **Number** | DO30_QTA1 - Quantità 1  | 
**qta2** | **Number** | DO30_QTA2 - Quantità 2  | [optional] 
**scimp** | **Number** | DO30_SCIMP - Sconto importo | [optional] [default to 0]
**scper1** | **Number** | DO30_SCPER1 - Sconto 1 percentuale | [optional] [default to 0]
**scper2** | **Number** | DO30_SCPER2 - Sconto 2 percentuale | [optional] [default to 0]
**scper3** | **Number** | DO30_SCPER3 - Sconto 3 percentuale | [optional] [default to 0]
**scper4** | **Number** | DO30_SCPER4 - Sconto 4 percentuale | [optional] [default to 0]
**scper5** | **Number** | DO30_SCPER5 - Sconto 5 percentuale | [optional] [default to 0]
**scper6** | **Number** | DO30_SCPER6 - Sconto 6 percentuale | [optional] [default to 0]
**stagioneMg5t** | **Number** | DO30_STAGIONE_MG5T - Codice stagione | [optional] 
**svar1** | **String** | DO30_SVAR1 - Svar1 | [optional] 
**svar2** | **String** | DO30_SVAR2 - Svar2 | [optional] 
**tara** | **Number** | DO30_TARA - Tara | [optional] 
**um1** | **String** | DO30_UM1 - U.M. 1 | [optional] 
**um2** | **String** | DO30_UM2 - U.M. 2 | [optional] 
**codIva** | [**VatCodeCODTO**](VatCodeCODTO.md) |  | [optional] 
**codIvaEff** | [**VatCodeCODTO**](VatCodeCODTO.md) |  | [optional] 
**documentoRigaCOINMG** | [**DocumentoRigaCOINMGDTO**](DocumentoRigaCOINMGDTO.md) |  | [optional] 
**documentoRigaProgettiMG** | [**DocumentoRigaProgettiMGDTO**](DocumentoRigaProgettiMGDTO.md) |  | [optional] 
**documentoRigaProvvigioniMG** | [**[DocumentoRigaProvvigioniMGDTO]**](DocumentoRigaProvvigioniMGDTO.md) |  | [optional] 
**documentoRigaRateiMG** | [**DocumentoRigaRateiMGDTO**](DocumentoRigaRateiMGDTO.md) |  | [optional] 
**officeCO** | [**OfficeCODTO**](OfficeCODTO.md) |  | [optional] 
**packaging** | [**DocumentoRigaConfMGDTO**](DocumentoRigaConfMGDTO.md) |  | [optional] 
**rigaEstesa** | [**[DocumentoRigaEstesaMGDTO]**](DocumentoRigaEstesaMGDTO.md) |  | [optional] 
**rigaLotti** | [**[DocumentoRigaLottoMGDTO]**](DocumentoRigaLottoMGDTO.md) |  | [optional] 
**rigaOrdine** | [**DocumentoRigaOrdineMGDTO**](DocumentoRigaOrdineMGDTO.md) |  | [optional] 
**rigaPersonalizzata** | [**[DocumentoRigaPersonalizzataMGDTO]**](DocumentoRigaPersonalizzataMGDTO.md) |  | [optional] 
**rigaRiferimenti** | [**[DocumentoRigaRiferimentoMGDTO]**](DocumentoRigaRiferimentoMGDTO.md) |  | [optional] 
**spesaVariaMG** | [**SpesaVariaMGDTO**](SpesaVariaMGDTO.md) |  | [optional] 
**statoAttualeCO** | [**StatoAttualeDTO**](StatoAttualeDTO.md) |  | 
**testoFissoMG** | [**TestoFissoMGDTO**](TestoFissoMGDTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgContribintegEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgContribprevEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgRitaccEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgRitenasEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndtipoomagEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: IndtiporigaEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `4` (value: `4`)

* `5` (value: `5`)

* `6` (value: `6`)

* `8` (value: `8`)

* `10` (value: `10`)

* `12` (value: `12`)

* `14` (value: `14`)

* `15` (value: `15`)

* `16` (value: `16`)

* `17` (value: `17`)




