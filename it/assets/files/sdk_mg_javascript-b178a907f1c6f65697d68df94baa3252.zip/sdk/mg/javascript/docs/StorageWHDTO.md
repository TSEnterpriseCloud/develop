# TseCloudMg.StorageWHDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**capdep** | **String** | MG58_CAPDEP - Cap | [optional] 
**codDep** | **String** | MG58_CODDEP - Codice deposito | 
**dataatt** | **Date** | MG58_DATAATT - Data attivazione | 
**datacess** | **Date** | MG58_DATACESS - Data cessazione | [optional] 
**descrdep** | **String** | MG58_DESCRDEP - Descrizione | [optional] 
**dittaCg18** | **Number** | MG58_DITTA_CG18 - Ditta | [optional] [default to 0]
**faxnumdep** | **String** | MG58_FAXNUMDEP - Fax | [optional] 
**flgDepprinc** | **Number** | MG58_FLGDEPPRINC - Deposito principale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgDepprincEnum.0]
**indEmail** | **String** | MG58_INDEMAIL - Email | [optional] 
**indIdep** | **String** | MG58_INDIDEP - Indirizzo deposito | [optional] 
**indInterest** | **Number** | MG58_INDINTEREST - Tipo deposito&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Interno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Esterno&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndInterestEnum.0]
**locdep** | **String** | MG58_LOCDEP - Località | [optional] 
**provdep** | **String** | MG58_PROVDEP - Prov. | [optional] 
**respdep** | **String** | MG58_RESPDEP - Responsabile | [optional] 
**telnumdep** | **String** | MG58_TELNUMDEP - Telefono | [optional] 
**locationWH** | [**[LocationWHDTO]**](LocationWHDTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgDepprincEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndInterestEnum


* `0` (value: `0`)

* `1` (value: `1`)




