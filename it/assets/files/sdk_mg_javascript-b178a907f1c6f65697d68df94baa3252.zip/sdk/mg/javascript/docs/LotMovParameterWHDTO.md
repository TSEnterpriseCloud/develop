# TseCloudMg.LotMovParameterWHDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dittaCg18** | **Number** | MG4F_DITTA_CG18 - Ditta | [optional] [default to 0]
**flgAggprogval** | **Number** | MG4F_FLGAGGPROGVAL - Gestione progressivi di magazzino a valore | [optional] [default to 0]
**flgNote** | **Number** | MG4F_FLGNOTE - Gestione note | [optional] [default to 0]
**indGiacsca** | **Number** | MG4F_INDGIACSCA - Indicatore scarichi con giacenza negativa&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Non gestito&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Segnala se in scarico la giacenza è negativa (senza blocco)&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Blocco se in scarico la giacenza è negativa&lt;/li&gt;&lt;/ul&gt; | [optional] 
**prog** | **Number** | MG4F_PROG - Progressivo | 
**tipomov** | **String** | MG4F_TIPOMOV - Tipo movimento | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndGiacscaEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)




