# TseCloudMg.CarrierMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codice** | **String** | MG14_CODICE - Codice | 
**codiceCg16** | **Number** | MG14_CODICE_CG16 - Codice anagrafica generale | 
**flgSchetra** | **Number** | MG14_FLGSCHETRA - Soggetto a stampa scheda di trasporto | [optional] [default to 0]
**idmediaCg99** | **Number** | MG14_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**indPrefstdoc** | **Number** | MG14_INDPREFSTDOC - Stampa pref. documenti&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Stampa&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Fax&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Mail&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - PEC&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Pdf&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Nessuna preferenza&lt;/li&gt;&lt;/ul&gt; | [optional] 
**nralbotra** | **String** | MG14_NRALBOTRA - Nr. iscrizione albo autotrasportatori | [optional] 
**targa** | **String** | MG14_TARGA - Targa | [optional] 
**generalMasterDataCO** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndPrefstdocEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `4` (value: `4`)

* `5` (value: `5`)

* `3` (value: `3`)




