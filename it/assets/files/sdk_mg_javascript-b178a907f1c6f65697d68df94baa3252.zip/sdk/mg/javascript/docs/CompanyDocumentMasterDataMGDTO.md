# TseCloudMg.CompanyDocumentMasterDataMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codDocumMg36** | **String** | MG3G_CODDOCUM_MG36 - Codice documento | 
**dittaCg18** | **Number** | MG3G_DITTA_CG18 - Ditta | [optional] [default to 0]
**indStaperMg36** | **Number** | MG3G_INDSTAPER_MG36 - Indicatore standard/personalizzato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Standard&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Personalizzato&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndStaperMg36Enum.0]
**sezdefault** | **String** | MG3G_SEZDEFAULT - Sezionale default | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndStaperMg36Enum


* `0` (value: `0`)

* `1` (value: `1`)




