# TseCloudMg.CategoryCODTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categ** | **String** | MG11_CATEG - Categoria | 
**descrcat** | **String** | MG11_DESCRCAT - Descrizione | [optional] 
**dittaCg18** | **Number** | MG11_DITTA_CG18 - Ditta | [optional] [default to 0]
**macrocatMg10** | **String** | MG11_MACROCAT_MG10 - Macrocategoria | 
**tipocfMg10** | **Number** | MG11_TIPOCF_MG10 - Tipo Cli/For&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] [default to TipocfMg10Enum.0]
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: TipocfMg10Enum


* `0` (value: `0`)

* `1` (value: `1`)




