# TseCloudMg.DocumentoDatiAccompagnamentoMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codAspettoMg99** | **String** | DO14_CODASPETTO_MG99 - Codice aspetto dei beni | [optional] 
**codCautraspMg13** | **String** | DO14_CODCAUTRASP_MG13 - Codice causale di trasporto | [optional] 
**codImballoMg95** | **String** | DO14_CODIMBALLO_MG95 - Codice Imballo | [optional] 
**codPortoMg91** | **String** | DO14_CODPORTO_MG91 - Codice Porto | [optional] 
**codTipospedMg93** | **String** | DO14_CODTIPOSPED_MG93 - Codice tipo spedizione | [optional] 
**datainiztrasp** | **Date** | DO14_DATAINIZTRASP - Data inizio trasporto | [optional] 
**dataritvet1** | **Date** | DO14_DATARITVET1 - Data ritiro vettore 1 | [optional] 
**dataritvet2** | **Date** | DO14_DATARITVET2 - Data ritiro vettore 2 | [optional] 
**descaspetto** | **String** | DO14_DESCASPETTO - Descrizione Aspetto dei beni | [optional] 
**descrlettint** | **String** | DO14_DESCRLETTINT - Descrizione lettera di intento | [optional] 
**dittaCg18** | **Number** | DO14_DITTA_CG18 - Codice ditta | [optional] [default to 0]
**numregCo99** | **String** | DO14_NUMREG_CO99 - Numero registrazione | 
**orainiziotrasp** | **Number** | DO14_ORAINIZIOTRASP - Ora inizio trasporto | [optional] 
**oraritvet1** | **Number** | DO14_ORARITVET1 - Ora ritiro vettore 1 | [optional] 
**oraritvet2** | **Number** | DO14_ORARITVET2 - Ora ritiro vettore 2 | [optional] 
**pesolordo** | **Number** | DO14_PESOLORDO - Peso lordo totale | [optional] 
**pesonetto** | **Number** | DO14_PESONETTO - Peso netto totale | [optional] 
**spedizMg15** | **String** | DO14_SPEDIZ_MG15 - Codice Spedizioniere | [optional] 
**targarim1** | **String** | DO14_TARGARIM1 - Targa rimorchio vettore 1 | [optional] 
**targarim2** | **String** | DO14_TARGARIM2 - Targa rimorchio vettore 2 | [optional] 
**targavet1** | **String** | DO14_TARGAVET1 - Targa vettore 1 | [optional] 
**targavet2** | **String** | DO14_TARGAVET2 - Targa vettore 2 | [optional] 
**totcolli** | **Number** | DO14_TOTCOLLI - Totale colli | [optional] 
**umpeso** | **String** | DO14_UMPESO - UM Peso | [optional] 
**umvolume** | **String** | DO14_UMVOLUME - UM Volume | [optional] 
**vettore1Mg14** | **String** | DO14_VETTORE1_MG14 - Codice Vettore 1 | [optional] 
**vettore2Mg14** | **String** | DO14_VETTORE2_MG14 - Codice Vettore 2 | [optional] 
**volume** | **Number** | DO14_VOLUME - Totale volume | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


