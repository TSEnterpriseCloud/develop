# TseCloudMg.DocumentoRigaLottoMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**causmagMg51** | **Number** | DO52_CAUSMAG_MG51 - Causale magazzino | [optional] 
**cliforCg44** | **Number** | DO52_CLIFOR_CG44 - Codice Cliente / Fornitore | [optional] 
**codArtMg66** | **String** | DO52_CODART_MG66 - Codice Articolo | [optional] 
**codArtpfMg66** | **String** | DO52_CODARTPF_MG66 - Codice articolo prodotto finito | [optional] 
**codBagnomat** | **String** | DO52_CODBAGNOMAT - Bagno materiali | [optional] 
**codConfezMg96** | **String** | DO52_CODCONFEZ_MG96 - Codice confezione | [optional] 
**codDepMg58** | **String** | DO52_CODDEP_MG58 - Deposito | [optional] 
**codLottoMg4g** | **String** | DO52_CODLOTTO_MG4G - Codice Lotto | [optional] 
**codLottopfMg4g** | **String** | DO52_CODLOTTOPF_MG4G - Cod. Lotto P.F. | [optional] 
**codPallets** | **String** | DO52_CODPALLETS - Codice Pallets | [optional] 
**codProgPd14** | **String** | DO52_CODPROG_PD14 - CodProgPd14 | [optional] 
**codSscc** | **String** | DO52_CODSSCC - Codice SSCC | [optional] 
**dittaCg18** | **Number** | DO52_DITTA_CG18 - Ditta | [optional] [default to 0]
**flgNonpiuev** | **Number** | DO52_FLGNONPIUEV - Flag non più evadibile | [optional] [default to 0]
**idmediaCg99** | **Number** | DO52_IDMEDIA_CG99 - Hypermedia | [optional] 
**note** | **String** | DO52_NOTE - Note | [optional] 
**numregCo99** | **String** | DO52_NUMREG_CO99 - Numero registrazione | 
**numregrifCo99** | **String** | DO52_NUMREGRIF_CO99 - Numero documento di riferimento | [optional] 
**opzioneMg5e** | **String** | DO52_OPZIONE_MG5E - Variante | [optional] 
**opzionepfMg5e** | **String** | DO52_OPZIONEPF_MG5E - Variante Prod. Finito | [optional] 
**prog** | **Number** | DO52_PROG - Progressivo | [optional] [default to 1]
**progMg4f** | **Number** | DO52_PROG_MG4F - Configurazione Movimenti Lotti | 
**progRifDo52** | **Number** | DO52_PROGRIF_DO52 - Progrssivo riga lotti | [optional] 
**progRiga** | **Number** | DO52_PROGRIGA - Progressivo Riga | 
**progRigarifDo30** | **Number** | DO52_PROGRIGARIF_DO30 - Progressivo di riga nel documento di riferimento | [optional] 
**qta1** | **Number** | DO52_QTA1 -  Quantita&#39; 1 | [optional] 
**qta1cons** | **Number** | DO52_QTA1CONS - Quantità 1 consegnata | [optional] 
**qta2** | **Number** | DO52_QTA2 -  Quantita&#39; 2 | [optional] 
**qta2cons** | **Number** | DO52_QTA2CONS - Quantità 2 consegnata | [optional] 
**scadenza** | **Date** | DO52_SCADENZA - Scadenza | [optional] 
**sernum** | **String** | DO52_SERNUM - Serial Number | [optional] 
**sotprogPd14** | **Number** | DO52_SOTPROG_PD14 - SotprogPd14 | [optional] 
**tipocfCg44** | **Number** | DO52_TIPOCF_CG44 - Tipologia cliente/fornitore | [optional] 
**ubicazcollMg97** | **String** | DO52_UBICAZCOLL_MG97 - Ubicazione collegata | [optional] 
**ubicazMg97** | **String** | DO52_UBICAZ_MG97 - Ubicazione | [optional] 
**anagraficaLotto** | [**BatchDataWHDTO**](BatchDataWHDTO.md) |  | [optional] 
**parametroMovimentazioneLotto** | [**LotMovParameterWHDTO**](LotMovParameterWHDTO.md) |  | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


