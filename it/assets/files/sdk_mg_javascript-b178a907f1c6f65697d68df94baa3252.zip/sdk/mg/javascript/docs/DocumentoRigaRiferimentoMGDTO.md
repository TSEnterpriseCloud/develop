# TseCloudMg.DocumentoRigaRiferimentoMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**collimov** | **Number** | DO33_COLLIMOV - Colli movimentati | [optional] 
**datansconf** | **Date** | DO33_DATANSCONF - Data nostra conferma | [optional] 
**datansdoc** | **Date** | DO33_DATANSDOC - Data nostro documento | [optional] 
**datavsconf** | **Date** | DO33_DATAVSCONF - Data vostra conferma | [optional] 
**datavsdoc** | **Date** | DO33_DATAVSDOC - Data vostro documento | [optional] 
**dittaCg18** | **Number** | DO33_DITTA_CG18 - Ditta | [optional] [default to 0]
**fasePd12** | **Number** | DO33_FASE_PD12 - Fase di lavorazione | [optional] 
**flgAggprescvar** | **Number** | DO33_FLGAGGPRESCVAR - Aggiornamento prezzi e sconti variati su doc. origine&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgAggqtatrasf** | **Number** | DO33_FLGAGGQTATRASF - Aggiornamento quantità evasa/trasformata su documento origine&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgNonpiuevpdc** | **Number** | DO33_FLGNONPIUEVPDC - FlgNonpiuevpdc&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgNsdocbis** | **Number** | DO33_FLGNSDOCBIS - Flag bis ns documento | [optional] 
**flgStornoqtaval** | **Number** | DO33_FLGSTORNOQTAVAL - Storno le quantità evase/trasformate con la causale del documento origine&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indAggdocorigine** | **Number** | DO33_INDAGGDOCORIGINE - Modalità di aggiornamento documento di origine | [optional] [default to 0]
**indQtaordres** | **Number** | DO33_INDQTAORDRES - IndQtaordres | [optional] 
**indStipodoc** | **Number** | DO33_INDSTIPODOC - Indicatore sottotipo documento di riferimento | [optional] [default to 0]
**indTipodoc** | **Number** | DO33_INDTIPODOC - Indicatore tipo documento di riferimento | [optional] [default to 0]
**notensdoc** | **String** | DO33_NOTENSDOC - Note nostro documento | [optional] 
**notevsdoc** | **String** | DO33_NOTEVSDOC - Note vostro documento | [optional] 
**numnsdoc** | **Number** | DO33_NUMNSDOC - Numero nostro documento | [optional] 
**numregCo99** | **String** | DO33_NUMREG_CO99 - Numero registrazione | 
**numregpadreCo99** | **String** | DO33_NUMREGPADRE_CO99 - Documento origine/riga padre | [optional] 
**numregrifCo99** | **String** | DO33_NUMREGRIF_CO99 - Num. doc. rif. | [optional] 
**numvsdoc** | **String** | DO33_NUMVSDOC - Numero vostro documento | [optional] 
**progPdcDo65** | **Number** | DO33_PROGPDC_DO65 - Gestione progressivo righe ordini aperti | [optional] 
**progPdcrifDo65** | **Number** | DO33_PROGPDCRIF_DO65 - Gestione progr.righe ordini aperti | [optional] 
**progRif** | **Number** | DO33_PROGRIF - Progressivo di rif. | 
**progRiga** | **Number** | DO33_PROGRIGA - Progressivo Riga | 
**progRigapadreDo30** | **Number** | DO33_PROGRIGAPADRE_DO30 - Documento origine/riga padre | [optional] 
**progRigarifDo30** | **Number** | DO33_PROGRIGARIF_DO30 - Progressivo di riga nel documento di riferimento | [optional] 
**qta1mov** | **Number** | DO33_QTA1MOV - Quantità 1 movimentata | [optional] 
**qta2mov** | **Number** | DO33_QTA2MOV - Quantità 2 movimentata | [optional] 
**rifnsdoc** | **String** | DO33_RIFNSDOC - Riferimento nostro documento | [optional] 
**rifvsdoc** | **String** | DO33_RIFVSDOC - Riferimento vostro documento | [optional] 
**seqfase** | **Number** | DO33_SEQFASE - Sequenza fase | [optional] 
**seznsdoc** | **String** | DO33_SEZNSDOC - Sezionale nostro documento | [optional] 
**valoremov** | **Number** | DO33_VALOREMOV - Valore movimentato | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: FlgAggprescvarEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgAggqtatrasfEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgNonpiuevpdcEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgStornoqtavalEnum


* `0` (value: `0`)

* `1` (value: `1`)




