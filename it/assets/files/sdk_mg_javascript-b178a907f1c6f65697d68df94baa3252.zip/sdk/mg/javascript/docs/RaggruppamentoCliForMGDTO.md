# TseCloudMg.RaggruppamentoCliForMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cliforCg44** | **Number** | MG24_CLIFOR_CG44 - Codice Cliente / Fornitore | 
**codRag** | **String** | MG24_CODRAG - Codice raggruppamento | 
**descragg** | **String** | MG24_DESCRAGG - Descrizione raggruppamento | 
**dittaCg18** | **Number** | MG24_DITTA_CG18 - Ditta | [optional] [default to 0]
**idmediaCg99** | **Number** | MG24_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


