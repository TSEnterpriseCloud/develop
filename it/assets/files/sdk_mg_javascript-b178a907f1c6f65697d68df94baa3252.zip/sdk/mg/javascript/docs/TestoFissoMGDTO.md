# TseCloudMg.TestoFissoMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codice** | **String** | MG62_CODICE - Codice testo fisso | 
**datafineval** | **Date** | MG62_DATAFINEVAL - Data fine validità | [optional] 
**datainizioval** | **Date** | MG62_DATAINIZIOVAL - Data inizio validità | [optional] 
**descr** | **String** | MG62_DESCR - Descrizione | [optional] 
**idmediaCg99** | **Number** | MG62_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**idprov** | **Number** | MG62_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**indTipoevas** | **Number** | MG62_INDTIPOEVAS - Tipo trasf. doc.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si trasformazione, solo la 1^ volta in automatico&lt;/li&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No trasformazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Si trasformazione, sempre in automatico&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Si trasformazione, solo la 1^ volta con conferma manuale&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Si trasformazione, sempre con conferma manuale&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Si trasformazione, se trasformata riga di riferimento&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndTipoevasEnum.1]
**testo** | **String** | MG62_TESTO - Testo | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: IndTipoevasEnum


* `1` (value: `1`)

* `0` (value: `0`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)




