# TseCloudMg.DocumentoTestataRateiMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**adatacomp** | **Date** | DO23_ADATACOMP - A data competenza | [optional] 
**contopar** | **String** | DO23_CONTOPAR - Conto contropartita | [optional] 
**dadatacomp** | **Date** | DO23_DADATACOMP - Da data competenza | [optional] 
**datacompivaman** | **Date** | DO23_DATACOMPIVAMAN - Data competenza IVA manuale | [optional] 
**dataregesinc** | **Date** | DO23_DATAREGESINC - Data registrazione rateo esercizio corrente | [optional] 
**dataregesprec** | **Date** | DO23_DATAREGESPREC - Data registrazione rateo esercizio precedente | [optional] 
**dittaCg18** | **Number** | DO23_DITTA_CG18 - Codice ditta | [optional] [default to 0]
**flgDaav** | **Number** | DO23_FLGDAAV - Indicatore Dare/Avere | [optional] [default to 0]
**flgDisatcoge** | **Number** | DO23_FLGDISATCOGE - FlgDisatcoge | [optional] [default to 0]
**indTipocomp** | **Number** | DO23_INDTIPOCOMP - Indicatore tipo competenza | [optional] [default to 0]
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


