# TseCloudMg.CustSuppClassificationMGDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**areaMGnielsenMg0e** | **String** | MG19_AREANIELSEN_MG0E - Area Nielsen | [optional] 
**art62txt** | **String** | MG19_ART62TXT - Estremi / dati del contratto | [optional] 
**cliforCg44** | **Number** | MG19_CLIFOR_CG44 - Codice cliente | 
**coddestprev** | **String** | MG19_CODDESTPREV - Codice destinatario prevalente per i documenti | [optional] 
**coddocumMg3g** | **String** | MG19_CODDOCUM_MG3G - Codice documento prevalente | [optional] 
**codprevragb** | **String** | MG19_CODPREVRAGB - Codice raggruppamento prevalente | [optional] 
**codrifalf** | **String** | MG19_CODRIFALF - Codice di riferimento alfanumerico | [optional] 
**codrifnum** | **Number** | MG19_CODRIFNUM - Codice di riferimento numerico | [optional] 
**datablocco** | **Date** | MG19_DATABLOCCO - Data dell&#39;attivazione del blocco | [optional] 
**datacreaz** | **Date** | MG19_DATACREAZ - Data creazione | 
**datadismis** | **Date** | MG19_DATADISMIS - Data dismissione | [optional] 
**datarischio** | **Date** | MG19_DATARISCHIO - Data dell&#39;attivazione controllo rischio | [optional] 
**dataultcalsp** | **Date** | MG19_DATAULTCALSP - Data emissione ultimo calcolo bolli e spese incasso del cliente/fornitore | [optional] 
**dataultdoc** | **Date** | MG19_DATAULTDOC - Data emissione ultimo documento non fattura | [optional] 
**dataultfat** | **Date** | MG19_DATAULTFAT - Data emissione ultima fattura del cliente/fornitore | [optional] 
**dataultord** | **Date** | MG19_DATAULTORD - Data emissione ultimo ordine del cliente/fornitore | [optional] 
**dataultvar** | **Date** | MG19_DATAULTVAR - Data ultima variazione | 
**dittaCg18** | **Number** | MG19_DITTA_CG18 - Ditta | [optional] [default to 0]
**fidoaziendale** | **Number** | MG19_FIDOAZIENDALE - Fido aziendale | [optional] 
**fidofactoring** | **Number** | MG19_FIDOFACTORING - Importo fido assicurazione credito | [optional] 
**fidolivello1** | **Number** | MG19_FIDOLIVELLO1 - Fido liv. 1 | [optional] 
**fidolivello2** | **Number** | MG19_FIDOLIVELLO2 - Fido liv.2 | [optional] 
**flgart62ctr** | **Number** | MG19_FLGART62CTR - Contratto stipulato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgdaticlfat** | **Number** | MG19_FLGDATICLFAT - Util. dati cliente x fatturazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgesclspepor** | **Number** | MG19_FLGESCLSPEPOR - Flag di esclusione delle spese indicate nel porto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgEstrpayline** | **Number** | MG19_FLGESTRPAYLINE - Estrazione Payline&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgEstrpaylineEnum.0]
**flgprzcamp** | **Number** | MG19_FLGPRZCAMP - Listini campagna&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Nessuna&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Tutte&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Da elenco&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgqualita** | **Number** | MG19_FLGQUALITA - Soggetto a controllo qualità&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgrottcig** | **Number** | MG19_FLGROTTCIG - Flag rottura CIG (codice identificativo di gara)&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgrottsingdoc** | **Number** | MG19_FLGROTTSINGDOC - Genera unico documento per ogni documento origine elaborato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**flgspbol** | **Number** | MG19_FLGSPBOL - Spese bolli&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgspbolEnum.0]
**flgspeinc** | **Number** | MG19_FLGSPEINC - Spese incasso&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgspeincEnum.0]
**flgTaxliable** | **Number** | MG19_FLGTAXLIABLE - Tax Liable&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to FlgTaxliableEnum.0]
**ggcons** | **Number** | MG19_GGCONS - Giorni consegna | [optional] 
**idmediaCg99** | **Number** | MG19_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**imparrotprec** | **Number** | MG19_IMPARROTPREC - Importo arrotondamento precedente | [optional] 
**impdaarrot** | **Number** | MG19_IMPDAARROT - Importo da arrotondare | [optional] 
**indarrinfat** | **Number** | MG19_INDARRINFAT - Indicatore arrotondamento fatture&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessun arrotondamento&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Matematico&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Limite superiore&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Limite inferiore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indarrl96** | **Number** | MG19_INDARRL96 - Arrotondamento legge 96&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;li&gt;&lt;i&gt;99&lt;/i&gt; - Come personalizzazione azienda&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indclibloc** | **Number** | MG19_INDCLIBLOC - Tipo blocco&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Blocco con possibilità di sblocco&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Blocco senza possibilità di sblocco&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndcliblocEnum.0]
**indclifat** | **Number** | MG19_INDCLIFAT - Tipo conversione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuna&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - In fatturazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - In fase di registrazione contabile&lt;/li&gt;&lt;/ul&gt; | [optional] 
**inddesdocest** | **Number** | MG19_INDDESDOCEST - Stampa descrizione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Descrizione base&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Descrizione base in lingua&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Entrambe le descrizioni&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indFattper** | **Number** | MG19_INDFATTPER - Periodicità di fatturazione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Non definito&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Mensile&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Quindicinale&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Settimanale&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indgesfido** | **Number** | MG19_INDGESFIDO - Indicatore gestione fido&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Come pers. documenti&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - No controllo fido&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Si controllo fido&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indgiorni** | **Number** | MG19_INDGIORNI - Modalità di gestione giorni di consegna&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Dato informativo&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Sostituiscono i giorni dell&#39;articolo&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; -  Sommano ai giorni dell&#39;articolo&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indprefstdoc** | **Number** | MG19_INDPREFSTDOC - Stampa pref. documento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Stampa&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Fax&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Mail&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - Nessuna preferenza&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - PEC&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - Pdf&lt;/li&gt;&lt;li&gt;&lt;i&gt;10&lt;/i&gt; - Da param. generali&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indrottcig** | **Number** | MG19_INDROTTCIG - Indrottcig | [optional] [default to 0]
**indspesecum** | **Number** | MG19_INDSPESECUM - Cumulo sp.bolli/incasso&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - mensili&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - quindicina&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - decade&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - settimana&lt;/li&gt;&lt;li&gt;&lt;i&gt;5&lt;/i&gt; - giorno&lt;/li&gt;&lt;/ul&gt; | [optional] [default to IndspesecumEnum.0]
**indstscadest** | **Number** | MG19_INDSTSCADEST - Stampa scadenze | [optional] 
**indtestof1** | **Number** | MG19_INDTESTOF1 - Indicatore testo fisso 1&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Domanda se inserirlo&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - In automatico all&#39;inizio del corpo documenti&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - In automatico alla fine del corpo documenti&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - In testata dei documenti&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Nel piede dei documenti&lt;/li&gt;&lt;/ul&gt; | [optional] 
**indtestof2** | **String** | MG19_INDTESTOF2 - Indicatore testo fisso 2&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Domanda se inserirlo&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - In automatico all&#39;inizio del corpo documenti&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - In automatico alla fine del corpo documenti&lt;/li&gt;&lt;li&gt;&lt;i&gt;3&lt;/i&gt; - In testata dei documenti&lt;/li&gt;&lt;li&gt;&lt;i&gt;4&lt;/i&gt; - Nel piede dei documenti&lt;/li&gt;&lt;/ul&gt; | [optional] [default to &#39;0&#39;]
**irs1099** | **String** | MG19_IRS1099 - IRSS1099 Code | [optional] 
**lastchange** | **Date** | MG19_LASTCHANGE - Data ultima variazione | [optional] 
**listmag** | **Number** | MG19_LISTMAG - Numero listino di magazzino utilizzato | [optional] 
**magimpcor** | **Number** | MG19_MAGIMPCOR - Magg. importo | [optional] 
**magpercor** | **Number** | MG19_MAGPERCOR - Maggiorazione % | [optional] 
**notebloc** | **String** | MG19_NOTEBLOC - Note blocco | [optional] 
**sc1percor** | **Number** | MG19_SC1PERCOR - Sconto % 1 | [optional] 
**sc2percor** | **Number** | MG19_SC2PERCOR - Sconto % 2 | [optional] 
**sc3percor** | **Number** | MG19_SC3PERCOR - Sconto % 3 | [optional] 
**scaglspbanc** | **Number** | MG19_SCAGLSPBANC - Codice della tabella bolli e spese incasso | [optional] 
**scimpcor** | **Number** | MG19_SCIMPCOR - Sconto importo | [optional] 
**scperpiede** | **Number** | MG19_SCPERPIEDE - % Sconto piede | [optional] 
**taxexemptionno** | **String** | MG19_TAXEXEMPTIONNO - USA-numero esenzione sales tax | [optional] 
**tipocfCg44** | **Number** | MG19_TIPOCF_CG44 - Tipo Cliente/ Fornitore | 
**tipoclxdoc** | **Number** | MG19_TIPOCLXDOC - Cl. x doc.&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Italia&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Estero&lt;/li&gt;&lt;/ul&gt; | [optional] 
**areaCO** | [**AreaCODTO**](AreaCODTO.md) |  | [optional] 
**blockLevelCO** | [**BlockLevelCODTO**](BlockLevelCODTO.md) |  | [optional] 
**categoryCO** | [**CategoryCODTO**](CategoryCODTO.md) |  | [optional] 
**cliForFatturazione** | [**CustomerSupplierMGDTO**](CustomerSupplierMGDTO.md) |  | [optional] 
**datiAccompagnamento** | [**CliForDatiAccompagnamentoMGDTO**](CliForDatiAccompagnamentoMGDTO.md) |  | [optional] 
**fixedExp1** | [**SpesaVariaMGDTO**](SpesaVariaMGDTO.md) |  | [optional] 
**fixedExp2** | [**SpesaVariaMGDTO**](SpesaVariaMGDTO.md) |  | [optional] 
**fixedText1** | [**TestoFissoMGDTO**](TestoFissoMGDTO.md) |  | [optional] 
**fixedText2** | [**TestoFissoMGDTO**](TestoFissoMGDTO.md) |  | [optional] 
**grouping1CO** | [**Grouping1CODTO**](Grouping1CODTO.md) |  | [optional] 
**grouping2CO** | [**Grouping2CODTO**](Grouping2CODTO.md) |  | [optional] 
**grouping3CO** | [**Grouping3CODTO**](Grouping3CODTO.md) |  | [optional] 
**language** | [**LanguageCODTO**](LanguageCODTO.md) |  | [optional] 
**macAreaCO** | [**MacroAreaCODTO**](MacroAreaCODTO.md) |  | [optional] 
**macroCategoryCO** | [**MacroCategoryCODTO**](MacroCategoryCODTO.md) |  | [optional] 
**priceListSalePurchase** | [**SalePurchasePriceListCodeMGDTO**](SalePurchasePriceListCodeMGDTO.md) |  | [optional] 
**priceListWithMultipleItems** | [**PriceListWithMultipleItemsMGDTO**](PriceListWithMultipleItemsMGDTO.md) |  | [optional] 
**raggruppamentoPrevalente** | [**RaggruppamentoCliForMGDTO**](RaggruppamentoCliForMGDTO.md) |  | [optional] 
**rischio** | [**RiskMGDTO**](RiskMGDTO.md) |  | [optional] 
**subCategoryCO** | [**SubCategoryCODTO**](SubCategoryCODTO.md) |  | [optional] 
**zoneCO** | [**ZoneCODTO**](ZoneCODTO.md) |  | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 



## Enum: Flgart62ctrEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgdaticlfatEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgesclspeporEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgEstrpaylineEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgprzcampEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: FlgqualitaEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgrottcigEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgrottsingdocEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgspbolEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgspeincEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: FlgTaxliableEnum


* `0` (value: `0`)

* `1` (value: `1`)





## Enum: IndarrinfatEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: Indarrl96Enum


* `0` (value: `0`)

* `1` (value: `1`)

* `99` (value: `99`)





## Enum: IndcliblocEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndclifatEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: InddesdocestEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndFattperEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)





## Enum: IndgesfidoEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndgiorniEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)





## Enum: IndprefstdocEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)

* `10` (value: `10`)





## Enum: IndspesecumEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)





## Enum: Indtestof1Enum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)





## Enum: Indtestof2Enum


* `TeamSystem.AlyCE.Services.Common.Attributes.RangeValueDescription` (value: `"TeamSystem.AlyCE.Services.Common.Attributes.RangeValueDescription"`)

* `TeamSystem.AlyCE.Services.Common.Attributes.RangeValueDescription2` (value: `"TeamSystem.AlyCE.Services.Common.Attributes.RangeValueDescription"`)

* `TeamSystem.AlyCE.Services.Common.Attributes.RangeValueDescription3` (value: `"TeamSystem.AlyCE.Services.Common.Attributes.RangeValueDescription"`)

* `TeamSystem.AlyCE.Services.Common.Attributes.RangeValueDescription4` (value: `"TeamSystem.AlyCE.Services.Common.Attributes.RangeValueDescription"`)

* `TeamSystem.AlyCE.Services.Common.Attributes.RangeValueDescription5` (value: `"TeamSystem.AlyCE.Services.Common.Attributes.RangeValueDescription"`)





## Enum: TipoclxdocEnum


* `0` (value: `0`)

* `1` (value: `1`)




