# TseCloudFw.FileListEditPathResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**files** | **[String]** | List of files | [optional] 


