# TseCloudFw.GetEditPathParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**asAttachment** | **Boolean** | Download as attachment | [optional] 
**deleteAfter** | **Boolean** | Delete after download | [optional] 
**filename** | **String** | File name | 
**fixedPathType** | **String** | Fixed path type (only UserFileTemp value managed) | [optional] [default to &#39;UserFileTemp&#39;]
**relativePath** | **String** | Relative path | [optional] 


