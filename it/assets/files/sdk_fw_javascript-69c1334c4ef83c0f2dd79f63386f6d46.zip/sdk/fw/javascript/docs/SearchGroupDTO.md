# TseCloudFw.SearchGroupDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**[OneOfSearchNodeDTOSearchElementDTOSearchGroupDTO]**](OneOfSearchNodeDTOSearchElementDTOSearchGroupDTO.md) | Items list to apply: any element can be a &#39;SearchGroupDTO&#39; or a &#39;SearchElementDTO&#39; | [optional] 
**operator** | [**SearchLogicalOperators**](SearchLogicalOperators.md) |  | [optional] 


