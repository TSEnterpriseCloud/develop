# TseCloudFw.EditPathFWApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiV1EnvironmentFWEditPathFWGetfilePost**](EditPathFWApi.md#apiV1EnvironmentFWEditPathFWGetfilePost) | **POST** /api/v1/{environment}/FW/EditPathFW/getfile | Get a file from Edit Path
[**apiV1EnvironmentFWEditPathFWGetfilelistPost**](EditPathFWApi.md#apiV1EnvironmentFWEditPathFWGetfilelistPost) | **POST** /api/v1/{environment}/FW/EditPathFW/getfilelist | Get file list from Edit Path
[**apiV1EnvironmentFWEditPathFWRemovefilePost**](EditPathFWApi.md#apiV1EnvironmentFWEditPathFWRemovefilePost) | **POST** /api/v1/{environment}/FW/EditPathFW/removefile | Remove a file Edit Path for error
[**apiV1EnvironmentFWEditPathFWUploadfilePost**](EditPathFWApi.md#apiV1EnvironmentFWEditPathFWUploadfilePost) | **POST** /api/v1/{environment}/FW/EditPathFW/uploadfile | Upload a file to Edit Path



## apiV1EnvironmentFWEditPathFWGetfilePost

> apiV1EnvironmentFWEditPathFWGetfilePost(environment, authorizationScope, opts)

Get a file from Edit Path

### Example

```javascript
import TseCloudFw from 'tse_cloud_fw';
let defaultClient = TseCloudFw.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFw.EditPathFWApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'", // String | Example for multilanguage
  'getEditPathParamsDTO': new TseCloudFw.GetEditPathParamsDTO() // GetEditPathParamsDTO | 
};
apiInstance.apiV1EnvironmentFWEditPathFWGetfilePost(environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]
 **getEditPathParamsDTO** | [**GetEditPathParamsDTO**](GetEditPathParamsDTO.md)|  | [optional] 

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined


## apiV1EnvironmentFWEditPathFWGetfilelistPost

> FileListEditPathResultDTO apiV1EnvironmentFWEditPathFWGetfilelistPost(environment, authorizationScope, opts)

Get file list from Edit Path

### Example

```javascript
import TseCloudFw from 'tse_cloud_fw';
let defaultClient = TseCloudFw.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFw.EditPathFWApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'", // String | Example for multilanguage
  'fileListEditPathParamsDTO': new TseCloudFw.FileListEditPathParamsDTO() // FileListEditPathParamsDTO | 
};
apiInstance.apiV1EnvironmentFWEditPathFWGetfilelistPost(environment, authorizationScope, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]
 **fileListEditPathParamsDTO** | [**FileListEditPathParamsDTO**](FileListEditPathParamsDTO.md)|  | [optional] 

### Return type

[**FileListEditPathResultDTO**](FileListEditPathResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: application/json, application/xml


## apiV1EnvironmentFWEditPathFWRemovefilePost

> apiV1EnvironmentFWEditPathFWRemovefilePost(environment, authorizationScope, fileEditPathParamsDTO, opts)

Remove a file Edit Path for error

### Example

```javascript
import TseCloudFw from 'tse_cloud_fw';
let defaultClient = TseCloudFw.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFw.EditPathFWApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let fileEditPathParamsDTO = new TseCloudFw.FileEditPathParamsDTO(); // FileEditPathParamsDTO | Input parameters
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'" // String | Example for multilanguage
};
apiInstance.apiV1EnvironmentFWEditPathFWRemovefilePost(environment, authorizationScope, fileEditPathParamsDTO, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **fileEditPathParamsDTO** | [**FileEditPathParamsDTO**](FileEditPathParamsDTO.md)| Input parameters | 
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: application/json, application/xml
- **Accept**: Not defined


## apiV1EnvironmentFWEditPathFWUploadfilePost

> apiV1EnvironmentFWEditPathFWUploadfilePost(environment, authorizationScope, file, fixedPathType, opts)

Upload a file to Edit Path

### Example

```javascript
import TseCloudFw from 'tse_cloud_fw';
let defaultClient = TseCloudFw.ApiClient.instance;
// Configure HTTP basic authorization: Basic
let Basic = defaultClient.authentications['Basic'];
Basic.username = 'YOUR USERNAME';
Basic.password = 'YOUR PASSWORD';
// Configure Bearer (JWT) access token for authorization: Bearer
let Bearer = defaultClient.authentications['Bearer'];
Bearer.accessToken = "YOUR ACCESS TOKEN"

let apiInstance = new TseCloudFw.EditPathFWApi();
let environment = "environment_example"; // String | 
let authorizationScope = "authorizationScope_example"; // String | The environment where this operation will be executed. This must match with the environment in the url.
let file = "/path/to/file"; // File | File to upload
let fixedPathType = "'UserFileTemp'"; // String | Fixed path type (only UserFileTemp value managed)
let opts = {
  'company': "company_example", // String | Company code
  'user': "user_example", // String | Application user (mandatory if the WebApi user does not have any mapped application user)
  'acceptLanguage': "'it-IT'", // String | Example for multilanguage
  'relativePath': "relativePath_example" // String | Relative path
};
apiInstance.apiV1EnvironmentFWEditPathFWUploadfilePost(environment, authorizationScope, file, fixedPathType, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **environment** | **String**|  | 
 **authorizationScope** | **String**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **file** | **File**| File to upload | 
 **fixedPathType** | **String**| Fixed path type (only UserFileTemp value managed) | [default to &#39;UserFileTemp&#39;]
 **company** | **String**| Company code | [optional] 
 **user** | **String**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **String**| Example for multilanguage | [optional] [default to &#39;it-IT&#39;]
 **relativePath** | **String**| Relative path | [optional] 

### Return type

null (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

- **Content-Type**: multipart/form-data
- **Accept**: Not defined

