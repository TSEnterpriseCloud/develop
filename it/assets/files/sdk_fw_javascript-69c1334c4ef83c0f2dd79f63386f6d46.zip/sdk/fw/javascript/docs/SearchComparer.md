# TseCloudFw.SearchComparer

## Enum


* `0` (value: `0`)

* `1` (value: `1`)

* `10` (value: `10`)

* `11` (value: `11`)

* `12` (value: `12`)

* `13` (value: `13`)

* `20` (value: `20`)

* `21` (value: `21`)

* `30` (value: `30`)

* `40` (value: `40`)

* `50` (value: `50`)

* `51` (value: `51`)

* `60` (value: `60`)

* `61` (value: `61`)

* `70` (value: `70`)

* `71` (value: `71`)


