# TseCloudFw.AsyncSchedulerFWDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**additionalinfo** | **String** | AdditionalInfo - Informazioni aggiuntive | [optional] 
**cronexpr** | **String** | CronExpr - Frequenza | 
**enddatetimeutc** | **Date** | EndDateTimeUtc - Data fine | [optional] 
**id** | **Number** | Id - Id processo (Required only in PUT/PATCH) | [optional] 
**idoperation** | **String** | IdOperation - Id operazione | 
**isDisabled** | **Boolean** | IsDisabled - Disabilitato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to false]
**lastexecutionutc** | **Date** | LastExecutionUtc - Ultima esecuzione | [optional] 
**nextexecutionutc** | **Date** | NextExecutionUtc - Prossima esecuzione | [optional] 
**serializedParameter** | **String** | SerializedParameter - Parametri di elaborazione | [optional] 
**startdatetimeutc** | **Date** | StartDateTimeUtc - Data inizio | 
**withcompany** | **Boolean** | WithCompany - per azienda | [optional] 
**asyncCatalogFW** | [**AsyncCatalogFWDTO**](AsyncCatalogFWDTO.md) |  | 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


