# TseCloudFw.FileEditPathParamsDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filename** | **String** | File name | 
**fixedPathType** | **String** | Fixed path type (only UserFileTemp value managed) | [optional] [default to &#39;UserFileTemp&#39;]
**relativePath** | **String** | Relative path | [optional] 


