# TseCloudFw.AsyncCatalogFWDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**assemblyname** | **String** | AssemblyName - Assemblyname | 
**classname** | **String** | ClassName - Classname | 
**descriptionid** | **Number** | DescriptionId - Descriptionid | [optional] 
**detaillifehours** | **Number** | DetailLifeHours - Detaillifehours | [optional] [default to 0]
**groupname** | **String** | GroupName - Groupname | 
**idoperation** | **String** | IdOperation - Id operazione | 
**isSchedulable** | **Boolean** | IsSchedulable - IsSchedulable | 
**rowversion** | **Blob** | RowVersion - RowVersion | [optional] 
**extensionData** | [**[StringObjectKeyValuePair]**](StringObjectKeyValuePair.md) |  | [optional] 
**additionalData** | **{String: Object}** |  | [optional] 


